package com.zarvimo.cricket.feed

import java.util.Locale

/** HTML to plain lines (table rows keep a TAB between their cells) plus the page title / meta tags. */
internal object HtmlText {

    fun decode(s: String): String {
        var t = s.replace("&nbsp;", " ").replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
            .replace("&apos;", "'").replace("&lt;", "<").replace("&gt;", ">").replace("&#x27;", "'").replace("&ndash;", "-")
        t = Regex("&#(\\d{1,5});").replace(t) { m ->
            val cp = m.groupValues[1].toIntOrNull()
            if (cp == null) m.value else String(Character.toChars(cp))
        }
        return t
    }

    fun toLines(html: String): List<String> {
        var s = html
        s = s.replace(Regex("(?is)<(script|style|noscript|svg|head)\\b[^>]*>.*?</\\1>"), " ")
        s = s.replace(Regex("(?i)<br\\s*/?>"), "\n")
        s = s.replace(Regex("(?i)</(p|div|li|tr|h[1-6]|section|article|table|ul|ol|header|footer|tbody|thead|span)>"), "\n")
        s = s.replace(Regex("(?i)</(td|th)>"), "\t")
        s = s.replace(Regex("<[^>]+>"), " ")
        s = decode(s)
        val out = ArrayList<String>()
        for (raw in s.split('\n')) {
            val cells = raw.split('\t').map { it.replace(Regex("[\\s\u00A0]+"), " ").trim() }.filter { it.isNotEmpty() }
            if (cells.isEmpty()) continue
            out.add(cells.joinToString("\t"))
        }
        return out
    }

    fun titleOf(html: String): String =
        Regex("(?is)<title[^>]*>(.*?)</title>").find(html)?.groupValues?.get(1)?.let { decode(it).trim() } ?: ""

    fun metaOf(html: String, key: String): String {
        val k = Regex.escape(key)
        val a = Regex("(?is)<meta[^>]+(?:property|name)\\s*=\\s*[\"']$k[\"'][^>]*?content\\s*=\\s*[\"']([^\"']*)[\"']").find(html)
        if (a != null) return decode(a.groupValues[1]).trim()
        val b = Regex("(?is)<meta[^>]+content\\s*=\\s*[\"']([^\"']*)[\"'][^>]*?(?:property|name)\\s*=\\s*[\"']$k[\"']").find(html)
        return if (b != null) decode(b.groupValues[1]).trim() else ""
    }
}

/**
 * Last-resort reader for pages that have no usable JSON: finds score headers ("Pakistan 158/5 (18.4 Ov)") and
 * batting / bowling rows (a name followed by numbers) in the page text. Every row is checked arithmetically
 * (strike rate = runs / balls, economy = runs / overs) so ordinary page text is not mistaken for a scorecard.
 */
internal object TextMatchExtractor {

    private val NUM = Regex("^\\d+(?:\\.\\d+)?\$")
    private val SCORE = Regex(
        "([A-Za-z][A-Za-z .&'-]{1,35}?)\\s*(?:\\d(?:st|nd|rd|th)\\s+(?i:inn(?:ings)?)\\s*)?[:\\-]?\\s*(\\d{1,4})\\s*(?:[/-]\\s*(\\d{1,2}))?\\s*(d|dec)?\\s*\\(\\s*(\\d{1,3}(?:\\.\\d)?)\\s*((?i:ov|overs?))?"
    )
    private val SCORE_ONLY = Regex("^(\\d{1,4})\\s*[/-]\\s*(\\d{1,2})\\s*\\(\\s*(\\d{1,3}(?:\\.\\d)?)\\s*(?:ov|overs?)?")
    private val DISMISSAL_AT = Regex("^(?:(?i:not out|batting|lbw|run out|retired|hit wicket|absent|timed out|obstructing|handled the ball|hit the ball)|c |b |st |c&b|c & b)")
    private val SKIP_NAME = Regex("(?i)^(extras|total|batting|bowling|batter|batsman|bowler|fall of|yet to|did not|partnership|innings|overs|score)\\b.*")
    private val TOTAL_WORDS = setOf("total", "tot", "score", "innings", "runs")

    private class Cand(val name: String, val dismissal: String, val nums: List<String>)

    private class Hdr(val team: String, val runs: Int?, val wickets: Int?, val overs: String, val declared: Boolean)

    private class Builder(var team: String, var runs: Int?, var wickets: Int?, var overs: String) {
        val batters = ArrayList<FeedBatter>()
        val bowlers = ArrayList<FeedBowler>()
        var extras = ""
        val fow = ArrayList<String>()
        var yet: List<String> = emptyList()
        var declared = false
        var sawBowler = false
        val hasRows: Boolean get() = batters.isNotEmpty() || bowlers.isNotEmpty()
    }

    private fun headerOf(line: String, prev: String): Hdr? {
        if (line.length > 100) return null
        val flat = line.replace('\t', ' ')
        val m = SCORE.find(flat)
        if (m != null && m.range.first == 0) {
            val runs = m.groupValues[2].toIntOrNull()
            val wk = if (m.groupValues[3].isEmpty()) null else m.groupValues[3].toIntOrNull()
            val ov = m.groupValues[5]
            val hasUnit = m.groupValues[6].isNotEmpty()
            val ovInt = ov.substringBefore('.').toIntOrNull() ?: 999
            if (runs != null && runs <= 999 && (wk == null || wk <= 10) && ovInt <= 500 && (wk != null || hasUnit)) {
                return Hdr(cleanTeamName(m.groupValues[1].trim()), runs, wk, ov, m.groupValues[4].isNotEmpty())
            }
        }
        val s = SCORE_ONLY.find(flat)
        if (s != null && prev.isNotBlank() && prev.length <= 40 && prev.any { it.isLetter() } && !prev.contains('\t') && prev.none { it.isDigit() }) {
            val runs = s.groupValues[1].toIntOrNull()
            val wk = s.groupValues[2].toIntOrNull()
            if (runs != null && wk != null && wk <= 10) return Hdr(cleanTeamName(prev.trim()), runs, wk, s.groupValues[3], false)
        }
        return null
    }

    private fun looksLikeName(s: String): Boolean {
        val t = s.trim()
        if (t.length < 2 || t.length > 45) return false
        if (!t.any { it.isLetter() }) return false
        if (SKIP_NAME.matches(t)) return false
        return true
    }

    private fun splitNameAndDismissal(text: String): Pair<String, String> {
        val tokens = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        for (i in 1 until tokens.size) {
            val rest = tokens.subList(i, tokens.size).joinToString(" ")
            if (DISMISSAL_AT.containsMatchIn(rest) && DISMISSAL_AT.find(rest)?.range?.first == 0) {
                return Pair(tokens.subList(0, i).joinToString(" "), rest)
            }
        }
        return Pair(text.trim(), "")
    }

    /** A name followed by at least five numbers on ONE line (a table row, tab separated or flattened). */
    private fun inlineCand(line: String): Cand? {
        val cells: List<String> =
            if (line.contains('\t')) line.split('\t').map { it.trim() }.filter { it.isNotEmpty() }
            else line.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (cells.size < 6) return null
        var i = cells.size
        while (i > 0 && NUM.matches(cells[i - 1])) i--
        val nums = cells.subList(i, cells.size)
        if (nums.size < 5 || i == 0) return null
        val text = cells.subList(0, i).joinToString(" ")
        val nd = splitNameAndDismissal(text)
        if (!looksLikeName(nd.first)) return null
        return Cand(nd.first, nd.second, nums)
    }

    private fun asBatter(c: Cand): FeedBatter? {
        val n = c.nums
        if (n.size < 5 || n.size > 6) return null
        val r = n[0].toIntOrNull() ?: return null
        val b = n[1].toIntOrNull() ?: return null
        val sixes = n[n.size - 2].toIntOrNull() ?: return null
        val fours = n[n.size - 3].toIntOrNull() ?: return null
        val sr = n[n.size - 1].toDoubleOrNull() ?: return null
        if (r > 500 || b > 800) return null
        if (b > 0) {
            if (Math.abs(sr - r * 100.0 / b) > 1.0) return null
        } else if (sr != 0.0) {
            return null
        }
        if (fours * 4 + sixes * 6 > r) return null
        val dis = c.dismissal
        val notOut = dis.isBlank() || dis.lowercase(Locale.ROOT).contains("not out") || dis.lowercase(Locale.ROOT) == "batting"
        return FeedBatter(Jx.cleanName(c.name), r, b, fours, sixes, n[n.size - 1], if (dis.isBlank() && notOut) "not out" else dis, notOut, c.name.trim().endsWith("*"))
    }

    private fun asBowler(c: Cand): FeedBowler? {
        val n = c.nums
        if (n.size < 5) return null
        val ov = n[0]
        val balls = CricketMath.ballsOf(ov) ?: return null
        val m = n[1].toIntOrNull() ?: return null
        val r = n[2].toIntOrNull() ?: return null
        val w = n[3].toIntOrNull() ?: return null
        val e = n[4].toDoubleOrNull() ?: return null
        if (balls == 0 || w > 10 || m > (balls + 5) / 6 || r > 400) return null
        if (Math.abs(e - r * 6.0 / balls) > 0.2) return null
        if (c.dismissal.isNotBlank()) return null
        return FeedBowler(Jx.cleanName(c.name), ov, m, r, w, n[4], false)
    }

    private fun sameInnings(a: Builder, b: Builder): Boolean {
        if (a.team.isBlank() || b.team.isBlank()) return false
        if (!TeamNames.same(a.team, b.team)) return false
        val ra = a.runs
        val rb = b.runs
        return ra == null || rb == null || ra == rb
    }

    private fun absorb(into: Builder, from: Builder) {
        if (from.team.length > into.team.length) into.team = from.team
        if (into.runs == null) { into.runs = from.runs; into.wickets = from.wickets }
        if (into.overs.isEmpty()) into.overs = from.overs
        if (into.batters.isEmpty()) into.batters.addAll(from.batters)
        if (into.bowlers.isEmpty()) into.bowlers.addAll(from.bowlers)
        if (into.extras.isEmpty()) into.extras = from.extras
        if (into.fow.isEmpty()) into.fow.addAll(from.fow)
        if (into.yet.isEmpty()) into.yet = from.yet
        if (from.declared) into.declared = true
    }

    fun extract(lines: List<String>, pageTitle: String): FeedMatch? {
        val builders = ArrayList<Builder>()
        var cur: Builder? = null
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            val flat = line.replace('\t', ' ')

            // ---- score header / total line
            val hdr = headerOf(line, if (i > 0) lines[i - 1] else "")
            if (hdr != null) {
                val b = cur
                val isTotal = hdr.team.trim().lowercase(Locale.ROOT) in TOTAL_WORDS
                if (isTotal) {
                    if (b != null && b.runs == null) { b.runs = hdr.runs; b.wickets = hdr.wickets; b.overs = hdr.overs }
                } else if (b != null && !b.hasRows && (hdr.team.isBlank() || TeamNames.same(b.team, hdr.team))) {
                    if (hdr.team.length > b.team.length) b.team = hdr.team
                    if (hdr.runs != null) { b.runs = hdr.runs; b.wickets = hdr.wickets; b.overs = hdr.overs }
                } else {
                    val nb = Builder(hdr.team, hdr.runs, hdr.wickets, hdr.overs)
                    nb.declared = hdr.declared
                    builders.add(nb)
                    cur = nb
                }
                i++
                continue
            }

            // ---- extras / fall of wickets / yet to bat
            val low = flat.lowercase(Locale.ROOT)
            if (low.startsWith("extras") && cur != null) {
                val rest = flat.substring(6).trim().trimStart(':').trim()
                if (rest.isNotEmpty() && rest[0].isDigit()) cur.extras = "Extras $rest"
                i++
                continue
            }
            if ((low.startsWith("fall of wickets") || low.startsWith("fow")) && cur != null) {
                val rest = flat.substringAfter(':', "").trim()
                val found = Regex("\\d+-\\d+\\s*\\([^)]*\\)").findAll(rest).map { it.value }.toList()
                if (found.isNotEmpty()) cur.fow.addAll(found) else if (rest.isNotEmpty()) cur.fow.add(rest)
                i++
                continue
            }
            if ((low.startsWith("yet to bat") || low.startsWith("did not bat")) && cur != null) {
                val rest = flat.substringAfter(':', "").trim()
                cur.yet = rest.split(',').map { Jx.cleanName(it) }.filter { it.isNotEmpty() }.take(12)
                i++
                continue
            }

            // ---- batting / bowling rows
            var cand: Cand? = inlineCand(line)
            var consumed = 1
            if (cand == null && NUM.matches(flat.trim()) && i >= 1) {
                // one value per line (div layouts): name, [dismissal], then the numbers
                var j = i
                val nums = ArrayList<String>()
                while (j < lines.size && NUM.matches(lines[j].trim())) { nums.add(lines[j].trim()); j++ }
                if (nums.size >= 5) {
                    val prev1 = lines[i - 1].replace('\t', ' ')
                    val prev2 = if (i >= 2) lines[i - 2].replace('\t', ' ') else ""
                    val isDis = DISMISSAL_AT.find(prev1)?.range?.first == 0
                    val name = if (isDis && prev2.isNotBlank()) prev2 else prev1
                    val dis = if (isDis && prev2.isNotBlank()) prev1 else ""
                    if (looksLikeName(name)) cand = Cand(name, dis, nums)
                    consumed = j - i
                }
            }
            if (cand != null) {
                val bat = asBatter(cand)
                val bowl = if (bat == null) asBowler(cand) else null
                if (bat != null) {
                    var b = cur
                    if (b == null || b.sawBowler) {
                        b = Builder("", null, null, "")
                        builders.add(b)
                        cur = b
                    }
                    b.batters.add(bat)
                } else if (bowl != null) {
                    var b = cur
                    if (b == null) {
                        b = Builder("", null, null, "")
                        builders.add(b)
                        cur = b
                    }
                    b.sawBowler = true
                    b.bowlers.add(bowl)
                }
            }
            i += consumed
        }

        // ---- merge duplicates (the same innings seen in a summary line and again in its scorecard)
        val merged = ArrayList<Builder>()
        for (b in builders) {
            val hit = merged.firstOrNull { sameInnings(it, b) }
            if (hit == null) merged.add(b) else absorb(hit, b)
        }
        val rowsOnly = merged.filter { it.team.isBlank() && it.hasRows }
        val named = merged.filter { it.team.isNotBlank() && !it.hasRows }
        if (rowsOnly.isNotEmpty() && rowsOnly.size == named.size) {
            for (k in rowsOnly.indices) {
                absorb(named[k], rowsOnly[k])
                merged.remove(rowsOnly[k])
            }
        }
        val innings = merged.filter { it.runs != null || it.hasRows }.map { b ->
            val runs = b.runs ?: (b.batters.sumOf { it.runs })
            FeedInnings(
                team = b.team, runs = runs, wickets = b.wickets ?: b.batters.count { !it.notOut }, overs = b.overs, declared = b.declared,
                batters = b.batters, bowlers = b.bowlers, extras = b.extras, fallOfWickets = b.fow, yetToBat = b.yet
            )
        }
        val teams = HeaderMeta.vsTeams(pageTitle)
        if (innings.isEmpty() && teams == null) return null
        return FeedMatch(
            title = pageTitle.substringBefore(" - ").substringBefore(" | ").trim(),
            teamA = teams?.first ?: "", teamB = teams?.second ?: "", innings = innings
        )
    }
}
