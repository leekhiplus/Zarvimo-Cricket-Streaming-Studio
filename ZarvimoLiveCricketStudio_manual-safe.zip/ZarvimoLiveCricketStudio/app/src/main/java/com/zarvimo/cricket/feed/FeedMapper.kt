package com.zarvimo.cricket.feed

import com.zarvimo.cricket.graphics.BatterLine
import com.zarvimo.cricket.graphics.MatchVisuals
import com.zarvimo.cricket.graphics.OverlayBuilder
import com.zarvimo.cricket.graphics.OverlayData
import com.zarvimo.cricket.graphics.PanelInfo
import com.zarvimo.cricket.graphics.PanelKind
import com.zarvimo.cricket.graphics.PanelRow
import java.util.Locale

/** Turns what was read from a website into the same on-air data the manual scorer produces. */
object FeedMapper {

    private val BREAK_WORDS = listOf(
        "innings break", "stumps", "rain", "lunch", "tea", "drinks", "delay", "bad light",
        "strategic", "timeout", "interrupted", "abandon", "toss"
    )

    private fun upperOrNull(s: String?): String? = if (s.isNullOrBlank()) null else s.uppercase()

    fun overlay(m: FeedMatch, vis: MatchVisuals): OverlayData {
        val cur = m.currentInnings
        val bat = m.battingTeam
        val bowl = m.bowlingTeam
        val battingIsA = !TeamNames.same(bat, m.teamB) || TeamNames.same(bat, m.teamA)
        val aShort = m.teamAShort.ifBlank { OverlayBuilder.shortName(m.teamA) }
        val bShort = m.teamBShort.ifBlank { OverlayBuilder.shortName(m.teamB) }
        val batShort = if (battingIsA) aShort else bShort
        val bowlShort = if (battingIsA) bShort else aShort

        val req = m.requiredRuns
        val left = m.ballsLeft
        val chaseText: String? = if (!m.complete && m.target != null && req != null) {
            val runsPart = "NEED $req RUN${if (req == 1) "" else "S"}"
            if (left != null) "$runsPart FROM $left BALL${if (left == 1) "" else "S"}" else runsPart
        } else {
            null
        }

        val status = m.status.lowercase(Locale.ROOT)
        val banner: String? = when {
            m.complete -> null
            !m.hasScore -> null
            m.status.length <= 48 && BREAK_WORDS.any { status.contains(it) } -> m.status.uppercase()
            else -> null
        }

        val lastWicket: String? = m.lastWicket
            ?: cur?.fallOfWickets?.lastOrNull()
            ?: cur?.batters?.lastOrNull { !it.notOut && it.dismissal.isNotBlank() }?.let { "${it.name} ${it.runs} (${it.balls})  ${it.dismissal}" }

        // No score yet: only a real website text (toss / status) may be shown. If there is none, nothing is drawn at all.
        val preText = m.toss.ifBlank { m.status }
        val preMatch = !m.hasScore && !m.complete && preText.isNotBlank()
        val nothingToShow = !m.hasScore && !preMatch && !(m.complete && (m.result ?: m.status).isNotBlank())
        return OverlayData(
            title = m.title.ifBlank { m.series },
            venue = m.venue,
            battingTeam = bat, battingShort = batShort, bowlingTeam = bowl, bowlingShort = bowlShort,
            battingColor = if (battingIsA) vis.teamAColor else vis.teamBColor,
            bowlingColor = if (battingIsA) vis.teamBColor else vis.teamAColor,
            inningsNumber = m.innings.size.coerceAtLeast(1),
            battingIsTeamA = battingIsA,
            score = cur?.scoreText?.ifBlank { "--" } ?: "--",
            overs = cur?.overs?.ifBlank { "--" } ?: "--",
            oversLimit = if (m.oversLimit > 0) m.oversLimit else 0,
            striker = m.striker?.let { BatterLine(it.name, it.runs, it.balls, true) },
            nonStriker = m.nonStriker?.let { BatterLine(it.name, it.runs, it.balls, false) },
            bowlerName = m.bowler?.name,
            bowlerFigures = m.bowler?.figures,
            recentBalls = m.recentBalls,
            currentRunRate = m.currentRunRate ?: "--",
            targetText = if (m.target != null && !m.complete) "TARGET ${m.target}" else null,
            chaseText = chaseText,
            requiredRunRate = m.requiredRunRate,
            targetValue = if (m.complete) null else m.target,
            requiredRuns = if (chaseText != null) req else null,
            ballsLeft = if (chaseText != null) left else null,
            lastWicket = lastWicket,
            banner = banner,
            resultText = if (m.complete) upperOrNull(m.result ?: m.status) else null,
            preMatch = if (preMatch) preText.uppercase() else null,
            preMatchSub = if (preMatch) upperOrNull(m.venue) else null,
            hideScoreboard = nothingToShow
        )
    }
}

/** On-air panels (scorecard, summary, result...) built from a website reading. */
object FeedPanels {

    private fun f1(s: String): String {
        val d = s.trim().toDoubleOrNull() ?: return s
        return String.format(Locale.ROOT, "%.1f", d)
    }

    private fun colorOf(team: String, m: FeedMatch, vis: MatchVisuals): Int =
        if (TeamNames.same(team, m.teamB) && !TeamNames.same(team, m.teamA)) vis.teamBColor else vis.teamAColor

    fun build(kind: PanelKind, m: FeedMatch, vis: MatchVisuals, inningsIndex: Int?): PanelInfo? = when (kind) {
        PanelKind.SCORECARD -> scorecard(m, inningsIndex ?: (m.innings.size - 1))
        PanelKind.STRIKER, PanelKind.NON_STRIKER, PanelKind.BOWLER -> player(m, kind)
        PanelKind.PARTNERSHIP -> partnership(m)
        PanelKind.MATCH_SUMMARY -> summary(m, vis)
        PanelKind.RESULT_CARD -> result(m, vis)
        PanelKind.TOSS_CARD -> toss(m, vis)
        PanelKind.MAN_OF_MATCH -> manOfMatch(m, vis)
        else -> null
    }

    fun scorecard(m: FeedMatch, idx: Int): PanelInfo? {
        val inn = m.innings.getOrNull(idx) ?: return null
        if (inn.batters.isEmpty() && inn.bowlers.isEmpty()) return null
        val live = idx == m.innings.lastIndex && !m.complete
        val atCrease = if (live) inn.batters.filter { it.notOut }.take(2).map { it.name } else emptyList()
        val bat = inn.batters.take(12).map { b ->
            PanelRow(
                name = b.name,
                sub = if (b.notOut) "not out" else b.dismissal,
                c1 = b.runs.toString(), c2 = b.balls.toString(), c3 = b.fours.toString(), c4 = b.sixes.toString(),
                c5 = f1(b.strikeRate.ifBlank { if (b.balls > 0) String.format(Locale.ROOT, "%.1f", b.runs * 100.0 / b.balls) else "0.0" }),
                highlight = b.name in atCrease
            )
        }
        val currentBowler = if (live) m.bowler?.name else null
        val bowl = inn.bowlers.take(8).map { b ->
            PanelRow(
                name = b.name, c1 = b.overs, c2 = b.maidens.toString(), c3 = b.runs.toString(), c4 = b.wickets.toString(),
                c5 = f1(b.economy.ifBlank { CricketMath.ballsOf(b.overs)?.let { CricketMath.rate(b.runs, it) } ?: "" }),
                highlight = b.current || (currentBowler != null && b.name == currentBowler)
            )
        }
        val balls = CricketMath.ballsOf(inn.overs)
        val rr = if (inn.runs != null && balls != null) CricketMath.rate(inn.runs, balls) else null
        val fow = inn.fallOfWickets.joinToString("  ")
        val yet = if (inn.yetToBat.isNotEmpty()) "     YET TO BAT: " + inn.yetToBat.joinToString(", ") else ""
        return PanelInfo(
            kind = PanelKind.SCORECARD,
            title = if (inn.team.isBlank()) "INNINGS ${idx + 1}" else inn.team.uppercase(),
            subtitle = "${inn.scoreText}  (${inn.overs.ifBlank { "-" }} ov)" + (if (rr != null) "  \u2022  RR $rr" else ""),
            batHeader = listOf("BATTING", "R", "B", "4s", "6s", "SR"), bat = bat,
            bowlHeader = listOf("BOWLING", "O", "M", "R", "W", "ECO"), bowl = bowl,
            footer = inn.extras + (if (fow.isNotEmpty()) "     FOW: $fow" else "") + yet
        )
    }

    private fun player(m: FeedMatch, kind: PanelKind): PanelInfo? {
        if (kind == PanelKind.BOWLER) {
            val b = m.bowler ?: return null
            return PanelInfo(
                kind = kind, title = b.name.uppercase(), subtitle = "BOWLING  \u2022  ${m.bowlingTeam}",
                stats = listOf("OVERS" to b.overs, "MAIDENS" to b.maidens.toString(), "RUNS" to b.runs.toString(), "WKTS" to b.wickets.toString(), "ECON" to f1(b.economy))
            )
        }
        val b = (if (kind == PanelKind.STRIKER) m.striker else m.nonStriker) ?: return null
        val sr = b.strikeRate.ifBlank { if (b.balls > 0) String.format(Locale.ROOT, "%.1f", b.runs * 100.0 / b.balls) else "0.0" }
        return PanelInfo(
            kind = kind, title = b.name.uppercase(),
            subtitle = (if (kind == PanelKind.STRIKER) "ON STRIKE" else "AT THE OTHER END") + "  \u2022  ${m.battingTeam}",
            stats = listOf("RUNS" to b.runs.toString(), "BALLS" to b.balls.toString(), "4s" to b.fours.toString(), "6s" to b.sixes.toString(), "SR" to f1(sr))
        )
    }

    private fun partnership(m: FeedMatch): PanelInfo? {
        val s = m.striker ?: return null
        val n = m.nonStriker ?: return null
        val text = m.partnership ?: return null
        val mm = Regex("(\\d+)\\s*(?:\\((\\d+)\\))?").find(text) ?: return null
        val runs = mm.groupValues[1].toInt()
        val balls = mm.groupValues[2].toIntOrNull()
        val chips = ArrayList<Pair<String, String>>()
        chips.add("RUNS" to runs.toString())
        if (balls != null) {
            chips.add("BALLS" to balls.toString())
            chips.add("RATE" to (if (balls == 0) "0.00" else String.format(Locale.ROOT, "%.2f", runs * 6.0 / balls)))
        }
        return PanelInfo(
            kind = PanelKind.PARTNERSHIP, title = "PARTNERSHIP", subtitle = "CURRENT PARTNERSHIP  \u2022  ${m.battingTeam}",
            stats = chips,
            bat = listOf(
                PanelRow(s.name, c1 = s.runs.toString(), c2 = "(${s.balls})", highlight = true),
                PanelRow(n.name, c1 = n.runs.toString(), c2 = "(${n.balls})")
            )
        )
    }

    private fun column(inn: FeedInnings): Pair<String, List<PanelRow>> {
        val bats = inn.batters.filter { it.balls > 0 || it.runs > 0 }
            .sortedWith(compareByDescending<FeedBatter> { it.runs }.thenBy { it.balls }).take(3)
        val bowls = inn.bowlers.sortedWith(compareByDescending<FeedBowler> { it.wickets }.thenBy { it.runs }).take(2)
        val rows = bats.map { PanelRow(it.name, "BAT", "${it.runs}", "(${it.balls})") } +
            bowls.map { PanelRow(it.name, "BOWL", "${it.wickets}/${it.runs}", "(${it.overs})") }
        return Pair("${inn.team.uppercase()}   ${inn.scoreText} (${inn.overs})", rows)
    }

    private fun summary(m: FeedMatch, vis: MatchVisuals): PanelInfo? {
        val first = m.innings.getOrNull(0) ?: return null
        val second = m.innings.getOrNull(1)
        val c1 = column(first)
        val c2 = if (second != null) column(second) else null
        val foot = (m.result ?: m.status).uppercase()
        return PanelInfo(
            kind = PanelKind.MATCH_SUMMARY, title = "MATCH SUMMARY", subtitle = m.title,
            batHeader = listOf(c1.first), bat = c1.second,
            bowlHeader = listOf(c2?.first ?: "SECOND INNINGS TO COME"), bowl = c2?.second ?: emptyList(),
            footer = if (foot.isBlank()) "MATCH IN PROGRESS" else foot,
            colorA = colorOf(first.team, m, vis),
            colorB = if (second != null) colorOf(second.team, m, vis) else vis.teamBColor
        )
    }

    private fun result(m: FeedMatch, vis: MatchVisuals): PanelInfo? {
        val res = m.result ?: m.status
        if (!m.complete || res.isBlank()) return null
        val first = m.innings.getOrNull(0)
        val second = m.innings.getOrNull(1)
        val lines = ArrayList<Pair<String, String>>()
        for (inn in listOf(first, second)) {
            if (inn != null) lines.add(inn.team.uppercase() to "${inn.scoreText} (${inn.overs} OV)")
        }
        return PanelInfo(
            kind = PanelKind.RESULT_CARD, title = "RESULT", subtitle = res.uppercase(),
            footer = if (m.playerOfMatch.isNotBlank()) "MAN OF THE MATCH: ${m.playerOfMatch.uppercase()}" else "",
            stats = lines,
            batHeader = listOf(first?.team ?: m.teamA), bowlHeader = listOf(second?.team ?: m.teamB),
            colorA = colorOf(first?.team ?: m.teamA, m, vis), colorB = colorOf(second?.team ?: m.teamB, m, vis),
            teamSide = if (first != null && TeamNames.same(first.team, m.teamB) && !TeamNames.same(first.team, m.teamA)) 2 else 1
        )
    }

    private fun toss(m: FeedMatch, vis: MatchVisuals): PanelInfo? {
        val t = m.toss.trim()
        if (t.isEmpty()) return null
        val winner = Regex("(?i)^(.+?)\\s+(?:won the toss|win the toss|elected|opted|chose|choose|will bat|will bowl)").find(t)?.groupValues?.get(1)?.trim()
        val low = t.lowercase(Locale.ROOT)
        val decision = when {
            low.contains("bat") -> "AND CHOSE TO BAT FIRST"
            low.contains("bowl") || low.contains("field") -> "AND CHOSE TO BOWL FIRST"
            else -> "WON THE TOSS"
        }
        val chips = ArrayList<Pair<String, String>>()
        if (m.venue.isNotBlank()) chips.add("VENUE" to m.venue.uppercase())
        return PanelInfo(
            kind = PanelKind.TOSS_CARD, title = "TOSS", subtitle = (winner ?: t).uppercase(), footer = decision, stats = chips,
            batHeader = listOf(m.teamA), bowlHeader = listOf(m.teamB),
            colorA = vis.teamAColor, colorB = vis.teamBColor
        )
    }

    private fun manOfMatch(m: FeedMatch, vis: MatchVisuals): PanelInfo? {
        val n = m.playerOfMatch.trim()
        if (n.isEmpty()) return null
        return PanelInfo(kind = PanelKind.MAN_OF_MATCH, title = "MAN OF THE MATCH", subtitle = n.uppercase(), colorA = vis.teamAColor)
    }
}
