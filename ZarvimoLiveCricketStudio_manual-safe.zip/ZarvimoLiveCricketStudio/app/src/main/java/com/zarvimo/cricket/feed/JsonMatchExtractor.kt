package com.zarvimo.cricket.feed

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** "Pakistan Innings" / "Pakistan 2nd Innings" gives "Pakistan". */
internal fun cleanTeamName(s: String): String {
    val t = s.replace(Regex("(?i)\\s*(?:\\d(?:st|nd|rd|th)\\s+)?innings.*\$"), "").trim()
    return if (t.isBlank()) s.trim() else t
}

/**
 * Reads a match out of JSON embedded in (or served by) a cricket website. It does not depend on one website's exact key
 * names: it looks for lists whose items look like batters (name + runs + balls) and bowlers (name + overs + wickets + runs).
 */
internal object JsonMatchExtractor {

    fun extract(roots: List<Any>): FeedMatch? {
        val found = ArrayList<FeedInnings>()
        for (r in roots) collect(r, true, 0, ArrayList(), found)
        if (found.isEmpty()) for (r in roots) collect(r, false, 0, ArrayList(), found)
        val innings = ordered(dedupe(found))
        val header = HeaderScan.scan(roots)
        if (innings.isEmpty() && header.teamA.isBlank() && header.title.isBlank() && header.status.isBlank()) return null
        return header.copy(innings = innings)
    }

    /** Deepest object that holds a batting table (and, when asked, a bowling table too) is one innings. */
    private fun collect(node: Any?, needBowlers: Boolean, depth: Int, ancestors: ArrayList<JSONObject>, out: MutableList<FeedInnings>): Boolean {
        if (depth > 40) return false
        if (node !is JSONObject && node !is JSONArray) return false
        if (node is JSONObject) ancestors.add(node)
        var found = false
        for (child in Jx.children(node)) {
            if (collect(child, needBowlers, depth + 1, ancestors, out)) found = true
        }
        if (node is JSONObject) ancestors.removeAt(ancestors.size - 1)
        if (found) return true
        if (node !is JSONObject) return false
        val bats = TableFinder.batters(node) ?: return false
        val bowls = TableFinder.bowlers(node)
        if (needBowlers && bowls == null) return false
        out.add(build(node, bats, bowls ?: emptyList(), ancestors))
        return true
    }

    private val SCORE_KEYS = arrayOf("scoreDetails", "scoreData", "inningScore", "inningsScore", "scoreDetail")
    private val TEAM_KEYS = arrayOf("batTeamName", "battingTeam", "teamName", "inningsName", "inningName", "team")

    private class Score(val runs: Int?, val wickets: Int?, val overs: String?, val declared: Boolean)

    private fun scoreIn(o: JSONObject): Score? {
        val r = Jx.int(o, "runs", "totalRuns", "total", "score")
        val w = Jx.int(o, "wickets", "wkts", "totalWickets", "wicketsFallen")
        val ov = Jx.str(o, "overs", "oversBowled", "totalOvers", "over")
        if (r == null && w == null && ov == null) return null
        return Score(r, w, ov, Jx.bool(o, "isDeclared", "declared") == true)
    }

    private fun scoreFor(ctx: List<JSONObject>): Score? {
        for (i in ctx.indices) {
            val c = ctx[i]
            for (k in SCORE_KEYS) {
                val sub = c.optJSONObject(k)
                if (sub != null) {
                    val s = scoreIn(sub)
                    if (s != null && s.runs != null) return s
                }
            }
            if (i == 0) {
                val s = scoreIn(c)
                if (s != null && s.runs != null) return s
            }
        }
        return null
    }

    private fun teamOf(c: JSONObject): String? {
        for (k in TEAM_KEYS) {
            val v = c.opt(k)
            if (v is String && v.isNotBlank()) return cleanTeamName(v)
            if (v is JSONObject) {
                val n = Jx.nameOf(v)
                if (n != null) return n
            }
        }
        for (k in arrayOf("batTeamDetails", "battingTeamDetails")) {
            val v = c.optJSONObject(k)
            if (v != null) {
                val t = teamOf(v)
                if (t != null) return t
            }
        }
        return null
    }

    private fun namesIn(v: Any?): List<String> {
        val out = ArrayList<String>()
        if (v is JSONArray) {
            for (i in 0 until minOf(v.length(), 20)) {
                val e = v.opt(i)
                if (e is String && e.isNotBlank()) out.add(Jx.cleanName(e))
                if (e is JSONObject) Jx.nameOf(e)?.let { out.add(it) }
            }
        }
        return out
    }

    private fun yetToBat(node: JSONObject): List<String> {
        val keys = node.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val lk = k.lowercase(Locale.ROOT)
            if (lk.contains("yettobat") || lk.contains("didnotbat")) {
                val n = namesIn(node.opt(k))
                if (n.isNotEmpty()) return n
            }
        }
        return emptyList()
    }

    private fun partnershipText(o: JSONObject): String? {
        val n1 = Jx.str(o, "bat1Name", "player1Name", "batsman1Name") ?: o.optJSONObject("player1")?.let { Jx.nameOf(it) }
        val n2 = Jx.str(o, "bat2Name", "player2Name", "batsman2Name") ?: o.optJSONObject("player2")?.let { Jx.nameOf(it) }
        val total = Jx.int(o, "totalRuns", "runs", "partnershipRuns")
        val balls = Jx.int(o, "totalBalls", "balls", "partnershipBalls")
        if (n1 == null || n2 == null || total == null) return null
        return "$n1 & $n2: $total" + (if (balls != null) " ($balls)" else "")
    }

    private fun partnerships(node: JSONObject): List<String> {
        val keys = node.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (!k.lowercase(Locale.ROOT).contains("partnership")) continue
            val items = Jx.objectItems(node.opt(k)) ?: continue
            val out = ArrayList<String>()
            for (o in items) partnershipText(o)?.let { out.add(it) }
            if (out.isNotEmpty()) return out
        }
        return emptyList()
    }

    private fun build(node: JSONObject, bats: List<FeedBatter>, bowls: List<FeedBowler>, ancestors: List<JSONObject>): FeedInnings {
        val ctx = ArrayList<JSONObject>()
        ctx.add(node)
        var i = ancestors.size - 1
        while (i >= 0 && ctx.size < 4) {
            ctx.add(ancestors[i])
            i--
        }
        var team = ""
        for (c in ctx) {
            val t = teamOf(c)
            if (t != null) { team = t; break }
        }
        val score = scoreFor(ctx)
        var fow = TableFinder.fallOfWickets(node)
        var extras = TableFinder.extrasText(node)
        var yet = yetToBat(node)
        var parts = partnerships(node)
        for (a in ctx) {
            if (a === node) continue
            if (fow.isEmpty()) fow = TableFinder.fallOfWickets(a, 1)
            if (extras.isEmpty()) extras = TableFinder.extrasText(a)
            if (yet.isEmpty()) yet = yetToBat(a)
            if (parts.isEmpty()) parts = partnerships(a)
        }
        var order = 0
        for (c in ctx) {
            val n = Jx.int(c, "inningsId", "inningNumber", "inningsNumber", "inningsNo")
            if (n != null) { order = n; break }
        }
        var runs = score?.runs
        if (runs == null && bats.isNotEmpty()) {
            val ex = Regex("(\\d+)").find(extras)?.groupValues?.get(1)?.toIntOrNull() ?: 0
            runs = bats.sumOf { it.runs } + ex
        }
        val wickets = score?.wickets ?: if (bats.isNotEmpty()) bats.count { !it.notOut } else null
        return FeedInnings(
            team = team, runs = runs, wickets = wickets, overs = score?.overs ?: "", declared = score?.declared == true,
            batters = bats, bowlers = bowls, extras = extras, fallOfWickets = fow, yetToBat = yet, partnerships = parts, order = order
        )
    }

    private fun dedupe(list: List<FeedInnings>): List<FeedInnings> {
        val seen = HashSet<String>()
        val out = ArrayList<FeedInnings>()
        for (inn in list) {
            val key = inn.team.lowercase(Locale.ROOT) + "|" + inn.runs + "|" + inn.wickets + "|" + inn.batters.size + "|" +
                (inn.batters.firstOrNull()?.name ?: "") + "|" + inn.bowlers.size
            if (seen.add(key)) out.add(inn)
        }
        return out
    }

    private fun ordered(list: List<FeedInnings>): List<FeedInnings> {
        if (list.none { it.order > 0 }) return list
        return list.withIndex()
            .sortedWith(compareBy<IndexedValue<FeedInnings>>({ if (it.value.order > 0) it.value.order else Int.MAX_VALUE }, { it.index }))
            .map { it.value }
    }
}

/** Match-level facts (teams, venue, status, toss, live batters / bowler...) from anywhere in the JSON. */
internal object HeaderScan {

    private class Acc {
        var title = ""
        var series = ""
        var venue = ""
        var status = ""
        var state = ""
        var format = ""
        var oversLimit = 0
        var teamA = ""
        var teamB = ""
        var shortA = ""
        var shortB = ""
        var toss = ""
        var pom = ""
        var crr: String? = null
        var rrr: String? = null
        var target: Int? = null
        var reqRuns: Int? = null
        var lastWicket: String? = null
        var partnership: String? = null
        var recent: List<String> = emptyList()
        var striker: FeedBatter? = null
        var nonStriker: FeedBatter? = null
        var bowler: FeedBowler? = null
    }

    fun scan(roots: List<Any>): FeedMatch {
        val acc = Acc()
        val queue = java.util.ArrayDeque<Any>()
        for (r in roots) queue.add(r)
        var budget = 300_000
        while (!queue.isEmpty() && budget > 0) {
            val node = queue.poll() ?: break
            budget--
            if (node is JSONObject) visit(node, acc)
            for (c in Jx.children(node)) queue.add(c)
        }
        val limit = if (acc.oversLimit > 0) acc.oversLimit else oversOfFormat(acc.format)
        return FeedMatch(
            title = acc.title, series = acc.series, venue = acc.venue, status = acc.status,
            complete = isCompleteState(acc.state),
            toss = acc.toss, teamA = acc.teamA, teamB = acc.teamB, teamAShort = acc.shortA, teamBShort = acc.shortB,
            oversLimit = limit, striker = acc.striker, nonStriker = acc.nonStriker, bowler = acc.bowler,
            recentBalls = acc.recent, currentRunRate = acc.crr, requiredRunRate = acc.rrr, target = acc.target,
            requiredRuns = acc.reqRuns, lastWicket = acc.lastWicket, partnership = acc.partnership, playerOfMatch = acc.pom
        )
    }

    fun oversOfFormat(f: String): Int {
        val s = f.uppercase(Locale.ROOT)
        return when {
            s.contains("T20") || s.contains("TWENTY") -> 20
            s.contains("T10") -> 10
            s.contains("ODI") || s.contains("LIST A") || s == "LA" || s.contains("ONE DAY") -> 50
            else -> 0
        }
    }

    private fun isCompleteState(state: String): Boolean {
        val s = state.lowercase(Locale.ROOT)
        return s.contains("complete") || s.contains("finished") || s == "result" || s.contains("post") || s.contains("abandon")
    }

    private fun stringOrName(v: Any?): String {
        if (v is String) return v.trim()
        if (v is JSONObject) return Jx.nameOf(v) ?: ""
        return ""
    }

    private fun venueText(v: Any?): String {
        if (v is String) return v.trim()
        if (v is JSONObject) {
            val parts = listOf(Jx.str(v, "name", "ground", "stadium", "longName"), Jx.str(v, "city", "town", "location"))
            return parts.filterNotNull().joinToString(", ")
        }
        return ""
    }

    private fun nameOfFirst(v: Any?): String {
        if (v is String) return Jx.cleanName(v)
        if (v is JSONObject) return Jx.nameOf(v) ?: ""
        if (v is JSONArray && v.length() > 0) return nameOfFirst(v.opt(0))
        return ""
    }

    fun parseBalls(text: String): List<String> {
        val out = ArrayList<String>()
        val extra = Regex("^(?:\\d(?:wd|nb|lb|b)|(?:wd|nb|lb|b)\\d?)\$")
        for (raw in text.split(Regex("[\\s,|]+"))) {
            val t = raw.trim()
            if (t.isEmpty()) continue
            val low = t.lowercase(Locale.ROOT)
            val mapped: String? = when {
                t == "." -> "0"
                low == "w" -> "W"
                low == "wd" -> "Wd"
                low == "nb" -> "Nb"
                t.length == 1 && t[0] in '0'..'7' -> t
                extra.matches(low) -> t
                else -> null
            }
            if (mapped != null) out.add(mapped)
        }
        return out.takeLast(6)
    }

    private fun ballsFrom(v: Any?): List<String> {
        if (v is String) return parseBalls(v)
        if (v is JSONArray) {
            val sb = StringBuilder()
            for (i in 0 until minOf(v.length(), 40)) sb.append(v.opt(i).toString()).append(' ')
            return parseBalls(sb.toString())
        }
        return emptyList()
    }

    private fun numberText(v: Any?): String? {
        if (v is Number) return String.format(Locale.ROOT, "%.2f", v.toDouble())
        if (v is String) {
            val d = v.trim().toDoubleOrNull() ?: return null
            return String.format(Locale.ROOT, "%.2f", d)
        }
        return null
    }

    private fun readTeams(o: JSONObject, acc: Acc) {
        val t1 = o.optJSONObject("team1")
        val t2 = o.optJSONObject("team2")
        if (t1 != null && t2 != null) {
            val a = Jx.nameOf(t1)
            val b = Jx.nameOf(t2)
            if (a != null && b != null) {
                acc.teamA = a
                acc.teamB = b
                acc.shortA = Jx.str(t1, "shortName", "teamSName", "abbreviation", "teamShortName") ?: ""
                acc.shortB = Jx.str(t2, "shortName", "teamSName", "abbreviation", "teamShortName") ?: ""
            }
            return
        }
        val arr = o.optJSONArray("teams") ?: return
        if (arr.length() < 2) return
        val i1 = arr.optJSONObject(0) ?: return
        val i2 = arr.optJSONObject(1) ?: return
        val x1 = i1.optJSONObject("team") ?: i1
        val x2 = i2.optJSONObject("team") ?: i2
        val a = Jx.nameOf(x1)
        val b = Jx.nameOf(x2)
        if (a != null && b != null) {
            acc.teamA = a
            acc.teamB = b
            acc.shortA = Jx.str(x1, "abbreviation", "shortName", "teamSName", "teamShortName", "short", "code") ?: ""
            acc.shortB = Jx.str(x2, "abbreviation", "shortName", "teamSName", "teamShortName", "short", "code") ?: ""
        }
    }

    private fun readMini(v: JSONObject, acc: Acc) {
        v.optJSONObject("batsmanStriker")?.let { acc.striker = miniBatter(it, true) }
        v.optJSONObject("batsmanNonStriker")?.let { acc.nonStriker = miniBatter(it, false) }
        v.optJSONObject("bowlerStriker")?.let { acc.bowler = miniBowler(it) }
    }

    private fun miniBatter(o: JSONObject, strike: Boolean): FeedBatter? {
        val name = Jx.str(o, "batName", "name") ?: return null
        val runs = Jx.int(o, "batRuns", "runs") ?: 0
        val balls = Jx.int(o, "batBalls", "balls") ?: 0
        val sr = Jx.str(o, "batStrikeRate", "strikeRate") ?: if (balls > 0) String.format(Locale.ROOT, "%.2f", runs * 100.0 / balls) else "0.00"
        return FeedBatter(Jx.cleanName(name), runs, balls, Jx.int(o, "batFours", "fours") ?: 0, Jx.int(o, "batSixes", "sixes") ?: 0, sr, "not out", true, strike)
    }

    private fun miniBowler(o: JSONObject): FeedBowler? {
        val name = Jx.str(o, "bowlName", "name") ?: return null
        return FeedBowler(
            Jx.cleanName(name), Jx.str(o, "bowlOvs", "overs") ?: "0", Jx.int(o, "bowlMaidens", "maidens") ?: 0,
            Jx.int(o, "bowlRuns", "runs") ?: 0, Jx.int(o, "bowlWkts", "wickets") ?: 0, Jx.str(o, "bowlEcon", "economy") ?: "", true
        )
    }

    private fun visit(o: JSONObject, acc: Acc) {
        if (acc.teamA.isEmpty()) readTeams(o, acc)
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val v = o.opt(k)
            when (k.lowercase(Locale.ROOT)) {
                "matchdescription", "matchdesc", "matchtitle", "matchname", "fixturename" ->
                    if (v is String && acc.title.isEmpty()) acc.title = v.trim()
                "seriesname", "seriesdesc", "tournamentname" ->
                    if (v is String && acc.series.isEmpty()) acc.series = v.trim()
                "series" -> if (acc.series.isEmpty()) acc.series = stringOrName(v)
                "venue", "ground", "stadium", "venuename" -> if (acc.venue.isEmpty()) acc.venue = venueText(v)
                "statustext", "customstatus", "status", "matchstatus", "statusstring", "resulttext" ->
                    if (acc.status.isEmpty() && v is String && v.trim().length >= 6 && v.contains(' ')) acc.status = v.trim()
                "state", "matchstate" -> if (acc.state.isEmpty() && v is String) acc.state = v.trim()
                "matchformat", "format", "matchtype" -> if (acc.format.isEmpty() && v is String) acc.format = v.trim()
                "overslimit", "maxovers", "oversperinnings" -> if (acc.oversLimit == 0 && v is Number) acc.oversLimit = v.toInt()
                "tossresults" -> if (acc.toss.isEmpty() && v is JSONObject) {
                    val w = Jx.str(v, "tossWinnerName")
                    val d = Jx.str(v, "decision")
                    if (w != null) acc.toss = "$w won the toss" + (if (d != null) " and chose to ${if (d.lowercase(Locale.ROOT).contains("bat")) "bat" else "bowl"}" else "")
                }
                "tossstatus", "toss", "tosstext" -> if (acc.toss.isEmpty() && v is String) acc.toss = v.trim()
                "playersofthematch", "playerofthematch", "playerofmatch", "momname", "manofthematch" ->
                    if (acc.pom.isEmpty()) acc.pom = nameOfFirst(v)
                "miniscore" -> if (v is JSONObject) {
                    readMini(v, acc)
                    if (acc.recent.isEmpty()) acc.recent = ballsFrom(v.opt("recentOvsStats") ?: v.opt("recentBalls"))
                    if (acc.crr == null) acc.crr = numberText(v.opt("currentRunRate") ?: v.opt("crr"))
                    if (acc.rrr == null) acc.rrr = numberText(v.opt("requiredRunRate") ?: v.opt("rrr"))
                    if (acc.target == null) acc.target = Jx.int(v, "target")
                    if (acc.reqRuns == null) acc.reqRuns = Jx.int(v, "remRunsToWin", "requiredRuns")
                    if (acc.lastWicket == null) acc.lastWicket = Jx.str(v, "lastWicket")
                    val ps = v.opt("partnerShip") ?: v.opt("partnership")
                    if (acc.partnership == null && ps is JSONObject) {
                        val r = Jx.int(ps, "runs")
                        val b = Jx.int(ps, "balls")
                        if (r != null) acc.partnership = "$r" + (if (b != null) " ($b)" else "")
                    }
                }
                "recentovsstats", "recentballs", "lastsixballs", "thisover" ->
                    if (acc.recent.isEmpty()) acc.recent = ballsFrom(v)
                "currentrunrate", "crr", "currrunrate" -> if (acc.crr == null) acc.crr = numberText(v)
                "requiredrunrate", "rrr", "reqrunrate" -> if (acc.rrr == null) acc.rrr = numberText(v)
                "target", "targetruns" -> if (acc.target == null && v is Number) acc.target = v.toInt()
                "lastwicket" -> if (acc.lastWicket == null && v is String && v.isNotBlank()) acc.lastWicket = v.trim()
                else -> Unit
            }
        }
    }
}
