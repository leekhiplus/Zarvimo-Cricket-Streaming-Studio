package com.zarvimo.cricket.feed

import java.util.Locale

/** One batter line of a scorecard, as read from a website. */
data class FeedBatter(
    val name: String,
    val runs: Int = 0,
    val balls: Int = 0,
    val fours: Int = 0,
    val sixes: Int = 0,
    val strikeRate: String = "",
    val dismissal: String = "",
    val notOut: Boolean = false,
    val onStrike: Boolean = false
)

/** One bowler line of a scorecard. */
data class FeedBowler(
    val name: String,
    val overs: String = "0",
    val maidens: Int = 0,
    val runs: Int = 0,
    val wickets: Int = 0,
    val economy: String = "",
    val current: Boolean = false
) {
    /** TV style figures: wickets-runs (overs), e.g. "1-28 (3.4)". */
    val figures: String get() = "$wickets-$runs ($overs)"
}

/** One innings of the match: the score plus whatever tables the website offered. */
data class FeedInnings(
    val team: String = "",
    val runs: Int? = null,
    val wickets: Int? = null,
    val overs: String = "",
    val declared: Boolean = false,
    val batters: List<FeedBatter> = emptyList(),
    val bowlers: List<FeedBowler> = emptyList(),
    val extras: String = "",
    val fallOfWickets: List<String> = emptyList(),
    val yetToBat: List<String> = emptyList(),
    val partnerships: List<String> = emptyList(),
    /** Innings number given by the website (0 = unknown); used only to sort. */
    val order: Int = 0
) {
    /** "158/5", or just "158" when the website gave no wickets. Empty when there is no score at all. */
    val scoreText: String
        get() {
            val r = runs ?: return ""
            val w = wickets ?: return "$r"
            return "$r/$w"
        }
}

/** Everything read from one cricket website page (or several pages of the same match merged together). */
data class FeedMatch(
    val sourceUrl: String = "",
    val sourceName: String = "",
    val title: String = "",
    val series: String = "",
    val venue: String = "",
    /** The website's own status line, e.g. "Pakistan need 111 runs in 62 balls". */
    val status: String = "",
    val result: String? = null,
    val complete: Boolean = false,
    val toss: String = "",
    val teamA: String = "",
    val teamB: String = "",
    val teamAShort: String = "",
    val teamBShort: String = "",
    /** Overs per innings of a limited-overs match (0 = unknown / a multi-day match). */
    val oversLimit: Int = 0,
    val innings: List<FeedInnings> = emptyList(),
    val striker: FeedBatter? = null,
    val nonStriker: FeedBatter? = null,
    val bowler: FeedBowler? = null,
    val recentBalls: List<String> = emptyList(),
    val currentRunRate: String? = null,
    val requiredRunRate: String? = null,
    val target: Int? = null,
    val requiredRuns: Int? = null,
    val ballsLeft: Int? = null,
    val lastWicket: String? = null,
    val partnership: String? = null,
    val playerOfMatch: String = "",
    val commentary: List<String> = emptyList()
) {
    val currentInnings: FeedInnings? get() = innings.lastOrNull()
    val hasScore: Boolean get() = innings.any { it.runs != null }
    val hasScorecard: Boolean get() = innings.any { it.batters.isNotEmpty() }
    val battingTeam: String
        get() = currentInnings?.team?.takeIf { it.isNotBlank() } ?: teamA
    val bowlingTeam: String
        get() {
            val bat = battingTeam
            return when {
                bat.isBlank() -> teamB
                TeamNames.same(bat, teamA) -> teamB
                TeamNames.same(bat, teamB) -> teamA
                else -> teamB
            }
        }
}

object TeamNames {
    /** "PAK" and "Pakistan", or "Pakistan" and "pakistan ", are the same team. */
    fun same(a: String, b: String): Boolean {
        val x = a.trim().lowercase(Locale.ROOT)
        val y = b.trim().lowercase(Locale.ROOT)
        if (x.isEmpty() || y.isEmpty()) return false
        if (x == y) return true
        val shorter = if (x.length <= y.length) x else y
        val longer = if (x.length <= y.length) y else x
        if (shorter.length >= 2 && shorter.length <= 4 && longer.startsWith(shorter)) return true
        val initials = longer.split(Regex("\\s+")).filter { it.isNotEmpty() }.map { it[0] }.joinToString("")
        return shorter.length >= 2 && shorter == initials
    }
}

object CricketMath {
    /** "18.4" gives 112 balls, "20" gives 120. Null when the text is not an overs value. */
    fun ballsOf(overs: String?, ballsPerOver: Int = 6): Int? {
        if (overs.isNullOrBlank()) return null
        val m = Regex("^(\\d{1,3})(?:\\.(\\d))?\$").find(overs.trim()) ?: return null
        val o = m.groupValues[1].toInt()
        val b = if (m.groupValues[2].isEmpty()) 0 else m.groupValues[2].toInt()
        if (b >= ballsPerOver) return null
        return o * ballsPerOver + b
    }

    /** Runs per over with two decimals, or null when no ball has been bowled. */
    fun rate(runs: Int, balls: Int): String? =
        if (balls <= 0) null else String.format(Locale.ROOT, "%.2f", runs * 6.0 / balls)

    fun oversText(balls: Int): String = "${balls / 6}.${balls % 6}"
}
