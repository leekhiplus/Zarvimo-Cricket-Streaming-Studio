package com.zarvimo.cricket.feed

/** Websites whose match pages can be opened from just a match ID. */
enum class MatchSite(val label: String, val hint: String) {
    CRICBUZZ("Cricbuzz", "the number in the match link, e.g. cricbuzz.com/live-cricket-scores/91811/... (ID 91811)"),
    CRICINFO("ESPNcricinfo", "the last number of the match part of the link, e.g. .../csk-vs-rcb-1st-match-1422119/... (ID 1422119)");

    /** The match page for [idText] (the first 4 to 10 digit number in it), or null when there is no usable ID. */
    fun urlFor(idText: String): String? {
        val id = Regex("\\d{4,10}").find(idText)?.value ?: return null
        return when (this) {
            CRICBUZZ -> "https://www.cricbuzz.com/live-cricket-scorecard/$id"
            CRICINFO -> "https://www.espncricinfo.com/matches/engine/match/$id.html"
        }
    }
}
