package com.zarvimo.cricket.feed

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONTokener
import kotlin.coroutines.resume

/**
 * Opens a page in a hidden browser so the page's own scripts run, then returns the rendered HTML.
 * Used when a plain download has no readable score (JavaScript sites) or is refused.
 */
class WebViewFetcher(private val context: Context) {
    private var view: WebView? = null
    private var loadedUrl: String = ""
    private var loadedAt: Long = 0L

    @SuppressLint("SetJavaScriptEnabled")
    private fun ensureView(): WebView {
        val existing = view
        if (existing != null) return existing
        val wv = WebView(context.applicationContext)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.loadsImagesAutomatically = false
        wv.settings.userAgentString = FeedHttp.USER_AGENT
        // A hidden view has no size; give it a phone-sized viewport so responsive pages lay out normally.
        wv.layout(0, 0, 1080, 2000)
        wv.onResume()
        wv.resumeTimers()
        view = wv
        return wv
    }

    /** Rendered HTML of [url], or null on failure / timeout. Reloads at most every 3 minutes; otherwise re-reads the live page. */
    suspend fun fetch(url: String, timeoutMs: Long = 35000L): String? = withContext(Dispatchers.Main) {
        withTimeoutOrNull(timeoutMs) {
            val wv = ensureView()
            val fresh = url == loadedUrl && System.currentTimeMillis() - loadedAt < 180_000L
            if (fresh) readHtml(wv) else load(wv, url)
        }
    }

    private suspend fun load(wv: WebView, url: String): String? {
        val ok = suspendCancellableCoroutine<Boolean> { cont ->
            wv.webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView?, u: String?) {
                    if (cont.isActive) cont.resume(true)
                }

                override fun onReceivedError(v: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                    if (request != null && request.isForMainFrame && cont.isActive) cont.resume(false)
                }
            }
            cont.invokeOnCancellation {
                Handler(Looper.getMainLooper()).post { wv.stopLoading() }
            }
            wv.loadUrl(url)
        }
        if (!ok) return null
        loadedUrl = url
        loadedAt = System.currentTimeMillis()
        delay(3500) // let the page's scripts fetch and draw the score
        return readHtml(wv)
    }

    private suspend fun readHtml(wv: WebView): String? = suspendCancellableCoroutine { cont ->
        wv.evaluateJavascript("(function(){return document.documentElement.outerHTML;})()") { raw ->
            if (cont.isActive) cont.resume(decode(raw))
        }
    }

    private fun decode(raw: String?): String? {
        if (raw.isNullOrEmpty() || raw == "null") return null
        return try {
            JSONTokener(raw).nextValue() as? String
        } catch (e: Exception) {
            null
        }
    }

    /** Forget the loaded page so the next fetch reloads it (used when a new link is started). */
    fun forget() {
        loadedUrl = ""
    }

    fun release() {
        val v = view
        view = null
        loadedUrl = ""
        if (v != null) Handler(Looper.getMainLooper()).post { v.destroy() }
    }
}
