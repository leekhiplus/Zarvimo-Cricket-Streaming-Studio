package com.zarvimo.cricket.feed

import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.util.Locale

/** Small, forgiving helpers for reading JSON whose exact layout is not known in advance. */
internal object Jx {

    fun parse(text: String): Any? = try {
        val v = JSONTokener(text).nextValue()
        if (v is JSONObject || v is JSONArray) v else null
    } catch (e: Exception) {
        null
    }

    /** Child objects / arrays of a node (at most 120 array elements, to keep huge pages fast). */
    fun children(node: Any?): List<Any> {
        val res = ArrayList<Any>()
        if (node is JSONObject) {
            val keys = node.keys()
            while (keys.hasNext()) {
                val v = node.opt(keys.next())
                if (v is JSONObject || v is JSONArray) res.add(v)
            }
        } else if (node is JSONArray) {
            val n = minOf(node.length(), 120)
            for (i in 0 until n) {
                val v = node.opt(i)
                if (v is JSONObject || v is JSONArray) res.add(v)
            }
        }
        return res
    }

    private fun numericSuffix(k: String): Int? = Regex("(\\d+)\$").find(k)?.groupValues?.get(1)?.toIntOrNull()

    /**
     * The objects of a list: a JSON array of objects, or an object whose values are all objects
     * (like {"bat_1": {...}, "bat_2": {...}}, sorted by the number in the key).
     */
    fun objectItems(node: Any?): List<JSONObject>? {
        if (node is JSONArray) {
            val res = ArrayList<JSONObject>()
            val n = minOf(node.length(), 60)
            for (i in 0 until n) {
                val v = node.opt(i)
                if (v is JSONObject) res.add(v)
            }
            return if (res.isEmpty()) null else res
        }
        if (node is JSONObject) {
            val keys = ArrayList<String>()
            val kit = node.keys()
            while (kit.hasNext()) keys.add(kit.next())
            if (keys.isEmpty() || keys.size > 60) return null
            for (k in keys) if (node.opt(k) !is JSONObject) return null
            val ordered = if (keys.all { numericSuffix(it) != null }) keys.sortedBy { numericSuffix(it) } else keys
            val res = ArrayList<JSONObject>()
            for (k in ordered) node.optJSONObject(k)?.let { res.add(it) }
            return res
        }
        return null
    }

    fun numText(n: Number): String {
        val d = n.toDouble()
        return if (d == Math.floor(d) && Math.abs(d) < 1e9) d.toLong().toString() else d.toString()
    }

    fun int(o: JSONObject, vararg keys: String): Int? {
        for (k in keys) {
            val v = o.opt(k) ?: continue
            if (v is Number) return v.toInt()
            if (v is String) {
                val n = v.trim().toIntOrNull()
                if (n != null) return n
            }
        }
        return null
    }

    fun str(o: JSONObject, vararg keys: String): String? {
        for (k in keys) {
            val v = o.opt(k) ?: continue
            if (v is String) {
                if (v.isNotBlank()) return v.trim()
            } else if (v is Number) {
                return numText(v)
            }
        }
        return null
    }

    fun bool(o: JSONObject, vararg keys: String): Boolean? {
        for (k in keys) {
            val v = o.opt(k) ?: continue
            if (v is Boolean) return v
            if (v is String) {
                val s = v.trim().lowercase(Locale.ROOT)
                if (s == "true" || s == "yes" || s == "1") return true
                if (s == "false" || s == "no" || s == "0") return false
            }
        }
        return null
    }

    fun hasKey(o: JSONObject, vararg keys: String): Boolean {
        for (k in keys) if (o.has(k)) return true
        return false
    }

    private val NAME_KEYS = arrayOf(
        "batName", "bowlName", "bowlerName", "batsmanName", "playerName", "name", "longName", "fullName",
        "displayName", "battingName", "shortName", "player", "batsman", "bowler"
    )

    /** A person's / team's name from an object, looking one or two levels down ("player": {"name": ...}). */
    fun nameOf(o: JSONObject, depth: Int = 0): String? {
        for (k in NAME_KEYS) {
            val v = o.opt(k)
            if (v is String && v.isNotBlank()) return cleanName(v)
            if (v is JSONObject && depth < 2) {
                val inner = nameOf(v, depth + 1)
                if (inner != null) return inner
            }
        }
        return null
    }

    fun cleanName(s: String): String =
        s.replace("\u2020", "").replace("*", "").replace(Regex("\\s*\\((?:c|wk|c & wk|wk & c|capt|captain)\\)\\s*", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("\\s+"), " ").trim()

    fun dismissal(o: JSONObject): String {
        for (k in arrayOf("outDesc", "dismissal", "dismissalText", "outStr", "howOut", "wicketDesc", "outDescription", "status")) {
            val v = o.opt(k) ?: continue
            if (v is String && v.isNotBlank()) return v.trim()
            if (v is JSONObject) {
                for (kk in arrayOf("short", "long", "text", "commentary", "dismissalText")) {
                    val s = v.opt(kk)
                    if (s is String && s.isNotBlank()) return s.trim()
                }
            }
        }
        return ""
    }
}

/** Finds the batting and bowling tables inside a JSON node, whatever the website calls its keys. */
internal object TableFinder {

    private fun <T> find(node: Any?, hops: Int, conv: (List<JSONObject>) -> List<T>): List<T>? {
        val items = Jx.objectItems(node)
        if (items != null) {
            val got = conv(items)
            if (got.isNotEmpty()) return got
        }
        if (hops <= 0) return null
        for (child in Jx.children(node)) {
            val r = find(child, hops - 1, conv)
            if (r != null) return r
        }
        return null
    }

    fun batters(node: Any?, hops: Int = 3): List<FeedBatter>? = find(node, hops) { items ->
        val res = ArrayList<FeedBatter>()
        for (o in items) toBatter(o)?.let { res.add(it) }
        if (res.isNotEmpty() && res.size * 2 >= items.size) res else emptyList()
    }

    fun bowlers(node: Any?, hops: Int = 3): List<FeedBowler>? = find(node, hops) { items ->
        val res = ArrayList<FeedBowler>()
        for (o in items) toBowler(o)?.let { res.add(it) }
        if (res.isNotEmpty() && res.size * 2 >= items.size) res else emptyList()
    }

    fun toBatter(o: JSONObject): FeedBatter? {
        if (Jx.hasKey(o, "overs", "wickets", "maidens", "economy", "conceded", "bowlOvs")) return null
        val rawName = Jx.nameOf(o) ?: return null
        val runs = Jx.int(o, "runs", "r", "run", "batRuns", "runsScored", "score") ?: return null
        val balls = Jx.int(o, "balls", "b", "ballsFaced", "batBalls", "bf", "ball") ?: return null
        val fours = Jx.int(o, "fours", "four", "4s", "boundaries4", "batFours") ?: 0
        val sixes = Jx.int(o, "sixes", "six", "6s", "boundaries6", "batSixes") ?: 0
        var dis = Jx.dismissal(o)
        val flagged = Jx.bool(o, "isNotOut", "notOut")
        val lower = dis.lowercase(Locale.ROOT)
        val notOut = flagged ?: (lower.isBlank() || lower.contains("not out") || lower == "batting")
        if (notOut && dis.isBlank()) dis = "not out"
        val starred = listOf("batName", "name", "longName", "fullName").any { (o.opt(it) as? String)?.trim()?.endsWith("*") == true }
        val strike = Jx.bool(o, "isStriker", "onStrike", "striker", "isOnStrike", "onstrike") == true || starred
        val sr = Jx.str(o, "strikeRate", "strikerate", "sr", "batStrikeRate", "strike_rate")
            ?: if (balls > 0) String.format(Locale.ROOT, "%.2f", runs * 100.0 / balls) else "0.00"
        return FeedBatter(Jx.cleanName(rawName), runs, balls, fours, sixes, sr, dis, notOut, strike)
    }

    fun toBowler(o: JSONObject): FeedBowler? {
        val name = Jx.nameOf(o) ?: return null
        val overs = Jx.str(o, "overs", "bowlOvs", "o", "oversBowled", "over") ?: return null
        val wickets = Jx.int(o, "wickets", "bowlWkts", "w", "wkts", "wicket") ?: return null
        val runs = Jx.int(o, "conceded", "runs", "bowlRuns", "runsConceded", "r") ?: return null
        val maidens = Jx.int(o, "maidens", "bowlMaidens", "m") ?: 0
        val ballsBowled = CricketMath.ballsOf(overs)
        val econ = Jx.str(o, "economy", "bowlEcon", "econ", "eco", "er")
            ?: (if (ballsBowled != null) CricketMath.rate(runs, ballsBowled) else null) ?: ""
        val current = Jx.bool(o, "isCurrent", "current", "isBowling", "live") == true
        return FeedBowler(Jx.cleanName(name), overs, maidens, runs, wickets, econ, current)
    }

    /** "1-111 (Shane Watson, 10.4 ov)" lines from a fall-of-wickets list. */
    fun fallOfWickets(node: JSONObject, hops: Int = 2): List<String> {
        val keys = node.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val lk = k.lowercase(Locale.ROOT)
            if (!(lk.contains("fow") || lk.contains("wicket") || lk.contains("fall"))) continue
            val items = Jx.objectItems(node.opt(k)) ?: continue
            val out = ArrayList<String>()
            for (o in items) fowText(o)?.let { out.add(it) }
            if (out.isNotEmpty()) return out
        }
        if (hops > 0) {
            for (c in Jx.children(node)) {
                if (c is JSONObject) {
                    val r = fallOfWickets(c, hops - 1)
                    if (r.isNotEmpty()) return r
                }
            }
        }
        return emptyList()
    }

    private fun fowText(o: JSONObject): String? {
        val n = Jx.int(o, "wktNbr", "wicketNumber", "fowOrder", "order", "wicket", "wicketNo", "fowWicketNum") ?: return null
        val r = Jx.int(o, "wktRuns", "fowRuns", "runs", "score", "teamRuns") ?: return null
        val nm = Jx.nameOf(o) ?: ""
        val ov = Jx.str(o, "wktOver", "fowOvers", "overs", "over", "overNumber")
        val inside = listOf(nm, if (ov != null) "$ov ov" else "").filter { it.isNotBlank() }.joinToString(", ")
        return if (inside.isEmpty()) "$n-$r" else "$n-$r ($inside)"
    }

    /** "Extras 10 (b 4, lb 2, w 4)" from either a number, a string or an object. */
    fun extrasText(node: JSONObject): String {
        val v = node.opt("extras") ?: node.opt("extrasData") ?: node.opt("extra")
        var total: Int? = null
        var src: JSONObject = node
        var shortKeys = false
        when (v) {
            is JSONObject -> { src = v; shortKeys = true; total = Jx.int(v, "total", "extras", "runs") }
            is Number -> total = v.toInt()
            is String -> {
                val t = v.trim()
                if (t.isEmpty()) return ""
                return if (t.lowercase(Locale.ROOT).startsWith("extra")) t else "Extras $t"
            }
            else -> Unit
        }
        val b = if (shortKeys) Jx.int(src, "byes", "b") else Jx.int(src, "byes")
        val lb = if (shortKeys) Jx.int(src, "legByes", "legbyes", "lb") else Jx.int(src, "legByes", "legbyes")
        val w = if (shortKeys) Jx.int(src, "wides", "wd", "w") else Jx.int(src, "wides")
        val nb = if (shortKeys) Jx.int(src, "noBalls", "noballs", "nb") else Jx.int(src, "noBalls", "noballs")
        val pen = Jx.int(src, "penalty", "penalties", "pen")
        val parts = ArrayList<String>()
        if (b != null) parts.add("b $b")
        if (lb != null) parts.add("lb $lb")
        if (w != null) parts.add("w $w")
        if (nb != null) parts.add("nb $nb")
        if (pen != null && pen > 0) parts.add("pen $pen")
        val sum = (b ?: 0) + (lb ?: 0) + (w ?: 0) + (nb ?: 0) + (pen ?: 0)
        val t = total ?: if (parts.isNotEmpty()) sum else return ""
        return "Extras $t" + if (parts.isEmpty()) "" else " (" + parts.joinToString(", ") + ")"
    }
}
