package com.zarvimo.cricket.feed

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class FeedUi(
    val url: String = "",
    val running: Boolean = false,
    val busy: Boolean = false,
    val status: String = "",
    val error: String? = null,
    val match: FeedMatch? = null,
    val updatedAt: Long = 0L,
    val intervalSec: Int = 10,
    val viaBrowser: Boolean = false,
    val fetchCount: Int = 0
)

/**
 * Reads a match link again and again and reports every successful reading through [onMatch] (always on the main thread,
 * because [scope] is the view model scope). First a plain download is tried; if the page has no readable score
 * (JavaScript sites, or a site that refuses plain requests) a hidden browser renders the page instead.
 */
class FeedController(
    private val appContext: Context,
    private val scope: CoroutineScope,
    private val onMatch: (FeedMatch) -> Unit
) {
    private val _ui = MutableStateFlow(FeedUi())
    val ui: StateFlow<FeedUi> = _ui

    private var job: Job? = null
    private val lock = Mutex()
    private val browser by lazy { WebViewFetcher(appContext) }
    private var useBrowser = false
    private var lastError = ""

    fun setUrlText(text: String) {
        _ui.update { it.copy(url = text) }
    }

    fun setInterval(sec: Int) {
        _ui.update { it.copy(intervalSec = sec.coerceIn(3, 120)) }
    }

    /** Starts watching a link. Returns an error text, or null when started. */
    fun start(input: String): String? {
        val url = MatchParser.normalizeUrl(input) ?: return "That does not look like a web link. Paste the match page address (https://...)."
        job?.cancel()
        useBrowser = false
        browser.forget()
        _ui.update { it.copy(url = url, running = true, busy = false, error = null, status = "Reading the page...", match = null, fetchCount = 0) }
        job = scope.launch {
            while (isActive) {
                val m = fetchOnce(url)
                if (m != null && m.complete) {
                    _ui.update { it.copy(running = false, status = "Match finished. The last data stays on air (tap Refresh to read again).") }
                    break
                }
                val min = if (useBrowser) 15 else 3
                delay(maxOf(_ui.value.intervalSec, min) * 1000L)
            }
        }
        return null
    }

    fun stop() {
        job?.cancel()
        job = null
        browser.release()
        _ui.update { it.copy(running = false, busy = false, status = "Stopped") }
    }

    /** One extra reading right now (works even after the match finished). */
    fun refreshNow() {
        val url = _ui.value.url
        if (url.isBlank()) return
        scope.launch { fetchOnce(url) }
    }

    private suspend fun fetchOnce(url: String): FeedMatch? = lock.withLock {
        _ui.update { it.copy(busy = true, error = null) }
        lastError = ""
        var match = readUrl(url)
        if (match == null || !match.hasScorecard) {
            for (c in MatchParser.companions(url)) {
                val extra = readUrl(c) ?: continue
                match = if (match == null) extra else MatchParser.combine(url, listOf(match, extra))
                if (match != null && match.hasScorecard) break
            }
        }
        val m = match
        if (m != null && MatchParser.useful(m)) {
            val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            _ui.update {
                it.copy(busy = false, match = m, error = null, status = "Updated $stamp", updatedAt = System.currentTimeMillis(), viaBrowser = useBrowser, fetchCount = it.fetchCount + 1)
            }
            onMatch(m)
            m
        } else {
            _ui.update { it.copy(busy = false, error = lastError.ifBlank { "Could not find a cricket score on this page." }, status = "") }
            null
        }
    }

    private suspend fun readUrl(u: String): FeedMatch? {
        var weak: FeedMatch? = null
        if (!useBrowser) {
            val r = withContext(Dispatchers.IO) { FeedHttp.get(u) }
            val body = r.body
            if (r.ok && body != null) {
                val m = withContext(Dispatchers.Default) { MatchParser.parse(u, body) }
                if (MatchParser.useful(m)) return m
                weak = m
                lastError = "The page has no readable score yet (it may need JavaScript)."
            } else {
                lastError = r.message
            }
        }
        val html = browser.fetch(u)
        if (html != null) {
            val m = withContext(Dispatchers.Default) { MatchParser.parse(u, html) }
            if (MatchParser.useful(m)) {
                useBrowser = true
                return m
            }
            if (weak == null) weak = m
            lastError = "The page opened but no cricket score was found on it."
        } else if (lastError.isEmpty()) {
            lastError = "The page could not be opened."
        }
        return weak
    }
}
