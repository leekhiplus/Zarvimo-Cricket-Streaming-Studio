package com.zarvimo.cricket.feed

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.nio.charset.Charset

/** Plain HTTPS download of a web page (blocking: call from a background thread). */
object FeedHttp {
    class Result(val ok: Boolean, val body: String?, val message: String)

    private const val MAX_BYTES = 8_000_000
    const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

    fun get(url: String, timeoutMs: Int = 15000): Result {
        return try {
            val u = URL(url)
            if (u.protocol != "https" && u.protocol != "http") {
                return Result(false, null, "Only web links (https://...) are supported")
            }
            val c = u.openConnection() as HttpURLConnection
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", USER_AGENT)
            c.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8")
            c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
            val code = c.responseCode
            if (code !in 200..299) {
                c.disconnect()
                return Result(false, null, httpMessage(code))
            }
            val charset = charsetOf(c.contentType)
            val bytes = c.inputStream.use { readLimited(it) }
            c.disconnect()
            Result(true, String(bytes, charset), "OK")
        } catch (e: UnknownHostException) {
            Result(false, null, "No internet connection, or the website address is wrong")
        } catch (e: SocketTimeoutException) {
            Result(false, null, "The website took too long to answer")
        } catch (e: Exception) {
            Result(false, null, e.message ?: "Network error")
        }
    }

    private fun httpMessage(code: Int): String = when (code) {
        401, 403, 429, 503 -> "The website refused the request (HTTP $code). It may block apps"
        404, 410 -> "Page not found (HTTP $code). Check the link"
        else -> "The website answered with HTTP $code"
    }

    private fun charsetOf(contentType: String?): Charset {
        val name = Regex("(?i)charset\\s*=\\s*([\\w-]+)").find(contentType ?: "")?.groupValues?.get(1)
        return try {
            if (name == null) Charsets.UTF_8 else Charset.forName(name)
        } catch (e: Exception) {
            Charsets.UTF_8
        }
    }

    private fun readLimited(input: InputStream): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(16 * 1024)
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
            if (out.size() > MAX_BYTES) break
        }
        return out.toByteArray()
    }
}
