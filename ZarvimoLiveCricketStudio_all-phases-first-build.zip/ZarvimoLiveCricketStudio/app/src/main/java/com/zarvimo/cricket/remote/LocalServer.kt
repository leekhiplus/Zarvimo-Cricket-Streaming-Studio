package com.zarvimo.cricket.remote

import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import org.json.JSONObject

/** What the server needs from the app. All callbacks may be called from server threads. */
interface ServerHost {
    fun stateJson(): String
    /** Blocks (max ~60 s) until the operator approves or denies. Returns the token or null. */
    fun requestPairing(code: String, deviceName: String, remoteAddr: String): String?
    fun handleCommand(c: RemoteCommand): GateResult
    fun applyOnMain(c: RemoteCommand): String?       // null = applied
    fun logoFile(which: String): File?
}

/**
 * Tiny local HTTP server (java.net only, NO extra dependency) serving the OBS overlay, a preview page, the remote-scoring page,
 * Server-Sent Events for live updates (the browser reconnects by itself and keeps showing the last state), and a small JSON API.
 *  - Off by default; the operator starts it. Binds to all local interfaces so other devices on the same Wi-Fi can connect; it is not
 *    exposed to the internet unless the router forwards the port (do not).
 *  - Read endpoints expose only [OverlayJson] data. Write endpoints need a Bearer token from an operator-approved pairing.
 *  - Tokens are only accepted in the Authorization header, never in URLs; nothing secret is logged.
 */
class LocalServer(private val port: Int, private val host: ServerHost, private val log: (String) -> Unit) {
    private var server: ServerSocket? = null
    private val pool = Executors.newFixedThreadPool(24)
    private val sse = CopyOnWriteArrayList<OutputStream>()
    @Volatile private var running = false

    val isRunning get() = running

    fun start(): String? {
        if (running) return null
        return try {
            val s = ServerSocket(port, 20, null as InetAddress?)
            server = s; running = true
            pool.execute { acceptLoop(s) }
            pool.execute { heartbeat() }
            null
        } catch (e: Exception) { "Could not start the server on port $port: ${e.message}" }
    }

    fun stop() {
        running = false
        try { server?.close() } catch (_: Exception) { }
        sse.forEach { try { it.close() } catch (_: Exception) { } }
        sse.clear()
    }

    /** Push the new state to every connected browser. */
    fun broadcast(json: String) {
        val bytes = ("data: " + json + "\n\n").toByteArray()
        for (o in sse) try { synchronized(o) { o.write(bytes); o.flush() } } catch (_: Exception) { sse.remove(o); try { o.close() } catch (_: Exception) { } }
    }

    val clients get() = sse.size

    private fun heartbeat() {
        while (running) {
            try { Thread.sleep(15_000) } catch (_: InterruptedException) { return }
            for (o in sse) try { synchronized(o) { o.write(": hb\n\n".toByteArray()); o.flush() } } catch (_: Exception) { sse.remove(o) }
        }
    }

    private fun acceptLoop(s: ServerSocket) {
        while (running) {
            val c = try { s.accept() } catch (_: Exception) { return }
            try { pool.execute { serve(c) } } catch (_: Exception) { try { c.close() } catch (_: Exception) { } }
        }
    }

    private class Req(val method: String, val path: String, val query: Map<String, String>, val headers: Map<String, String>, val body: String)

    private fun readRequest(inp: InputStream): Req? {
        val bin = BufferedInputStream(inp)
        fun line(): String? {
            val sb = StringBuilder()
            while (true) {
                val b = bin.read(); if (b < 0) return if (sb.isEmpty()) null else sb.toString()
                if (b == '\n'.code) return sb.toString().trimEnd('\r')
                if (sb.length > 4096) return null
                sb.append(b.toChar())
            }
        }
        val first = line() ?: return null
        val p = first.split(" "); if (p.size < 2) return null
        val headers = HashMap<String, String>()
        while (true) { val l = line() ?: return null; if (l.isEmpty()) break; val i = l.indexOf(':'); if (i > 0 && headers.size < 40) headers[l.substring(0, i).trim().lowercase()] = l.substring(i + 1).trim() }
        val len = (headers["content-length"]?.toIntOrNull() ?: 0).coerceIn(0, 8192)
        val buf = ByteArray(len); var got = 0
        while (got < len) { val n = bin.read(buf, got, len - got); if (n < 0) break; got += n }
        val raw = p[1]; val path = raw.substringBefore('?')
        val q = HashMap<String, String>()
        raw.substringAfter('?', "").split('&').filter { it.contains('=') }.forEach { q[it.substringBefore('=')] = java.net.URLDecoder.decode(it.substringAfter('='), "UTF-8") }
        return Req(p[0].uppercase(), path, q, headers, String(buf, 0, got))
    }

    private fun respond(o: OutputStream, code: Int, type: String, body: ByteArray, extra: String = "") {
        val head = "HTTP/1.1 $code ${if (code == 200) "OK" else "Error"}\r\nContent-Type: $type\r\nContent-Length: ${body.size}\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nConnection: close\r\n$extra\r\n"
        o.write(head.toByteArray()); o.write(body); o.flush()
    }
    private fun json(o: OutputStream, code: Int, j: JSONObject) = respond(o, code, "application/json; charset=utf-8", j.toString().toByteArray())

    private fun serve(sock: Socket) {
        var keepOpen = false
        try {
            sock.soTimeout = 10_000
            val out = sock.getOutputStream()
            val r = readRequest(sock.getInputStream()) ?: return
            when {
                r.method == "GET" && r.path == "/overlay" -> respond(out, 200, "text/html; charset=utf-8", WebPages.overlay(false).toByteArray())
                r.method == "GET" && r.path == "/preview" -> respond(out, 200, "text/html; charset=utf-8", WebPages.overlay(true).toByteArray())
                r.method == "GET" && r.path == "/remote" -> respond(out, 200, "text/html; charset=utf-8", WebPages.remote().toByteArray())
                r.method == "GET" && r.path == "/api/state" -> respond(out, 200, "application/json; charset=utf-8", host.stateJson().toByteArray())
                r.method == "GET" && r.path.startsWith("/logo/") -> {
                    val f = host.logoFile(r.path.removePrefix("/logo/"))
                    if (f != null && f.exists() && f.length() < 3_000_000) respond(out, 200, if (f.name.endsWith(".png", true)) "image/png" else "image/jpeg", f.readBytes())
                    else respond(out, 404, "text/plain", "none".toByteArray())
                }
                r.method == "GET" && r.path == "/events" -> {
                    if (sse.size >= 16) { respond(out, 503, "text/plain", "too many viewers".toByteArray()); return }
                    sock.soTimeout = 0
                    out.write("HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nCache-Control: no-store\r\nConnection: keep-alive\r\n\r\nretry: 2000\n\n".toByteArray())
                    out.write(("data: " + host.stateJson() + "\n\n").toByteArray()); out.flush()
                    sse.add(out); keepOpen = true
                }
                r.method == "POST" && r.path == "/api/pair" -> {
                    val b = try { JSONObject(r.body) } catch (_: Exception) { return json(out, 400, JSONObject().put("error", "bad json")) }
                    val token = host.requestPairing(b.optString("code").take(12), b.optString("name", "Remote").take(40), sock.inetAddress.hostAddress ?: "?")
                    if (token == null) json(out, 403, JSONObject().put("error", "Pairing was not approved or the code is wrong/expired"))
                    else json(out, 200, JSONObject().put("token", token))
                }
                r.method == "POST" && r.path == "/api/command" -> {
                    val token = r.headers["authorization"]?.removePrefix("Bearer ")?.trim().orEmpty()
                    val b = try { JSONObject(r.body) } catch (_: Exception) { return json(out, 400, JSONObject().put("error", "bad json")) }
                    val args = HashMap<String, String>()
                    b.optJSONObject("args")?.let { a -> a.keys().forEach { k -> if (args.size < 12) args[k.take(20)] = a.optString(k).take(60) } }
                    val cmd = RemoteCommand(token, b.optString("commandId").take(64), b.optLong("seq", -1), b.optString("action").take(30), args)
                    when (val g = host.handleCommand(cmd)) {
                        is GateResult.Duplicate -> json(out, 200, JSONObject().put("status", "duplicate"))
                        is GateResult.Gap -> json(out, 409, JSONObject().put("error", "sequence gap").put("expected", g.expectedSeq))
                        is GateResult.Reject -> json(out, 403, JSONObject().put("error", g.reason))
                        is GateResult.Accept -> {
                            val err = host.applyOnMain(cmd)
                            if (err == null) json(out, 200, JSONObject().put("status", if (g.needsHostApproval) "queued-for-host" else "ok"))
                            else json(out, 422, JSONObject().put("error", err))
                        }
                    }
                }
                else -> respond(out, 404, "text/plain", "not found".toByteArray())
            }
        } catch (_: SocketTimeoutException) {
        } catch (e: Exception) { log("server: ${e.javaClass.simpleName}") }
        finally { if (!keepOpen) try { sock.close() } catch (_: Exception) { } }
    }
}
