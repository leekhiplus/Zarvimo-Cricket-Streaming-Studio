package com.zarvimo.cricket.highlights

import com.zarvimo.cricket.analytics.Analytics
import com.zarvimo.cricket.scoring.BallRecord

enum class HKind { FOUR, SIX, WICKET, OTHER }

/**
 * EVENT MARKING ONLY. recordingOffsetMs is null when no local recording was running, so no clip can be cut for that marker.
 * Clip extraction (MediaMuxer/MediaExtractor, keyframe aligned, no re-encode) and live replay are separate features and are NOT implemented here.
 */
data class Marker(val eventId: Long, val kind: HKind, val label: String, val wallClockMs: Long, val recordingOffsetMs: Long?)
data class ClipSpec(val startMs: Long, val endMs: Long)

class HighlightLog {
    private val items = mutableListOf<Marker>()
    val markers: List<Marker> get() = items.toList()

    /** Returns the new marker, or null for a non-highlight ball or an event already marked (duplicate protection). */
    fun add(b: BallRecord, nowMs: Long, recordingStartMs: Long?): Marker? {
        val kind = when { b.wicket -> HKind.WICKET; Analytics.isBoundary(b) -> if (b.label.removePrefix("Nb+").startsWith("6")) HKind.SIX else HKind.FOUR; else -> return null }
        if (items.any { it.eventId == b.eventId }) return null
        val m = Marker(b.eventId, kind, "${b.label} – ${b.bowler} to ${b.striker}", nowMs, recordingStartMs?.let { nowMs - it })
        items += m; return m
    }

    fun search(text: String = "", kinds: Set<HKind> = emptySet()) =
        items.filter { (kinds.isEmpty() || it.kind in kinds) && (text.isBlank() || it.label.contains(text, ignoreCase = true)) }

    /** Re-adds a saved marker (loading a match); ignores duplicates. */
    fun restore(m: Marker) { if (items.none { it.eventId == m.eventId }) items += m }

    fun remove(eventId: Long) { items.removeAll { it.eventId == eventId } }

    companion object {
        /** Clip around a marker with pre/post buffers, clamped to the recording. Null when the marker has no recording position. */
        fun clipFor(m: Marker, preMs: Long, postMs: Long, recordingLengthMs: Long): ClipSpec? {
            val at = m.recordingOffsetMs ?: return null
            if (at < 0 || at > recordingLengthMs) return null
            val s = (at - preMs.coerceAtLeast(0)).coerceAtLeast(0)
            val e = (at + postMs.coerceAtLeast(0)).coerceAtMost(recordingLengthMs)
            return if (e > s) ClipSpec(s, e) else null
        }
    }
}
