package com.zarvimo.cricket.report

import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import java.io.OutputStream
import java.util.Locale

/**
 * Writes the scorecard as a real multi-page A4 PDF using the platform PdfDocument (no extra dependency).
 * Text uses the default font: Latin text only. Urdu/Arabic glyphs need a bundled font and are NOT handled here.
 */
object PdfExporter {

    fun lines(r: MatchReport): List<Pair<String, Boolean>> {   // text, bold
        val out = mutableListOf<Pair<String, Boolean>>()
        fun f2(d: Double) = String.format(Locale.US, "%.2f", d)
        out += r.title to true
        if (r.venue.isNotBlank()) out += r.venue to false
        r.toss?.let { out += it to false }
        out += (r.result ?: "Match in progress") to true
        r.manOfMatch?.let { out += "Player of the Match: $it" to false }
        r.innings.forEach { i ->
            val s = i.state
            out += "" to false
            out += "${i.title}  ${s.runs}/${s.wickets} (${s.oversText} ov)" to true
            out += "Batter                      Dismissal                R    B   4s  6s     SR" to true
            s.batters.forEach { b -> out += String.format(Locale.US, "%-26.26s %-22.22s %4d %4d %3d %3d %6s", b.name, if (b.out) (b.dismissal ?: "out") else "not out", b.runs, b.balls, b.fours, b.sixes, f2(b.strikeRate)) to false }
            val e = s.extras
            out += "Extras ${e.total} (w ${e.wides}, nb ${e.noBalls}, b ${e.byes}, lb ${e.legByes}, pen ${e.penalty})" to false
            out += "Total ${s.runs}/${s.wickets} in ${s.oversText} overs, RR ${f2(s.runRate)}" to true
            out += "Bowler                        O    M    R   W   Econ" to true
            s.bowlers.forEach { b -> out += String.format(Locale.US, "%-26.26s %5s %4d %4d %3d %6s", b.name, b.oversText, b.maidens, b.runs, b.wickets, f2(b.economy)) to false }
            if (s.fallOfWickets.isNotEmpty()) out += "FoW: " + s.fallOfWickets.joinToString("; ") { "${it.teamRuns}-${it.wicketNumber} (${it.batter}, ${it.oversText})" } to false
        }
        return out
    }

    fun write(r: MatchReport, out: OutputStream) {
        val doc = PdfDocument()
        val normal = Paint().apply { textSize = 9f; typeface = android.graphics.Typeface.MONOSPACE }
        val bold = Paint(normal).apply { typeface = android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD) }
        val w = 595; val h = 842; val margin = 28f; val lh = 13f
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, pageNo).create())
        var y = margin + lh
        try {
            for ((text, isBold) in lines(r)) {
                // wrap overly long lines at ~88 chars (monospace 9pt on A4)
                text.chunked(88).ifEmpty { listOf("") }.forEach { part ->
                    if (y > h - margin) {
                        doc.finishPage(page); pageNo++
                        page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, pageNo).create()); y = margin + lh
                    }
                    page.canvas.drawText(part, margin, y, if (isBold) bold else normal); y += lh
                }
            }
            doc.finishPage(page)
            doc.writeTo(out)
        } finally { doc.close() }
    }
}
