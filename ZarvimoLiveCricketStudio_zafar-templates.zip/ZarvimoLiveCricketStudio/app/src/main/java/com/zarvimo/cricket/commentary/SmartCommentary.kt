package com.zarvimo.cricket.commentary

import com.zarvimo.cricket.analytics.Analytics
import com.zarvimo.cricket.scoring.InningsState

enum class Lang { EN, UR }
enum class CKind { WICKET, SIX, FOUR, MAIDEN, DOT, RUNS, TARGET, INNINGS_END }
data class CommentaryLine(val eventId: Long, val kind: CKind, val text: String, val priority: Int)

/** Editable offline templates. Placeholders: {batter} {bowler} {runs} {score} {overs} {need} {balls}. */
object DefaultTemplates {
    val PLACEHOLDERS = setOf("batter", "bowler", "runs", "score", "overs", "need", "balls")
    fun forLang(l: Lang): Map<CKind, String> = if (l == Lang.EN) mapOf(
        CKind.WICKET to "Wicket! {bowler} strikes. {batter} is out. {score} after {overs} overs.",
        CKind.SIX to "Six! {batter} hits it out of the park. {score}.",
        CKind.FOUR to "Four runs! Lovely shot from {batter}. {score}.",
        CKind.MAIDEN to "That is a maiden over from {bowler}. {score} after {overs}.",
        CKind.DOT to "Dot ball. {bowler} keeps it tight.",
        CKind.RUNS to "{runs} run{s}. {score} after {overs} overs.",
        CKind.TARGET to "{need} needed from {balls} balls.",
        CKind.INNINGS_END to "End of the innings. {score} in {overs} overs."
    ) else mapOf(
        CKind.WICKET to "آؤٹ! {bowler} نے وکٹ لے لی۔ {batter} واپس۔ {overs} اوورز کے بعد {score}۔",
        CKind.SIX to "چھکا! {batter} کا شاندار شاٹ۔ {score}۔",
        CKind.FOUR to "چوکا! {batter} کا خوبصورت شاٹ۔ {score}۔",
        CKind.MAIDEN to "{bowler} کا میڈن اوور۔ {overs} اوورز کے بعد {score}۔",
        CKind.DOT to "ڈاٹ بال۔ {bowler} نے رنز روک دیے۔",
        CKind.RUNS to "{runs} رن۔ {overs} اوورز کے بعد {score}۔",
        CKind.TARGET to "جیت کے لیے {balls} گیندوں پر {need} رنز درکار ہیں۔",
        CKind.INNINGS_END to "اننگز ختم۔ {overs} اوورز میں {score}۔"
    )

    /** Returns an error text, or null when the template only uses known placeholders. */
    fun validate(t: String): String? {
        if (t.isBlank()) return "Template is empty"
        Regex("\\{([^}]*)\\}").findAll(t).forEach { if (it.groupValues[1] !in PLACEHOLDERS && it.groupValues[1] != "s") return "Unknown placeholder {${it.groupValues[1]}}" }
        return null
    }
}

/**
 * Turns the NEWEST recorded ball into at most one line. Uses only the engine's state, never invents events.
 * Duplicate protection: a ball id is considered once. Routine lines (dot, singles) are spoken every [routineEvery]-th time.
 */
class CommentaryPlanner(
    var lang: Lang = Lang.EN,
    val templates: MutableMap<CKind, String> = DefaultTemplates.forLang(Lang.EN).toMutableMap(),
    var enabled: Boolean = true,
    var paused: Boolean = false,
    var routineEvery: Int = 2
) {
    private var lastEventId = 0L
    private var routineCount = 0
    private var lastMaidens = -1

    fun setLanguage(l: Lang) { lang = l; templates.clear(); templates.putAll(DefaultTemplates.forLang(l)) }

    fun next(st: InningsState): CommentaryLine? {
        val last = st.allBalls.lastOrNull() ?: return null
        if (last.eventId <= lastEventId) return null
        lastEventId = last.eventId
        val maidens = st.bowlers.sumOf { it.maidens }
        val maidenNow = lastMaidens >= 0 && maidens > lastMaidens
        lastMaidens = maidens
        if (!enabled || paused) return null
        val (kind, pri) = when {
            last.wicket -> CKind.WICKET to 3
            st.ended -> CKind.INNINGS_END to 2
            Analytics.isBoundary(last) -> (if (last.label.removePrefix("Nb+").startsWith("6")) CKind.SIX else CKind.FOUR) to 2
            maidenNow -> CKind.MAIDEN to 2
            last.legal && last.runsAdded == 0 -> CKind.DOT to 1
            last.legal && last.runsAdded in 1..3 -> CKind.RUNS to 1
            else -> return null
        }
        if (pri == 1 && (++routineCount % routineEvery.coerceAtLeast(1)) != 0) return null
        return build(last.eventId, kind, pri, st, last.striker, last.bowler, last.runsAdded)
    }

    /** Operator-triggered: describes the current state, bypassing frequency and pause (but not the real score). */
    fun manual(st: InningsState): CommentaryLine? {
        val last = st.allBalls.lastOrNull() ?: return null
        return build(last.eventId, CKind.RUNS, 1, st, last.striker, last.bowler, last.runsAdded, forceNoRun = true)
    }

    private fun build(id: Long, kind: CKind, pri: Int, st: InningsState, batter: String, bowler: String, runs: Int, forceNoRun: Boolean = false): CommentaryLine {
        val tpl = if (forceNoRun) "{score} after {overs} overs." else templates[kind] ?: DefaultTemplates.forLang(lang).getValue(kind)
        var text = fill(tpl, st, batter, bowler, runs)
        val chase = st.target != null && !st.ended && kind in setOf(CKind.WICKET, CKind.FOUR, CKind.SIX, CKind.MAIDEN)
        if (chase) text += " " + fill(templates[CKind.TARGET] ?: DefaultTemplates.forLang(lang).getValue(CKind.TARGET), st, batter, bowler, runs)
        return CommentaryLine(id, kind, text, pri)
    }

    private fun fill(t: String, st: InningsState, batter: String, bowler: String, runs: Int) = t
        .replace("{batter}", batter).replace("{bowler}", bowler).replace("{runs}", runs.toString())
        .replace("{s}", if (runs == 1) "" else "s")
        .replace("{score}", st.scoreText).replace("{overs}", st.oversText)
        .replace("{need}", (st.requiredRuns ?: 0).toString()).replace("{balls}", st.ballsRemaining.toString())

    companion object {
        /** A new line may interrupt a running announcement only when its priority is higher. */
        fun canInterrupt(newPriority: Int, speakingPriority: Int?) = speakingPriority == null || newPriority > speakingPriority
    }
}
