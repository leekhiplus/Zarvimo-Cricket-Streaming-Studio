package com.zarvimo.cricket.ui

import android.content.Intent
import android.content.IntentFilter
import android.media.MediaMetadataRetriever
import android.os.BatteryManager
import android.os.StatFs
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.cricket.commentary.CKind
import com.zarvimo.cricket.graphics.AlertInfo
import com.zarvimo.cricket.graphics.AlertTone
import com.zarvimo.cricket.health.Level
import com.zarvimo.cricket.health.StreamHealth
import com.zarvimo.cricket.health.StreamMetrics
import com.zarvimo.cricket.highlights.ClipSpec
import com.zarvimo.cricket.highlights.HKind
import com.zarvimo.cricket.highlights.HighlightLog
import com.zarvimo.cricket.report.ClipExporter
import com.zarvimo.cricket.sponsors.RotatorState
import com.zarvimo.cricket.stream.StatusLabels
import com.zarvimo.cricket.stream.StreamState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Locale

private fun lanAddress(): String? = try {
    NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp && !it.isLoopback }
        .flatMap { it.inetAddresses.toList() }.firstOrNull { it is Inet4Address && !it.isLoopbackAddress }?.hostAddress
} catch (e: Exception) { null }

private fun mmss(ms: Long) = String.format(Locale.US, "%d:%02d", ms / 60000, (ms / 1000) % 60)

// ---------------------------------------------------------------------------------------------- stream health

@Composable
fun HealthScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val ss by vm.streamStatus.collectAsState()
    val mic by vm.micLevel.collectAsState()
    val recording by vm.engineForHub().recording.collectAsState()
    val settings by vm.stream.collectAsState()
    val log = remember { mutableStateListOf<String>() }
    var battery by remember { mutableStateOf<Int?>(null) }
    var temp by remember { mutableStateOf<Float?>(null) }
    var freeMb by remember { mutableStateOf<Long?>(null) }
    val live = ss.state == StreamState.STREAMING || ss.state == StreamState.RECONNECTING

    LaunchedEffect(Unit) {
        while (true) {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (i != null) {
                val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                battery = if (l >= 0 && sc > 0) l * 100 / sc else null
                val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE); temp = if (t == Int.MIN_VALUE) null else t / 10f
            }
            freeMb = try { (ctx.getExternalFilesDir(null) ?: ctx.filesDir).let { StatFs(it.path).availableBytes / 1_048_576 } } catch (e: Exception) { null }
            delay(2000)
        }
    }
    LaunchedEffect(ss.state, ss.errorMessage) { log.add(0, "${java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(java.util.Date())}  ${StatusLabels.stream(ss.state)}" + (ss.errorMessage?.let { " – $it" } ?: "")); while (log.size > 40) log.removeAt(log.lastIndex) }

    val metrics = StreamMetrics(
        state = StatusLabels.stream(ss.state),
        bitrateKbps = if (live) ss.measuredBitrateBps?.let { (it / 1000).toInt() } else null,
        fps = if (live) ss.measuredFps else null,
        droppedFrames = if (live) ss.droppedFrames else null,
        reconnects = if (ss.reconnectAttempt > 0 || live) ss.reconnectAttempt else null,
        audioPeak = if (live) mic else null,
        freeStorageMb = freeMb, batteryPct = battery, tempC = temp, recording = recording
    )
    val indicators = StreamHealth.evaluate(metrics, if (live) settings.videoBitrateKbps else null, if (live) settings.fps else null)
    val suggestion = if (live) StreamHealth.suggestedBitrateKbps(metrics, settings.videoBitrateKbps, 300) else null

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionCard("Stream health", icon = Ic.Radio) {
            Text("Only measured values are shown. “Unavailable” means the phone or streaming library does not report it.", fontSize = 11.sp, color = Muted)
            indicators.forEach { i ->
                val c = when (i.level) { Level.OK -> Mint; Level.WARN -> Gold; Level.CRITICAL -> Color(0xFFFF6B6B); Level.UNAVAILABLE -> Muted }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(i.name, fontSize = 14.sp); Pill(i.text, c) }
            }
            Text("Battery temperature is the battery sensor, not the processor. Resolution is not reported by the library; configured: ${settings.profile.name} @ ${settings.fps} fps. Recording: " + if (recording) "ON" else "off", fontSize = 11.sp, color = Muted)
        }
        val warnings = indicators.filter { it.level == Level.WARN || it.level == Level.CRITICAL }
        if (warnings.isNotEmpty()) SectionCard("Warnings", icon = Ic.Info) { warnings.forEach { WarnLine("${it.name}: ${it.text}", color = if (it.level == Level.CRITICAL) Color(0xFFFF6B6B) else Gold) } }
        SectionCard("Recommendation & recovery", icon = Ic.Sliders) {
            if (suggestion != null) {
                Text("Measured bitrate is well below the target (${settings.videoBitrateKbps} kbps). Suggested: $suggestion kbps.", fontSize = 13.sp)
                BigButton("Apply $suggestion kbps now", Modifier.fillMaxWidth()) { vm.updateStream { it.copy(videoBitrateKbps = suggestion) } }
            } else Text(if (live) "No bitrate change is recommended right now." else "Recommendations appear while streaming.", fontSize = 13.sp, color = Muted)
            BigButton("Lower bitrate one step", Modifier.fillMaxWidth(), enabled = live) { vm.lowerBitrateNow() }
            Text("Nothing is changed automatically unless you switch these on:", fontSize = 12.sp, color = Muted)
            SwitchRow("Automatic recovery: lower bitrate after a reconnect", settings.lowerBitrateOnReconnect) { v -> vm.updateStream { it.copy(lowerBitrateOnReconnect = v) } }
            SwitchRow("Adaptive bitrate", settings.adaptiveBitrate) { v -> vm.updateStream { it.copy(adaptiveBitrate = v) } }
            if (ss.state == StreamState.ERROR || ss.state == StreamState.RECONNECTING) Text("Reconnecting uses the app's built-in retry (attempt ${ss.reconnectAttempt}/${ss.maxReconnectAttempts}). If it fails: Stop Live, check the server/key and network, then Go Live again.", fontSize = 12.sp)
        }
        val clip = LocalClipboardManager.current
        SectionCard("Diagnostic log", icon = Ic.Info) {
            log.take(12).forEach { Text(it, fontSize = 11.sp, fontFamily = FontFamily.Monospace) }
            BigButton("Copy log", Modifier.fillMaxWidth()) { clip.setText(AnnotatedString(log.joinToString("\n"))) }
        }
    }
}

// ---------------------------------------------------------------------------------------------- highlights

@Composable
fun HighlightsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val markers by vm.hub.markers.collectAsState()
    val pre by vm.hub.preBufferMs.collectAsState()
    val post by vm.hub.postBufferMs.collectAsState()
    var text by remember { mutableStateOf("") }
    var kinds by remember { mutableStateOf<HKind?>(null) }
    val selected = remember { mutableStateListOf<Long>() }
    var source by remember { mutableStateOf<File?>(null) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var startS by remember { mutableStateOf("") }
    var endS by remember { mutableStateOf("") }
    val recordings = remember(markers) { vm.engineForHub().listRecordings() }
    val current = vm.engineForHub().currentRecordingPath()
    val shown = markers.filter { (kinds == null || it.marker.kind == kinds) && (text.isBlank() || it.marker.label.contains(text, true)) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionCard("What is available", icon = Ic.Film) {
            Text("1. Event marking: automatic for fours, sixes and wickets (below).", fontSize = 12.sp)
            Text("2. Clip extraction: from a FINISHED local recording (turn on “Record locally” in Stream settings).", fontSize = 12.sp)
            Text("3. Automatic replay inside the live stream: NOT available in this app.", fontSize = 12.sp, color = Gold)
            Text("Marker time is measured from the moment recording started (accuracy about ±1 s). Your original recording is never modified.", fontSize = 11.sp, color = Muted)
        }
        SectionCard("Timeline (${shown.size})", icon = Ic.Film) {
            TextInput("Search", text, { text = it })
            ChipChoice(listOf<HKind?>(null) + HKind.values().toList(), kinds, { it?.name ?: "All" }) { kinds = it }
            if (shown.isEmpty()) Text("No highlight events yet.", fontSize = 13.sp, color = Muted)
            shown.forEach { sm ->
                val m = sm.marker
                val ok = m.recordingOffsetMs != null
                SwitchRow("${m.kind.name}  ${m.label}  " + (if (ok) "@ ${mmss(m.recordingOffsetMs!!)}" else "(no recording)"), m.eventId in selected) { on -> if (on) selected.add(m.eventId) else selected.remove(m.eventId) }
            }
        }
        SectionCard("Export clips", icon = Ic.Save) {
            LabeledSlider("Before the event", pre.toFloat(), 0f..30000f, "${pre / 1000} s") { vm.hub.preBufferMs.value = it.toLong() }
            LabeledSlider("After the event", post.toFloat(), 0f..30000f, "${post / 1000} s") { vm.hub.postBufferMs.value = it.toLong() }
            Text("Source recording", fontSize = 12.sp, color = Muted)
            val finished = recordings.filter { it.absolutePath != current }
            if (finished.isEmpty()) Text("No finished recording yet.", fontSize = 13.sp, color = Muted)
            else ChipChoice(finished, source ?: finished.first(), { it.name.removePrefix("Zarvimo_").removeSuffix(".mp4") }) { source = it }
            Text("Optional manual clip (seconds in the recording)", fontSize = 12.sp, color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextInput("Start", startS, { startS = it }, Modifier.weight(1f), numeric = true)
                TextInput("End", endS, { endS = it }, Modifier.weight(1f), numeric = true)
            }
            BigButton(if (busy) "Exporting…" else "Export selected clips as one reel", Modifier.fillMaxWidth(), Gold, Color.Black, enabled = !busy && finished.isNotEmpty()) {
                val src = source ?: finished.first()
                busy = true; msg = null
                scope.launch {
                    val err: String? = withContext(Dispatchers.IO) {
                        val len = try { MediaMetadataRetriever().run { setDataSource(src.absolutePath); val d = extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L; release(); d } } catch (e: Exception) { 0L }
                        if (len <= 0) return@withContext "The recording could not be read (is it finished?)"
                        val clips = markers.filter { it.marker.eventId in selected && it.recordingFile == src.absolutePath }.mapNotNull { HighlightLog.clipFor(it.marker, pre, post, len) }.toMutableList()
                        val s = startS.toDoubleOrNull(); val e = endS.toDoubleOrNull()
                        if (s != null && e != null && e > s && s >= 0 && e * 1000 <= len) clips += ClipSpec((s * 1000).toLong(), (e * 1000).toLong())
                        if (clips.isEmpty()) return@withContext "Nothing to export: select events that belong to this recording, or enter a valid start/end."
                        val out = File(exportDir(ctx), "highlights_${System.currentTimeMillis()}.mp4")
                        val r = ClipExporter.export(src.absolutePath, clips.sortedBy { it.startMs }, out.absolutePath)
                        if (r == null) { withContext(Dispatchers.Main) { shareFile(ctx, out, "video/mp4") } }
                        r
                    }
                    busy = false; msg = err
                }
            }
            msg?.let { WarnLine(it) }
            Text("Clips start at the nearest earlier keyframe (no re-encoding). Title cards and score graphics are not burned into video: export them as PNG from Graphics package.", fontSize = 11.sp, color = Muted)
        }
    }
}

// ---------------------------------------------------------------------------------------------- sponsors

@Composable
fun SponsorsScreen(vm: AppViewModel) {
    val sponsors by vm.hub.sponsors.collectAsState()
    val state by vm.hub.sponsorState.collectAsState()
    val now by vm.hub.sponsorNow.collectAsState()
    val exposure by vm.hub.exposure.collectAsState()
    val history by vm.hub.history.collectAsState()
    var name by remember { mutableStateOf("") }
    var secs by remember { mutableStateOf("8") }
    var logo by remember { mutableStateOf<String?>(null) }
    var preview by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    val scope = rememberCoroutineScope()
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) scope.launch { logo = withContext(Dispatchers.IO) { vm.hub.importLogo(uri) } } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionCard("On air", icon = Ic.Cricket) {
            Text("State: ${state.name}" + (now?.let { "   now: ${it.name}" } ?: ""), fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton("Start", Modifier.weight(1f), Gold, Color.Black, enabled = state == RotatorState.STOPPED) { vm.hub.sponsorStart() }
                BigButton(if (state == RotatorState.PAUSED) "Resume" else "Pause", Modifier.weight(1f), enabled = state != RotatorState.STOPPED) { if (state == RotatorState.PAUSED) vm.hub.sponsorResume() else vm.hub.sponsorPause() }
                BigButton("Stop", Modifier.weight(1f), enabled = state != RotatorState.STOPPED) { vm.hub.sponsorStop() }
            }
            Text("Each sponsor appears as a banner through the normal graphics system (it will not cover a DRS or break banner you put on air). If the sponsor slot in Graphics settings is on, the sponsor logo rotates there too. Boundary and innings-break sponsor graphics are not implemented.", fontSize = 11.sp, color = Muted)
        }
        SectionCard("Sponsors (${sponsors.size})", icon = Ic.Layers) {
            if (sponsors.isEmpty()) Text("No sponsors yet. Add one below.", fontSize = 13.sp, color = Muted)
            sponsors.forEach { s ->
                SwitchRow("${s.name} · ${s.durationMs / 1000}s" + if (s.logoPath != null) " · logo" else "", s.enabled) { vm.hub.toggleSponsor(s.id) }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    BigButton("Up", Modifier.weight(1f)) { vm.hub.moveSponsor(s.id, -1) }
                    BigButton("Down", Modifier.weight(1f)) { vm.hub.moveSponsor(s.id, 1) }
                    BigButton("Preview", Modifier.weight(1f)) { scope.launch { preview = withContext(Dispatchers.Default) { vm.renderCard(null, null, 960, 540, true, AlertInfo(s.name.uppercase(), "SPONSOR", AlertTone.GREY.color, false)) } } }
                    BigButton("Delete", Modifier.weight(1f), Color(0xFF8E1B1B)) { vm.hub.removeSponsor(s.id) }
                }
            }
            preview?.let { Image(it.asImageBitmap(), "Preview", Modifier.fillMaxWidth()) }
        }
        SectionCard("Add sponsor", icon = Ic.Save) {
            TextInput("Display name", name, { name = it })
            TextInput("Seconds on screen (3–60)", secs, { secs = it }, numeric = true)
            BigButton(if (logo == null) "Choose logo (optional)" else "Logo chosen", Modifier.fillMaxWidth()) { pick.launch("image/*") }
            BigButton("Add", Modifier.fillMaxWidth(), Gold, Color.Black, enabled = name.isNotBlank()) { vm.hub.addSponsor(name, logo, secs.toIntOrNull() ?: 8); name = ""; logo = null }
        }
        SectionCard("Exposure report", icon = Ic.Activity) {
            val counts = history.groupingBy { it.sponsorId }.eachCount()
            if (history.isEmpty()) Text("No appearances recorded yet.", fontSize = 13.sp, color = Muted)
            sponsors.forEach { s -> if (counts.containsKey(s.id)) Text("${s.name}: ${counts[s.id]} appearances, ${(exposure[s.id] ?: 0) / 1000} s on screen (this session)", fontSize = 13.sp) }
            Text("Totals count time the sponsor was set on air; they cannot tell whether viewers watched.", fontSize = 11.sp, color = Muted)
        }
    }
}

// ---------------------------------------------------------------------------------------------- remote scoring

@Composable
fun RemoteScreen(vm: AppViewModel) {
    val hub = vm.hub
    val ui by hub.serverUi.collectAsState()
    val code by hub.pairingCode.collectAsState()
    val pairing by hub.pairing.collectAsState()
    val devices by hub.devices.collectAsState()
    val requests by hub.requests.collectAsState()
    val log by hub.serverLog.collectAsState()
    val ip = remember(ui.running) { lanAddress() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionCard("Remote scoring host", icon = Ic.Sliders) {
            Text("This phone is the only authority: every remote action goes through the same scoring rules, and each command is applied only once even if it is delivered twice.", fontSize = 12.sp, color = Muted)
            Text(if (ui.running) "Server ON · ${ui.viewers} browser(s) connected" else "Server OFF", fontWeight = FontWeight.Bold, color = if (ui.running) Mint else Muted)
            ui.error?.let { WarnLine(it) }
            BigButton(if (ui.running) "Stop server" else "Start server", Modifier.fillMaxWidth(), if (ui.running) Color(0xFF8E1B1B) else Gold, if (ui.running) Color.White else Color.Black) { if (ui.running) hub.serverStop() else hub.serverStart() }
            if (ui.running) {
                if (ip == null) WarnLine("No Wi-Fi / local network address found. Connect to the same Wi-Fi as the scorer's phone (or enable the hotspot).")
                else Text("Scorer opens:  http://$ip:${hub.port}/remote", fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                Text("Local network only. Do not forward this port on your router. QR code is not included: type or share the address.", fontSize = 11.sp, color = Muted)
            }
        }
        if (ui.running) {
            SectionCard("Pair a device", icon = Ic.Sliders) {
                Text(code?.let { "Code: $it (valid 2 minutes, single use)" } ?: "No code shown", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Gold)
                BigButton("New pairing code", Modifier.fillMaxWidth()) { hub.newPairingCode() }
                Text("You must also approve each device when it asks. Remote devices can score and request undo; they never receive your stream key.", fontSize = 11.sp, color = Muted)
            }
        }
        SectionCard("Connected devices (${devices.size})", icon = Ic.Radio) {
            if (devices.isEmpty()) Text("None", fontSize = 13.sp, color = Muted)
            devices.forEach { d -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(d.name, fontSize = 14.sp); BigButton("Disconnect", Modifier, Color(0xFF8E1B1B)) { hub.disconnect(d.deviceId) } } }
        }
        if (requests.isNotEmpty()) SectionCard("Requests from remote devices", icon = Ic.Info) {
            requests.forEach { r ->
                Text("${r.deviceName}: ${if (r.action == "UNDO_REQUEST") "undo the last event" else "correction needed"}", fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BigButton(if (r.action == "UNDO_REQUEST") "Approve undo" else "Done", Modifier.weight(1f), Gold, Color.Black) { hub.resolveRequest(r.id, true) }
                    BigButton("Dismiss", Modifier.weight(1f)) { hub.resolveRequest(r.id, false) }
                }
            }
            Text("Conflicts are resolved here: nothing from a remote device that changes history is applied until you approve it.", fontSize = 11.sp, color = Muted)
        }
        SectionCard("Log", icon = Ic.Info) { log.take(8).forEach { Text(it, fontSize = 11.sp, fontFamily = FontFamily.Monospace) } }
    }
    pairing?.let { p ->
        AlertDialog(onDismissRequest = { hub.answerPairing(false) }, title = { Text("Allow this device?") },
            text = { Text("“${p.name}” from ${p.address} wants to score this match.") },
            confirmButton = { TextButton(onClick = { hub.answerPairing(true) }) { Text("Allow") } },
            dismissButton = { TextButton(onClick = { hub.answerPairing(false) }) { Text("Deny") } })
    }
}

// ---------------------------------------------------------------------------------------------- OBS / integrations

@Composable
fun ObsScreen(vm: AppViewModel) {
    val ui by vm.hub.serverUi.collectAsState()
    val clip = LocalClipboardManager.current
    val ip = remember(ui.running) { lanAddress() ?: "PHONE-IP" }
    val base = "http://$ip:${vm.hub.port}"
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionCard("Browser-source overlay", icon = Ic.Layers) {
            Text(if (ui.running) "Server is ON (${ui.viewers} viewer(s))" else "Server is OFF: start it in Remote scoring first.", color = if (ui.running) Mint else Gold, fontSize = 13.sp)
            BigButton("Start server", Modifier.fillMaxWidth(), enabled = !ui.running) { vm.hub.serverStart() }
            listOf("Overlay (transparent)" to "$base/overlay", "Compact layout" to "$base/overlay?layout=compact", "Full layout (batters + bowler)" to "$base/overlay?layout=full", "Preview page (checker background)" to "$base/preview").forEach { (l, u) ->
                Text(l, fontSize = 12.sp, color = Muted); Text(u, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                BigButton("Copy", Modifier.fillMaxWidth().heightIn(min = 40.dp)) { clip.setText(AnnotatedString(u)) }
            }
        }
        SectionCard("OBS setup", icon = Ic.Info) {
            Text("1. PC and phone on the same Wi-Fi.  2. In OBS: Sources → + → Browser.  3. Paste the overlay address, width 1920, height 1080.  4. Leave “Shutdown source when not visible” off.  5. The page keeps the last score if Wi-Fi drops and reconnects by itself.", fontSize = 12.sp)
            Text("Overlay shows score, overs, wickets, batters, bowler, required rate, team colours and logos. Layout is chosen with ?layout=bar | compact | full.", fontSize = 12.sp)
            Text("Direct OBS control (scene switching, OBS WebSocket) is not implemented: it would need OBS WebSocket credentials and a client library.", fontSize = 11.sp, color = Muted)
        }
        SectionCard("Local API", icon = Ic.Activity) {
            Text("GET $base/api/state — read-only match JSON (no keys, tokens or file paths)\nGET $base/events — live updates (Server-Sent Events)\nPOST $base/api/pair, /api/command — need operator-approved pairing; token only in the Authorization header", fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            Text("Anyone on your Wi-Fi can read the read-only state while the server is ON. Turn the server off when you do not need it.", fontSize = 11.sp, color = Muted)
        }
    }
}

// ---------------------------------------------------------------------------------------------- smart commentary

@Composable
fun CommentaryScreen(vm: AppViewModel) {
    val hub = vm.hub
    val c by hub.commentary.collectAsState()
    val log by hub.commentaryLog.collectAsState()
    val auto by vm.autoShow.collectAsState()
    var paused by remember { mutableStateOf(false) }
    var kind by remember { mutableStateOf(CKind.WICKET) }
    var tpl by remember(kind, c.urdu) { mutableStateOf(hub.planner.templates[kind] ?: "") }
    var err by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionCard("Smart commentary", icon = Ic.Chat) {
            Text("Lines are built offline from the real match state (score, names, overs, target). Nothing is made up and no internet is needed.", fontSize = 12.sp, color = Muted)
            SwitchRow("Automatic commentary", c.enabled) { v -> hub.updateCommentary { it.copy(enabled = v) } }
            SwitchRow("Pause", paused) { paused = it; hub.setPaused(it) }
            SwitchRow("Speak aloud (uses the existing voice into the stream)", c.spoken) { v -> hub.updateCommentary { it.copy(spoken = v) } }
            SwitchRow("Urdu", c.urdu) { v -> hub.updateCommentary { it.copy(urdu = v) } }
            LabeledSlider("Routine balls: speak every", c.routineEvery.toFloat(), 1f..8f, "${c.routineEvery}") { v -> hub.updateCommentary { it.copy(routineEvery = v.toInt()) } }
            if (auto.voiceEnabled) Text("The existing four / six / wicket voice is ON, so those events are not spoken twice. Smart commentary covers maidens, runs and dots.", fontSize = 11.sp, color = Gold)
            BigButton("Speak the current situation now", Modifier.fillMaxWidth(), Gold, Color.Black) { hub.speakNow() }
            Text("A wicket line may interrupt other lines; routine lines never interrupt a running announcement.", fontSize = 11.sp, color = Muted)
        }
        SectionCard("Templates", icon = Ic.Sliders) {
            ChipChoice(CKind.values().toList(), kind, { it.name.lowercase().replace('_', ' ') }) { kind = it; err = null }
            TextInput("Template", tpl, { tpl = it }, singleLine = false)
            Text("Placeholders: {batter} {bowler} {runs} {score} {overs} {need} {balls}", fontSize = 11.sp, color = Muted)
            err?.let { WarnLine(it) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton("Save", Modifier.weight(1f), Gold, Color.Black) { err = hub.setTemplate(kind, tpl) }
                BigButton("Reset all", Modifier.weight(1f)) { hub.resetTemplates(); tpl = hub.planner.templates[kind] ?: "" }
            }
        }
        SectionCard("Recent lines", icon = Ic.Info) { if (log.isEmpty()) Text("Nothing yet.", fontSize = 13.sp, color = Muted); log.take(8).forEach { Text("• $it", fontSize = 12.sp) } }
    }
}
