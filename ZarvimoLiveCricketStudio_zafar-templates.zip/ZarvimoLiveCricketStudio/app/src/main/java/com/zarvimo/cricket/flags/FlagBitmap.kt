package com.zarvimo.cricket.flags

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Build

/**
 * Draws a country's flag emoji into a transparent bitmap (cropped to the flag) so the existing scoreboard templates can show it in the
 * normal team-logo slot. Uses the phone's colour-emoji font; if the phone cannot draw that flag (old Android), returns null instead of
 * showing two letters. A logo the operator uploads always wins over the flag.
 */
object FlagBitmap {
    private val cache = HashMap<String, Bitmap?>()

    @Synchronized
    fun forTeam(teamName: String): Bitmap? {
        val code = CountryFlags.codeFor(teamName) ?: return null
        if (!cache.containsKey(code)) cache[code] = draw(code)
        return cache[code]
    }

    private fun draw(code: String): Bitmap? = try {
        val e = CountryFlags.emoji(code)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 300f }
        if (Build.VERSION.SDK_INT >= 23 && !p.hasGlyph(e)) null else {
            val size = 480
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val fm = p.fontMetrics
            Canvas(bmp).drawText(e, (size - p.measureText(e)) / 2f, size / 2f - (fm.ascent + fm.descent) / 2f, p)
            trim(bmp)
        }
    } catch (ex: Exception) { null }

    private fun trim(b: Bitmap): Bitmap? {
        val w = b.width; val h = b.height
        val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        var x0 = w; var y0 = h; var x1 = -1; var y1 = -1
        for (y in 0 until h) for (x in 0 until w) if ((px[y * w + x] ushr 24) > 12) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y }
        if (x1 < x0 || y1 < y0) return null
        return Bitmap.createBitmap(b, x0, y0, x1 - x0 + 1, y1 - y0 + 1)
    }
}
