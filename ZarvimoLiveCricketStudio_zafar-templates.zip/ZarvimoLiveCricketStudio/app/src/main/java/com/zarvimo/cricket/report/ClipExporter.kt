package com.zarvimo.cricket.report

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import com.zarvimo.cricket.highlights.ClipSpec
import java.io.File
import java.nio.ByteBuffer

/**
 * Clip extraction from an EXISTING, FINISHED recording by re-muxing (no re-encode, no quality loss, streams sample by sample so
 * the file is never loaded into memory). Limits: the cut starts at the keyframe at or before the requested start; the source file
 * is never modified; a recording that is still being written cannot be read; title cards / score graphics are NOT burned in
 * (that would need re-encoding) - export them as PNG from the Graphics package instead.
 */
object ClipExporter {
    /** Returns null on success, else an error text. Several clips are joined into one highlights reel. */
    fun export(srcPath: String, clips: List<ClipSpec>, outPath: String): String? {
        if (clips.isEmpty()) return "No clips selected"
        if (!File(srcPath).exists()) return "Recording file not found"
        val ex = MediaExtractor()
        var mux: MediaMuxer? = null
        var started = false
        try {
            ex.setDataSource(srcPath)
            mux = MediaMuxer(outPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val map = HashMap<Int, Int>()
            var maxIn = 2 shl 20
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                    ex.selectTrack(i)
                    map[i] = mux.addTrack(f)
                    if (f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) maxIn = maxOf(maxIn, f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE))
                }
            }
            if (map.isEmpty()) return "The recording has no audio/video track"
            mux.start(); started = true
            val buf = ByteBuffer.allocate(maxIn)
            val info = MediaCodec.BufferInfo()
            var base = 0L
            for (c in clips) {
                ex.seekTo(c.startMs * 1000, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                var first = -1L
                var lastOut = base
                while (true) {
                    buf.clear()
                    val n = ex.readSampleData(buf, 0)
                    if (n < 0) break
                    val t = ex.sampleTime
                    if (t > c.endMs * 1000) break
                    if (first < 0) first = t
                    val flags = if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    info.set(0, n, base + (t - first).coerceAtLeast(0), flags)
                    map[ex.sampleTrackIndex]?.let { mux.writeSampleData(it, buf, info) }
                    lastOut = info.presentationTimeUs
                    ex.advance()
                }
                base = lastOut + 33_000
            }
            return null
        } catch (e: Exception) {
            File(outPath).delete()
            return "Clip export failed (${e.javaClass.simpleName}): ${e.message ?: "unknown"}"
        } finally {
            try { if (started) mux?.stop() } catch (_: Exception) { }
            try { mux?.release() } catch (_: Exception) { }
            ex.release()
        }
    }
}
