package com.zarvimo.cricket.remote

import com.zarvimo.cricket.graphics.MatchVisuals
import com.zarvimo.cricket.scoring.InningsState
import com.zarvimo.cricket.scoring.MatchSetup
import org.json.JSONArray
import org.json.JSONObject

/**
 * The ONLY match data sent to browsers (OBS overlay, remote page). Built from the engine state; contains no stream key,
 * no tokens, no file paths and no settings. Pure Kotlin + org.json.
 */
object OverlayJson {
    private fun hex(c: Int) = String.format("#%06X", c and 0xFFFFFF)

    fun build(setup: MatchSetup, visuals: MatchVisuals, st: InningsState?, result: String?, hasLogoA: Boolean, hasLogoB: Boolean): JSONObject {
        val o = JSONObject().put("title", setup.title).put("teamA", setup.teamA).put("teamB", setup.teamB)
            .put("colorA", hex(visuals.teamAColor)).put("colorB", hex(visuals.teamBColor))
            .put("logoA", hasLogoA).put("logoB", hasLogoB).put("result", result ?: JSONObject.NULL)
        if (st == null) return o.put("live", false)
        val batIsA = st.battingTeam == setup.teamA
        o.put("live", true).put("battingTeam", st.battingTeam).put("bowlingTeam", st.bowlingTeam)
            .put("battingColor", hex(if (batIsA) visuals.teamAColor else visuals.teamBColor))
            .put("bowlingColor", hex(if (batIsA) visuals.teamBColor else visuals.teamAColor))
            .put("battingLogo", if (batIsA) "a" else "b")
            .put("runs", st.runs).put("wickets", st.wickets).put("score", st.scoreText).put("overs", st.oversText).put("oversLimit", st.oversLimit)
            .put("runRate", String.format("%.2f", st.runRate))
            .put("target", st.target ?: JSONObject.NULL).put("requiredRuns", st.requiredRuns ?: JSONObject.NULL)
            .put("ballsLeft", st.ballsRemaining)
            .put("requiredRate", st.requiredRunRate?.let { String.format("%.2f", it) } ?: JSONObject.NULL)
            .put("ended", st.ended).put("freeHit", st.freeHit)
            .put("recent", JSONArray().also { a -> st.recentBalls.forEach { a.put(it.label) } })
        st.striker?.let { o.put("striker", JSONObject().put("name", it.name).put("runs", it.runs).put("balls", it.balls)) }
        st.nonStriker?.let { o.put("nonStriker", JSONObject().put("name", it.name).put("runs", it.runs).put("balls", it.balls)) }
        st.bowler?.let { o.put("bowler", JSONObject().put("name", it.name).put("figures", it.figuresText)) }
        return o
    }
}
