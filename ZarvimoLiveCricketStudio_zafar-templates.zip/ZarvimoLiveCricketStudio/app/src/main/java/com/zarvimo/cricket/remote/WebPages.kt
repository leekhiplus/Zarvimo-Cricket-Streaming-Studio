package com.zarvimo.cricket.remote

/** Self-contained pages (no external scripts). All dynamic text is inserted with textContent, never innerHTML. */
object WebPages {

    fun overlay(preview: Boolean): String = """<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Zarvimo overlay</title><style>
html,body{margin:0;height:100%;overflow:hidden;font-family:Arial,Helvetica,sans-serif;background:${if (preview) "repeating-conic-gradient(#2a2a2a 0% 25%,#3a3a3a 0% 50%) 50% / 40px 40px" else "transparent"}}
#wrap{position:absolute;color:#fff;text-shadow:0 1px 3px #000}
.bar #wrap{left:2%;right:2%;bottom:4%}.compact #wrap{left:2%;top:3%;width:34%;min-width:260px}.full #wrap{left:2%;right:2%;bottom:4%}
.row{display:flex;align-items:stretch;background:rgba(10,14,30,.88);border-radius:8px;overflow:hidden;margin-top:4px}
#team{padding:10px 18px;font-weight:800;font-size:3.2vmin;display:flex;align-items:center;gap:10px;min-width:20%}
#team img{height:5vmin;display:none}
#score{padding:6px 18px;font-weight:900;font-size:5vmin;background:rgba(0,0,0,.35);display:flex;align-items:center}
#info{padding:6px 18px;font-size:2.6vmin;flex:1;display:flex;flex-direction:column;justify-content:center}
#recent{display:flex;gap:6px;align-items:center;padding:0 14px}.b{min-width:3vmin;height:3vmin;line-height:3vmin;text-align:center;border-radius:50%;background:#37474f;font-size:1.9vmin;font-weight:700}
.b.f{background:#1e88e5}.b.s{background:#8e24aa}.b.w{background:#d32f2f}
.compact #info2,.bar #info2{display:none}#info2{font-size:2.4vmin;padding:6px 18px}
#status{position:fixed;right:6px;top:4px;font-size:11px;color:#ff8;display:none}
</style></head><body class="bar"><div id="wrap"><div class="row"><div id="team"><img id="logo" alt=""><span id="tn">--</span></div><div id="score">0/0</div><div id="info"><div id="l1"></div><div id="l2"></div></div><div id="recent"></div></div>
<div class="row" id="info2"><span id="bat"></span></div></div><div id="status">reconnecting…</div>
<script>
var q=new URLSearchParams(location.search);var layout=q.get('layout')||'bar';document.body.className=layout;
var last=null;
function t(id,v){document.getElementById(id).textContent=v==null?'':v}
function draw(s){last=s;
 var row=document.getElementById('team');
 if(!s.live){t('tn',s.teamA+' v '+s.teamB);t('score','');t('l1',s.result||'Waiting for the match');t('l2','');document.getElementById('recent').textContent='';return}
 row.style.background=s.battingColor;t('tn',s.battingTeam);t('score',s.score);
 var lg=document.getElementById('logo');var has=(s.battingLogo=='a'&&s.logoA)||(s.battingLogo=='b'&&s.logoB);
 if(has){lg.src='/logo/'+s.battingLogo;lg.style.display='block'}else{lg.style.display='none'}
 var l1=s.overs+' / '+s.oversLimit+' ov   RR '+s.runRate;if(s.freeHit)l1+='   FREE HIT';t('l1',l1);
 var l2='';if(s.target!=null&&!s.ended){l2='Need '+s.requiredRuns+' from '+s.ballsLeft+' balls'+(s.requiredRate?'   RRR '+s.requiredRate:'')}
 if(s.result)l2=s.result;t('l2',l2);
 var r=document.getElementById('recent');r.textContent='';(s.recent||[]).forEach(function(x){var e=document.createElement('span');e.className='b'+(x=='4'?' f':x=='6'?' s':(x.indexOf('W')>=0?' w':''));e.textContent=x;r.appendChild(e)});
 var bt='';if(s.striker)bt+=s.striker.name+' '+s.striker.runs+'('+s.striker.balls+')*';if(s.nonStriker)bt+='   '+s.nonStriker.name+' '+s.nonStriker.runs+'('+s.nonStriker.balls+')';if(s.bowler)bt+='   |  '+s.bowler.name+' '+s.bowler.figures;
 t('bat',bt);if(layout=='full')document.getElementById('info2').style.display='flex'}
function show(on){document.getElementById('status').style.display=on?'block':'none'}
function connect(){var es=new EventSource('/events');es.onmessage=function(e){show(false);try{draw(JSON.parse(e.data))}catch(x){}};es.onerror=function(){show(true)}}
connect();
setInterval(function(){if(document.getElementById('status').style.display=='block'){fetch('/api/state').then(function(r){return r.json()}).then(function(j){draw(j);show(false)}).catch(function(){})}},5000);
</script></body></html>"""

    fun remote(): String = """<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Zarvimo remote scoring</title><style>
body{font-family:Arial,sans-serif;background:#070b16;color:#fff;margin:0;padding:12px}h2{color:#ffc107;margin:6px 0}
button{font-size:20px;padding:14px 0;margin:3px;border:0;border-radius:10px;background:#1a2444;color:#fff;min-width:22%}button.g{background:#ffc107;color:#000}button.r{background:#8e1b1b}
button:disabled{opacity:.4}input,select{font-size:18px;padding:10px;margin:3px;border-radius:8px;border:1px solid #26335a;background:#111830;color:#fff;width:90%}
#sc{font-size:34px;font-weight:900}#msg{min-height:24px;color:#ff8}.card{background:#111830;border-radius:12px;padding:10px;margin:8px 0}#conn{font-size:12px;color:#9aa6c7}
</style></head><body><h2>Zarvimo remote scoring</h2><div id="conn">connecting…</div>
<div class="card" id="pair"><div>Enter the 6-digit code shown on the host phone, then wait for the host to approve.</div>
<input id="code" inputmode="numeric" maxlength="6" placeholder="Code"><input id="dn" placeholder="Device name" value="Scorer phone"><button class="g" onclick="doPair()">Pair</button></div>
<div id="ctl" style="display:none"><div class="card"><div id="sc">--</div><div id="ov"></div><div id="pl"></div></div>
<div class="card"><div>Runs</div><span id="rb"></span></div>
<div class="card"><div>Extras</div><button onclick="ex('WIDE')">Wd</button><button onclick="ex('NO_BALL')">Nb</button><button onclick="ex('BYE')">Bye</button><button onclick="ex('LEG_BYE')">LB</button></div>
<div class="card"><div>Wicket</div><select id="wt"><option>BOWLED</option><option>CAUGHT</option><option>LBW</option><option>STUMPED</option><option>RUN_OUT</option><option>HIT_WICKET</option></select><button class="r" onclick="wk()">Wicket</button>
<input id="inc" placeholder="Next batter (optional)"></div>
<div class="card"><input id="nm" placeholder="Bowler / batter name"><button onclick="nm('SET_BOWLER')">Set bowler</button><button onclick="nm('NEW_BATTER')">New batter</button></div>
<div class="card"><button onclick="send('UNDO_REQUEST',{})">Ask host to undo</button></div></div><div id="msg"></div>
<script>
var tok=sessionStorage.zt||'';var busy=false;
function msg(m){document.getElementById('msg').textContent=m}
function rid(){return Math.random().toString(36).slice(2)+Date.now().toString(36)}
function ui(){document.getElementById('pair').style.display=tok?'none':'block';document.getElementById('ctl').style.display=tok?'block':'none'}
function doPair(){msg('Waiting for the host to approve…');fetch('/api/pair',{method:'POST',body:JSON.stringify({code:document.getElementById('code').value,name:document.getElementById('dn').value})}).then(function(r){return r.json()}).then(function(j){if(j.token){tok=j.token;sessionStorage.zt=tok;sessionStorage.zs=1;msg('Paired');ui()}else msg(j.error||'Failed')}).catch(function(){msg('Network error')})}
function send(action,args){if(busy)return;busy=true;post(rid(),+sessionStorage.zs||1,action,args)}
function post(id,seq,action,args){fetch('/api/command',{method:'POST',headers:{'Authorization':'Bearer '+tok,'Content-Type':'application/json'},body:JSON.stringify({commandId:id,seq:seq,action:action,args:args})})
.then(function(r){return r.json().then(function(j){return{s:r.status,j:j}})}).then(function(x){
 if(x.s==409){sessionStorage.zs=x.j.expected;post(id,x.j.expected,action,args);return}
 if(x.s==403&&x.j.error=='Not paired'){tok='';sessionStorage.zt='';ui()}
 if(x.s!=409)sessionStorage.zs=seq+1;busy=false;msg(x.s==200?'OK ('+x.j.status+')':(x.j.error||'Error'))})
.catch(function(){msg('Network lost, retrying the same command…');setTimeout(function(){post(id,seq,action,args)},2000)})}
function ex(t){var n=prompt('Extra runs (beyond the automatic penalty / total byes):','0');if(n===null)return;send('EXTRA',{type:t,extraRuns:n,runsBat:'0'})}
function wk(){send('WICKET',{type:document.getElementById('wt').value,incoming:document.getElementById('inc').value})}
function nm(a){send(a,{name:document.getElementById('nm').value})}
var rb=document.getElementById('rb');[0,1,2,3,4,5,6].forEach(function(n){var b=document.createElement('button');b.textContent=n;b.onclick=function(){send('RUNS',{runs:n,boundary:(n==4||n==6)?'true':'false'})};rb.appendChild(b)});
function draw(s){document.getElementById('conn').textContent='connected';if(!s.live){document.getElementById('sc').textContent='No innings';return}
 document.getElementById('sc').textContent=s.battingTeam+' '+s.score;document.getElementById('ov').textContent=s.overs+' / '+s.oversLimit+' ov';
 document.getElementById('pl').textContent=(s.striker?s.striker.name+'* ':'')+(s.nonStriker?s.nonStriker.name+'  ':'')+(s.bowler?'| '+s.bowler.name:'')}
var es=new EventSource('/events');es.onmessage=function(e){try{draw(JSON.parse(e.data))}catch(x){}};es.onerror=function(){document.getElementById('conn').textContent='disconnected – reconnecting…'};
ui();
</script></body></html>"""
}
