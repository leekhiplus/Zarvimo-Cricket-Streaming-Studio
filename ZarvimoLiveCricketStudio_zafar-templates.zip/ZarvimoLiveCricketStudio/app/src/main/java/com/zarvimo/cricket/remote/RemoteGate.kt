package com.zarvimo.cricket.remote

import java.security.SecureRandom

enum class RemoteAction(val needsHostApproval: Boolean = false) { RUNS, WICKET, EXTRA, SET_BOWLER, NEW_BATTER, UNDO_REQUEST(true), CORRECTION_REQUEST(true) }

data class RemoteCommand(val token: String, val commandId: String, val seq: Long, val action: String, val args: Map<String, String> = emptyMap())

sealed class GateResult {
    data class Accept(val action: RemoteAction, val deviceId: String, val needsHostApproval: Boolean) : GateResult()
    object Duplicate : GateResult()            // already applied: reply OK again, do NOT apply twice
    data class Gap(val expectedSeq: Long) : GateResult()   // resync needed
    data class Reject(val reason: String) : GateResult()
}

data class PairedDevice(val deviceId: String, val name: String, val allowed: Set<RemoteAction>)

/**
 * Transport-independent security + idempotency layer for remote scoring. The host applies an accepted command through
 * MatchSession (same validation as local scoring); this class never touches scores and never holds stream keys.
 * The network transport (WebSocket server) is NOT included: it needs an HTTP/WebSocket library dependency.
 */
class RemoteGate(private val clock: () -> Long, private val rnd: SecureRandom = SecureRandom(), private val codeTtlMs: Long = 120_000) {
    private var code: String? = null; private var codeAt = 0L
    private val devices = mutableMapOf<String, PairedDevice>()       // token -> device
    private val lastSeq = mutableMapOf<String, Long>()
    private val seen = mutableMapOf<String, LinkedHashSet<String>>()

    /** Host shows this 6-digit code (or a QR containing it). Single use, expires. */
    fun newPairingCode(): String { code = String.format("%06d", rnd.nextInt(1_000_000)); codeAt = clock(); return code!! }

    /** Host must call this only after the operator explicitly approves the device. Returns the long random token, or null. */
    fun pair(presentedCode: String, deviceName: String, hostApproved: Boolean): String? {
        val c = code ?: return null
        if (!hostApproved || clock() - codeAt > codeTtlMs || presentedCode != c) return null
        code = null
        val token = ByteArray(24).also { rnd.nextBytes(it) }.joinToString("") { "%02x".format(it) }
        devices[token] = PairedDevice("dev-${devices.size + 1}", deviceName.take(40), RemoteAction.values().toSet())
        return token
    }

    /** True while a pairing code is displayed, matches and has not expired (checked BEFORE the operator is asked to approve). */
    fun codeValid(presented: String): Boolean = code != null && presented == code && clock() - codeAt <= codeTtlMs
    fun deviceFor(token: String): PairedDevice? = devices[token]

    fun revoke(deviceId: String) { devices.entries.removeAll { it.value.deviceId == deviceId } }
    fun connected(): List<PairedDevice> = devices.values.toList()

    fun check(c: RemoteCommand): GateResult {
        val d = devices[c.token] ?: return GateResult.Reject("Not paired")
        val action = RemoteAction.values().firstOrNull { it.name == c.action } ?: return GateResult.Reject("Unknown action")
        if (action !in d.allowed) return GateResult.Reject("Action not permitted for this device")
        if (c.commandId.isBlank() || c.commandId.length > 64) return GateResult.Reject("Bad command id")
        val ids = seen.getOrPut(d.deviceId) { LinkedHashSet() }
        if (c.commandId in ids) return GateResult.Duplicate
        val expected = (lastSeq[d.deviceId] ?: 0L) + 1
        if (c.seq != expected) return GateResult.Gap(expected)
        ids += c.commandId; if (ids.size > 500) ids.remove(ids.first())
        lastSeq[d.deviceId] = c.seq
        return GateResult.Accept(action, d.deviceId, action.needsHostApproval)
    }
}
