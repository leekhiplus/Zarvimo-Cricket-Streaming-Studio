package com.zarvimo.cricket.analytics

import com.zarvimo.cricket.scoring.BallRecord
import com.zarvimo.cricket.scoring.InningsState

/**
 * Read-only analytics over [InningsState] (the engine's derived state). Nothing here changes scoring.
 * Values that cannot be known are null ("unavailable"); the UI must show "–", never 0.
 * Limits: overs before a mid-match join point (seed) only have runs per over if the operator entered them;
 * wickets/dots/boundaries for those overs are unavailable.
 */
data class OverStat(val overIndex: Int, val runs: Int, val wickets: Int?, val cumulativeRuns: Int?, val requiredRateAfter: Double?)

data class BallFilter(val bowler: String? = null, val striker: String? = null, val overFrom: Int? = null, val overTo: Int? = null) {
    fun matches(b: BallRecord) =
        (bowler == null || b.bowler == bowler) && (striker == null || b.striker == striker) &&
            (overFrom == null || b.overIndex >= overFrom) && (overTo == null || b.overIndex <= overTo)
}

data class BallSummary(val legalBalls: Int, val runs: Int, val dots: Int, val boundaries: Int, val wicketBalls: Int) {
    val dotPercent: Double? get() = if (legalBalls == 0) null else dots * 100.0 / legalBalls
    val boundaryPercent: Double? get() = if (legalBalls == 0) null else boundaries * 100.0 / legalBalls
}

data class InningsComparison(val team: String, val runs: Int, val wickets: Int, val oversText: String, val runRate: Double, val extras: Int, val dotPercent: Double?, val boundaries: Int)

object Analytics {
    // 4 or 6 off the bat on a legal ball ("4", "6") or on a no-ball ("Nb+4", "Nb+6", "Nb+4+1b"). A run-out "4W" is not a boundary.
    private val BOUNDARY = Regex("^(Nb\\+)?[46](\\+.*)?$")

    fun isBoundary(b: BallRecord) = BOUNDARY.matches(b.label)

    fun summarize(balls: List<BallRecord>, filter: BallFilter = BallFilter()): BallSummary {
        val f = balls.filter(filter::matches)
        val legal = f.filter { it.legal }
        return BallSummary(legal.size, f.sumOf { it.runsAdded }, legal.count { it.runsAdded == 0 }, f.count(::isBoundary), f.count { it.wicket })
    }

    /** Runs per over plus cumulative runs and the required rate after each over (chases only). */
    fun overs(st: InningsState): List<OverStat> {
        val out = mutableListOf<OverStat>()
        var cum: Int? = 0
        for (i in 0 until st.seedOvers) {
            val r = st.seedOverRuns.getOrNull(i)
            if (r == null) { cum = null; out += OverStat(i, 0, null, null, null) } else { cum = cum?.plus(r); out += OverStat(i, r, null, cum, rrr(st, cum, i)) }
        }
        // If the operator gave no per-over runs for a seeded innings the cumulative line is unknown until the join point.
        if (st.seedOvers > 0 && st.seedOverRuns.size < st.seedOvers) cum = null
        val byOver = st.allBalls.groupBy { it.overIndex }
        byOver.keys.sorted().forEach { o ->
            val bs = byOver.getValue(o)
            val runs = bs.sumOf { it.runsAdded }
            cum = if (st.seedOvers > 0 && cum == null) null else (cum ?: 0) + runs
            val complete = bs.count { it.legal } >= st.ballsPerOver
            out += OverStat(o, runs, bs.count { it.wicket }, cum, if (complete) rrr(st, cum, o) else null)
        }
        return out
    }

    private fun rrr(st: InningsState, cum: Int?, overIndex: Int): Double? {
        val t = st.target ?: return null; val c = cum ?: return null
        val left = st.oversLimit * st.ballsPerOver - (overIndex + 1) * st.ballsPerOver
        if (left <= 0) return null
        return maxOf(0, t - c) * st.ballsPerOver.toDouble() / left
    }

    fun compare(states: List<InningsState>): List<InningsComparison> = states.map {
        val s = summarize(it.allBalls)
        InningsComparison(it.battingTeam, it.runs, it.wickets, it.oversText, it.runRate, it.extras.total, s.dotPercent, s.boundaries)
    }

    /** Runs scored between wickets (the engine does not record which batters formed each partnership). */
    fun runsBetweenWickets(st: InningsState): List<Int> {
        var prev = 0
        return st.fallOfWickets.map { val r = it.teamRuns - prev; prev = it.teamRuns; r } + (st.runs - prev)
    }
}
