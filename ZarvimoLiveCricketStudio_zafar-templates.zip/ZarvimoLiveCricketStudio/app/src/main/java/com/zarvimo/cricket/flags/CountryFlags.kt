package com.zarvimo.cricket.flags

import java.util.Locale

/**
 * Team name -> country flag. Pure Kotlin (testable). Covers every ISO 3166 country through the platform's own country-name data
 * (English and Urdu names), plus cricket short codes (PAK, IND, ...) and common alternative names.
 * A team name matches when it is exactly a country (any language / alias) or "<country> <suffix>" with a known suffix such as
 * A, XI, U19, Women. So "Pakistan", "pakistan u19", "پاکستان" and "PAK" get the flag, while "Team A" or "Lahore Lions" do not.
 * West Indies / Northern Ireland have no flag emoji, so they get none (upload a logo instead).
 */
object CountryFlags {
    private val SUFFIXES = setOf(
        "a", "b", "c", "xi", "11", "u19", "u 19", "u21", "u 21", "u23", "u 23", "u17", "u 17", "women", "womens", "women s", "men", "mens", "men s",
        "academy", "emerging", "legends", "senior", "juniors", "junior", "national team", "cricket team", "team", "ladies"
    )

    /** Special (non ISO) flags drawn from emoji subdivision sequences. */
    private val SUBDIVISION_TAG = mapOf("ENG" to "gbeng", "SCT" to "gbsct", "WLS" to "gbwls")

    private val ALIASES: Map<String, String> = mapOf(
        "pak" to "PK", "ind" to "IN", "aus" to "AU", "eng" to "ENG", "sl" to "LK", "sa" to "ZA", "nz" to "NZ", "ban" to "BD", "afg" to "AF",
        "zim" to "ZW", "ire" to "IE", "ned" to "NL", "usa" to "US", "uae" to "AE", "nep" to "NP", "oma" to "OM", "sco" to "SCT", "nam" to "NA",
        "can" to "CA", "png" to "PG", "hk" to "HK", "kuw" to "KW", "ksa" to "SA", "uga" to "UG", "ken" to "KE", "ger" to "DE", "ita" to "IT",
        "england" to "ENG", "scotland" to "SCT", "wales" to "WLS",
        "u s a" to "US", "us" to "US", "united states of america" to "US", "america" to "US",
        "uk" to "GB", "u k" to "GB", "great britain" to "GB", "britain" to "GB", "united kingdom" to "GB",
        "u a e" to "AE", "emirates" to "AE", "holland" to "NL", "ivory coast" to "CI", "cote d ivoire" to "CI", "côte d ivoire" to "CI",
        "czech republic" to "CZ", "czechia" to "CZ", "turkey" to "TR", "turkiye" to "TR", "türkiye" to "TR", "burma" to "MM", "myanmar" to "MM",
        "hong kong" to "HK", "macau" to "MO", "macao" to "MO", "palestine" to "PS", "russia" to "RU", "south korea" to "KR", "korea" to "KR",
        "north korea" to "KP", "iran" to "IR", "syria" to "SY", "vietnam" to "VN", "viet nam" to "VN", "laos" to "LA", "bolivia" to "BO",
        "venezuela" to "VE", "tanzania" to "TZ", "brunei" to "BN", "moldova" to "MD", "swaziland" to "SZ", "eswatini" to "SZ",
        "cape verde" to "CV", "cabo verde" to "CV", "east timor" to "TL", "timor leste" to "TL", "kosovo" to "XK", "dr congo" to "CD", "drc" to "CD",
        "bahamas" to "BS", "gambia" to "GM", "taiwan" to "TW", "ireland" to "IE", "republic of ireland" to "IE", "usa a" to "US"
    )

    fun normalize(s: String): String =
        s.lowercase(Locale.ROOT).replace(Regex("[.'’`\\-_,()/]"), " ").replace(Regex("\\s+"), " ").trim().removePrefix("the ").trim()

    private val byName: Map<String, String> by lazy {
        val m = HashMap<String, String>()
        for (code in Locale.getISOCountries()) {
            for (loc in listOf(Locale.ENGLISH, Locale("ur"))) {
                val raw = Locale("", code).getDisplayCountry(loc)
                if (raw.isBlank() || raw == code) continue
                m.putIfAbsent(normalize(raw), code)
                m.putIfAbsent(normalize(raw.replace(Regex("\\s*\\(.*\\)"), "").replace(" SAR China", "")), code)
            }
        }
        m.putAll(ALIASES)        // aliases always win
        m
    }

    /** ISO alpha-2 code (or ENG/SCT/WLS) for a team name, or null when the name is not a country. */
    fun codeFor(teamName: String): String? {
        val n = normalize(teamName)
        if (n.isEmpty()) return null
        byName[n]?.let { return it }
        val words = n.split(' ')
        for (i in words.size - 1 downTo 1) {
            val rest = words.drop(i).joinToString(" ")
            if (rest in SUFFIXES) byName[words.take(i).joinToString(" ")]?.let { return it }
        }
        return null
    }

    /** Flag emoji for a code from [codeFor]. */
    fun emoji(code: String): String {
        SUBDIVISION_TAG[code]?.let { tag ->
            val sb = StringBuilder().appendCodePoint(0x1F3F4)
            tag.forEach { sb.appendCodePoint(0xE0000 + it.code) }
            return sb.appendCodePoint(0xE007F).toString()
        }
        val sb = StringBuilder()
        code.uppercase(Locale.ROOT).forEach { sb.appendCodePoint(0x1F1E6 + (it - 'A')) }
        return sb.toString()
    }

    fun emojiFor(teamName: String): String? = codeFor(teamName)?.let { emoji(it) }
}
