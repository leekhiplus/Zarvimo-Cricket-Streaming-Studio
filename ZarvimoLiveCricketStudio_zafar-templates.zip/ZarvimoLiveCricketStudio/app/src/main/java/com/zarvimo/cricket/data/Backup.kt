package com.zarvimo.cricket.data

import com.zarvimo.cricket.graphics.GraphicsConfig
import com.zarvimo.cricket.stream.StreamSettings
import org.json.JSONArray
import org.json.JSONObject

/**
 * Backup file format "zarvimo-backup" v1. Contains matches, graphics presets and non-secret stream settings.
 * NEVER contains the stream key, passwords or OAuth tokens (those live in SecretStore / are not in these models).
 * Pure Kotlin + org.json: validation and merge planning are unit-testable; file I/O stays in LocalStore.
 */
object Backup {
    const val FORMAT = "zarvimo-backup"
    const val VERSION = 1

    enum class DuplicatePolicy { SKIP, KEEP_BOTH, REPLACE }

    /** Result of validating a backup file. Nothing is written by validation. */
    data class Validation(
        val ok: Boolean,
        val error: String?,
        val matches: List<Json.SavedMatch>,
        val presets: List<GraphicsConfig>,
        val streamSettings: StreamSettings?,
        /** Human-readable problems with individual entries (those entries are excluded). */
        val skipped: List<String>
    )

    /** What a restore WOULD do, so the user can confirm before anything is overwritten. */
    data class Plan(val newMatches: List<Json.SavedMatch>, val duplicates: List<Json.SavedMatch>, val newPresets: List<GraphicsConfig>, val duplicatePresetNames: List<String>)

    fun export(matches: List<Json.SavedMatch>, presets: List<GraphicsConfig>, stream: StreamSettings?, nowMs: Long): String {
        val o = JSONObject().put("format", FORMAT).put("version", VERSION).put("createdAt", nowMs)
            .put("matches", JSONArray().also { a -> matches.forEach { a.put(Json.matchToJson(it)) } })
            .put("presets", JSONArray().also { a -> presets.forEach { a.put(Json.graphicsToJson(it)) } })
        if (stream != null) {
            val j = Json.streamSettingsToJson(stream)
            j.put("server", j.optString("server").substringBefore('?'))   // drop any query string that could carry a token
            o.put("streamSettings", j)
        }
        return o.toString(1)
    }

    /** Export of a single complete match record (restorable with [validate]). */
    fun exportOne(m: Json.SavedMatch, nowMs: Long) = export(listOf(m), emptyList(), null, nowMs)

    fun validate(text: String): Validation {
        fun fail(msg: String) = Validation(false, msg, emptyList(), emptyList(), null, emptyList())
        val o = try { JSONObject(text) } catch (e: Exception) { return fail("This file is not valid JSON.") }
        if (o.optString("format") != FORMAT) return fail("This is not a Zarvimo backup file.")
        val v = o.optInt("version", -1)
        if (v < 1) return fail("Backup version is missing or invalid.")
        if (v > VERSION) return fail("This backup was made by a newer version of the app (v$v). Update the app first.")
        val skipped = mutableListOf<String>()
        val matches = mutableListOf<Json.SavedMatch>()
        val ma = o.optJSONArray("matches") ?: JSONArray()
        for (i in 0 until ma.length()) {
            try {
                val m = Json.matchFromJson(ma.getJSONObject(i))
                if (m.id.isBlank()) { skipped += "Match #${i + 1}: missing id"; continue }
                // Every innings must replay cleanly through the scoring engine, otherwise the record is corrupt.
                val bad = m.session?.let { ss -> ss.innings.indices.firstOrNull { ss.stateOf(it) == null } }
                if (bad != null) { skipped += "Match '${m.name}': innings ${bad + 1} does not replay (corrupt or incompatible)"; continue }
                matches += m
            } catch (e: Exception) { skipped += "Match #${i + 1}: unreadable (${e.javaClass.simpleName})" }
        }
        val presets = mutableListOf<GraphicsConfig>()
        val pa = o.optJSONArray("presets") ?: JSONArray()
        for (i in 0 until pa.length()) {
            try { presets += Json.graphicsFromJson(pa.getJSONObject(i)) } catch (e: Exception) { skipped += "Preset #${i + 1}: unreadable" }
        }
        val ss = o.optJSONObject("streamSettings")?.let { try { Json.streamSettingsFromJson(it) } catch (e: Exception) { skipped += "Stream settings: unreadable"; null } }
        return Validation(true, null, matches, presets, ss, skipped)
    }

    fun plan(v: Validation, existingMatchIds: Set<String>, existingPresetNames: Set<String>): Plan {
        val (dup, fresh) = v.matches.partition { it.id in existingMatchIds }
        val (dp, np) = v.presets.partition { it.name.lowercase() in existingPresetNames.map { n -> n.lowercase() } }
        return Plan(fresh, dup, np, dp.map { it.name })
    }

    /** Id for KEEP_BOTH: never collides with [taken]. */
    fun freshId(base: String, taken: Set<String>): String {
        var n = 2
        while ("$base-copy$n" in taken) n++
        return "$base-copy$n"
    }
}
