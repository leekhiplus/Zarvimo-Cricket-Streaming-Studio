package com.zarvimo.cricket.analytics

import com.zarvimo.cricket.scoring.BallRecord

/**
 * Scoring zones are entered BY THE SCORER (tap a zone after a shot). The app has no shot tracking / video analysis and never guesses a direction.
 * Zones are for a right-handed batter seen from above with the bowler at the top; [leftHanded] mirrors them.
 */
enum class Zone(val label: String) {
    LONG_OFF("Long off"), COVER("Cover"), POINT("Point"), THIRD_MAN("Third man"),
    FINE_LEG("Fine leg"), SQUARE_LEG("Square leg"), MIDWICKET("Midwicket"), LONG_ON("Long on");

    fun mirrored(): Zone = values()[7 - ordinal]   // reflection across the pitch line (off side <-> leg side)
}

data class ZoneEntry(val eventId: Long, val zone: Zone, val leftHanded: Boolean = false) {
    /** Zone as seen for a right-hander (left-handed entries are mirrored so one wheel can show everything). */
    val normalised: Zone get() = if (leftHanded) zone.mirrored() else zone
}

data class ZoneStat(val zone: Zone, val shots: Int, val runs: Int)
data class WheelSummary(val zones: List<ZoneStat>, val recordedShots: Int, val totalBatBalls: Int) {
    /** Share of faced bat shots that have a recorded zone; null when there were none. */
    val coveragePercent: Double? get() = if (totalBatBalls == 0) null else recordedShots * 100.0 / totalBatBalls
}

object WagonWheel {
    private val BAT = Regex("^(?:Nb\\+)?(\\d)(?:\\W.*)?$")
    fun batRuns(label: String): Int? = BAT.find(label)?.groupValues?.get(1)?.toIntOrNull()

    /** Entries whose ball no longer exists (undone / deleted) are ignored. */
    fun summarize(balls: List<BallRecord>, entries: List<ZoneEntry>): WheelSummary {
        val byId = balls.associateBy { it.eventId }
        val valid = entries.filter { byId.containsKey(it.eventId) }.distinctBy { it.eventId }
        val stats = Zone.values().map { z ->
            val es = valid.filter { it.normalised == z }
            ZoneStat(z, es.size, es.sumOf { batRuns(byId.getValue(it.eventId).label) ?: 0 })
        }
        return WheelSummary(stats, valid.size, balls.count { batRuns(it.label) != null })
    }
}
