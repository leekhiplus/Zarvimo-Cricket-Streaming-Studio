package com.zarvimo.cricket.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.zarvimo.cricket.analytics.*
import com.zarvimo.cricket.data.Backup
import com.zarvimo.cricket.graphics.BurstKind
import com.zarvimo.cricket.graphics.PanelKind
import com.zarvimo.cricket.report.MatchReport
import com.zarvimo.cricket.report.PdfExporter
import com.zarvimo.cricket.report.ReportBuilder
import com.zarvimo.cricket.scoring.InningsState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

// ---------------------------------------------------------------------------------------------- helpers

internal fun exportDir(ctx: Context) = File(ctx.cacheDir, "exports").apply { mkdirs() }

internal fun shareFile(ctx: Context, f: File, mime: String) {
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
    val send = Intent(Intent.ACTION_SEND).apply { type = mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

private fun stamp() = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date())

// ---------------------------------------------------------------------------------------------- More hub

@Composable
fun MoreScreen(vm: AppViewModel, onNavigate: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StatusStrip(vm)
        Text("Reports & tools", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Gold)
        HomeTile("Reports & backup", "PDF, CSV, JSON, backup and restore", Ic.Save, Modifier.fillMaxWidth()) { onNavigate("reports") }
        HomeTile("Analytics", "Charts, strike rates, wagon wheel", Ic.Activity, Modifier.fillMaxWidth(), Mint) { onNavigate("analytics") }
        HomeTile("Graphics package", "Toss, XI, results, PNG export", Ic.Layers, Modifier.fillMaxWidth(), Color(0xFFBA68C8)) { onNavigate("cards") }
        HomeTile("Stream health", "Measured metrics and warnings", Ic.Radio, Modifier.fillMaxWidth(), Color(0xFFFF7043)) { onNavigate("health") }
        HomeTile("Smart commentary", "Urdu / English, editable templates", Ic.Chat, Modifier.fillMaxWidth(), Color(0xFF4FC3F7)) { onNavigate("commentary") }
        HomeTile("Highlights", "Event markers and clip export", Ic.Film, Modifier.fillMaxWidth(), Color(0xFFFFB74D)) { onNavigate("highlights") }
        HomeTile("Sponsors", "Rotation, history, exposure", Ic.Cricket, Modifier.fillMaxWidth(), Color(0xFF90A4AE)) { onNavigate("sponsors") }
        HomeTile("Remote scoring", "Second phone as scorer", Ic.Sliders, Modifier.fillMaxWidth(), Gold) { onNavigate("remote") }
        HomeTile("OBS & integrations", "Browser overlay and local API", Ic.Info, Modifier.fillMaxWidth(), Color(0xFF81C784)) { onNavigate("obs") }
    }
}

// ---------------------------------------------------------------------------------------------- reports + backup

@Composable
fun ReportsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val m by vm.match.collectAsState()          // recompose when the score changes
    val session = vm.sessionOrNull()
    val report: MatchReport? = remember(m.events, m.inningsIndex, m.state) { session?.let { ReportBuilder.build(it) } }
    var validation by remember { mutableStateOf<Backup.Validation?>(null) }
    var policy by remember { mutableStateOf(Backup.DuplicatePolicy.SKIP) }
    var withStream by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun export(name: String, mime: String, write: (File) -> Unit) {
        scope.launch {
            try {
                val f = withContext(Dispatchers.IO) { File(exportDir(ctx), name).also(write) }
                shareFile(ctx, f, mime)
            } catch (e: Exception) { error = "Export failed: ${e.javaClass.simpleName}: ${e.message}" }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val text = withContext(Dispatchers.IO) {
                try {
                    ctx.contentResolver.openInputStream(uri)?.use { s -> val b = s.readNBytes(20_000_001); if (b.size > 20_000_000) null else String(b) }
                } catch (e: Exception) { null }
            }
            if (text == null) error = "The file could not be read or is larger than 20 MB." else validation = Backup.validate(text).also { if (!it.ok) error = it.error }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionCard("Match report", icon = Ic.Save) {
            if (report == null || report.innings.isEmpty()) {
                Text("No innings yet. Start a match to create a report.", fontSize = 13.sp, color = Muted)
            } else {
                Text(report.title, fontWeight = FontWeight.Bold)
                Text(report.result ?: "Match in progress", color = Gold, fontSize = 13.sp)
                report.innings.forEach { i -> Text("${i.title}: ${i.state.runs}/${i.state.wickets} (${i.state.oversText} ov)", fontSize = 13.sp) }
                Text("Every figure comes from the scoring engine.", fontSize = 11.sp, color = Muted)
                val r = report
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BigButton("PDF", Modifier.weight(1f)) { export("scorecard_${stamp()}.pdf", "application/pdf") { f -> f.outputStream().use { PdfExporter.write(r, it) } } }
                    BigButton("CSV", Modifier.weight(1f)) { export("statistics_${stamp()}.csv", "text/csv") { it.writeText(ReportBuilder.toCsv(r)) } }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BigButton("JSON", Modifier.weight(1f)) { export("match_${stamp()}.json", "application/json") { it.writeText(ReportBuilder.toJson(r).toString(1)) } }
                    BigButton("Printable", Modifier.weight(1f)) { export("report_${stamp()}.html", "text/html") { it.writeText(ReportBuilder.toHtml(r)) } }
                }
                Text("Printable opens in a browser: use Print or Save as PDF there. The PDF contains Latin text only (Urdu names need a font and are not supported in the PDF).", fontSize = 11.sp, color = Muted)
            }
        }
        SectionCard("Backup & restore", icon = Ic.Save) {
            Text("Backups contain matches, graphics presets and stream settings. Stream keys, passwords and tokens are never included.", fontSize = 12.sp, color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton("Back up everything", Modifier.weight(1f)) { export("zarvimo_backup_${stamp()}.json", "application/json") { it.writeText(vm.backupText()) } }
                BigButton("Back up this match", Modifier.weight(1f), enabled = session != null) { export("match_record_${stamp()}.json", "application/json") { it.writeText(vm.currentMatchBackupText()) } }
            }
            BigButton("Restore from file…", Modifier.fillMaxWidth(), icon = Ic.Save) { picker.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) }
            Text("The app also saves the running match automatically after every change and recovers interrupted saves when it starts.", fontSize = 11.sp, color = Muted)
        }
    }

    validation?.takeIf { it.ok }?.let { v ->
        val plan = Backup.plan(v, vm.existingMatchIds(), vm.existingPresetNames())
        AlertDialog(
            onDismissRequest = { validation = null },
            title = { Text("Restore this backup?") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("New matches: ${plan.newMatches.size}", fontSize = 13.sp)
                    Text("Matches that already exist: ${plan.duplicates.size}", fontSize = 13.sp)
                    Text("New presets: ${plan.newPresets.size}   existing: ${plan.duplicatePresetNames.size}", fontSize = 13.sp)
                    if (v.skipped.isNotEmpty()) { Text("Ignored (damaged or incompatible):", fontSize = 13.sp, color = Color(0xFFFF6B6B)); v.skipped.take(6).forEach { Text("• $it", fontSize = 11.sp) } }
                    if (plan.duplicates.isNotEmpty()) {
                        Text("For matches that already exist:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        ChipChoice(Backup.DuplicatePolicy.values().toList(), policy, { when (it) { Backup.DuplicatePolicy.SKIP -> "Keep mine"; Backup.DuplicatePolicy.KEEP_BOTH -> "Keep both"; Backup.DuplicatePolicy.REPLACE -> "Replace" } }) { policy = it }
                        if (policy == Backup.DuplicatePolicy.REPLACE) WarnLine("Replace overwrites the existing records with the ones from the file.")
                    }
                    if (v.streamSettings != null) SwitchRow("Also restore stream settings (server, quality)", withStream) { withStream = it }
                }
            },
            confirmButton = { TextButton(onClick = { vm.restoreBackup(v, policy, withStream); validation = null }) { Text("Restore") } },
            dismissButton = { TextButton(onClick = { validation = null }) { Text("Cancel") } }
        )
    }
    error?.let { AlertDialog(onDismissRequest = { error = null }, title = { Text("Problem") }, text = { Text(it) }, confirmButton = { TextButton(onClick = { error = null }) { Text("OK") } }) }
}

// ---------------------------------------------------------------------------------------------- analytics

private fun pct(v: Double?) = v?.let { String.format(Locale.US, "%.1f%%", it) } ?: "–"
private fun f2(v: Double?) = v?.let { String.format(Locale.US, "%.2f", it) } ?: "–"

@Composable
fun AnalyticsScreen(vm: AppViewModel) {
    val m by vm.match.collectAsState()
    val zones by vm.hub.zones.collectAsState()
    val session = vm.sessionOrNull()
    val count = session?.innings?.size ?: 0
    var sel by remember { mutableStateOf(-1) }
    var bowlerF by remember { mutableStateOf<String?>(null) }
    var batterF by remember { mutableStateOf<String?>(null) }
    var leftHanded by remember { mutableStateOf(false) }
    val idx = if (count == 0) -1 else (if (sel in 0 until count) sel else count - 1)
    val st: InningsState? = remember(m.events, m.state, idx) { if (idx >= 0) session?.stateOf(idx) else null }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (st == null) { SectionCard("Analytics", icon = Ic.Activity) { Text("Start an innings to see analytics.", color = Muted, fontSize = 13.sp) }; return@Column }
        if (count > 1) ChipChoice((0 until count).toList(), idx, { "Innings ${it + 1}" }) { sel = it }
        val filter = BallFilter(bowler = bowlerF, striker = batterF)
        val sum = Analytics.summarize(st.allBalls, filter)
        SectionCard("${st.battingTeam}  ${st.scoreText}  (${st.oversText} ov)", icon = Ic.Activity) {
            Text("Run rate ${f2(st.runRate)}" + (st.requiredRunRate?.let { "   Required ${f2(it)}" } ?: ""), fontSize = 14.sp)
            Text("Dot balls ${pct(sum.dotPercent)}   Boundaries ${sum.boundaries} (${pct(sum.boundaryPercent)})   Legal balls ${sum.legalBalls}", fontSize = 13.sp)
            if (st.seedOvers > 0) Text("Joined after ${st.seedOvers} overs: earlier balls are not recorded, so shares are based on recorded balls only.", fontSize = 11.sp, color = Muted)
        }
        SectionCard("Filter", icon = Ic.Sliders) {
            Text("Bowler", fontSize = 12.sp, color = Muted)
            ChipChoice(listOf<String?>(null) + st.bowlers.map { it.name }, bowlerF, { it ?: "All" }) { bowlerF = it }
            Text("Batter", fontSize = 12.sp, color = Muted)
            ChipChoice(listOf<String?>(null) + st.batters.map { it.name }, batterF, { it ?: "All" }) { batterF = it }
        }
        val overs = Analytics.overs(st)
        SectionCard("Runs per over", icon = Ic.Activity) {
            if (overs.isEmpty()) Text("No overs yet.", color = Muted, fontSize = 13.sp)
            else {
                val maxR = (overs.maxOf { it.runs }).coerceAtLeast(1)
                Canvas(Modifier.fillMaxWidth().height(150.dp)) {
                    val w = size.width / overs.size
                    overs.forEachIndexed { i, o ->
                        val h = size.height * 0.85f * o.runs / maxR
                        drawRect(if ((o.wickets ?: 0) > 0) Color(0xFFD32F2F) else Gold, Offset(i * w + w * 0.12f, size.height - h), Size(w * 0.76f, h))
                        drawIntoCanvas { c -> val p = android.graphics.Paint().apply { color = android.graphics.Color.WHITE; textSize = 22f; textAlign = android.graphics.Paint.Align.CENTER }; c.nativeCanvas.drawText("${o.runs}", i * w + w / 2, size.height - h - 4f, p) }
                    }
                }
                Text("Red bars: overs with a wicket. Overs before a mid-match join show runs only if the scorer entered them.", fontSize = 11.sp, color = Muted)
                overs.filter { it.requiredRateAfter != null }.takeLast(3).forEach { Text("After over ${it.overIndex + 1}: required rate ${f2(it.requiredRateAfter)}", fontSize = 12.sp) }
            }
        }
        SectionCard("Batting", icon = Ic.Cricket) {
            st.batters.forEach { b -> Text("${b.name}  ${b.runs}(${b.balls})  4s ${b.fours}  6s ${b.sixes}  SR ${f2(b.strikeRate)}" + if (b.out) "" else " *", fontSize = 13.sp) }
        }
        SectionCard("Bowling", icon = Ic.Cricket) {
            st.bowlers.forEach { b -> Text("${b.name}  ${b.figuresText}  Econ ${f2(b.economy)}", fontSize = 13.sp) }
        }
        SectionCard("Wickets & partnerships", icon = Ic.Activity) {
            if (st.fallOfWickets.isEmpty()) Text("No wickets yet.", fontSize = 13.sp, color = Muted)
            st.fallOfWickets.forEach { Text("${it.teamRuns}-${it.wicketNumber}  ${it.batter} (${it.batterRuns})  ${it.oversText} ov", fontSize = 13.sp) }
            Text("Runs between wickets: " + Analytics.runsBetweenWickets(st).joinToString(", "), fontSize = 12.sp)
            Text("Which batters formed each partnership is not recorded by the scoring engine.", fontSize = 11.sp, color = Muted)
        }
        if (count > 1) {
            SectionCard("Innings comparison", icon = Ic.Activity) {
                Analytics.compare((0 until count).mapNotNull { session?.stateOf(it) }).forEach {
                    Text("${it.team}: ${it.runs}/${it.wickets} (${it.oversText})  RR ${f2(it.runRate)}  extras ${it.extras}  dots ${pct(it.dotPercent)}  boundaries ${it.boundaries}", fontSize = 12.sp)
                }
            }
        }
        // ---- wagon wheel
        val wheel = WagonWheel.summarize(st.allBalls, zones)
        SectionCard("Wagon wheel (scorer-entered zones)", icon = Ic.Cricket) {
            Text("Zones are entered by the scorer. The app does not detect shot direction by itself.", fontSize = 11.sp, color = Muted)
            WheelCanvas(wheel)
            Text("Recorded: ${wheel.recordedShots} of ${wheel.totalBatBalls} bat shots (${pct(wheel.coveragePercent)})", fontSize = 12.sp)
            val batBalls = st.allBalls.filter { WagonWheel.batRuns(it.label) != null }.takeLast(8).reversed()
            var pick by remember(idx) { mutableStateOf<Long?>(null) }
            if (batBalls.isEmpty()) Text("No bat shots yet.", fontSize = 12.sp, color = Muted) else {
                Text("1. Choose the shot", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                ChipChoice(batBalls.map { it.eventId }, pick, { id -> batBalls.first { it.eventId == id }.let { "${it.label} ${it.striker.take(8)}" + (zones.firstOrNull { z -> z.eventId == id }?.let { z -> " · ${z.zone.label}" } ?: "") } }) { pick = it }
                SwitchRow("Left-handed batter", leftHanded) { leftHanded = it }
                Text("2. Choose the zone", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Zone.values().toList().chunked(4).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { z -> BigButton(z.label, Modifier.weight(1f).heightIn(min = 44.dp), enabled = pick != null) { pick?.let { vm.hub.setZone(it, z, leftHanded) } } }
                    }
                }
                BigButton("Clear zone of this shot", Modifier.fillMaxWidth(), enabled = pick != null) { pick?.let { vm.hub.clearZone(it) } }
            }
        }
    }
}

@Composable
private fun WheelCanvas(w: WheelSummary) {
    val maxRuns = w.zones.maxOf { it.runs }.coerceAtLeast(1)
    Canvas(Modifier.fillMaxWidth().height(220.dp)) {
        val d = minOf(size.width, size.height) * 0.95f
        val tl = Offset((size.width - d) / 2, (size.height - d) / 2)
        w.zones.forEachIndexed { i, z ->
            val a = 0.15f + 0.85f * z.runs / maxRuns
            drawArc(Color(0xFFFFC107).copy(alpha = if (z.runs == 0) 0.08f else a), -90f + i * 45f, 45f, true, tl, Size(d, d))
            drawArc(Color(0xFF26335A), -90f + i * 45f, 45f, true, tl, Size(d, d), style = androidx.compose.ui.graphics.drawscope.Stroke(2f))
            val ang = Math.toRadians((-90 + i * 45 + 22.5).toDouble())
            val cx = size.width / 2 + (d * 0.33f * Math.cos(ang)).toFloat(); val cy = size.height / 2 + (d * 0.33f * Math.sin(ang)).toFloat()
            drawIntoCanvas { c -> val p = android.graphics.Paint().apply { color = android.graphics.Color.WHITE; textSize = 24f; textAlign = android.graphics.Paint.Align.CENTER }
                c.nativeCanvas.drawText(z.zone.label, cx, cy - 4f, p); c.nativeCanvas.drawText(if (z.shots == 0) "–" else "${z.runs} (${z.shots})", cx, cy + 24f, p) }
        }
    }
}

// ---------------------------------------------------------------------------------------------- graphics package

private enum class CardKind(val label: String, val panel: PanelKind?, val burst: BurstKind?) {
    SCORE("Match announcement / score image", null, null),
    TOSS("Toss result", PanelKind.TOSS_CARD, null),
    XI("Team lineups / Playing XI", PanelKind.PLAYING_XI, null),
    BATTER("Batter introduction", PanelKind.STRIKER, null),
    BOWLER("Bowler introduction", PanelKind.BOWLER, null),
    PARTNERSHIP("Partnership", PanelKind.PARTNERSHIP, null),
    SCORECARD("Scorecard", PanelKind.SCORECARD, null),
    SUMMARY("Innings / match summary", PanelKind.MATCH_SUMMARY, null),
    RESULT("Match result poster", PanelKind.RESULT_CARD, null),
    MOM("Player of the Match", PanelKind.MAN_OF_MATCH, null),
    FOUR("Four", null, BurstKind.FOUR),
    SIX("Six", null, BurstKind.SIX),
    WICKET("Wicket", null, BurstKind.WICKET)
}

@Composable
fun CardsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val m by vm.match.collectAsState()
    var kind by remember { mutableStateOf(CardKind.SCORE) }
    var size by remember { mutableStateOf(1280) }
    var withBg by remember { mutableStateOf(true) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var msg by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionCard("Graphics package", icon = Ic.Layers) {
            Text("Cards are drawn by the same renderer as the live overlay, from the current match data, team colours, logos and your Graphics settings (template, sponsor slot).", fontSize = 12.sp, color = Muted)
            Text("Card", fontSize = 12.sp, color = Muted)
            ChipChoice(CardKind.values().toList(), kind, { it.label }) { kind = it; preview = null; msg = null }
            Text("Image size", fontSize = 12.sp, color = Muted)
            ChipChoice(listOf(1280, 1920, 3840), size, { when (it) { 1280 -> "1280×720"; 1920 -> "1920×1080"; else -> "3840×2160" } }) { size = it }
            SwitchRow("Include background picture (off = transparent PNG)", withBg) { withBg = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton("Preview", Modifier.weight(1f)) {
                    scope.launch { val b = withContext(Dispatchers.Default) { vm.renderCard(kind.panel, kind.burst, 960, 540, withBg) }; preview = b; msg = if (b == null) (kind.panel?.emptyHint ?: "Nothing to draw") else null }
                }
                BigButton("Export PNG", Modifier.weight(1f), Gold, Color.Black) {
                    scope.launch {
                        val f = withContext(Dispatchers.Default) {
                            val b = vm.renderCard(kind.panel, kind.burst, size, size * 9 / 16, withBg) ?: return@withContext null
                            File(exportDir(ctx), "${kind.name.lowercase()}_${stamp()}.png").also { f -> f.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }; b.recycle() }
                        }
                        if (f == null) msg = kind.panel?.emptyHint ?: "Nothing to draw" else shareFile(ctx, f, "image/png")
                    }
                }
            }
            msg?.let { WarnLine(it) }
            preview?.let { Image(it.asImageBitmap(), contentDescription = "Preview", modifier = Modifier.fillMaxWidth()) }
            Text("Urdu text in names and titles uses the phone's Arabic font; check the preview. Wicket / four / six images show the animation's final frame.", fontSize = 11.sp, color = Muted)
        }
    }
}
