package com.zarvimo.cricket.sponsors

data class Sponsor(val id: String, val name: String, val logoPath: String? = null, val durationMs: Long = 8000, val enabled: Boolean = true)
data class Appearance(val sponsorId: String, val startMs: Long, var endMs: Long? = null)
enum class RotatorState { STOPPED, RUNNING, PAUSED }

/** Deterministic rotation (time is passed in, so it is unit-testable). The UI renders [tick]'s result with the normal graphics renderer. */
class SponsorRotator(sponsors: List<Sponsor>) {
    private val active = sponsors.filter { it.enabled && it.durationMs > 0 }
    private var idx = -1
    private var shownSince = 0L
    var state = RotatorState.STOPPED; private set
    val history = mutableListOf<Appearance>()

    val current: Sponsor? get() = if (state == RotatorState.RUNNING) active.getOrNull(idx) else null

    fun start(now: Long) { if (active.isEmpty() || state == RotatorState.RUNNING) return; state = RotatorState.RUNNING; show(if (idx < 0) 0 else idx, now) }
    fun pause(now: Long) { if (state != RotatorState.RUNNING) return; closeOpen(now); state = RotatorState.PAUSED }
    fun resume(now: Long) { if (state == RotatorState.PAUSED) { state = RotatorState.RUNNING; show(idx, now) } }
    fun stop(now: Long) { closeOpen(now); state = RotatorState.STOPPED; idx = -1 }

    fun tick(now: Long): Sponsor? {
        if (state != RotatorState.RUNNING) return null
        val c = active[idx]
        if (now - shownSince >= c.durationMs) { closeOpen(shownSince + c.durationMs); show((idx + 1) % active.size, shownSince + c.durationMs) }
        return active[idx]
    }

    private fun show(i: Int, now: Long) { idx = i; shownSince = now; history += Appearance(active[i].id, now) }
    private fun closeOpen(at: Long) { history.lastOrNull()?.let { if (it.endMs == null) it.endMs = at } }

    /** Total on-screen milliseconds per sponsor (open appearance counted up to [now]). */
    fun exposureMs(now: Long): Map<String, Long> = history.groupBy { it.sponsorId }.mapValues { (_, l) -> l.sumOf { (it.endMs ?: now) - it.startMs } }
    fun appearances(): Map<String, Int> = history.groupingBy { it.sponsorId }.eachCount()
}
