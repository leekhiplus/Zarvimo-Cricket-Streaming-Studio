package com.zarvimo.cricket.health

/** Every field is null when the platform/engine did not MEASURE it. Estimates must never be put here. */
data class StreamMetrics(
    val state: String? = null, val bitrateKbps: Int? = null, val fps: Int? = null, val width: Int? = null, val height: Int? = null,
    val droppedFrames: Long? = null, val reconnects: Int? = null, val audioPeak: Float? = null,
    val freeStorageMb: Long? = null, val batteryPct: Int? = null, val tempC: Float? = null, val recording: Boolean? = null
)

enum class Level { OK, WARN, CRITICAL, UNAVAILABLE }
data class Indicator(val name: String, val level: Level, val text: String)

object StreamHealth {
    fun evaluate(m: StreamMetrics, targetKbps: Int?, targetFps: Int?): List<Indicator> {
        fun na(n: String) = Indicator(n, Level.UNAVAILABLE, "Unavailable")
        val out = mutableListOf<Indicator>()
        out += m.state?.let { Indicator("State", Level.OK, it) } ?: na("State")
        out += when {
            m.bitrateKbps == null -> na("Bitrate")
            targetKbps != null && m.bitrateKbps < targetKbps * 0.5 -> Indicator("Bitrate", Level.CRITICAL, "${m.bitrateKbps} kbps (target $targetKbps)")
            targetKbps != null && m.bitrateKbps < targetKbps * 0.75 -> Indicator("Bitrate", Level.WARN, "${m.bitrateKbps} kbps (target $targetKbps)")
            else -> Indicator("Bitrate", Level.OK, "${m.bitrateKbps} kbps")
        }
        out += when {
            m.fps == null -> na("Frame rate")
            targetFps != null && m.fps < targetFps * 0.8 -> Indicator("Frame rate", Level.WARN, "${m.fps} fps (target $targetFps)")
            else -> Indicator("Frame rate", Level.OK, "${m.fps} fps")
        }
        out += when {
            m.droppedFrames == null -> na("Dropped frames")
            m.droppedFrames > 300 -> Indicator("Dropped frames", Level.CRITICAL, "${m.droppedFrames}")
            m.droppedFrames > 30 -> Indicator("Dropped frames", Level.WARN, "${m.droppedFrames}")
            else -> Indicator("Dropped frames", Level.OK, "${m.droppedFrames}")
        }
        out += m.reconnects?.let { Indicator("Reconnects", if (it >= 3) Level.WARN else Level.OK, "$it") } ?: na("Reconnects")
        out += when {
            m.audioPeak == null -> na("Audio")
            m.audioPeak >= 0.98f -> Indicator("Audio", Level.WARN, "Clipping")
            else -> Indicator("Audio", Level.OK, "Peak %.0f%%".format(m.audioPeak * 100))
        }
        out += when {
            m.freeStorageMb == null -> na("Storage")
            m.freeStorageMb < 500 -> Indicator("Storage", Level.CRITICAL, "${m.freeStorageMb} MB free")
            m.freeStorageMb < 2000 -> Indicator("Storage", Level.WARN, "${m.freeStorageMb} MB free")
            else -> Indicator("Storage", Level.OK, "${m.freeStorageMb} MB free")
        }
        out += when {
            m.batteryPct == null -> na("Battery")
            m.batteryPct < 10 -> Indicator("Battery", Level.CRITICAL, "${m.batteryPct}%")
            m.batteryPct < 20 -> Indicator("Battery", Level.WARN, "${m.batteryPct}%")
            else -> Indicator("Battery", Level.OK, "${m.batteryPct}%")
        }
        out += when {
            m.tempC == null -> na("Temperature")
            m.tempC >= 45f -> Indicator("Temperature", Level.CRITICAL, "%.1f °C".format(m.tempC))
            m.tempC >= 40f -> Indicator("Temperature", Level.WARN, "%.1f °C".format(m.tempC))
            else -> Indicator("Temperature", Level.OK, "%.1f °C".format(m.tempC))
        }
        return out
    }

    /** Suggestion only. The caller must ask the user (or honour an explicit auto-recovery setting) before changing anything. */
    fun suggestedBitrateKbps(m: StreamMetrics, targetKbps: Int, minKbps: Int): Int? {
        val b = m.bitrateKbps ?: return null
        return if (b < targetKbps * 0.75) maxOf(minKbps, (targetKbps * 0.75).toInt()) else null
    }
}
