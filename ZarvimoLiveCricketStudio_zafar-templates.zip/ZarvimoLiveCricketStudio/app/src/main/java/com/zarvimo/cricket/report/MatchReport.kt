package com.zarvimo.cricket.report

import com.zarvimo.cricket.scoring.InningsState
import com.zarvimo.cricket.scoring.MatchSession
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Read-only match report. EVERY figure comes from [MatchSession.stateOf] (the scoring engine replay);
 * nothing is recalculated here, so a report can never disagree with the scoreboard.
 * Pure Kotlin + org.json (no Android classes) so it is unit-testable on the JVM.
 */
data class PartnershipLine(val wicketNumber: Int, val runs: Int, val note: String)

data class InningsReport(
    val index: Int,
    val title: String,
    val state: InningsState,
    /** Runs added between successive wickets, derived from the engine's fall of wickets. Pair names are not recorded by the engine. */
    val partnerships: List<PartnershipLine>,
    val dotBalls: Int,
    val boundaryBalls: Int,
    val legalBalls: Int
)

data class MatchReport(
    val title: String,
    val venue: String,
    val teamA: String,
    val teamB: String,
    val toss: String?,
    val result: String?,
    val innings: List<InningsReport>,
    val manOfMatch: String?
)

object ReportBuilder {

    fun build(session: MatchSession): MatchReport {
        val s = session.setup
        val list = session.innings.indices.mapNotNull { i ->
            val st = session.stateOf(i) ?: return@mapNotNull null
            InningsReport(i, inningsTitle(session, i, st), st, partnerships(st), dots(st), boundaries(st), st.allBalls.count { it.legal })
        }
        val toss = if (s.tossWinner.isNotBlank() && s.tossDecision.name != "NONE") "${s.tossWinner} won the toss and chose to ${s.tossDecision.label.lowercase(Locale.ROOT)}" else null
        val mom = s.momName.takeIf { it.isNotBlank() }?.let { n -> listOf(n, s.momTeam.takeIf { it.isNotBlank() }).filterNotNull().joinToString(" · ") }
        return MatchReport(s.title.ifBlank { "${s.teamA} v ${s.teamB}" }, s.venue, s.teamA, s.teamB, toss, session.finalResult(), list, mom)
    }

    private fun inningsTitle(session: MatchSession, i: Int, st: InningsState): String =
        if (session.isSuperOver(i)) "Super Over ${(i - 2) / 2 + 1} – ${st.battingTeam}" else "${st.battingTeam} innings"

    private fun partnerships(st: InningsState): List<PartnershipLine> {
        var prev = 0
        val out = st.fallOfWickets.map { f ->
            val line = PartnershipLine(f.wicketNumber, f.teamRuns - prev, if (f.wicketNumber == 1 && st.seedOvers > 0) "includes runs before this app joined the match" else "")
            prev = f.teamRuns; line
        }.toMutableList()
        if (!st.ended || st.wickets < st.maxWickets) out += PartnershipLine(st.wickets + 1, st.runs - prev, "unbroken / current")
        return out
    }

    // Balls of a seeded innings before the join point are not recorded, so these only cover recorded balls.
    private fun dots(st: InningsState) = st.allBalls.count { it.legal && it.runsAdded == 0 }
    private fun boundaries(st: InningsState) = st.allBalls.count(com.zarvimo.cricket.analytics.Analytics::isBoundary)

    private fun f2(d: Double) = String.format(Locale.US, "%.2f", d)

    // ------------------------------------------------------------------ CSV
    private fun csv(v: Any?): String {
        val t = v?.toString() ?: ""
        val safe = if (t.isNotEmpty() && t[0] in "=+-@") "'$t" else t   // block spreadsheet formula injection
        return if (safe.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) "\"" + safe.replace("\"", "\"\"") + "\"" else safe
    }
    private fun row(vararg c: Any?) = c.joinToString(",") { csv(it) }

    fun toCsv(r: MatchReport): String {
        val sb = StringBuilder()
        sb.append("Section,Innings,Name,Runs,Balls,Fours,Sixes,StrikeRate,Dismissal\n")
        r.innings.forEach { i ->
            i.state.batters.forEach { b -> sb.append(row("Batting", i.title, b.name, b.runs, b.balls, b.fours, b.sixes, f2(b.strikeRate), if (b.out) b.dismissal else "not out")).append('\n') }
        }
        sb.append("\nSection,Innings,Name,Overs,Maidens,Runs,Wickets,Economy,Wides,NoBalls\n")
        r.innings.forEach { i ->
            i.state.bowlers.forEach { b -> sb.append(row("Bowling", i.title, b.name, b.oversText, b.maidens, b.runs, b.wickets, f2(b.economy), b.wides, b.noBalls)).append('\n') }
        }
        sb.append("\nSection,Innings,Wicket,TeamRuns,Batter,BatterRuns,Over\n")
        r.innings.forEach { i -> i.state.fallOfWickets.forEach { f -> sb.append(row("FoW", i.title, f.wicketNumber, f.teamRuns, f.batter, f.batterRuns, f.oversText)).append('\n') } }
        sb.append("\nSection,Innings,Runs,Wickets,Overs,Extras,RunRate\n")
        r.innings.forEach { i -> sb.append(row("Total", i.title, i.state.runs, i.state.wickets, i.state.oversText, i.state.extras.total, f2(i.state.runRate))).append('\n') }
        return sb.toString()
    }

    // ------------------------------------------------------------------ JSON (report view; the restorable record is Json.matchToJson)
    fun toJson(r: MatchReport): JSONObject = JSONObject()
        .put("title", r.title).put("venue", r.venue).put("toss", r.toss ?: JSONObject.NULL)
        .put("result", r.result ?: JSONObject.NULL).put("manOfMatch", r.manOfMatch ?: JSONObject.NULL)
        .put("innings", JSONArray().also { arr ->
            r.innings.forEach { i ->
                val s = i.state
                arr.put(JSONObject().put("title", i.title).put("team", s.battingTeam).put("runs", s.runs).put("wickets", s.wickets)
                    .put("overs", s.oversText).put("runRate", s.runRate).put("target", s.target ?: JSONObject.NULL)
                    .put("extras", JSONObject().put("wides", s.extras.wides).put("noBalls", s.extras.noBalls).put("byes", s.extras.byes)
                        .put("legByes", s.extras.legByes).put("penalty", s.extras.penalty).put("total", s.extras.total))
                    .put("manualRunsAdjustment", s.manualRunsAdjustment).put("manualWicketsAdjustment", s.manualWicketsAdjustment)
                    .put("batters", JSONArray().also { a -> s.batters.forEach { b -> a.put(JSONObject().put("name", b.name).put("runs", b.runs).put("balls", b.balls).put("fours", b.fours).put("sixes", b.sixes).put("strikeRate", b.strikeRate).put("out", b.out).put("dismissal", b.dismissal ?: JSONObject.NULL)) } })
                    .put("bowlers", JSONArray().also { a -> s.bowlers.forEach { b -> a.put(JSONObject().put("name", b.name).put("overs", b.oversText).put("maidens", b.maidens).put("runs", b.runs).put("wickets", b.wickets).put("economy", b.economy)) } })
                    .put("fallOfWickets", JSONArray().also { a -> s.fallOfWickets.forEach { f -> a.put(JSONObject().put("wicket", f.wicketNumber).put("teamRuns", f.teamRuns).put("batter", f.batter).put("batterRuns", f.batterRuns).put("over", f.oversText)) } })
                    .put("partnershipRuns", JSONArray().also { a -> i.partnerships.forEach { p -> a.put(JSONObject().put("wicket", p.wicketNumber).put("runs", p.runs).put("note", p.note)) } })
                    .put("balls", JSONArray().also { a -> s.allBalls.forEach { b -> a.put(JSONObject().put("eventId", b.eventId).put("over", b.overIndex).put("label", b.label).put("runs", b.runsAdded).put("legal", b.legal).put("wicket", b.wicket).put("bowler", b.bowler).put("striker", b.striker)) } }))
            }
        })

    // ------------------------------------------------------------------ Printable HTML (also the source for the PDF)
    private fun h(s: String?) = (s ?: "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    fun toHtml(r: MatchReport): String {
        val sb = StringBuilder("<!DOCTYPE html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>${h(r.title)}</title>")
        sb.append("<style>body{font:14px sans-serif;margin:24px;color:#111}table{border-collapse:collapse;width:100%;margin:8px 0 18px}th,td{border-bottom:1px solid #ccc;padding:4px 6px;text-align:right}th:first-child,td:first-child{text-align:left}h2{margin:18px 0 4px}@media print{body{margin:8mm}}</style></head><body>")
        sb.append("<h1>${h(r.title)}</h1>")
        if (r.venue.isNotBlank()) sb.append("<p>${h(r.venue)}</p>")
        r.toss?.let { sb.append("<p>${h(it)}</p>") }
        sb.append("<p><b>${h(r.result ?: "Match in progress")}</b></p>")
        r.manOfMatch?.let { sb.append("<p>Player of the Match: ${h(it)}</p>") }
        r.innings.forEach { i ->
            val s = i.state
            sb.append("<h2>${h(i.title)} — ${s.runs}/${s.wickets} (${s.oversText} ov)</h2>")
            sb.append("<table><tr><th>Batter</th><th>Dismissal</th><th>R</th><th>B</th><th>4s</th><th>6s</th><th>SR</th></tr>")
            s.batters.forEach { b -> sb.append("<tr><td>${h(b.name)}</td><td>${h(if (b.out) b.dismissal else "not out")}</td><td>${b.runs}</td><td>${b.balls}</td><td>${b.fours}</td><td>${b.sixes}</td><td>${f2(b.strikeRate)}</td></tr>") }
            val e = s.extras
            sb.append("<tr><td>Extras</td><td colspan=\"6\">${e.total} (w ${e.wides}, nb ${e.noBalls}, b ${e.byes}, lb ${e.legByes}, pen ${e.penalty})</td></tr>")
            if (s.manualRunsAdjustment != 0 || s.manualWicketsAdjustment != 0) sb.append("<tr><td>Manual adjustment</td><td colspan=\"6\">${s.manualRunsAdjustment} runs, ${s.manualWicketsAdjustment} wickets</td></tr>")
            sb.append("<tr><td><b>Total</b></td><td colspan=\"6\"><b>${s.runs}/${s.wickets} in ${s.oversText} overs (RR ${f2(s.runRate)})</b></td></tr></table>")
            sb.append("<table><tr><th>Bowler</th><th>O</th><th>M</th><th>R</th><th>W</th><th>Econ</th></tr>")
            s.bowlers.forEach { b -> sb.append("<tr><td>${h(b.name)}</td><td>${b.oversText}</td><td>${b.maidens}</td><td>${b.runs}</td><td>${b.wickets}</td><td>${f2(b.economy)}</td></tr>") }
            sb.append("</table>")
            if (s.fallOfWickets.isNotEmpty()) sb.append("<p><b>Fall of wickets:</b> " + s.fallOfWickets.joinToString("; ") { "${it.teamRuns}-${it.wicketNumber} (${h(it.batter)}, ${it.oversText} ov)" } + "</p>")
            sb.append("<p><b>Runs between wickets:</b> " + i.partnerships.joinToString("; ") { "wkt ${it.wicketNumber}: ${it.runs}" + if (it.note.isNotBlank()) " (${h(it.note)})" else "" } + "</p>")
            sb.append("<p>Dot balls: ${i.dotBalls} · Boundaries (4/6): ${i.boundaryBalls} · Legal balls recorded: ${i.legalBalls}</p>")
        }
        return sb.append("</body></html>").toString()
    }
}
