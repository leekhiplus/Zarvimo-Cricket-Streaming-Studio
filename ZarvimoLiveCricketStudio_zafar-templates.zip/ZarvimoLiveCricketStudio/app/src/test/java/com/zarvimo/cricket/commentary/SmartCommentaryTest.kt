package com.zarvimo.cricket.commentary

import com.zarvimo.cricket.scoring.*
import org.junit.Assert.*
import org.junit.Test

class SmartCommentaryTest {
    private fun session(): MatchSession {
        val s = MatchSession(MatchSetup(teamA = "L", teamB = "T", oversLimit = 5))
        s.startInnings(InningsSetup("L", "T", "Ali", "Bob", "Zed")); return s
    }
    @Test fun six_usesRealNamesAndScore_andIsNotRepeated() {
        val s = session(); s.add { BallEvent(it, runsBat = 6, boundary = true) }
        val p = CommentaryPlanner()
        val l = p.next(s.stateOf(0)!!)!!
        assertEquals(CKind.SIX, l.kind); assertTrue(l.text.contains("Ali")); assertTrue(l.text.contains("6/0"))
        assertNull(p.next(s.stateOf(0)!!))   // same ball: no duplicate
    }
    @Test fun paused_orDisabled_staysSilent() {
        val s = session(); s.add { BallEvent(it, runsBat = 4, boundary = true) }
        assertNull(CommentaryPlanner(paused = true).next(s.stateOf(0)!!))
        assertNull(CommentaryPlanner(enabled = false).next(s.stateOf(0)!!))
    }
    @Test fun priorityRules() { assertTrue(CommentaryPlanner.canInterrupt(3, 2)); assertFalse(CommentaryPlanner.canInterrupt(1, 3)); assertTrue(CommentaryPlanner.canInterrupt(1, null)) }
    @Test fun templateValidation() { assertNull(DefaultTemplates.validate("{batter} {score}")); assertNotNull(DefaultTemplates.validate("{nope}")) }
    @Test fun urdu_templates_exist_forEveryKind() { assertEquals(CKind.values().toSet(), DefaultTemplates.forLang(Lang.UR).keys) }
}
