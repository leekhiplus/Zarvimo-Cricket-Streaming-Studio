package com.zarvimo.cricket.sponsors

import org.junit.Assert.*
import org.junit.Test

class SponsorRotatorTest {
    private val list = listOf(Sponsor("a", "A", durationMs = 1000), Sponsor("b", "B", durationMs = 2000), Sponsor("off", "Off", enabled = false))
    @Test fun rotates_inOrder_andSkipsDisabled() {
        val r = SponsorRotator(list); r.start(0)
        assertEquals("a", r.tick(500)!!.id); assertEquals("b", r.tick(1000)!!.id); assertEquals("a", r.tick(3000)!!.id)
    }
    @Test fun exposure_andPause() {
        val r = SponsorRotator(list); r.start(0); r.tick(1000); r.pause(1500)
        assertNull(r.tick(2000)); assertEquals(1000L, r.exposureMs(2000)["a"]); assertEquals(500L, r.exposureMs(2000)["b"])
        r.stop(3000); assertEquals(RotatorState.STOPPED, r.state)
    }
}
