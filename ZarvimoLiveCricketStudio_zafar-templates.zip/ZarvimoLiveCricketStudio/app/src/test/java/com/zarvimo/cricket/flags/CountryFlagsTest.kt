package com.zarvimo.cricket.flags

import org.junit.Assert.*
import org.junit.Test

class CountryFlagsTest {
    @Test fun commonTeams() {
        assertEquals("PK", CountryFlags.codeFor("Pakistan")); assertEquals("PK", CountryFlags.codeFor("  PAKISTAN "))
        assertEquals("IN", CountryFlags.codeFor("India")); assertEquals("ENG", CountryFlags.codeFor("England"))
        assertEquals("AE", CountryFlags.codeFor("United Arab Emirates")); assertEquals("US", CountryFlags.codeFor("USA"))
        assertEquals("LK", CountryFlags.codeFor("Sri Lanka")); assertEquals("ZA", CountryFlags.codeFor("South Africa")); assertEquals("NZ", CountryFlags.codeFor("New Zealand"))
        assertEquals("HK", CountryFlags.codeFor("Hong Kong")); assertEquals("AF", CountryFlags.codeFor("Afghanistan"))
    }
    @Test fun suffixesAndAbbreviations() {
        assertEquals("PK", CountryFlags.codeFor("Pakistan U-19")); assertEquals("AU", CountryFlags.codeFor("Australia Women")); assertEquals("IN", CountryFlags.codeFor("India A")); assertEquals("PK", CountryFlags.codeFor("PAK"))
    }
    @Test fun nonCountriesGetNoFlag() {
        assertNull(CountryFlags.codeFor("Team A")); assertNull(CountryFlags.codeFor("Lahore Lions")); assertNull(CountryFlags.codeFor("")); assertNull(CountryFlags.codeFor("West Indies"))
    }
    @Test fun emojiCodePoints() {
        assertEquals("\uD83C\uDDF5\uD83C\uDDF0", CountryFlags.emoji("PK"))
        assertTrue(CountryFlags.emoji("ENG").startsWith("\uD83C\uDFF4"))
    }
    @Test fun everyIsoCountryNameResolves() {
        val codes = java.util.Locale.getISOCountries()
        val ok = codes.count { c -> val n = java.util.Locale("", c).getDisplayCountry(java.util.Locale.ENGLISH); n != c && CountryFlags.codeFor(n) != null }
        assertTrue("only $ok of ${codes.size}", ok >= codes.size - 8)
    }
}
