package com.zarvimo.cricket.analytics

import com.zarvimo.cricket.scoring.BallRecord
import org.junit.Assert.*
import org.junit.Test

class WagonWheelTest {
    private fun b(id: Long, l: String) = BallRecord(id, 0, l, l.toIntOrNull() ?: 0, true, false, "B", "S")
    @Test fun runsPerZone_ignoreUndoneBalls_andShowCoverage() {
        val balls = listOf(b(1, "4"), b(2, "1"), b(3, "0"))
        val w = WagonWheel.summarize(balls, listOf(ZoneEntry(1, Zone.COVER), ZoneEntry(2, Zone.COVER), ZoneEntry(99, Zone.POINT)))
        assertEquals(5, w.zones.first { it.zone == Zone.COVER }.runs)
        assertEquals(0, w.zones.first { it.zone == Zone.POINT }.shots)
        assertEquals(2, w.recordedShots); assertEquals(3, w.totalBatBalls)
    }
    @Test fun noBalls_hasNullCoverage() = assertNull(WagonWheel.summarize(emptyList(), emptyList()).coveragePercent)
    @Test fun leftHanderIsMirrored() = assertEquals(Zone.POINT, ZoneEntry(1, Zone.SQUARE_LEG, true).normalised)
    @Test fun mirror_isInvolution() { Zone.values().forEach { assertEquals(it, it.mirrored().mirrored()) } }
}
