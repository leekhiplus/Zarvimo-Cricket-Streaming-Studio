package com.zarvimo.cricket.highlights

import com.zarvimo.cricket.scoring.BallRecord
import org.junit.Assert.*
import org.junit.Test

class HighlightsTest {
    private fun b(id: Long, label: String, w: Boolean = false) = BallRecord(id, 0, label, 4, true, w, "Bwl", "Bat")
    @Test fun marks_boundaryAndWicket_notSingles_noDuplicates() {
        val l = HighlightLog()
        assertNotNull(l.add(b(1, "4"), 10_000, 4_000)); assertNull(l.add(b(1, "4"), 10_000, 4_000)); assertNull(l.add(b(2, "1"), 11_000, 4_000))
        assertEquals(HKind.WICKET, l.add(b(3, "W", true), 20_000, null)!!.kind)
        assertEquals(6000L, l.markers[0].recordingOffsetMs); assertNull(l.markers[1].recordingOffsetMs)
        assertEquals(1, l.search(kinds = setOf(HKind.WICKET)).size)
    }
    @Test fun clip_buffers_clamped_andNullWithoutRecording() {
        val m = Marker(1, HKind.SIX, "x", 0, 3000)
        assertEquals(ClipSpec(0, 11000), HighlightLog.clipFor(m, 10_000, 8_000, 60_000))
        assertNull(HighlightLog.clipFor(m.copy(recordingOffsetMs = null), 1, 1, 60_000))
    }
}
