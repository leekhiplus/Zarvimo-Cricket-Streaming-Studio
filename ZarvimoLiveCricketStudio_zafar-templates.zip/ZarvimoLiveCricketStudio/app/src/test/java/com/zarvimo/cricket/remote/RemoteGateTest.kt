package com.zarvimo.cricket.remote

import org.junit.Assert.*
import org.junit.Test

class RemoteGateTest {
    private var now = 0L
    private val g = RemoteGate({ now })
    private fun paired(): String { val c = g.newPairingCode(); return g.pair(c, "Phone", true)!! }

    @Test fun pairing_needsApproval_expires_singleUse() {
        val c = g.newPairingCode(); assertNull(g.pair(c, "x", false))
        assertNotNull(g.pair(c, "x", true)); assertNull(g.pair(c, "x", true))
        val c2 = g.newPairingCode(); now += 200_000; assertNull(g.pair(c2, "x", true))
    }
    @Test fun duplicate_isNotAppliedTwice_andGapDetected() {
        val t = paired()
        assertTrue(g.check(RemoteCommand(t, "c1", 1, "RUNS")) is GateResult.Accept)
        assertTrue(g.check(RemoteCommand(t, "c1", 1, "RUNS")) is GateResult.Duplicate)
        assertEquals(GateResult.Gap(2), g.check(RemoteCommand(t, "c3", 5, "RUNS")))
    }
    @Test fun unknownToken_unknownAction_revoked() {
        assertTrue(g.check(RemoteCommand("nope", "c", 1, "RUNS")) is GateResult.Reject)
        val t = paired()
        assertTrue(g.check(RemoteCommand(t, "c", 1, "SHOW_STREAM_KEY")) is GateResult.Reject)
        g.revoke(g.connected().first().deviceId); assertTrue(g.check(RemoteCommand(t, "d", 1, "RUNS")) is GateResult.Reject)
    }
    @Test fun undo_requiresHostApproval() { val t = paired(); assertTrue((g.check(RemoteCommand(t, "u", 1, "UNDO_REQUEST")) as GateResult.Accept).needsHostApproval) }
}
