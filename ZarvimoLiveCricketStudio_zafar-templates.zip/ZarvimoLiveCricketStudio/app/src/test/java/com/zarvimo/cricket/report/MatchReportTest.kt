package com.zarvimo.cricket.report

import com.zarvimo.cricket.scoring.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MatchReportTest {
    private fun session(): MatchSession {
        val s = MatchSession(MatchSetup(teamA = "Lions", teamB = "Tigers", oversLimit = 5))
        s.startInnings(InningsSetup("Lions", "Tigers", "A1", "A2", "T1"))
        s.add { BallEvent(it, runsBat = 4, boundary = true) }
        s.add { BallEvent(it) }
        s.add { BallEvent(it, runsBat = 1) }
        return s
    }

    @Test fun report_matches_engine_state() {
        val s = session()
        val r = ReportBuilder.build(s)
        val st = s.stateOf(0)!!
        assertEquals(st.runs, r.innings[0].state.runs)
        assertEquals(5, st.runs)
        assertEquals(1, r.innings[0].dotBalls)
        assertEquals(1, r.innings[0].boundaryBalls)
    }

    @Test fun csv_has_batting_row_and_escapes_formulas() {
        val s = MatchSession(MatchSetup(teamA = "L", teamB = "T"))
        s.startInnings(InningsSetup("L", "T", "=HYPERLINK(x)", "A2", "T1"))
        val csv = ReportBuilder.toCsv(ReportBuilder.build(s))
        assertTrue(csv.contains("'=HYPERLINK(x)"))
        assertTrue(csv.startsWith("Section,Innings"))
    }

    @Test fun json_and_html_contain_total_and_escape_markup() {
        val s = MatchSession(MatchSetup(teamA = "<b>L</b>", teamB = "T"))
        s.startInnings(InningsSetup("<b>L</b>", "T", "A1", "A2", "T1"))
        val r = ReportBuilder.build(s)
        assertEquals(0, ReportBuilder.toJson(r).getJSONArray("innings").getJSONObject(0).getInt("runs"))
        assertTrue(!ReportBuilder.toHtml(r).contains("<b>L</b>"))
    }
}
