package com.zarvimo.cricket.health

import org.junit.Assert.*
import org.junit.Test

class StreamHealthTest {
    @Test fun unmeasured_isUnavailable_notZero() {
        val r = StreamHealth.evaluate(StreamMetrics(), 2000, 30)
        assertTrue(r.filter { it.name != "State" || true }.all { it.level == Level.UNAVAILABLE })
    }
    @Test fun lowBitrate_warns_andSuggestionOnlyWhenMeasured() {
        val m = StreamMetrics(bitrateKbps = 900)
        assertEquals(Level.CRITICAL, StreamHealth.evaluate(m, 2000, null).first { it.name == "Bitrate" }.level)
        assertEquals(1500, StreamHealth.suggestedBitrateKbps(m, 2000, 500))
        assertNull(StreamHealth.suggestedBitrateKbps(StreamMetrics(), 2000, 500))
    }
}
