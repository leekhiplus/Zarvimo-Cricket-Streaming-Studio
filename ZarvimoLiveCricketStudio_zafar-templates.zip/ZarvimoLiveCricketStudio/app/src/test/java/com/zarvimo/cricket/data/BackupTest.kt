package com.zarvimo.cricket.data

import com.zarvimo.cricket.graphics.MatchVisuals
import com.zarvimo.cricket.scoring.*
import org.junit.Assert.*
import org.junit.Test

class BackupTest {
    private fun match(id: String): Json.SavedMatch {
        val setup = MatchSetup(teamA = "L", teamB = "T")
        val s = MatchSession(setup)
        s.startInnings(InningsSetup("L", "T", "A1", "A2", "T1"))
        s.add { BallEvent(it, runsBat = 2) }
        return Json.SavedMatch(id, "L v T", 1L, setup, MatchVisuals(), s)
    }

    @Test fun roundTrip_keepsScore() {
        val v = Backup.validate(Backup.export(listOf(match("m1")), emptyList(), null, 5L))
        assertTrue(v.ok); assertEquals(1, v.matches.size)
        assertEquals(2, v.matches[0].session!!.stateOf(0)!!.runs)
    }

    @Test fun rejectsGarbageWrongFormatAndNewerVersion() {
        assertFalse(Backup.validate("not json").ok)
        assertFalse(Backup.validate("""{"format":"other","version":1}""").ok)
        assertFalse(Backup.validate("""{"format":"zarvimo-backup","version":99}""").ok)
    }

    @Test fun corruptMatchIsSkipped_notFatal() {
        val v = Backup.validate("""{"format":"zarvimo-backup","version":1,"matches":[{"id":"x"}]}""")
        assertTrue(v.ok); assertEquals(0, v.matches.size); assertEquals(1, v.skipped.size)
    }

    @Test fun plan_detectsDuplicates_andFreshIdIsUnique() {
        val v = Backup.validate(Backup.export(listOf(match("m1"), match("m2")), emptyList(), null, 5L))
        val p = Backup.plan(v, setOf("m1"), emptySet())
        assertEquals(listOf("m1"), p.duplicates.map { it.id }); assertEquals(listOf("m2"), p.newMatches.map { it.id })
        assertEquals("m1-copy3", Backup.freshId("m1", setOf("m1-copy2")))
    }

    @Test fun streamSettings_exportHasNoKey() {
        val t = Backup.export(emptyList(), emptyList(), com.zarvimo.cricket.stream.StreamSettings(streamKey = "SECRET123"), 1L)
        assertFalse(t.contains("SECRET123"))
    }
}
