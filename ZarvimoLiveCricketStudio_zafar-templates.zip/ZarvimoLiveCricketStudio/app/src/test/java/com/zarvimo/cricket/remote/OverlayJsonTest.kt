package com.zarvimo.cricket.remote

import com.zarvimo.cricket.graphics.MatchVisuals
import com.zarvimo.cricket.scoring.*
import org.junit.Assert.*
import org.junit.Test

class OverlayJsonTest {
    @Test fun matchesEngine_andLeaksNothingPrivate() {
        val setup = MatchSetup(teamA = "L", teamB = "T", oversLimit = 5)
        val s = MatchSession(setup); s.startInnings(InningsSetup("L", "T", "A1", "A2", "T1")); s.add { BallEvent(it, runsBat = 4, boundary = true) }
        val j = OverlayJson.build(setup, MatchVisuals(), s.currentState, null, false, false)
        assertEquals(4, j.getInt("runs")); assertEquals("4/0", j.getString("score")); assertEquals("A1", j.getJSONObject("striker").getString("name"))
        val text = j.toString().lowercase()
        listOf("streamkey", "token", "password", "path").forEach { assertFalse(text.contains(it)) }
    }
    @Test fun noInnings_isNotLive() = assertFalse(OverlayJson.build(MatchSetup(), MatchVisuals(), null, null, false, false).getBoolean("live"))
}
