# New features (Reports, Analytics, Graphics, Health, Commentary, Highlights, Sponsors, Remote, OBS)

STATUS: written but NEVER COMPILED OR RUN. Expect compile errors on the first build; fix them from the Gradle log.

Open **Home → Reports & tools**.

## Remote scoring (second phone)
1. Both phones on the same Wi-Fi (or the host phone's hotspot).
2. Host: Reports & tools → Remote scoring → Start server → New pairing code.
3. Scorer phone browser: open the shown address `http://<ip>:8765/remote`, enter the code. The host must tap Allow.
4. Remote can: runs, wickets, extras, set bowler, new batter, ask for undo. Undo is applied only when the host approves.
5. Innings transitions, setup and anything stream-related are host-only. Host can Disconnect any device.
Reconnect: the page retries the same command id; duplicates are ignored by the host; a sequence gap triggers resync.

## OBS
Start the server, then in OBS add a Browser source: `http://<ip>:8765/overlay` (1920x1080).
Layouts: `?layout=bar|compact|full`. Test page: `/preview`. Direct OBS control (scene switching) is NOT implemented.

## Requirements
No API keys. Local recording must be ON for highlight clips. FileProvider is declared in the manifest for sharing exports.

## Needs real-device verification (nothing here has been verified)
Streaming metrics, battery/storage readings, MediaMuxer clip export on your recordings, sponsor banner timing, Urdu rendering,
LAN server from a second phone and from OBS, TTS commentary into the stream, PDF layout.
