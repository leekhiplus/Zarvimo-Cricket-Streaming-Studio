# PROGRESS / HANDOFF (read this first when continuing)

Project: Zarvimo Live Cricket Streaming Studio (native Android, Kotlin, Compose, RootEncoder).
Working dir: /home/claude/ZarvimoLiveCricketStudio  (snapshot copies saved in /mnt/user-data/outputs)

## Environment facts (verified)
- JDK 21 present. NO Gradle, NO Kotlin compiler, NO Android SDK, NO network for bash => nothing can be compiled or
  unit-tested in this sandbox. Every file is therefore UNCOMPILED until built on GitHub Actions / Android Studio.
- web_search works (used to verify library coordinates).

## Decisions
- Transport: RootEncoder `com.github.pedroSG94.RootEncoder:library:2.8.1` (JitPack, Apache-2.0; README lists RTMP + RTMPS,
  H264, AAC). Version taken from the official README fetched during this session.
- Pipeline: custom `VideoSource` that draws the composed frame (Canvas) into RootEncoder's SurfaceTexture ->
  RootEncoder GL pipeline -> MediaCodec H.264 + AAC -> RTMP. Preview = `GenericStream.startPreview(surfaceView)` which
  shows the SAME GL output that feeds the encoder.
- Toolchain: AGP 8.10.1, Gradle 8.11.1, Kotlin 2.1.21 (+compose plugin), Compose BOM 2025.05.01, compileSdk 36,
  targetSdk 35, minSdk 24, JDK 17. NOT verified by a build. If RootEncoder 2.8.1 was compiled with a newer Kotlin and the
  compiler complains about metadata version, bump Kotlin + compose plugin in build.gradle.kts.
- 480p profile uses 848x480 (16-aligned) instead of 854x480 for encoder compatibility (documented in README).
- Foreground service type: microphone only (no MediaProjection, no camera).
- Gradle wrapper JAR could not be generated offline: workflow uses gradle/actions/setup-gradle with gradle-version 8.11.1;
  gradle-wrapper.properties is included; README tells users to run `gradle wrapper` once in Android Studio.

## DONE (this session)
- [x] Gradle skeleton, manifest, resources, .gitignore, THIRD_PARTY_NOTICES.md
- [x] scoring/Models.kt, ScoreEngine.kt, MatchSession.kt (event-sourced; undo/redo/edit/delete validated by replay)
- [x] test/scoring/ScoreEngineTest.kt (~70 tests; hand-traced, not executed)
- [x] stream/StreamModel.kt (config, validator, state machine, reconnect policy, labels) + test/stream/StreamModelTest.kt
- [x] .github/workflows/build-android.yml

## CI / Release (updated)
- The workflow is NOT inside this zip. It is delivered separately as `build-release.yml` and must be saved in the
  repository as `.github/workflows/build-release.yml`.
- It accepts this zip committed as-is (it unzips it on the runner) or the extracted project, builds the debug APK,
  and publishes it under GitHub Releases (tag `v<versionName>-build<run number>`). Unit tests run AFTER the APK is
  built and are informational (a failing hand-traced test does not block the release). Remove `continue-on-error`
  from the "Run unit tests" step once the tests are known to pass.
- Placeholders added so the APK installs and opens: `ZarvimoApp.kt`, `MainActivity.kt`, `stream/StreamService.kt`.
  Replace them with the real implementations (TODO items 3 and 5).
- `app/debug.keystore` (public debug key, password `android`) gives every CI build the same signature, so a new APK
  installs over the previous one. Never use it for Play Store releases.
- Main sources (scoring/, stream/StreamModel.kt) were re-read for compile errors on this pass; still not compiled.

## TODO (in order)
1. graphics/: GraphicsConfig (+3 templates, colors, position/size/margins, safe area, presets) and
   BroadcastRenderer (Canvas) that draws background, logo, sponsor, scoreboard, ticker from MatchState + GraphicsConfig.
   Add pure-logic tests (safe-area clamp, scaling to output profiles).
2. stream/BroadcastVideoSource.kt (RootEncoder VideoSource) - VERIFY exact abstract members against 2.8.1
   (known from a Dec-2025 discussion: start(SurfaceTexture), stop(), isRunning(), getOrientationConfig(); create(...) and
   release() also exist - check signatures on first compile).
3. stream/StreamEngine.kt (wraps GenericStream, ConnectChecker callbacks -> StreamStateMachine, bounded backoff reconnect,
   mic mute, audio focus) + StreamService.kt (foreground, Stop Live action, notification channel) + ZarvimoApp.kt.
4. data/: JSON persistence (saved matches, graphics presets, stream settings), SecretStore (Android Keystore AES-GCM)
   for the stream key, media import (SAF persistable URIs -> app-private copies).
5. ui/: MainActivity + Compose navigation + 9 screens (Home, Match Setup, Scoring Console, Program Preview, Graphics Editor,
   Stream Config, Live Monitor, Saved/Presets, Settings/Diagnostics) + ViewModel.
6. README.md (full, honest), LICENSE (project license choice - ask user), final ZIP + verify listing.
7. Final report: what was/wasn't verified. Live RTMP end-to-end test CANNOT be done in this sandbox.

## Honest status
- Nothing has been compiled or run. No streaming test was possible.
