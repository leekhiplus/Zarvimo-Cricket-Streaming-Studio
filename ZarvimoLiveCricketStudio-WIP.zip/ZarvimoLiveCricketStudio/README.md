# Zarvimo Live Cricket Studio

Native Android app (Kotlin, Jetpack Compose) for live cricket scoring and RTMP/RTMPS streaming.
Status: work in progress, see `PROGRESS.md`.

## Get the APK from GitHub (no Android Studio needed)

1. Upload `ZarvimoLiveCricketStudio-WIP.zip` to your repository (the zip itself is fine, no need to extract it).
2. Add the workflow file as `.github/workflows/build-release.yml` (Add file > Create new file).
3. Every push runs the build. When it finishes (about 5-10 minutes) open **Releases** on the repository page and
   download the `.apk`. You can also start it manually: Actions > "Build APK and publish Release" > Run workflow.

Install the APK on a phone by allowing "install unknown apps" for your browser or file manager.
It is a debug-signed build; all builds share one signing key, so a newer APK installs over an older one.

## Build locally

Open the folder in Android Studio (JDK 17), or run `gradle :app:assembleDebug` with Gradle 8.11.1.

## Licenses

See `THIRD_PARTY_NOTICES.md`. A project license has not been chosen yet.
