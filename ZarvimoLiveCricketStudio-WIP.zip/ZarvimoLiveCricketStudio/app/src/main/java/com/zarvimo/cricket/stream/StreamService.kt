package com.zarvimo.cricket.stream

import android.app.Service
import android.content.Intent
import android.os.IBinder

/**
 * PLACEHOLDER for the foreground streaming service declared in the manifest (type "microphone").
 * The real implementation (StreamEngine + notification + Stop Live action) is listed in PROGRESS.md.
 */
class StreamService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}
