package com.zarvimo.cricket

import android.app.Application

/** Application class referenced by the manifest. App-wide initialisation will be added here later. */
class ZarvimoApp : Application()
