package com.zarvimo.cricket.scoring

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SuperOverTest {

    private fun session() = MatchSession(MatchSetup(teamA = "A", teamB = "B", oversLimit = 1, playersPerSide = 3))

    private fun MatchSession.ok(r: OpResult) = assertTrue("Expected Ok but got $r", r is OpResult.Ok)

    private fun MatchSession.sixSingles() = repeat(6) { ok(add { id -> BallEvent(id, runsBat = 1) }) }

    /** A and B both score 6: the match is tied. */
    private fun tied(): MatchSession {
        val s = session()
        s.ok(s.startInnings(InningsSetup("A", "B", "a1", "a2", "b1")))
        s.sixSingles()
        s.ok(s.startInnings(InningsSetup("B", "A", "b1", "b2", "a1")))
        s.sixSingles()
        return s
    }

    @Test fun tiedMatch_offersSuperOver_withReversedBattingOrder() {
        val s = tied()
        assertEquals("MATCH TIED", s.finalResult())
        assertTrue(s.canStartSuperOver)
        assertEquals("B", s.nextSuperOverBattingTeam)
    }

    @Test fun superOver_isOneOver_twoWickets_andCanDecideTheMatch() {
        val s = tied()
        s.ok(s.startInnings(InningsSetup("B", "A", "b1", "b2", "a1")))
        val first = s.currentState!!
        assertEquals(1, first.oversLimit)
        assertEquals(2, first.maxWickets)
        assertNull(first.target)
        repeat(6) { s.ok(s.add { id -> BallEvent(id, runsBat = 4, boundary = true) }) }
        assertTrue(s.currentState!!.ended)
        assertEquals(24, s.currentState!!.runs)

        s.ok(s.startInnings(InningsSetup("A", "B", "a1", "a2", "b1")))
        assertEquals(25, s.currentState!!.target)
        s.ok(s.add { id -> BallEvent(id, wicket = WicketInfo(DismissalType.BOWLED, true, null, null)) })
        s.ok(s.add { id -> BatterInEvent(id, "a3") })
        s.ok(s.add { id -> BallEvent(id, wicket = WicketInfo(DismissalType.BOWLED, true, null, null)) })
        assertTrue("two wickets end a super over", s.currentState!!.ended)
        assertEquals("B WON THE SUPER OVER", s.finalResult())
        assertFalse(s.canStartSuperOver)
    }

    @Test fun superOver_notAllowedWhenNotTied() {
        val s = session()
        s.ok(s.startInnings(InningsSetup("A", "B", "a1", "a2", "b1")))
        s.sixSingles()
        s.ok(s.startInnings(InningsSetup("B", "A", "b1", "b2", "a1")))
        repeat(4) { s.ok(s.add { id -> BallEvent(id, runsBat = 2) }) }
        assertEquals("B WON BY 2 WICKETS", s.finalResult())
        assertFalse(s.canStartSuperOver)
        assertTrue(s.startInnings(InningsSetup("A", "B", "a1", "a2", "b1")) is OpResult.Error)
    }

    @Test fun reducedOvers_rejectedWhenBallsAlreadyExceedThem() {
        val s = MatchSession(MatchSetup(teamA = "A", teamB = "B", oversLimit = 20))
        s.ok(s.startInnings(InningsSetup("A", "B", "a1", "a2", "b1")))
        repeat(6) { s.ok(s.add { id -> BallEvent(id, runsBat = 1) }) }
        s.ok(s.add { id -> SetBowlerEvent(id, "b2") })
        repeat(6) { s.ok(s.add { id -> BallEvent(id, runsBat = 1) }) }
        assertTrue(s.setOversOverride(0, 1) is OpResult.Error)
        s.ok(s.setOversOverride(0, 5))
        assertEquals(5, s.stateOf(0)!!.oversLimit)
        assertEquals(20, s.setup.oversLimit)
    }
}
