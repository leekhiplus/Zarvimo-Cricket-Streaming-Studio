package com.zarvimo.cricket.scoring

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DlsAndTossTest {

    @Test
    fun revisedTargetWithFewerResources() {
        // par = 150 x 80 / 100 = 120, target = par + 1
        assertEquals(121, Dls.revisedTarget(150, 100.0, 80.0, 245))
    }

    @Test
    fun revisedTargetWithEqualResources() {
        assertEquals(151, Dls.revisedTarget(150, 100.0, 100.0, 245))
    }

    @Test
    fun revisedTargetWithMoreResources() {
        // par = 200 + 245 x (100 - 90) / 100 = 224.5 -> 224, target 225
        assertEquals(225, Dls.revisedTarget(200, 90.0, 100.0, 245))
    }

    @Test
    fun invalidInputsGiveNoTarget() {
        assertNull(Dls.revisedTarget(-1, 100.0, 80.0, 245))
        assertNull(Dls.revisedTarget(100, 0.0, 80.0, 245))
        assertNull(Dls.revisedTarget(100, 100.0, 0.0, 245))
        assertNull(Dls.revisedTarget(100, 100.0, 80.0, 0))
    }

    @Test
    fun tossDecidesBattingFirstTeamAndPreMatchLines() {
        val s = MatchSetup(teamA = "Lahore", teamB = "Karachi", tossWinner = "Karachi", tossDecision = TossDecision.BOWL, startTime = "3:30 pm")
        assertEquals("Lahore", s.battingFirstTeam)
        val (first, second) = s.preMatchLines()
        assertEquals("TOSS: KARACHI WON AND CHOSE TO BOWL FIRST", first)
        assertTrue(second!!.contains("LAHORE BAT FIRST"))
        assertTrue(second.contains("MATCH STARTS 3:30 PM"))
    }

    @Test
    fun noTossMeansNothingToAnnounce() {
        val s = MatchSetup()
        assertNull(s.battingFirstTeam)
        val (first, second) = s.preMatchLines()
        assertNull(first)
        assertNull(second)
    }
}
