package com.zarvimo.cricket.stream

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class CrowdSynthTest {

    @Test fun everySound_isStereo_audible_andNotClipping() {
        for (k in Sfx.values()) {
            val d = CrowdSynth.render(k)
            assertTrue("$k has an even number of samples (stereo)", d.size % 2 == 0)
            assertTrue("$k lasts at least half a second", d.size / 2 >= CrowdSynth.RATE / 2)
            val peak = d.maxOf { abs(it.toInt()) }
            assertTrue("$k is audible (peak $peak)", peak > 8000)
            assertTrue("$k leaves headroom (peak $peak)", peak < 32767)
        }
    }

    @Test fun rendering_isDeterministic() {
        assertArrayEquals(CrowdSynth.render(Sfx.APPLAUSE), CrowdSynth.render(Sfx.APPLAUSE))
    }

    @Test fun ambience_loopsWithoutAJump() {
        val d = CrowdSynth.render(Sfx.AMBIENCE)
        val n = d.size / 2
        assertEquals(12 * CrowdSynth.RATE, n)
        // the step from the last frame to the first frame is no bigger than normal sample-to-sample movement
        var maxStep = 0
        for (i in 1 until 2000) maxStep = maxOf(maxStep, abs(d[2 * i] - d[2 * (i - 1)]))
        val seam = abs(d[0] - d[2 * (n - 1)])
        assertTrue("seam $seam vs normal $maxStep", seam <= maxStep * 3 + 2000)
    }

    @Test fun player_mixesVoices_andFinishesOneShots() {
        val p = SfxPlayer()
        val dst = ShortArray(200)
        assertEquals(0, p.pullStereo(dst, 100))
        p.play(Sfx.CHEER, ShortArray(300) { 1000 }, 1f)
        p.play(Sfx.HORN, ShortArray(300) { 500 }, 1f)
        assertTrue(p.oneShotActive)
        assertEquals(100, p.pullStereo(dst, 100))
        assertEquals(1500, dst[0].toInt())
        assertEquals(100, p.pullStereo(dst, 100))
        assertFalse("both clips ended", p.oneShotActive)
        assertEquals(0, p.pullStereo(dst, 100))
    }

    @Test fun player_loopKeepsGoing_untilStopped() {
        val p = SfxPlayer()
        val dst = ShortArray(400)
        p.play(Sfx.AMBIENCE, ShortArray(50) { 200 }, 0.5f, loop = true)
        repeat(5) { assertEquals(200, p.pullStereo(dst, 200)) }
        assertEquals(100, dst[399].toInt())
        assertFalse(p.oneShotActive)
        p.stop(Sfx.AMBIENCE)
        assertEquals(0, p.pullStereo(dst, 200))
    }
}
