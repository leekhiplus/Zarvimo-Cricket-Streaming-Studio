package com.zarvimo.cricket.stream

import com.zarvimo.cricket.data.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class WavDecoderTest {

    private fun wav(format: Int, bits: Int, rate: Int, channels: Int, extensible: Boolean, data: ByteArray): ByteArray {
        val fmtLen = if (extensible) 40 else 16
        val bb = ByteBuffer.allocate(12 + 8 + fmtLen + 8 + data.size).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()).putInt(36 + data.size).put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()).putInt(fmtLen)
        bb.putShort((if (extensible) 0xFFFE else format).toShort()).putShort(channels.toShort()).putInt(rate)
        bb.putInt(rate * channels * bits / 8).putShort((channels * bits / 8).toShort()).putShort(bits.toShort())
        if (extensible) {
            bb.putShort(22).putShort(bits.toShort()).putInt(4)
            bb.putShort(format.toShort()) // first two bytes of the sub-format GUID = the real format
            bb.put(ByteArray(14))
        }
        bb.put("data".toByteArray()).putInt(data.size).put(data)
        return bb.array()
    }

    private fun pcm16(vararg v: Int): ByteArray {
        val o = ByteArrayOutputStream()
        for (x in v) { o.write(x and 0xFF); o.write((x shr 8) and 0xFF) }
        return o.toByteArray()
    }

    @Test fun pcm16Mono_isDuplicatedToStereo() {
        val out = WavDecoder.toStereo44k(wav(1, 16, 44100, 1, false, pcm16(1000, -2000, 3000)))!!
        assertEquals(6, out.size)
        assertEquals(1000, out[0].toInt()); assertEquals(1000, out[1].toInt())
        assertEquals(-2000, out[2].toInt())
    }

    @Test fun extensiblePcm16_isAccepted() {
        val out = WavDecoder.toStereo44k(wav(1, 16, 44100, 1, true, pcm16(500, 600)))
        assertNotNull(out)
        assertEquals(500, out!![0].toInt())
    }

    @Test fun float32_isConvertedTo16Bit() {
        val bb = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN)
        bb.putFloat(0.5f).putFloat(-1f)
        val out = WavDecoder.toStereo44k(wav(3, 32, 44100, 1, false, bb.array()))!!
        assertEquals(16383, out[0].toInt())
        assertEquals(-32767, out[2].toInt())
    }

    @Test fun resamples_toTheStreamRate() {
        val out = WavDecoder.toStereo44k(wav(1, 16, 22050, 1, false, pcm16(*IntArray(100) { 1000 })))!!
        assertTrue(out.size / 2 in 195..205)
    }

    @Test fun unsupportedOrBrokenInput_returnsNull() {
        assertNull(WavDecoder.toStereo44k(ByteArray(10)))
        assertNull(WavDecoder.toStereo44k(wav(1, 8, 44100, 1, false, ByteArray(10))))
    }

    @Test fun audioMixSettings_newFieldsRoundTripAndAreClamped() {
        val s = AudioMixSettings(musicOnAir = false, duckMusic = false, duckLevel = 0.5f)
        val back = Json.audioMixFromJson(Json.audioMixToJson(s))
        assertEquals(false, back.musicOnAir)
        assertEquals(false, back.duckMusic)
        assertEquals(0.5f, back.duckLevel, 0.001f)
        assertEquals(0.05f, AudioMixSettings(duckLevel = 0f).sanitized().duckLevel, 0.0001f)
    }
}
