package com.zarvimo.cricket.stream

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StreamModelTest {

    // ------------------------------------------------------------ validation

    @Test fun validate_acceptsRtmpAndBuildsEndpoint() {
        val r = StreamValidator.validate("rtmp://a.rtmp.youtube.com/live2", "abcd-efgh-ijkl")
        assertTrue(r is ValidationResult.Valid)
        r as ValidationResult.Valid
        assertEquals("rtmp://a.rtmp.youtube.com/live2/abcd-efgh-ijkl", r.endpoint)
        assertFalse(r.secure)
    }

    @Test fun validate_acceptsRtmpsWithPort_andFlagsSecure() {
        val r = StreamValidator.validate(" rtmps://a.rtmps.youtube.com:443/live2/ ", " key123 ") as ValidationResult.Valid
        assertEquals("rtmps://a.rtmps.youtube.com:443/live2/key123", r.endpoint)
        assertTrue(r.secure)
    }

    @Test fun validate_rejectsEmptyAndWrongScheme() {
        val r = StreamValidator.validate("http://example.com/live", "") as ValidationResult.Invalid
        assertTrue(r.problems.any { it.contains("rtmp://") })
        assertTrue(r.problems.any { it.contains("key", ignoreCase = true) })
        assertTrue(StreamValidator.validate("", "k") is ValidationResult.Invalid)
    }

    @Test fun validate_rejectsSpacesAndMissingHost() {
        assertTrue(StreamValidator.validate("rtmp://host/live 2", "k") is ValidationResult.Invalid)
        assertTrue(StreamValidator.validate("rtmp:///live", "k") is ValidationResult.Invalid)
        assertTrue(StreamValidator.validate("rtmp://host/live", "ab cd") is ValidationResult.Invalid)
    }

    @Test fun neverLeaksKey_inToString_orRedaction() {
        val secret = "SUPER-SECRET-KEY-1234"
        val settings = StreamSettings(serverUrl = "rtmp://a.rtmp.youtube.com/live2", streamKey = secret)
        assertFalse(settings.toString().contains(secret))
        val valid = StreamValidator.validate(settings.serverUrl, secret) as ValidationResult.Valid
        assertFalse(valid.toString().contains(secret))
        assertFalse(StreamValidator.redactServer("rtmp://host:1935/app/$secret").contains(secret))
        assertEquals("rtmp://host:1935/...", StreamValidator.redactServer("rtmp://host:1935/app/$secret"))
    }

    @Test fun scrub_removesKeyFromErrorText() {
        val out = StreamValidator.scrub("handshake failed for rtmp://h/app/SECRETKEY99", "SECRETKEY99")
        assertFalse(out.contains("SECRETKEY99"))
        assertTrue(out.contains("<key>"))
        assertEquals("", StreamValidator.scrub(null, "k"))
    }

    // ------------------------------------------------------------ profiles

    @Test fun profiles_areLandscapeAndBitrateClamped() {
        ResolutionProfile.values().forEach {
            assertTrue(it.width > it.height)
            assertEquals(0, it.width % 2)
            assertEquals(0, it.height % 2)
            assertTrue(it.defaultKbps in it.minKbps..it.maxKbps)
        }
        assertEquals(800, ResolutionProfile.P360.clampBitrate(5000))
        assertEquals(400, ResolutionProfile.P360.clampBitrate(10))
        assertEquals(listOf(15, 20, 24, 30), StreamOptions.fpsOptions)
    }

    // ------------------------------------------------------------ state machine

    private fun walk(start: StreamState, vararg events: StreamEvent): StreamState {
        var s = start
        for (e in events) s = StreamStateMachine.next(s, e) ?: error("Invalid transition: $s + $e")
        return s
    }

    @Test fun happyPath_idleToStreamingToIdle() {
        assertEquals(StreamState.STREAMING, walk(StreamState.IDLE,
            StreamEvent.StartRequested, StreamEvent.PrepareSucceeded, StreamEvent.ConnectionSucceeded))
        assertEquals(StreamState.IDLE, walk(StreamState.STREAMING, StreamEvent.StopRequested, StreamEvent.StopCompleted))
    }

    @Test fun cannotBecomeStreaming_withoutConnectionSuccess() {
        assertNull(StreamStateMachine.next(StreamState.IDLE, StreamEvent.ConnectionSucceeded))
        assertNull(StreamStateMachine.next(StreamState.PREPARING, StreamEvent.ConnectionSucceeded))
        assertNull(StreamStateMachine.next(StreamState.STOPPING, StreamEvent.ConnectionSucceeded))
        assertNull(StreamStateMachine.next(StreamState.ERROR, StreamEvent.ConnectionSucceeded))
    }

    @Test fun firstConnectionFailure_goesToError_thenUserCanRetry() {
        val s = walk(StreamState.IDLE,
            StreamEvent.StartRequested, StreamEvent.PrepareSucceeded, StreamEvent.ConnectionFailed("refused"))
        assertEquals(StreamState.ERROR, s)
        assertEquals(StreamState.PREPARING, StreamStateMachine.next(s, StreamEvent.StartRequested))
    }

    @Test fun prepareFailure_goesToError() {
        assertEquals(StreamState.ERROR, walk(StreamState.IDLE,
            StreamEvent.StartRequested, StreamEvent.PrepareFailed("encoder unsupported")))
    }

    @Test fun connectionLost_reconnects_thenRecovers_orExhausts() {
        val lost = walk(StreamState.STREAMING, StreamEvent.ConnectionLost("eof"))
        assertEquals(StreamState.RECONNECTING, lost)
        assertEquals(StreamState.RECONNECTING, walk(lost, StreamEvent.ReconnectAttemptFailed("timeout")))
        assertEquals(StreamState.STREAMING, walk(lost, StreamEvent.ConnectionSucceeded))
        assertEquals(StreamState.ERROR, walk(lost, StreamEvent.RetriesExhausted("gave up")))
    }

    @Test fun authFailure_isTerminalError() {
        assertEquals(StreamState.ERROR, walk(StreamState.STREAMING, StreamEvent.AuthFailed("bad key")))
        assertEquals(StreamState.ERROR, walk(StreamState.CONNECTING, StreamEvent.AuthFailed("bad key")))
    }

    @Test fun stop_isPossibleFromEveryActiveState_andIdleIgnoresIt() {
        listOf(StreamState.PREPARING, StreamState.CONNECTING, StreamState.STREAMING,
            StreamState.RECONNECTING, StreamState.ERROR).forEach {
            assertEquals(StreamState.STOPPING, StreamStateMachine.next(it, StreamEvent.StopRequested))
        }
        assertNull(StreamStateMachine.next(StreamState.IDLE, StreamEvent.StopRequested))
        assertNull(StreamStateMachine.next(StreamState.IDLE, StreamEvent.StopCompleted))
    }

    @Test fun startIgnored_whileAlreadyActive_preventsDuplicateSessions() {
        listOf(StreamState.PREPARING, StreamState.CONNECTING, StreamState.STREAMING,
            StreamState.RECONNECTING, StreamState.STOPPING).forEach {
            assertNull(StreamStateMachine.next(it, StreamEvent.StartRequested))
        }
    }

    // ------------------------------------------------------------ labels

    @Test fun liveBadge_onlyWhenReallyStreaming() {
        StreamState.values().forEach {
            assertEquals(it == StreamState.STREAMING, StatusLabels.mayShowLiveBadge(it))
        }
        assertEquals("LIVE STREAMING", StatusLabels.stream(StreamState.STREAMING))
        assertEquals("STREAM STOPPED", StatusLabels.stream(StreamState.IDLE))
        assertEquals("CONNECTING", StatusLabels.stream(StreamState.CONNECTING))
        assertEquals("RECONNECTING", StatusLabels.stream(StreamState.RECONNECTING))
        assertEquals("PREVIEW READY", StatusLabels.preview(true))
    }

    @Test fun unavailableMetrics_areNullNotZero() {
        val st = StreamStatus()
        assertNull(st.measuredBitrateBps)
        assertNull(st.measuredFps)
        assertNull(st.droppedFrames)
        assertNull(st.liveSinceMs)
    }

    // ------------------------------------------------------------ reconnect policy

    @Test fun backoff_isExponential_andBounded() {
        val p = ReconnectPolicy(maxAttempts = 6, baseDelayMs = 2_000, maxDelayMs = 30_000)
        assertEquals(2_000, p.delayForAttempt(1))
        assertEquals(4_000, p.delayForAttempt(2))
        assertEquals(8_000, p.delayForAttempt(3))
        assertEquals(16_000, p.delayForAttempt(4))
        assertEquals(30_000, p.delayForAttempt(5))
        assertEquals(30_000, p.delayForAttempt(99))
    }

    @Test fun retries_areBounded() {
        val p = ReconnectPolicy(maxAttempts = 3)
        assertTrue(p.shouldRetry(0))
        assertTrue(p.shouldRetry(2))
        assertFalse(p.shouldRetry(3))
    }

    @Test fun duration_format() {
        assertEquals("00:00:00", DurationFormat.hhmmss(0))
        assertEquals("01:02:03", DurationFormat.hhmmss(3723))
        assertEquals("00:00:00", DurationFormat.hhmmss(-5))
    }
}

class BitrateAdvisorTest {
    @org.junit.Test fun reducesBy25Percent_butNotBelowProfileMinimum() {
        org.junit.Assert.assertEquals(750, BitrateAdvisor.reduced(1000, ResolutionProfile.P480))
        org.junit.Assert.assertEquals(700, BitrateAdvisor.reduced(800, ResolutionProfile.P480)) // 600 -> clamped to 700
        org.junit.Assert.assertEquals(400, BitrateAdvisor.reduced(400, ResolutionProfile.P360))
    }
}
