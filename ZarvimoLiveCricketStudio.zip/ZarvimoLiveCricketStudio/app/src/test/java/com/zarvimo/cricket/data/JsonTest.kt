package com.zarvimo.cricket.data

import com.zarvimo.cricket.graphics.FontChoice
import com.zarvimo.cricket.graphics.GraphicsConfig
import com.zarvimo.cricket.graphics.MatchVisuals
import com.zarvimo.cricket.graphics.ScoreboardTemplate
import com.zarvimo.cricket.scoring.BallEvent
import com.zarvimo.cricket.scoring.DismissalType
import com.zarvimo.cricket.scoring.ExtraType
import com.zarvimo.cricket.scoring.InningsSetup
import com.zarvimo.cricket.scoring.MatchSession
import com.zarvimo.cricket.scoring.MatchSetup
import com.zarvimo.cricket.scoring.OpResult
import com.zarvimo.cricket.scoring.SetBowlerEvent
import com.zarvimo.cricket.scoring.WicketInfo
import com.zarvimo.cricket.stream.ResolutionProfile
import com.zarvimo.cricket.stream.StreamSettings
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class JsonTest {

    @Test fun matchRoundTrip_preservesEveryEvent_andRebuildsIdenticalScore() {
        val setup = MatchSetup(teamA = "Lahore", teamB = "Karachi", oversLimit = 5, title = "Final", venue = "LHR")
        val s = MatchSession(setup)
        s.startInnings(InningsSetup("Lahore", "Karachi", "A", "B", "X"))
        s.add { BallEvent(it, runsBat = 4, boundary = true) }
        s.add { BallEvent(it, extra = ExtraType.NO_BALL, extraRuns = 2, noBallRunType = ExtraType.LEG_BYE) }
        s.add { BallEvent(it, wicket = WicketInfo(DismissalType.RUN_OUT, outBatterIsStriker = false, fielder = "F", incomingBatter = "C"), runsBat = 1) }
        for (i in 1..3) s.add { BallEvent(it) }
        s.add { SetBowlerEvent(it, "Y") }

        val before = s.currentState!!
        val text = Json.matchToJson(Json.SavedMatch("m1", "Test", 123L, setup, MatchVisuals(), s)).toString()
        val back = Json.matchFromJson(JSONObject(text))
        val after = back.session!!.currentState!!

        assertEquals(before.runs, after.runs)
        assertEquals(before.wickets, after.wickets)
        assertEquals(before.oversText, after.oversText)
        assertEquals(before.striker!!.name, after.striker!!.name)
        assertEquals(s.current!!.events, back.session!!.current!!.events)
        assertEquals("Final", back.setup.title)
        // new events after a reload must not reuse old ids
        val ok = back.session!!.add { BallEvent(it) }
        assertTrue(ok is OpResult.Ok)
        assertEquals(back.session!!.current!!.events.map { it.id }.toSet().size, back.session!!.current!!.events.size)
    }

    @Test fun graphicsRoundTrip() {
        val g = GraphicsConfig(
            name = "Night", template = ScoreboardTemplate.MODERN_BAR, posX = 0.2f, posY = 0.8f, scale = 1.3f,
            primaryColor = 0xFF112233.toInt(), font = FontChoice.SERIF, tickerText = "Hello", logoUri = "/x/logo.img"
        )
        val back = Json.graphicsFromJson(JSONObject(Json.graphicsToJson(g).toString()))
        assertEquals(g.template, back.template)
        assertEquals(g.posX, back.posX, 1e-6f)
        assertEquals(g.primaryColor, back.primaryColor)
        assertEquals(FontChoice.SERIF, back.font)
        assertEquals("/x/logo.img", back.logoUri)
        assertNull(back.backgroundUri)
    }

    @Test fun graphicsFromGarbage_fallsBackToDefaultsAndSanitizes() {
        val back = Json.graphicsFromJson(JSONObject("""{"template":"NOPE","posX":9,"scale":-4}"""))
        assertEquals(ScoreboardTemplate.CLASSIC, back.template)
        assertEquals(1f, back.posX, 0f)
        assertEquals(0.5f, back.scale, 0f)
    }

    @Test fun streamSettings_neverSerialiseTheKey() {
        val s = StreamSettings(serverUrl = "rtmp://h/app", streamKey = "TOPSECRETKEY", profile = ResolutionProfile.P720, videoBitrateKbps = 9999)
        val text = Json.streamSettingsToJson(s).toString()
        assertFalse(text.contains("TOPSECRETKEY"))
        val back = Json.streamSettingsFromJson(JSONObject(text))
        assertEquals("", back.streamKey)
        assertEquals(ResolutionProfile.P720, back.profile)
        assertEquals(3000, back.videoBitrateKbps) // clamped to profile max
    }

    @Test fun unknownEventType_isSkipped_notCrash() {
        assertNull(Json.eventFromJson(JSONObject("""{"t":"mystery","id":5}""")))
        assertNotNull(Json.eventFromJson(JSONObject("""{"t":"swap","id":6}""")))
    }
}
