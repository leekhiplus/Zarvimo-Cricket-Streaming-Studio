package com.zarvimo.cricket.graphics

import com.zarvimo.cricket.scoring.BallEvent
import com.zarvimo.cricket.scoring.InningsSetup
import com.zarvimo.cricket.scoring.MatchSession
import com.zarvimo.cricket.scoring.MatchSetup
import com.zarvimo.cricket.scoring.OpResult
import com.zarvimo.cricket.scoring.TossDecision
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CardsAndAlertsTest {

    private val visuals = MatchVisuals()

    private fun finished(): Pair<MatchSetup, MatchSession> {
        val setup = MatchSetup(teamA = "Lahore", teamB = "Karachi", oversLimit = 1, playersPerSide = 3, tossWinner = "Lahore", tossDecision = TossDecision.BAT)
        val s = MatchSession(setup)
        s.startInnings(InningsSetup("Lahore", "Karachi", "L1", "L2", "K1"))
        repeat(6) { check(s.add { id -> BallEvent(id, runsBat = 2) } is OpResult.Ok) }
        s.startInnings(InningsSetup("Karachi", "Lahore", "K1", "K2", "L1"))
        repeat(4) { check(s.add { id -> BallEvent(id, runsBat = 1) } is OpResult.Ok) }
        return Pair(setup, s)
    }

    @Test fun tossCard_needsAWinner() {
        assertNull(PanelBuilder.toss(MatchSetup(teamA = "A", teamB = "B"), visuals))
        val p = PanelBuilder.toss(MatchSetup(teamA = "A", teamB = "B", tossWinner = "A", tossDecision = TossDecision.BOWL), visuals)!!
        assertEquals(PanelKind.TOSS_CARD, p.kind)
        assertEquals("A", p.subtitle)
        assertTrue(p.footer.contains("BOWL"))
    }

    @Test fun manOfMatch_needsAName_andFindsTheTeamSide() {
        assertNull(PanelBuilder.manOfMatch(MatchSetup(teamA = "A", teamB = "B"), visuals))
        val p = PanelBuilder.manOfMatch(MatchSetup(teamA = "A", teamB = "B", momName = "Ali", momTeam = "b", momDetail = "50 off 20"), visuals)!!
        assertEquals("ALI", p.subtitle)
        assertEquals(2, p.teamSide)
        assertEquals("50 OFF 20", p.footer)
    }

    @Test fun summary_showsBothInnings_andTheTopBatter() {
        val (setup, s) = finished()
        val p = PanelBuilder.summary(setup, s, visuals)!!
        assertEquals(PanelKind.MATCH_SUMMARY, p.kind)
        assertTrue(p.batHeader.first().startsWith("LAHORE"))
        assertTrue(p.bowlHeader.first().startsWith("KARACHI"))
        assertTrue(p.bat.any { it.sub == "BAT" })
        assertTrue(p.bat.any { it.sub == "BOWL" })
        assertEquals("MATCH IN PROGRESS", p.footer)
    }

    @Test fun resultCard_onlyWhenFinished() {
        val (setup, s) = finished()
        assertNull(PanelBuilder.result(setup, s, visuals))
        s.add { id -> BallEvent(id, runsBat = 6, boundary = true) }
        s.add { id -> BallEvent(id, runsBat = 4, boundary = true) }
        val p = PanelBuilder.result(setup.copy(momName = "Ali"), s, visuals)
        assertNotNull(p)
        assertEquals("KARACHI WON BY 2 WICKETS", p!!.subtitle)
        assertTrue(p.footer.contains("ALI"))
    }

    @Test fun topPerformers_rankRunsAndWickets() {
        val (_, s) = finished()
        val top = PanelBuilder.topPerformers(s)
        assertTrue(top.isNotEmpty())
        assertTrue(top.zipWithNext().all { (a, b) -> a.points >= b.points })
    }

    @Test fun alertKinds_haveTextAndStickyBreaks() {
        assertTrue(AlertKind.values().all { it.title.isNotBlank() })
        assertTrue(AlertKind.DRINKS.sticky)
        assertTrue(!AlertKind.UMPIRES_CALL.sticky)
        val r = DrsText.review("Lahore", 1)
        assertTrue(r.sub.contains("LAHORE") && r.sub.contains("REVIEWS LEFT: 1") && r.sticky)
    }

    @Test fun fullScreenKinds_areFlagged() {
        assertTrue(PanelKind.RESULT_CARD.fullScreen && PanelKind.TOSS_CARD.fullScreen)
        assertTrue(!PanelKind.SCORECARD.fullScreen)
    }
}
