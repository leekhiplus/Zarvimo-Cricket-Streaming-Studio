package com.zarvimo.cricket.data

import com.zarvimo.cricket.scoring.InningsSeed
import com.zarvimo.cricket.scoring.InningsSetup
import com.zarvimo.cricket.scoring.SeedBatter
import com.zarvimo.cricket.scoring.SeedBowler
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SeedJsonTest {

    @Test
    fun seedSurvivesSaveAndLoad() {
        val seed = InningsSeed(
            runs = 52, wickets = 2, legalBalls = 33, wides = 3, noBalls = 1,
            strikerRuns = 18, strikerBalls = 14, strikerFours = 2, strikerSixes = 1,
            nonStrikerRuns = 8, nonStrikerBalls = 9,
            bowlerLegalBalls = 15, bowlerRuns = 20, bowlerWickets = 1, currentOverRuns = 4,
            outBatters = listOf(SeedBatter("Cee", 12, 10, 1, 0, "b Shah")),
            otherBowlers = listOf(SeedBowler("Shah", 12, 0, 18, 1)),
            overRuns = listOf(8, 5, 12),
            partnershipRuns = 20, partnershipBalls = 15
        )
        val setup = InningsSetup("A", "B", "Ali", "Bilal", "Khan", seed)
        val back = Json.inningsSetupFromJson(Json.inningsSetupToJson(setup))
        assertEquals(setup, back)
    }

    @Test
    fun normalInningsHasNoSeed() {
        val setup = InningsSetup("A", "B", "Ali", "Bilal", "Khan")
        assertNull(Json.inningsSetupFromJson(Json.inningsSetupToJson(setup)).seed)
    }
}
