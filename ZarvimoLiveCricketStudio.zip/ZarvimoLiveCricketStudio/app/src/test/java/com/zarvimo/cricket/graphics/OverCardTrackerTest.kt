package com.zarvimo.cricket.graphics

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OverCardTrackerTest {

    @Test fun firstSightNeverTriggers_thenEachNewOverDoes() {
        val t = OverCardTracker()
        assertFalse(t.update("m#0", 7, false, true, 1)) // loaded in the middle of an innings
        assertFalse(t.update("m#0", 7, false, true, 1)) // a ball inside the same over
        assertTrue(t.update("m#0", 8, false, true, 1))
        assertFalse(t.update("m#0", 8, false, true, 1))
        assertTrue(t.update("m#0", 9, false, true, 1))
    }

    @Test fun undoDoesNotTrigger_andRedoingTheOverDoes() {
        val t = OverCardTracker()
        t.update("m#0", 3, false, true, 1)
        assertFalse(t.update("m#0", 2, false, true, 1)) // undo
        assertTrue(t.update("m#0", 3, false, true, 1)) // over completed again
    }

    @Test fun respectsEveryNthOver_disabled_andEndedInnings() {
        val t = OverCardTracker()
        t.update("m#0", 0, false, true, 2)
        assertFalse(t.update("m#0", 1, false, true, 2))
        assertTrue(t.update("m#0", 2, false, true, 2))
        assertFalse(t.update("m#0", 3, false, false, 2)) // switched off
        assertFalse(t.update("m#0", 4, true, true, 2)) // innings over
    }

    @Test fun newInningsOrMatchStartsFresh() {
        val t = OverCardTracker()
        t.update("a#0", 19, false, true, 1)
        assertFalse(t.update("a#1", 0, false, true, 1))
        assertFalse(t.update("b#0", 5, false, true, 1))
        assertTrue(t.update("b#0", 6, false, true, 1))
        t.reset()
        assertFalse(t.update("b#0", 7, false, true, 1))
    }
}
