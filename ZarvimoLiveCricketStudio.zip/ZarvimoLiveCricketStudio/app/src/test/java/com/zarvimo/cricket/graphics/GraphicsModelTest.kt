package com.zarvimo.cricket.graphics

import com.zarvimo.cricket.scoring.BallEvent
import com.zarvimo.cricket.scoring.ExtraType
import com.zarvimo.cricket.scoring.InningsSetup
import com.zarvimo.cricket.scoring.MatchSession
import com.zarvimo.cricket.scoring.MatchSetup
import com.zarvimo.cricket.scoring.OpResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GraphicsModelTest {

    // ------------------------------------------------------------ layout / safe area

    @Test fun scoreboard_alwaysInsideSafeArea_forEveryTemplateScaleAndPosition() {
        val positions = listOf(0f, 0.25f, 0.5f, 1f)
        val scales = listOf(0.5f, 1f, 1.6f)
        for (t in ScoreboardTemplate.values()) for (sc in scales) for (px in positions) for (py in positions) {
            for (h in listOf(360, 480, 720, 1080)) {
                val cfg = GraphicsConfig(template = t, scale = sc, posX = px, posY = py)
                val safe = BroadcastLayout.safeBox(cfg)
                val p = BroadcastLayout.scoreboard(cfg, h)
                assertTrue("$t scale=$sc pos=($px,$py) h=$h box=${p.box} safe=$safe", safe.contains(p.box))
            }
        }
    }

    @Test fun scoreboard_neverOverlapsTicker() {
        val cfg = GraphicsConfig(template = ScoreboardTemplate.CLASSIC, posY = 1f, showTicker = true)
        val sb = BroadcastLayout.scoreboard(cfg, 720).box
        val tk = BroadcastLayout.tickerBox(cfg)!!
        assertTrue(sb.bottom <= tk.top)
    }

    @Test fun noTicker_returnsNull_andBoardCanUseBottom() {
        val cfg = GraphicsConfig(showTicker = false, posY = 1f)
        assertNull(BroadcastLayout.tickerBox(cfg))
        val safe = BroadcastLayout.safeBox(cfg)
        val sb = BroadcastLayout.scoreboard(cfg, 720).box
        assertTrue(safe.bottom - sb.bottom <= cfg.marginPx + 0.01f)
    }

    @Test fun positionExtremes_alignToAreaEdges() {
        val left = BroadcastLayout.scoreboard(GraphicsConfig(template = ScoreboardTemplate.COMPACT, posX = 0f, posY = 0f), 1080).box
        val right = BroadcastLayout.scoreboard(GraphicsConfig(template = ScoreboardTemplate.COMPACT, posX = 1f, posY = 0f), 1080).box
        assertTrue(left.left < right.left)
        assertEquals(left.top, right.top, 0.01f)
    }

    @Test fun legibilityBoost_growsForSmallOutputs() {
        assertEquals(1.0f, BroadcastLayout.legibilityBoost(1080), 0f)
        assertEquals(1.0f, BroadcastLayout.legibilityBoost(720), 0f)
        assertTrue(BroadcastLayout.legibilityBoost(480) > 1f)
        assertTrue(BroadcastLayout.legibilityBoost(360) > BroadcastLayout.legibilityBoost(480))
    }

    @Test fun oversizedBoard_isShrunkToFit() {
        val cfg = GraphicsConfig(template = ScoreboardTemplate.MODERN_BAR, scale = 1.6f)
        val p = BroadcastLayout.scoreboard(cfg, 360)
        assertTrue(p.scale < 1.6f * 1.25f)
        assertTrue(BroadcastLayout.safeBox(cfg).contains(p.box))
    }

    @Test fun imageBox_staysInSafeArea() {
        val cfg = GraphicsConfig()
        for (x in listOf(0f, 0.5f, 1f)) for (y in listOf(0f, 0.5f, 1f)) for (sc in listOf(0.3f, 1f, 3f)) {
            val b = BroadcastLayout.imageBox(cfg, x, y, sc, 2.5f)
            assertTrue(BroadcastLayout.safeBox(cfg).contains(b))
        }
    }

    @Test fun sanitized_clampsOutOfRangeValues() {
        val c = GraphicsConfig(posX = 5f, posY = -3f, scale = 99f, panelOpacity = 0f, marginPx = 1000f).sanitized()
        assertEquals(1f, c.posX, 0f)
        assertEquals(0f, c.posY, 0f)
        assertEquals(1.6f, c.scale, 0f)
        assertEquals(0.2f, c.panelOpacity, 0f)
        assertEquals(80f, c.marginPx, 0f)
    }

    @Test fun atLeastThreeTemplates() {
        assertTrue(ScoreboardTemplate.values().size >= 3)
    }

    // ------------------------------------------------------------ overlay data from real scoring state

    private val setup = MatchSetup(teamA = "Lahore Qalandars", teamB = "Karachi Kings", oversLimit = 1, title = "PSL Final", venue = "Gaddafi Stadium")
    private val visuals = MatchVisuals(teamAColor = 0xFF00AA00.toInt(), teamBColor = 0xFF0000AA.toInt())

    private fun newSession(): MatchSession {
        val s = MatchSession(setup)
        assertTrue(s.startInnings(InningsSetup("Lahore Qalandars", "Karachi Kings", "Fakhar", "Rizwan", "Shaheen")) is OpResult.Ok)
        return s
    }

    @Test fun shortName_rules() {
        assertEquals("LQ", OverlayBuilder.shortName("Lahore Qalandars"))
        assertEquals("PAK", OverlayBuilder.shortName("Pakistan"))
        assertEquals("", OverlayBuilder.shortName("  "))
    }

    @Test fun overlay_beforeMatchStart_showsStartingSoon_notFakeScore() {
        val d = OverlayBuilder.from(setup, null, visuals)
        assertEquals("MATCH STARTING SOON", d.banner)
        assertNull(d.striker)
    }

    @Test fun overlay_reflectsEveryScoreChange() {
        val s = newSession()
        s.add { id -> BallEvent(id, runsBat = 4, boundary = true) }
        var d = OverlayBuilder.from(setup, s, visuals)
        assertEquals("4/0", d.score)
        assertEquals("0.1", d.overs)
        assertEquals("Fakhar", d.striker!!.name)
        assertEquals(4, d.striker!!.runs)
        assertEquals("Shaheen", d.bowlerName)
        assertEquals("0.1-0-4-0", d.bowlerFigures)
        assertEquals(listOf("4"), d.recentBalls)
        assertEquals(visuals.teamAColor, d.battingColor)

        s.add { id -> BallEvent(id, runsBat = 1) }
        d = OverlayBuilder.from(setup, s, visuals)
        assertEquals("5/0", d.score)
        assertEquals("Rizwan", d.striker!!.name) // strike rotated
        assertEquals(listOf("4", "1"), d.recentBalls)
    }

    @Test fun overlay_freeHitBanner_afterNoBall() {
        val s = newSession()
        s.add { id -> BallEvent(id, extra = ExtraType.NO_BALL) }
        assertEquals("FREE HIT", OverlayBuilder.from(setup, s, visuals).banner)
    }

    @Test fun overlay_chaseAndResult() {
        val s = newSession()
        repeat(6) { s.add { id -> BallEvent(id, runsBat = 1) } } // 6 runs, innings ends (1 over)
        assertEquals("INNINGS BREAK", OverlayBuilder.from(setup, s, visuals).banner)
        s.startInnings(InningsSetup("Karachi Kings", "Lahore Qalandars", "Babar", "Hasan", "Haris"))
        s.add { id -> BallEvent(id, runsBat = 2) }
        var d = OverlayBuilder.from(setup, s, visuals)
        assertEquals("TARGET 7", d.targetText)
        assertEquals("NEED 5 RUNS FROM 5 BALLS", d.chaseText)
        assertNotNull(d.requiredRunRate)
        assertEquals(visuals.teamBColor, d.battingColor)

        s.add { id -> BallEvent(id, runsBat = 4, boundary = true) }
        s.add { id -> BallEvent(id, runsBat = 1) }
        d = OverlayBuilder.from(setup, s, visuals)
        assertEquals("KARACHI KINGS WON BY 10 WICKETS", d.resultText?.uppercase())
        assertFalse(d.chaseText != null)
    }

    @Test fun result_text_variants() {
        val s = newSession()
        repeat(6) { s.add { id -> BallEvent(id, runsBat = 1) } }
        s.startInnings(InningsSetup("Karachi Kings", "Lahore Qalandars", "Babar", "Hasan", "Haris"))
        repeat(6) { s.add { id -> BallEvent(id, runsBat = 0) } } // overs end, 0 runs, target 7 => defend by 6
        val d = OverlayBuilder.from(setup, s, visuals)
        assertEquals("Lahore Qalandars WON BY 6 RUNS", d.resultText)
    }
}
