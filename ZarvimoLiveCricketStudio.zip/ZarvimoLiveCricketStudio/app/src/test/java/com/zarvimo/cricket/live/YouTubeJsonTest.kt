package com.zarvimo.cricket.live

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class YouTubeJsonTest {

    @Test
    fun chatMessagesAreParsed() {
        val json = """
            {"nextPageToken":"abc","pollingIntervalMillis":5000,"items":[
              {"id":"1","snippet":{"type":"textMessageEvent","displayMessage":"Hello","publishedAt":"2026-10-24T10:00:00Z"},
               "authorDetails":{"displayName":"Ali","isChatModerator":true,"isChatOwner":false}},
              {"id":"2","snippet":{"type":"superChatEvent","displayMessage":"","superChatDetails":{"amountDisplayString":"Rs500","userComment":"Great match"}},
               "authorDetails":{"displayName":"Sara"}},
              {"id":"3","snippet":{"type":"messageDeletedEvent"}}
            ]}
        """.trimIndent()
        val page = YouTubeJson.parseChat(json)
        assertEquals(2, page.messages.size)
        assertEquals("abc", page.nextPageToken)
        assertEquals(5000L, page.pollingIntervalMs)
        assertEquals("Ali", page.messages[0].author)
        assertEquals("Hello", page.messages[0].text)
        assertTrue(page.messages[0].isModerator)
        assertEquals("Rs500", page.messages[1].highlight)
        assertEquals("Great match", page.messages[1].text)
    }

    @Test
    fun broadcastAndVideoAreParsed() {
        val b = YouTubeJson.parseBroadcast("""{"items":[{"id":"VID123","snippet":{"liveChatId":"CHAT1"}}]}""")
        assertNotNull(b)
        assertEquals("VID123", b!!.videoId)
        assertEquals("CHAT1", b.liveChatId)
        assertNull(YouTubeJson.parseBroadcast("""{"items":[]}"""))

        val v = YouTubeJson.parseVideo(
            """{"items":[{"liveStreamingDetails":{"concurrentViewers":"123","activeLiveChatId":"C"},"statistics":{"viewCount":"4567"}}]}"""
        )
        assertNotNull(v)
        assertEquals(123L, v!!.concurrentViewers)
        assertEquals(4567L, v.totalViews)
        assertEquals("C", v.liveChatId)
    }

    @Test
    fun videoIdIsExtractedFromLinks() {
        assertEquals("dQw4w9WgXcQ", YouTubeJson.extractVideoId("dQw4w9WgXcQ"))
        assertEquals("dQw4w9WgXcQ", YouTubeJson.extractVideoId("https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=5"))
        assertEquals("dQw4w9WgXcQ", YouTubeJson.extractVideoId("https://youtu.be/dQw4w9WgXcQ?si=x"))
        assertEquals("dQw4w9WgXcQ", YouTubeJson.extractVideoId("https://www.youtube.com/live/dQw4w9WgXcQ"))
        assertNull(YouTubeJson.extractVideoId("hello"))
        assertNull(YouTubeJson.extractVideoId("  "))
    }

    @Test
    fun errorReasonIsExtracted() {
        val (reason, message) = YouTubeJson.errorReason("""{"error":{"message":"Quota","errors":[{"reason":"quotaExceeded"}]}}""")
        assertEquals("quotaExceeded", reason)
        assertEquals("Quota", message)
        assertEquals(Pair("", ""), YouTubeJson.errorReason("not json"))
    }
}
