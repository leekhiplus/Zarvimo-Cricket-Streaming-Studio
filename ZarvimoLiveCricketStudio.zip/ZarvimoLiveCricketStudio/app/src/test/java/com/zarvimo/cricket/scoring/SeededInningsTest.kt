package com.zarvimo.cricket.scoring

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SeededInningsTest {

    private val config = InningsConfig(oversLimit = 20, ballsPerOver = 6, maxWickets = 10)

    private fun seed(legalBalls: Int = 33) = InningsSeed(
        runs = 52, wickets = 2, legalBalls = legalBalls,
        wides = 3, noBalls = 1,
        strikerRuns = 18, strikerBalls = 14, strikerFours = 2, strikerSixes = 1,
        nonStrikerRuns = 8, nonStrikerBalls = 9,
        bowlerLegalBalls = 15, bowlerMaidens = 0, bowlerRuns = 20, bowlerWickets = 1,
        currentOverRuns = 4,
        outBatters = listOf(SeedBatter("Cee", 12, 10, 1, 0, "b Shah"), SeedBatter("Dee", 9, 8, 0, 0, "c Ali b Khan")),
        otherBowlers = listOf(SeedBowler("Shah", 12, 0, 18, 1))
    )

    private fun setup(s: InningsSeed?) = InningsSetup("A", "B", "Ali", "Bilal", "Khan", s)

    private fun state(setup: InningsSetup, events: List<ScoreEvent> = emptyList()): InningsState {
        val r = ScoreEngine.replay(config, setup, events)
        assertTrue("replay failed: $r", r is ReplayResult.Ok)
        return (r as ReplayResult.Ok).state
    }

    @Test
    fun seededInningsStartsWithTheEnteredFigures() {
        val st = state(setup(seed()))
        assertEquals(52, st.runs)
        assertEquals(2, st.wickets)
        assertEquals("5.3", st.oversText)
        assertEquals(4, st.extras.total)
        assertEquals(18, st.striker!!.runs)
        assertEquals(2, st.striker!!.fours)
        assertEquals("Khan", st.bowler!!.name)
        assertEquals(15, st.bowler!!.legalBalls)
        assertEquals(4, st.batters.size) // Cee and Dee are already out, Ali and Bilal are batting
        assertEquals("Dee", st.lastDismissed!!.name)
        assertTrue(st.canScoreNextBall)
    }

    @Test
    fun scoringContinuesFromTheSeed() {
        val events = listOf(
            BallEvent(1, runsBat = 4, boundary = true),
            BallEvent(2),
            BallEvent(3)
        )
        val st = state(setup(seed()), events)
        assertEquals(56, st.runs)
        assertEquals("6.0", st.oversText)
        assertEquals(3, st.batters.first { it.name == "Ali" }.fours)
        // the over ended: a new bowler is needed and Khan cannot bowl two overs in a row
        assertTrue(st.bowlerRequired)
        val tooSoon = ScoreEngine.replay(config, setup(seed()), events + SetBowlerEvent(4, "Khan"))
        assertTrue(tooSoon is ReplayResult.Failed)
        val ok = ScoreEngine.replay(config, setup(seed()), events + SetBowlerEvent(4, "Shah"))
        assertTrue(ok is ReplayResult.Ok)
    }

    @Test
    fun joiningAtTheEndOfAnOverNeedsTheNextBowler() {
        val st = state(setup(seed(legalBalls = 30)))
        assertTrue(st.bowlerRequired)
        assertNull(st.bowler)
        assertEquals(5, st.seedOvers)
    }

    @Test
    fun wicketsAfterTheSeedContinueTheNumbering() {
        val events = listOf(BallEvent(1, wicket = WicketInfo(DismissalType.BOWLED, incomingBatter = "Eve")))
        val st = state(setup(seed()), events)
        assertEquals(3, st.wickets)
        assertEquals(3, st.fallOfWickets.last().wicketNumber)
        assertEquals(5, st.batters.first { it.name == "Eve" }.order)
    }

    @Test
    fun aFinishedInningsCanBeEnteredAsASeed() {
        val s = seed(legalBalls = 120).copy(runs = 160, wickets = 10, strikerRuns = 18, nonStrikerRuns = 8, bowlerLegalBalls = 24, currentOverRuns = 0)
        val st = state(setup(s))
        assertTrue(st.ended)
        assertEquals(161, st.runs + 1)
    }

    @Test
    fun inconsistentSeedsAreRejected() {
        val tooManyBatterRuns = seed().copy(strikerRuns = 60)
        assertNotNull(ScoreEngine.seedProblem(config, setup(tooManyBatterRuns)))
        val tooManyBowlerBalls = seed().copy(bowlerLegalBalls = 40)
        assertNotNull(ScoreEngine.seedProblem(config, setup(tooManyBowlerBalls)))
        val bowlerTooFewForTheOver = seed().copy(bowlerLegalBalls = 1, otherBowlers = emptyList())
        assertNotNull(ScoreEngine.seedProblem(config, setup(bowlerTooFewForTheOver)))
        val tooManyOuts = seed().copy(wickets = 1)
        assertNotNull(ScoreEngine.seedProblem(config, setup(tooManyOuts)))
        assertNull(ScoreEngine.seedProblem(config, setup(seed())))
        assertNull(ScoreEngine.seedProblem(config, setup(null)))
    }

    @Test
    fun parserBuildsTheSameSeed() {
        val inputs = SeedInputs(
            score = "52, 2", overs = "5.3", extras = "3, 1, 0, 0",
            striker = "18, 14, 2, 1", nonStriker = "8, 9",
            bowler = "2.3, 0, 20, 1", currentOverRuns = "4",
            outBatters = "Cee, 12, 10, b Shah\nDee, 9, 8, c Ali b Khan",
            otherBowlers = "Shah, 2.0, 0, 18, 1",
            overRuns = "8, 5, 12, 6, 9"
        )
        val r = SeedParser.build(inputs, 6)
        assertNull(r.error)
        val s = r.seed!!
        assertEquals(33, s.legalBalls)
        assertEquals(15, s.bowlerLegalBalls)
        assertEquals(2, s.outBatters.size)
        assertEquals("c Ali b Khan", s.outBatters[1].dismissal)
        assertEquals(12, s.otherBowlers[0].legalBalls)
        assertEquals(listOf(8, 5, 12, 6, 9), s.overRuns)
        assertNull(ScoreEngine.seedProblem(config, setup(s)))
    }

    @Test
    fun parserExplainsMistakes() {
        assertNotNull(SeedParser.build(SeedInputs(), 6).error)
        assertNotNull(SeedParser.build(SeedInputs(score = "52, 2", overs = "5.7"), 6).error)
        assertNotNull(SeedParser.build(SeedInputs(score = "52, x", overs = "5.3"), 6).error)
        assertEquals(33, SeedParser.parseOvers("5.3", 6))
        assertEquals(60, SeedParser.parseOvers("10", 6))
        assertNull(SeedParser.parseOvers("5.6", 6))
        assertFalse(SeedParser.parseInts("1, 2, 3", 2) != null)
    }
}
