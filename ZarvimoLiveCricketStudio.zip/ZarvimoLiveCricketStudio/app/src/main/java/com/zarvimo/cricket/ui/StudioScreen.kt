package com.zarvimo.cricket.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.cricket.stream.DurationFormat
import com.zarvimo.cricket.stream.StatusLabels
import com.zarvimo.cricket.stream.StreamState
import kotlinx.coroutines.delay

/** The studio sections. Only one is shown at a time, so the screen stays short instead of one long scroll. */
enum class StudioTab(val icon: ImageVector, val label: String) {
    SOURCE(Ic.Video, "Source"),
    ONAIR(Ic.Tv, "On-air"),
    AUDIO(Ic.Music, "Audio"),
    CHAT(Ic.Chat, "Chat"),
    STATUS(Ic.Activity, "Status")
}

@Composable
private fun StudioTabStrip(selected: StudioTab, onSelect: (StudioTab) -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Panel).border(1.dp, Line, shape).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        StudioTab.values().forEach { t ->
            val on = t == selected
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(if (on) Gold else Color.Transparent)
                    .clickable { onSelect(t) }.padding(vertical = 7.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                AppIcon(t.icon, size = 20.dp, tint = if (on) Color.Black else Muted)
                Text(t.label, color = if (on) Color.Black else Muted, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
            }
        }
    }
}

/**
 * One screen for everything live: the preview stays pinned at the top, a tab strip chooses the section below it.
 * Viewers and comments are visible in every tab.
 */
@Composable
fun StudioScreen(vm: AppViewModel, onStartLive: () -> Unit, onNavigate: (String) -> Unit, startTab: StudioTab) {
    val pv by vm.previewStatus.collectAsState()
    val ss by vm.streamStatus.collectAsState()
    val s by vm.stream.collectAsState()
    val m by vm.match.collectAsState()
    val live by vm.live.collectAsState()
    val liveKbps by vm.liveBitrateKbps.collectAsState()
    val recording by vm.recording.collectAsState()
    val elapsed by produceState<Long?>(null, ss.state) { while (true) { value = vm.elapsedSeconds(); delay(1000) } }
    var tabName by rememberSaveable(startTab.name) { mutableStateOf(startTab.name) }
    val tab = StudioTab.values().firstOrNull { it.name == tabName } ?: startTab

    PinnedPreviewScreen(
        vm,
        previewNotes = {
            pv.error?.let { Text("Preview problem: $it", color = Color(0xFFFF6B6B), fontSize = 12.sp) }
            if (live.connected) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AppIcon(Ic.Eye, size = 16.dp, tint = Gold)
                    Text("${live.viewers?.toString() ?: "–"} watching now", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Gold)
                    Spacer(Modifier.width(10.dp))
                    AppIcon(Ic.Chat, size = 16.dp, tint = Gold)
                    Text("${live.messages.size} comments", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Gold)
                }
            }
            StudioTabStrip(tab) { tabName = it.name }
        }
    ) {
        when (tab) {
            StudioTab.SOURCE -> VideoSourceCard(vm)
            StudioTab.ONAIR -> {
                OnAirGraphicsCard(vm)
                AnnouncementsCard(vm)
                AutoShowCard(vm)
                BigButton("Design the scoreboard", Modifier.fillMaxWidth(), icon = Ic.Palette) { onNavigate("graphics") }
            }
            StudioTab.AUDIO -> {
                VoiceFxCard(vm)
                AudioMixerCard(vm)
                CrowdSoundsCard(vm)
            }
            StudioTab.CHAT -> LiveChatCard(vm)
            StudioTab.STATUS -> {
                Text(
                    StatusLabels.stream(ss.state), fontSize = 22.sp, fontWeight = FontWeight.ExtraBold,
                    color = if (ss.state == StreamState.STREAMING) Crimson else Color.White
                )
                LiveControls(vm, onStartLive)
                SectionCard("Real metrics (from the streaming engine)", icon = Ic.Activity) {
                    InfoRow("Elapsed since connected", elapsed?.let { DurationFormat.hhmmss(it) } ?: "not connected")
                    InfoRow("Resolution", "${s.profile.width}×${s.profile.height} (${s.profile.label})")
                    InfoRow("Configured frame rate", "${s.fps} fps")
                    InfoRow("Configured video bitrate", "${s.videoBitrateKbps} kbps")
                    if (liveKbps > 0) InfoRow("Video bitrate right now" + if (s.adaptiveBitrate) " (adaptive)" else "", "$liveKbps kbps")
                    InfoRow("Local recording", if (recording) "RECORDING" else if (s.recordLocally) "starts with the stream" else "off")
                    InfoRow("Measured upload bitrate", ss.measuredBitrateBps?.let { "${it / 1000} kbps" } ?: "unavailable")
                    InfoRow("Compositor fps (measured)", pv.compositorFps?.let { "$it" } ?: "unavailable")
                    InfoRow("Dropped frames", ss.droppedFrames?.toString() ?: "unavailable")
                    if (ss.state == StreamState.RECONNECTING || ss.reconnectAttempt > 0) InfoRow("Reconnect attempt", "${ss.reconnectAttempt} / ${ss.maxReconnectAttempts}")
                    ss.errorMessage?.let { Text("Last error: $it", color = Color(0xFFFF6B6B), fontSize = 13.sp) }
                }
                if (ss.state == StreamState.STREAMING || ss.state == StreamState.RECONNECTING) {
                    BigButton("Lower bitrate now (−25%)", Modifier.fillMaxWidth(), icon = Ic.Signal) { vm.lowerBitrateNow() }
                }
                val st = m.state
                if (st != null && !st.ended) {
                    SectionCard("Quick score", icon = Ic.Cricket) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(0, 1, 2, 3).forEach { r -> BigButton("$r", Modifier.weight(1f).height(52.dp), enabled = st.canScoreNextBall) { vm.addBall(r) } }
                            BigButton("4", Modifier.weight(1f).height(52.dp), Color(0xFF1976D2), enabled = st.canScoreNextBall) { vm.addBall(4, true) }
                            BigButton("6", Modifier.weight(1f).height(52.dp), Color(0xFF8E24AA), enabled = st.canScoreNextBall) { vm.addBall(6, true) }
                            BigButton("", Modifier.weight(1f).height(52.dp), enabled = m.canUndo, icon = Ic.Undo) { vm.undo() }
                        }
                        BigButton("Open full scoring console", Modifier.fillMaxWidth(), icon = Ic.Cricket) { onNavigate("score") }
                    }
                }
                Text(
                    "Troubleshooting: if the platform shows no video, confirm the stream is active in YouTube Studio, that the key matches, and that your uplink exceeds the bitrate. Try a lower profile.",
                    fontSize = 11.sp
                )
            }
        }
    }
}
