package com.zarvimo.cricket.ui

import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Professional line-icon set drawn in code (24x24 grid, 2 px round strokes). No emoji, no extra library, so the APK
 * does not grow. Every icon is tinted by the caller through [AppIcon].
 */
private fun circle(cx: Float, cy: Float, r: Float): String =
    "M${cx - r} ${cy}a$r $r 0 1 0 ${2 * r} 0a$r $r 0 1 0 ${-2 * r} 0z"

private fun icon(name: String, vararg paths: String, filled: Boolean = false): ImageVector =
    ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).apply {
        for (p in paths) {
            addPath(
                pathData = PathParser().parsePathString(p).toNodes(),
                fill = if (filled) SolidColor(Color.Black) else null,
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            )
        }
    }.build()

object Ic {
    val Home = icon("home", "M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z", "M9 22V12h6v10")
    /** Cricket bat and ball. */
    val Cricket = icon("cricket", "M12.5 7.5L16.5 11.5L7 21L3 17Z", "M14.5 9.5L20 4", circle(19f, 18.5f, 2.5f))
    val Film = icon(
        "film", "M4.2 2h15.6A2.2 2.2 0 0 1 22 4.2v15.6a2.2 2.2 0 0 1-2.2 2.2H4.2A2.2 2.2 0 0 1 2 19.8V4.2A2.2 2.2 0 0 1 4.2 2z",
        "M7 2v20", "M17 2v20", "M2 12h20", "M2 7h5", "M2 17h5", "M17 17h5", "M17 7h5"
    )
    val Layers = icon("layers", "M12 2L2 7l10 5 10-5-10-5z", "M2 17l10 5 10-5", "M2 12l10 5 10-5")
    val Radio = icon(
        "radio", circle(12f, 12f, 2f),
        "M16.24 7.76a6 6 0 0 1 0 8.49m-8.48-.01a6 6 0 0 1 0-8.49m11.31-2.82a10 10 0 0 1 0 14.14m-14.14 0a10 10 0 0 1 0-14.14"
    )
    val Video = icon("video", "M23 7l-7 5 7 5V7z", "M3 5h11a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z")
    val Tv = icon("tv", "M4 7h16a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2z", "M17 2l-5 5-5-5")
    val Music = icon("music", "M9 18V5l12-2v13", circle(6f, 18f, 3f), circle(18f, 16f, 3f))
    val Chat = icon(
        "chat",
        "M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"
    )
    val Activity = icon("activity", "M22 12h-4l-3 9L9 3l-3 9H2")
    val Trend = icon("trend", "M23 6l-9.5 9.5-5-5L1 18", "M17 6h6v6")
    val Eye = icon("eye", "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z", circle(12f, 12f, 3f))
    val Undo = icon("undo", "M1 4v6h6", "M3.51 15a9 9 0 1 0 2.13-9.36L1 10")
    val Play = icon("play", "M6 4l14 8-14 8V4z", filled = true)
    val Pause = icon("pause", "M6 4h4v16H6z", "M14 4h4v16h-4z", filled = true)
    val Next = icon("next", "M5 4l10 8-10 8V4z", "M19 5v14", filled = false)
    val Stop = icon("stop", "M5 5h14v14H5z", filled = true)
    val Mic = icon(
        "mic", "M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z", "M19 10v2a7 7 0 0 1-14 0v-2", "M12 19v4", "M8 23h8"
    )
    val MicOff = icon(
        "micoff", "M1 1l22 22", "M9 9v3a3 3 0 0 0 5.12 2.12", "M15 9.34V4a3 3 0 0 0-5.94-.6",
        "M17 16.95A7 7 0 0 1 5 12v-2", "M19 10v2a7 7 0 0 1-.11 1.23", "M12 19v4", "M8 23h8"
    )
    val Camera = icon(
        "camera", "M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z", circle(12f, 13f, 4f)
    )
    val Flip = icon(
        "flip", "M23 4v6h-6", "M1 20v-6h6", "M3.51 9a9 9 0 0 1 14.85-3.36L23 10", "M1 14l4.64 4.36A9 9 0 0 0 20.49 15"
    )
    val Image = icon(
        "image", "M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z", circle(8.5f, 8.5f, 1.5f), "M21 15l-5-5L5 21"
    )
    val Trash = icon(
        "trash", "M3 6h18", "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2", "M10 11v6", "M14 11v6"
    )
    val Save = icon(
        "save", "M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z", "M17 21v-8H7v8", "M7 3v5h8"
    )
    val Plus = icon("plus", "M12 5v14", "M5 12h14")
    val Check = icon("check", "M20 6L9 17l-5-5")
    val Close = icon("close", "M18 6L6 18", "M6 6l12 12")
    val Upload = icon("upload", "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", "M17 8l-5-5-5 5", "M12 3v12")
    val Volume = icon("volume", "M11 5L6 9H2v6h4l5 4V5z", "M19.07 4.93a10 10 0 0 1 0 14.14", "M15.54 8.46a5 5 0 0 1 0 7.07")
    val Sliders = icon(
        "sliders", "M4 21v-7", "M4 10V3", "M12 21v-9", "M12 8V3", "M20 21v-5", "M20 12V3", "M1 14h6", "M9 8h6", "M17 16h6"
    )
    val Folder = icon("folder", "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z")
    val Alert = icon(
        "alert", "M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z", "M12 9v4", "M12 17h.01"
    )
    val Info = icon("info", circle(12f, 12f, 10f), "M12 16v-4", "M12 8h.01")
    val Palette = icon(
        "palette", circle(13.5f, 6.5f, 1f), circle(17.5f, 10.5f, 1f), circle(8.5f, 7.5f, 1f), circle(6.5f, 12.5f, 1f),
        "M12 2a10 10 0 1 0 0 20c1.1 0 2-.9 2-2 0-.5-.2-1-.5-1.3-.3-.4-.5-.8-.5-1.3 0-1.1.9-2 2-2h2.4a4.6 4.6 0 0 0 4.6-4.6C22 6 17.5 2 12 2z"
    )
    val Reply = icon("reply", "M9 14L4 9l5-5", "M20 20v-7a4 4 0 0 0-4-4H4")
    val Send = icon("send", "M22 2L11 13", "M22 2l-7 20-4-9-9-4 20-7z")
    val Signal = icon("signal", "M2 20h.01", "M7 20v-4", "M12 20v-8", "M17 20V8", "M22 4v16")
}

/** One icon, tinted. Default colour follows the surrounding content colour. */
@Composable
fun AppIcon(icon: ImageVector, modifier: Modifier = Modifier, size: Dp = 20.dp, tint: Color = LocalContentColor.current) {
    Icon(imageVector = icon, contentDescription = null, modifier = modifier.size(size), tint = tint)
}
