package com.zarvimo.cricket.live

import android.content.Context
import android.os.SystemClock
import com.zarvimo.cricket.data.SecretStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.max

/** One live-chat message. */
data class ChatMessage(
    val id: String,
    val author: String,
    val text: String,
    val publishedAt: String = "",
    val isModerator: Boolean = false,
    val isOwner: Boolean = false,
    /** e.g. the Super Chat amount; null for normal messages. */
    val highlight: String? = null
)

data class ChatPage(val messages: List<ChatMessage>, val nextPageToken: String?, val pollingIntervalMs: Long)
data class BroadcastInfo(val videoId: String, val liveChatId: String?)
data class VideoStats(val liveChatId: String?, val concurrentViewers: Long?, val totalViews: Long?)

/** Everything the "Live chat" screen shows. */
data class LiveInsights(
    val signedIn: Boolean = false,
    /** While signing in: the code the user types on google.com/device. */
    val deviceCode: String? = null,
    val verificationUrl: String? = null,
    val status: String = "Not signed in",
    val connected: Boolean = false,
    val videoId: String? = null,
    val viewers: Long? = null,
    val totalViews: Long? = null,
    val messages: List<ChatMessage> = emptyList(),
    val error: String? = null,
    val replyStatus: String? = null
)

/** Parsing helpers (pure, unit-tested). */
object YouTubeJson {

    fun parseChat(json: String): ChatPage {
        val o = JSONObject(json)
        val arr = o.optJSONArray("items")
        val list = ArrayList<ChatMessage>()
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val sn = item.optJSONObject("snippet") ?: continue
                val au = item.optJSONObject("authorDetails")
                val type = sn.optString("type")
                var text = sn.optString("displayMessage")
                var highlight: String? = null
                if (type == "superChatEvent") {
                    val d = sn.optJSONObject("superChatDetails")
                    highlight = d?.optString("amountDisplayString")?.takeIf { it.isNotBlank() }
                    val comment = d?.optString("userComment").orEmpty()
                    if (comment.isNotBlank()) text = comment
                } else if (type == "newSponsorEvent") {
                    highlight = "NEW MEMBER"
                }
                if (text.isBlank() && highlight == null) continue
                list.add(
                    ChatMessage(
                        id = item.optString("id"),
                        author = au?.optString("displayName").orEmpty().ifBlank { "Viewer" },
                        text = text,
                        publishedAt = sn.optString("publishedAt"),
                        isModerator = au?.optBoolean("isChatModerator") ?: false,
                        isOwner = au?.optBoolean("isChatOwner") ?: false,
                        highlight = highlight
                    )
                )
            }
        }
        return ChatPage(list, o.optString("nextPageToken").ifBlank { null }, o.optLong("pollingIntervalMillis", 10_000L))
    }

    /** liveBroadcasts.list result -> first active broadcast. */
    fun parseBroadcast(json: String): BroadcastInfo? {
        val first = JSONObject(json).optJSONArray("items")?.optJSONObject(0) ?: return null
        val id = first.optString("id")
        if (id.isBlank()) return null
        val chat = first.optJSONObject("snippet")?.optString("liveChatId")?.ifBlank { null }
        return BroadcastInfo(id, chat)
    }

    /** videos.list(part=liveStreamingDetails,statistics) result. */
    fun parseVideo(json: String): VideoStats? {
        val first = JSONObject(json).optJSONArray("items")?.optJSONObject(0) ?: return null
        val live = first.optJSONObject("liveStreamingDetails")
        val stats = first.optJSONObject("statistics")
        return VideoStats(
            liveChatId = live?.optString("activeLiveChatId")?.ifBlank { null },
            concurrentViewers = live?.optString("concurrentViewers")?.toLongOrNull(),
            totalViews = stats?.optString("viewCount")?.toLongOrNull()
        )
    }

    /** Accepts a bare 11-character video id or any common YouTube link (watch, youtu.be, /live/, /shorts/). */
    fun extractVideoId(input: String): String? {
        val t = input.trim()
        if (t.isEmpty()) return null
        if (Regex("^[A-Za-z0-9_-]{11}$").matches(t)) return t
        val patterns = listOf(
            Regex("[?&]v=([A-Za-z0-9_-]{11})"),
            Regex("youtu\\.be/([A-Za-z0-9_-]{11})"),
            Regex("/(?:live|shorts|embed)/([A-Za-z0-9_-]{11})")
        )
        for (p in patterns) p.find(t)?.let { return it.groupValues[1] }
        return null
    }

    /** Short human message for a failed API call (never contains tokens). */
    fun errorReason(body: String): Pair<String, String> {
        return try {
            val e = JSONObject(body).optJSONObject("error")
            val reason = e?.optJSONArray("errors")?.optJSONObject(0)?.optString("reason").orEmpty()
            Pair(reason, e?.optString("message").orEmpty())
        } catch (_: Exception) {
            Pair("", "")
        }
    }
}

internal object Http {
    data class Result(val code: Int, val body: String)

    fun request(method: String, url: String, headers: Map<String, String> = emptyMap(), body: String? = null, contentType: String? = null): Result {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 15_000
            c.readTimeout = 20_000
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (body != null) {
                c.doOutput = true
                if (contentType != null) c.setRequestProperty("Content-Type", contentType)
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            return Result(code, text)
        } finally {
            c.disconnect()
        }
    }

    fun form(vararg pairs: Pair<String, String>): String =
        pairs.joinToString("&") { URLEncoder.encode(it.first, "UTF-8") + "=" + URLEncoder.encode(it.second, "UTF-8") }
}

/**
 * Viewer count + live-chat comments + replies for a YouTube live stream.
 *
 * Sign-in uses Google's OAuth "device" flow: the app shows a short code, the user types it on google.com/device on any
 * phone or computer. The user needs their own Google Cloud OAuth client (type "TVs and Limited Input devices"); the
 * client id/secret and the refresh token are stored encrypted with the Android Keystore (see [SecretStore]).
 *
 * Quota (default 10,000 units/day): reading chat costs about 5 units per call and this polls every 10 seconds or more
 * (about 1,800 units per hour), viewers are read every 30 seconds (1 unit each), a reply costs about 50 units.
 */
class LiveChatController(private val context: Context, private val scope: CoroutineScope) {

    private val _state = MutableStateFlow(LiveInsights())
    val state: StateFlow<LiveInsights> = _state.asStateFlow()

    private var accessToken: String? = null
    private var tokenExpiresAt = 0L
    private var signInJob: Job? = null
    private var pollJob: Job? = null
    @Volatile private var liveChatId: String? = null

    init {
        scope.launch(Dispatchers.IO) {
            val signedIn = SecretStore.load(context, KEY_REFRESH).isNotEmpty()
            _state.update {
                it.copy(signedIn = signedIn, status = if (signedIn) "Signed in. Connect when your stream is live." else "Not signed in")
            }
        }
    }

    // ------------------------------------------------------------------------------------------ credentials & sign-in

    fun credentials(): Pair<String, String> = Pair(SecretStore.load(context, KEY_ID), SecretStore.load(context, KEY_SECRET))

    fun saveCredentials(clientId: String, clientSecret: String) {
        SecretStore.save(context, clientId.trim(), KEY_ID)
        SecretStore.save(context, clientSecret.trim(), KEY_SECRET)
    }

    fun isPolling(): Boolean = pollJob?.isActive == true

    fun beginSignIn() {
        signInJob?.cancel()
        signInJob = scope.launch(Dispatchers.IO) {
            val (cid, secret) = credentials()
            if (cid.isBlank() || secret.isBlank()) {
                setError("Enter the Client ID and Client secret first")
                return@launch
            }
            try {
                _state.update { it.copy(error = null, status = "Contacting Google…") }
                val r = Http.request("POST", DEVICE_URL, body = Http.form("client_id" to cid, "scope" to SCOPE), contentType = FORM)
                if (r.code != 200) {
                    setError("Google refused the sign-in request (${YouTubeJson.errorReason(r.body).second.ifBlank { "HTTP ${r.code}" }}). Check the Client ID and that the client type is \"TVs and Limited Input devices\".")
                    return@launch
                }
                val o = JSONObject(r.body)
                val deviceCode = o.optString("device_code")
                var interval = max(5L, o.optLong("interval", 5L))
                val deadline = SystemClock.elapsedRealtime() + o.optLong("expires_in", 1800L) * 1000
                _state.update {
                    it.copy(
                        deviceCode = o.optString("user_code"),
                        verificationUrl = o.optString("verification_url", "https://www.google.com/device"),
                        status = "Open the page below on any phone or computer and enter the code"
                    )
                }
                while (isActive && SystemClock.elapsedRealtime() < deadline) {
                    delay(interval * 1000)
                    val t = Http.request(
                        "POST", TOKEN_URL, contentType = FORM,
                        body = Http.form(
                            "client_id" to cid, "client_secret" to secret, "device_code" to deviceCode,
                            "grant_type" to "urn:ietf:params:oauth:grant-type:device_code"
                        )
                    )
                    val tj = try { JSONObject(t.body) } catch (_: Exception) { JSONObject() }
                    if (t.code == 200 && tj.optString("access_token").isNotBlank()) {
                        accessToken = tj.optString("access_token")
                        tokenExpiresAt = System.currentTimeMillis() + tj.optLong("expires_in", 3600L) * 1000
                        val refresh = tj.optString("refresh_token")
                        if (refresh.isNotBlank()) SecretStore.save(context, refresh, KEY_REFRESH)
                        _state.update { it.copy(signedIn = true, deviceCode = null, verificationUrl = null, error = null, status = "Signed in. Connect when your stream is live.") }
                        return@launch
                    }
                    when (tj.optString("error")) {
                        "authorization_pending" -> Unit
                        "slow_down" -> interval += 5
                        "access_denied" -> { setError("Sign-in was cancelled"); clearCode(); return@launch }
                        "expired_token" -> { setError("The code expired. Press Sign in again."); clearCode(); return@launch }
                        else -> { setError("Sign-in failed: " + tj.optString("error_description", tj.optString("error", "HTTP ${t.code}"))); clearCode(); return@launch }
                    }
                }
                setError("The code expired. Press Sign in again.")
                clearCode()
            } catch (e: Exception) {
                setError("Network problem during sign-in (${e.javaClass.simpleName})")
                clearCode()
            }
        }
    }

    private fun clearCode() {
        _state.update { it.copy(deviceCode = null, verificationUrl = null) }
    }

    fun signOut() {
        signInJob?.cancel()
        disconnect()
        accessToken = null
        tokenExpiresAt = 0L
        SecretStore.clear(context, KEY_REFRESH)
        _state.value = LiveInsights(signedIn = false, status = "Not signed in")
    }

    private fun setError(msg: String) {
        _state.update { it.copy(error = msg, status = msg) }
    }

    /** Returns a valid access token or null (and signs out when Google says the refresh token is no longer valid). */
    private fun token(): String? {
        val now = System.currentTimeMillis()
        accessToken?.let { if (now < tokenExpiresAt - 60_000) return it }
        val refresh = SecretStore.load(context, KEY_REFRESH)
        val (cid, secret) = credentials()
        if (refresh.isEmpty() || cid.isEmpty()) return null
        val r = Http.request(
            "POST", TOKEN_URL, contentType = FORM,
            body = Http.form("client_id" to cid, "client_secret" to secret, "refresh_token" to refresh, "grant_type" to "refresh_token")
        )
        if (r.code != 200) {
            if (r.code == 400 || r.code == 401) {
                SecretStore.clear(context, KEY_REFRESH)
                _state.update { it.copy(signedIn = false, connected = false, status = "Google sign-in expired. Please sign in again.", error = "Google sign-in expired. Please sign in again.") }
            }
            return null
        }
        val o = JSONObject(r.body)
        accessToken = o.optString("access_token").ifBlank { null }
        tokenExpiresAt = now + o.optLong("expires_in", 3600L) * 1000
        return accessToken
    }

    private fun authed(method: String, url: String, body: String? = null): Http.Result? {
        val t = token() ?: return null
        return Http.request(method, url, headers = mapOf("Authorization" to "Bearer $t"), body = body, contentType = if (body != null) "application/json; charset=UTF-8" else null)
    }

    // ------------------------------------------------------------------------------------------ polling

    /** Finds the running broadcast (or uses the link/id typed by the user), then polls viewers and chat until [disconnect]. */
    fun connect(manualLinkOrId: String?) {
        pollJob?.cancel()
        liveChatId = null
        val manualId = manualLinkOrId?.let { YouTubeJson.extractVideoId(it) }
        if (!manualLinkOrId.isNullOrBlank() && manualId == null) {
            setError("That does not look like a YouTube video link or id")
            return
        }
        pollJob = scope.launch(Dispatchers.IO) {
            _state.update { it.copy(connected = false, error = null, status = "Looking for your live broadcast…", messages = emptyList(), viewers = null, totalViews = null) }
            try {
                var info: BroadcastInfo? = null
                while (isActive && info == null) {
                    val r = if (manualId != null) {
                        authed("GET", "$API/videos?part=liveStreamingDetails,statistics&id=$manualId")
                    } else {
                        authed("GET", "$API/liveBroadcasts?part=snippet&broadcastStatus=active&mine=true")
                    }
                    if (r == null) {
                        setError("Not signed in")
                        return@launch
                    }
                    if (r.code == 200) {
                        info = if (manualId != null) {
                            YouTubeJson.parseVideo(r.body)?.let { BroadcastInfo(manualId, it.liveChatId) }
                        } else {
                            YouTubeJson.parseBroadcast(r.body)
                        }
                        if (info == null) _state.update { it.copy(status = "Waiting for YouTube to start the broadcast…") }
                    } else if (fatal(r)) {
                        return@launch
                    }
                    if (info == null) delay(15_000)
                }
                val found = info ?: return@launch
                liveChatId = found.liveChatId
                _state.update { it.copy(connected = true, videoId = found.videoId, status = if (found.liveChatId == null) "Connected (this broadcast has no live chat)" else "Connected") }

                var page: String? = null
                var nextViewers = 0L
                var pollMs = 10_000L
                val seen = HashSet<String>()
                while (isActive) {
                    val now = SystemClock.elapsedRealtime()
                    if (now >= nextViewers) {
                        nextViewers = now + 30_000
                        val v = authed("GET", "$API/videos?part=liveStreamingDetails,statistics&id=${found.videoId}")
                        if (v != null && v.code == 200) {
                            YouTubeJson.parseVideo(v.body)?.let { s -> _state.update { it.copy(viewers = s.concurrentViewers ?: it.viewers, totalViews = s.totalViews ?: it.totalViews) } }
                        } else if (v != null && fatal(v)) {
                            return@launch
                        }
                    }
                    val chatId = liveChatId
                    if (chatId != null) {
                        val url = "$API/liveChat/messages?liveChatId=" + URLEncoder.encode(chatId, "UTF-8") +
                            "&part=snippet,authorDetails&maxResults=200" + (page?.let { "&pageToken=" + URLEncoder.encode(it, "UTF-8") } ?: "")
                        val r = authed("GET", url)
                        if (r != null && r.code == 200) {
                            val p = YouTubeJson.parseChat(r.body)
                            page = p.nextPageToken ?: page
                            pollMs = max(10_000L, p.pollingIntervalMs)
                            val fresh = p.messages.filter { seen.add(it.id) }
                            if (fresh.isNotEmpty()) _state.update { it.copy(messages = (it.messages + fresh).takeLast(150), error = null) }
                        } else if (r != null && fatal(r)) {
                            return@launch
                        }
                    }
                    delay(pollMs)
                }
            } catch (e: Exception) {
                if (isActive) setError("Network problem (${e.javaClass.simpleName}). Press Connect to try again.")
            }
        }
    }

    /** Handles an error response; returns true when polling must stop. */
    private fun fatal(r: Http.Result): Boolean {
        val (reason, message) = YouTubeJson.errorReason(r.body)
        return when {
            reason == "quotaExceeded" || reason == "dailyLimitExceeded" -> {
                setError("The YouTube API quota is used up for today. Chat and viewer numbers resume tomorrow.")
                true
            }
            reason == "liveChatEnded" || reason == "liveChatNotFound" || reason == "liveChatDisabled" -> {
                setError("Live chat is not available for this broadcast ($reason)")
                true
            }
            r.code == 401 -> {
                setError("Google sign-in expired. Please sign in again.")
                true
            }
            r.code == 403 -> {
                setError("YouTube refused the request: ${message.ifBlank { reason.ifBlank { "forbidden" } }}")
                true
            }
            else -> {
                _state.update { it.copy(error = "YouTube error ${r.code}: ${message.ifBlank { reason }}") }
                false
            }
        }
    }

    fun disconnect() {
        pollJob?.cancel()
        pollJob = null
        liveChatId = null
        _state.update { it.copy(connected = false, viewers = null, totalViews = null, videoId = null, status = if (it.signedIn) "Disconnected" else it.status) }
    }

    // ------------------------------------------------------------------------------------------ replies

    /** Posts a message to the live chat as the signed-in channel; [replyToAuthor] is added as an @mention. */
    fun send(text: String, replyToAuthor: String?) {
        val chatId = liveChatId
        if (chatId == null) {
            _state.update { it.copy(replyStatus = "Connect to your live stream first") }
            return
        }
        val clean = text.trim()
        if (clean.isEmpty()) return
        val full = ((if (replyToAuthor != null) "@$replyToAuthor " else "") + clean).take(200)
        _state.update { it.copy(replyStatus = "Sending…") }
        scope.launch(Dispatchers.IO) {
            try {
                val body = JSONObject().put(
                    "snippet", JSONObject()
                        .put("liveChatId", chatId)
                        .put("type", "textMessageEvent")
                        .put("textMessageDetails", JSONObject().put("messageText", full))
                ).toString()
                val r = authed("POST", "$API/liveChat/messages?part=snippet", body)
                val msg = when {
                    r == null -> "Not signed in"
                    r.code in 200..299 -> "Sent"
                    else -> "Could not send: " + YouTubeJson.errorReason(r.body).let { it.second.ifBlank { it.first.ifBlank { "HTTP ${r.code}" } } }
                }
                _state.update { it.copy(replyStatus = msg) }
            } catch (e: Exception) {
                _state.update { it.copy(replyStatus = "Network problem (${e.javaClass.simpleName})") }
            }
        }
    }

    fun clearReplyStatus() {
        _state.update { it.copy(replyStatus = null) }
    }

    private companion object {
        const val API = "https://www.googleapis.com/youtube/v3"
        const val DEVICE_URL = "https://oauth2.googleapis.com/device/code"
        const val TOKEN_URL = "https://oauth2.googleapis.com/token"
        const val SCOPE = "https://www.googleapis.com/auth/youtube"
        const val FORM = "application/x-www-form-urlencoded"
        const val KEY_ID = "yt_client_id"
        const val KEY_SECRET = "yt_client_secret"
        const val KEY_REFRESH = "yt_refresh_token"
    }
}
