package com.zarvimo.cricket.ui

import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.text.KeyboardOptions
import com.zarvimo.cricket.stream.DurationFormat
import com.zarvimo.cricket.stream.StatusLabels
import com.zarvimo.cricket.stream.StreamState
import kotlinx.coroutines.delay

val Ink = Color(0xFF070B16)
val Panel = Color(0xFF111830)
val PanelHi = Color(0xFF1A2444)
val Line = Color(0xFF26335A)
val Muted = Color(0xFF9AA6C7)
val Gold = Color(0xFFFFC107)
val Crimson = Color(0xFFE11D48)
val Mint = Color(0xFF2ECC71)

@Composable
fun ZarvimoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold, onPrimary = Color.Black, secondary = Crimson, background = Ink, surface = Panel,
            onBackground = Color.White, onSurface = Color.White, surfaceVariant = PanelHi, error = Color(0xFFFF6B6B)
        ),
        content = content
    )
}

@Composable
fun SectionCard(title: String, modifier: Modifier = Modifier, icon: ImageVector? = null, content: @Composable () -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Panel),
        border = BorderStroke(1.dp, Line),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (icon != null) {
                    Box(Modifier.size(30.dp).clip(RoundedCornerShape(9.dp)).background(Color(0x26FFC107)), contentAlignment = Alignment.Center) {
                        AppIcon(icon, size = 18.dp, tint = Gold)
                    }
                }
                Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Gold)
            }
            content()
        }
    }
}

/** Big tappable tile for the home screen: icon on a tinted square, title, one short line. */
@Composable
fun HomeTile(title: String, subtitle: String, icon: ImageVector, modifier: Modifier = Modifier, accent: Color = Gold, onClick: () -> Unit) {
    Row(
        modifier.clip(RoundedCornerShape(16.dp)).background(Panel).border(1.dp, Line, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(accent.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            AppIcon(icon, size = 24.dp, tint = accent)
        }
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
            Text(subtitle, fontSize = 11.sp, color = Muted, maxLines = 2)
        }
    }
}

@Composable
fun Pill(text: String, color: Color, modifier: Modifier = Modifier, dot: Boolean = false) {
    Row(
        modifier.clip(RoundedCornerShape(50)).background(color).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (dot) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(Color.White))
            Spacer(Modifier.size(6.dp))
        }
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

/**
 * Two deliberately separate indicators:
 *  - PREVIEW: is the local compositor + preview running (says nothing about the network).
 *  - STREAM:  the real network state, straight from the engine's state machine. "LIVE" only when really STREAMING.
 */
@Composable
fun StatusStrip(vm: AppViewModel, modifier: Modifier = Modifier) {
    val st by vm.streamStatus.collectAsState()
    val pv by vm.previewStatus.collectAsState()
    val elapsed by produceState<Long?>(null, st.state) {
        while (true) {
            value = vm.elapsedSeconds()
            delay(1000)
        }
    }
    val streamColor = when (st.state) {
        StreamState.STREAMING -> Crimson
        StreamState.CONNECTING, StreamState.PREPARING -> Color(0xFFB8860B)
        StreamState.RECONNECTING -> Color(0xFFE67E22)
        StreamState.STOPPING -> Color(0xFF6C7A89)
        StreamState.ERROR -> Color(0xFF8E1B1B)
        StreamState.IDLE -> Color(0xFF3B445E)
    }
    Row(modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Pill(StatusLabels.preview(pv.running), if (pv.running) Color(0xFF1565C0) else Color(0xFF3B445E))
        Pill(StatusLabels.stream(st.state), streamColor, dot = StatusLabels.mayShowLiveBadge(st.state))
        if (st.state == StreamState.STREAMING && elapsed != null) {
            Text(DurationFormat.hhmmss(elapsed!!), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

/** The on-screen Program Output. Shows RootEncoder's GL output = the very frames that are encoded. */
@Composable
fun ProgramPreview(vm: AppViewModel, modifier: Modifier = Modifier) {
    val settings by vm.stream.collectAsState()
    val engine = vm.engineRef()
    Box(modifier.fillMaxWidth().aspectRatio(settings.profile.width.toFloat() / settings.profile.height).clip(RoundedCornerShape(12.dp)).background(Color.Black).border(1.dp, Line, RoundedCornerShape(12.dp))) {
        AndroidView(
            modifier = Modifier.matchParentSize(),
            factory = { ctx ->
                SurfaceView(ctx).apply {
                    val view = this
                    holder.addCallback(object : SurfaceHolder.Callback {
                        override fun surfaceCreated(h: SurfaceHolder) {
                            val s = vm.stream.value
                            engine.attachPreview(view, s.profile, s.fps)
                        }
                        override fun surfaceChanged(h: SurfaceHolder, format: Int, width: Int, height: Int) {
                            engine.onPreviewSurfaceSize(width, height)
                        }
                        override fun surfaceDestroyed(h: SurfaceHolder) {
                            engine.detachPreview(view)
                        }
                    })
                }
            }
        )
    }
}

@Composable
fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 13.sp)
            Text(valueText, fontSize = 13.sp, color = Gold, fontWeight = FontWeight.Bold)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun <T> ChipChoice(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        options.forEach { o ->
            FilterChip(
                selected = o == selected, onClick = { onSelect(o) }, label = { Text(label(o), fontSize = 13.sp) },
                leadingIcon = if (o == selected) ({ AppIcon(Ic.Check, size = 16.dp, tint = Gold) }) else null,
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = Color.Transparent, labelColor = Color(0xFFD5DBF0),
                    selectedContainerColor = Color(0x33FFC107), selectedLabelColor = Gold
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true, selected = o == selected, borderColor = Line, selectedBorderColor = Gold
                )
            )
        }
    }
}

val Palette = listOf(
    0xFF0B1E4B, 0xFF1B5E20, 0xFF0D47A1, 0xFFB71C1C, 0xFF4A148C, 0xFFE65100, 0xFF004D40, 0xFF212121,
    0xFFFFC107, 0xFFFFFFFF, 0xFF00E5FF, 0xFFFF4081, 0xFF76FF03, 0xFFE11D48
).map { it.toInt() }

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ColorPicker(label: String, selected: Int, onSelect: (Int) -> Unit) {
    Column {
        Text(label, fontSize = 13.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
            Palette.forEach { c ->
                Box(
                    Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                        .border(BorderStroke(if (c == selected) 3.dp else 1.dp, if (c == selected) Color.White else Color(0x55FFFFFF)), CircleShape)
                        .clickable { onSelect(c) }
                )
            }
        }
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontSize = 14.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun TextInput(
    label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier,
    numeric: Boolean = false, secret: Boolean = false, singleLine: Boolean = true, placeholder: String? = null
) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, modifier = modifier.fillMaxWidth(),
        singleLine = singleLine, placeholder = if (placeholder != null) ({ Text(placeholder) }) else null,
        keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Number else KeyboardType.Text),
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None
    )
}

@Composable
fun BigButton(
    text: String, modifier: Modifier = Modifier, color: Color = PanelHi, textColor: Color = Color.White, enabled: Boolean = true,
    icon: ImageVector? = null, onClick: () -> Unit
) {
    Button(
        onClick = onClick, enabled = enabled, modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        border = if (color == PanelHi) BorderStroke(1.dp, Line) else null,
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = textColor, disabledContainerColor = Color(0xFF1B2440), disabledContentColor = Color(0xFF6B7699))
    ) {
        if (icon != null) AppIcon(icon, size = 20.dp, tint = LocalContentColor.current)
        if (icon != null && text.isNotBlank()) Spacer(Modifier.size(8.dp))
        if (text.isNotBlank()) {
            // long labels get a smaller size and wrap between words instead of being cut in the middle of a word
            val size = when {
                text.length > 16 -> 12.sp
                text.length > 9 -> 13.sp
                else -> 15.sp
            }
            Text(text, fontWeight = FontWeight.Bold, fontSize = size, lineHeight = (size.value + 3).sp, maxLines = 2, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
}

/** Warning line with a proper icon instead of a text symbol. */
@Composable
fun WarnLine(message: String, modifier: Modifier = Modifier, color: Color = Color(0xFFFF6B6B)) {
    Row(modifier, verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        AppIcon(Ic.Alert, size = 16.dp, tint = color, modifier = Modifier.padding(top = 1.dp))
        Text(message, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}
