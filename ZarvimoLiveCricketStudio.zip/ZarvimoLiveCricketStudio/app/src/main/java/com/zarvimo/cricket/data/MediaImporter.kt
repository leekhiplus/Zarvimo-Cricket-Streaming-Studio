package com.zarvimo.cricket.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaExtractor
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

/**
 * Images are copied into app-private storage on import, so they keep working after the picker's temporary permission
 * ends and survive app restarts. Decoding is down-scaled so a 48MP photo cannot exhaust memory.
 */
object MediaImporter {

    fun importImage(context: Context, uri: Uri, kind: String): String? = try {
        val dir = File(context.filesDir, "media").apply { mkdirs() }
        val out = File(dir, "${kind}_${System.currentTimeMillis()}.img")
        context.contentResolver.openInputStream(uri)?.use { input -> out.outputStream().use { input.copyTo(it) } } ?: return null
        // validate it really decodes as an image
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(out.path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) { out.delete(); null } else out.path
    } catch (e: Exception) {
        null
    }

    /**
     * Copies a picked audio file into app-private storage (so it keeps working after the picker's temporary permission
     * ends) and checks that it really contains an audio track. Returns (path, display name) or null.
     */
    fun importAudio(context: Context, uri: Uri): Pair<String, String>? = try {
        val fullName = displayName(context, uri) ?: "Music"
        val dir = File(context.filesDir, "music").apply { mkdirs() }
        val ext = fullName.substringAfterLast('.', "").filter { it.isLetterOrDigit() }.take(5).ifEmpty { "audio" }
        val out = File(dir, "track_${System.currentTimeMillis()}.$ext")
        context.contentResolver.openInputStream(uri)?.use { input -> out.outputStream().use { input.copyTo(it) } } ?: return null
        if (!hasAudioTrack(out.path)) {
            out.delete()
            null
        } else {
            Pair(out.path, fullName.substringBeforeLast('.', fullName).take(60))
        }
    } catch (e: Exception) {
        null
    }

    private fun displayName(context: Context, uri: Uri): String? = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (e: Exception) {
        null
    }

    private fun hasAudioTrack(path: String): Boolean {
        val ex = MediaExtractor()
        return try {
            ex.setDataSource(path)
            var found = false
            for (i in 0 until ex.trackCount) {
                val mime = ex.getTrackFormat(i).getString(android.media.MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) { found = true; break }
            }
            found
        } catch (e: Exception) {
            false
        } finally {
            ex.release()
        }
    }

    fun load(path: String?, maxDim: Int): Bitmap? {
        if (path.isNullOrBlank()) return null
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, bounds)
            var sample = 1
            while (bounds.outWidth / sample > maxDim * 2 || bounds.outHeight / sample > maxDim * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
            BitmapFactory.decodeFile(path, opts)
        } catch (e: Throwable) {
            null
        }
    }
}
