package com.zarvimo.cricket.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File

/**
 * Images are copied into app-private storage on import, so they keep working after the picker's temporary permission
 * ends and survive app restarts. Decoding is down-scaled so a 48MP photo cannot exhaust memory.
 */
object MediaImporter {

    fun importImage(context: Context, uri: Uri, kind: String): String? = try {
        val dir = File(context.filesDir, "media").apply { mkdirs() }
        val out = File(dir, "${kind}_${System.currentTimeMillis()}.img")
        context.contentResolver.openInputStream(uri)?.use { input -> out.outputStream().use { input.copyTo(it) } } ?: return null
        // validate it really decodes as an image
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(out.path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) { out.delete(); null } else out.path
    } catch (e: Exception) {
        null
    }

    fun load(path: String?, maxDim: Int): Bitmap? {
        if (path.isNullOrBlank()) return null
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, bounds)
            var sample = 1
            while (bounds.outWidth / sample > maxDim * 2 || bounds.outHeight / sample > maxDim * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
            BitmapFactory.decodeFile(path, opts)
        } catch (e: Throwable) {
            null
        }
    }
}
