package com.zarvimo.cricket.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.cricket.live.ChatMessage

private val Warn = Color(0xFFFFB74D)
private val Bad = Color(0xFFFF6B6B)

@Composable
private fun StatBox(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Gold)
        Text(label, fontSize = 11.sp)
    }
}

/** Viewer count, live-chat comments, reply box and the one-time YouTube sign-in. */
@Composable
fun LiveChatCard(vm: AppViewModel) {
    val st by vm.live.collectAsState()
    val uri = LocalUriHandler.current
    val saved = remember { vm.ytCredentials() }
    var clientId by remember { mutableStateOf(saved.first) }
    var clientSecret by remember { mutableStateOf(saved.second) }
    var showHelp by remember { mutableStateOf(false) }
    var manual by remember { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<ChatMessage?>(null) }
    var replyText by remember { mutableStateOf("") }

    SectionCard("Viewers & comments (YouTube)") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            StatBox(st.viewers?.toString() ?: "–", "WATCHING NOW")
            StatBox(st.totalViews?.toString() ?: "–", "TOTAL VIEWS")
            StatBox(st.messages.size.toString(), "COMMENTS")
        }
        Text(st.status, fontSize = 12.sp)
        st.error?.let { if (it != st.status) Text(it, color = Bad, fontSize = 12.sp) }

        if (!st.signedIn) {
            Text(
                "Sign in once with your own Google account to see viewers and comments and to reply. Only YouTube is supported (Facebook is not).",
                fontSize = 12.sp
            )
            BigButton(if (showHelp) "Hide setup steps" else "Show setup steps (one time, about 5 minutes)", Modifier.fillMaxWidth()) { showHelp = !showHelp }
            if (showHelp) {
                Text(
                    "1. On console.cloud.google.com create a project and enable \"YouTube Data API v3\".\n" +
                        "2. OAuth consent screen: choose External, and add your own Google account as a Test user.\n" +
                        "3. Credentials > Create credentials > OAuth client ID > Application type \"TVs and Limited Input devices\".\n" +
                        "4. Copy the Client ID and Client secret into the boxes below, press Save, then Sign in.\n" +
                        "5. Open the page shown below on any phone or computer and type the code.\n\n" +
                        "Limits: Google allows about 10,000 API units per day for free; comments use about 2,000 per hour of streaming. " +
                        "While the app is in Google's \"Testing\" mode you may have to sign in again after 7 days.",
                    fontSize = 11.sp
                )
            }
            TextInput("OAuth Client ID", clientId, { clientId = it })
            TextInput("OAuth Client secret", clientSecret, { clientSecret = it }, secret = true)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton("Save", Modifier.weight(1f)) { vm.ytSaveCredentials(clientId, clientSecret) }
                BigButton("Sign in with Google", Modifier.weight(2f), Gold, Color.Black) {
                    vm.ytSaveCredentials(clientId, clientSecret)
                    vm.ytSignIn()
                }
            }
            st.deviceCode?.let { code ->
                Text("Your code: $code", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Gold)
                val url = st.verificationUrl ?: "https://www.google.com/device"
                Text(url, fontSize = 13.sp)
                BigButton("Open $url", Modifier.fillMaxWidth()) { uri.openUri(url) }
            }
        } else {
            TextInput("Video link or ID (optional; empty = find my running broadcast automatically)", manual, { manual = it })
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (st.connected) {
                    BigButton("Disconnect", Modifier.weight(1f), Color(0xFF5A2A2A)) { vm.ytDisconnect() }
                } else {
                    BigButton("Connect to my live stream", Modifier.weight(2f), Gold, Color.Black) { vm.ytConnect(manual) }
                }
                BigButton("Sign out", Modifier.weight(1f)) { vm.ytSignOut() }
            }
            Text("It connects by itself when you go live. Viewer numbers refresh every 30 seconds, comments about every 10 seconds.", fontSize = 11.sp)

            // ---- reply box
            val target = replyTo
            if (target != null) {
                Text("Replying to @${target.author}: ${target.text.take(60)}", fontSize = 12.sp, color = Gold)
            }
            TextInput(if (target != null) "Your reply" else "Write in the live chat", replyText, { replyText = it })
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton("Send", Modifier.weight(2f).height(48.dp), Gold, Color.Black, enabled = st.connected && replyText.isNotBlank()) {
                    vm.ytSend(replyText, target?.author)
                    replyText = ""
                    replyTo = null
                }
                if (target != null) BigButton("Cancel", Modifier.weight(1f).height(48.dp)) { replyTo = null }
            }
            st.replyStatus?.let { Text(it, fontSize = 12.sp, color = if (it == "Sent") Gold else Warn) }

            // ---- comments (newest first)
            if (st.messages.isEmpty()) {
                Text(if (st.connected) "No comments yet." else "Comments appear here once you are connected.", fontSize = 12.sp)
            }
            st.messages.takeLast(40).reversed().forEach { m ->
                Column(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    val badge = when {
                        m.highlight != null -> "  [${m.highlight}]"
                        m.isOwner -> "  [OWNER]"
                        m.isModerator -> "  [MOD]"
                        else -> ""
                    }
                    Text(m.author + badge, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Gold)
                    Text(m.text, fontSize = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BigButton("Reply", Modifier.height(40.dp)) { replyTo = m; vm.ytClearReplyStatus() }
                        BigButton("Show on air", Modifier.height(40.dp)) { vm.showComment(m) }
                    }
                }
            }
        }
    }
}
