package com.zarvimo.cricket.ui

import com.zarvimo.cricket.scoring.Dls
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.cricket.scoring.BallEvent
import com.zarvimo.cricket.scoring.BallRecord
import com.zarvimo.cricket.scoring.BatterStat
import com.zarvimo.cricket.scoring.DismissalType
import com.zarvimo.cricket.scoring.ExtraType
import com.zarvimo.cricket.scoring.InningsState
import com.zarvimo.cricket.scoring.WicketInfo

@Composable
fun ScoringScreen(vm: AppViewModel, onNavigate: (String) -> Unit) {
    val m by vm.match.collectAsState()
    val st = m.state
    var ballDialog by remember { mutableStateOf<BallDialogSpec?>(null) }
    var showHistory by remember { mutableStateOf(false) }
    var showMore by remember { mutableStateOf(false) }
    var boundaryMode by remember { mutableStateOf(true) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StatusStrip(vm)
        if (st == null) {
            SectionCard("No innings in progress") {
                Text(if (m.setup.validate() != null) "Set up the match first." else "Match is set up. Choose the opening batters and bowler to start the innings.")
                BigButton("Go to Match Setup", Modifier.fillMaxWidth(), Gold, Color.Black, icon = Ic.Sliders) { onNavigate("setup") }
            }
            return@Column
        }

        ScoreCard(m, st)
        m.message?.let { WarnLine(it, color = MaterialColor.error) }

        PlayersCard(st)
        RecentBallsRow(st)

        // ---- prompts the rules require before the next ball can be scored
        if (st.batterRequired) NewNamePrompt(
            "New batter", "Batter name", if (st.pendingBatterEnd?.name == "STRIKER") "comes in on strike" else "comes in at the non-striker's end",
            squad = m.setup.squadOf(st.battingTeam), exclude = st.batters.map { it.name }
        ) { vm.batterIn(it) }
        if (st.bowlerRequired) NewNamePrompt(
            "End of over: select bowler", "Bowler name", "The previous bowler cannot bowl the next over",
            squad = m.setup.squadOf(st.bowlingTeam), exclude = emptyList()
        ) { vm.setBowler(it) }

        if (st.ended) {
            SectionCard("Innings ended: ${st.endReason ?: ""}") {
                if (m.inningsIndex == 0) {
                    Text("${st.battingTeam} ${st.scoreText} (${st.oversText} ov). Target for ${st.bowlingTeam}: ${st.runs + 1}.")
                    BigButton("Start 2nd innings", Modifier.fillMaxWidth(), Gold, Color.Black) { onNavigate("setup") }
                } else {
                    OverlayResult(vm)
                }
            }
        } else {
            val canScore = st.canScoreNextBall
            // Run buttons
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (r in 0..3) ScoreButton("$r", Modifier.weight(1f), enabled = canScore) { vm.addBall(r) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ScoreButton("4", Modifier.weight(1f), Color(0xFF1976D2), canScore) { vm.addBall(4, boundary = boundaryMode) }
                ScoreButton("5", Modifier.weight(1f), enabled = canScore) { vm.addBall(5) }
                ScoreButton("6", Modifier.weight(1f), Color(0xFF8E24AA), canScore) { vm.addBall(6, boundary = boundaryMode) }
                ScoreButton("W", Modifier.weight(1f), Crimson, canScore) { ballDialog = BallDialogSpec(null, ExtraType.NONE, true) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ScoreButton("Wide", Modifier.weight(1f), Color(0xFFF57C00), canScore, 15) { ballDialog = BallDialogSpec(null, ExtraType.WIDE, false) }
                ScoreButton("No ball", Modifier.weight(1f), Color(0xFFF57C00), canScore, 15) { ballDialog = BallDialogSpec(null, ExtraType.NO_BALL, false) }
                ScoreButton("Bye", Modifier.weight(1f), Color(0xFF8D6E63), canScore, 15) { ballDialog = BallDialogSpec(null, ExtraType.BYE, false) }
                ScoreButton("Leg bye", Modifier.weight(1f), Color(0xFF8D6E63), canScore, 15) { ballDialog = BallDialogSpec(null, ExtraType.LEG_BYE, false) }
            }
            SwitchRow("4 and 6 are boundaries (turn off if the batters ran them)", boundaryMode) { boundaryMode = it }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ScoreButton("Undo", Modifier.weight(1f), PanelHi, m.canUndo, 15) { vm.undo() }
            ScoreButton("Redo", Modifier.weight(1f), PanelHi, m.canRedo, 15) { vm.redo() }
            ScoreButton("Swap strike", Modifier.weight(1f), PanelHi, !st.ended, 15) { vm.swapStrike() }
            ScoreButton("More", Modifier.weight(1f), PanelHi, true, 15) { showMore = true }
        }
        BigButton("Ball-by-ball history / corrections", Modifier.fillMaxWidth(), icon = Ic.Undo) { showHistory = true }
        Spacer(Modifier.height(24.dp))
    }

    ballDialog?.let { spec ->
        if (st != null) BallDialog(spec, st, m.setup.squadOf(st.battingTeam), m.setup.squadOf(st.bowlingTeam), onDismiss = { ballDialog = null }) { runs, extra, extraRuns, nbType, boundary, wicket ->
            val editId = spec.initial?.id
            val factory: (Long) -> com.zarvimo.cricket.scoring.ScoreEvent = { id -> BallEvent(id, runs, extra, extraRuns, nbType, boundary, wicket) }
            if (editId != null) vm.replaceEvent(editId, factory) else vm.addEvent(factory)
            ballDialog = null
            if (editId != null) showHistory = true
        }
    }
    if (showHistory && st != null) {
        HistoryDialog(vm, st, onDismiss = { showHistory = false }, onEdit = { ev -> showHistory = false; ballDialog = BallDialogSpec(ev, ev.extra, ev.wicket != null) })
    }
    if (showMore && st != null) MoreDialog(vm, st, onDismiss = { showMore = false })
}

private object MaterialColor { val error = Color(0xFFFF6B6B) }

@Composable
private fun OverlayResult(vm: AppViewModel) {
    val m by vm.match.collectAsState()
    val st = m.state ?: return
    val result = com.zarvimo.cricket.graphics.OverlayBuilder.resultText(st, st.battingTeam, st.bowlingTeam)
    Text(result ?: "Match complete", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Gold)
}

@Composable
private fun ScoreButton(text: String, modifier: Modifier = Modifier, color: Color = Color(0xFF2A3A6B), enabled: Boolean = true, fontSize: Int = 24, onClick: () -> Unit) {
    androidx.compose.material3.Button(
        onClick = onClick, enabled = enabled, modifier = modifier.height(64.dp), shape = RoundedCornerShape(14.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(2.dp),
        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
            containerColor = color, contentColor = Color.White,
            disabledContainerColor = Color(0xFF2A3350), disabledContentColor = Color(0xFF7C86A5)
        )
    ) { Text(text, fontWeight = FontWeight.ExtraBold, fontSize = fontSize.sp, maxLines = 1) }
}

@Composable
private fun ScoreCard(m: MatchUi, st: InningsState) {
    SectionCard("${st.battingTeam}  •  innings ${m.inningsIndex + 1}") {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(st.scoreText, fontSize = 56.sp, fontWeight = FontWeight.ExtraBold)
            Column(horizontalAlignment = Alignment.End) {
                Text("${st.oversText} / ${st.oversLimit} ov", fontSize = 20.sp, color = Gold, fontWeight = FontWeight.Bold)
                Text("CRR ${"%.2f".format(java.util.Locale.ROOT, st.runRate)}", fontSize = 14.sp)
            }
        }
        st.target?.let { t ->
            val req = st.requiredRuns ?: 0
            Text(
                if (st.ended) "Target $t" else "Target $t • need $req from ${st.ballsRemaining} balls" +
                    (st.requiredRunRate?.let { " • RRR ${"%.2f".format(java.util.Locale.ROOT, it)}" } ?: ""),
                fontWeight = FontWeight.Bold
            )
        }
        if (st.freeHit) Pill("FREE HIT", Color(0xFFD81B60))
        if (st.manualRunsAdjustment != 0 || st.manualWicketsAdjustment != 0) {
            Text("Includes manual adjustment: ${st.manualRunsAdjustment} runs, ${st.manualWicketsAdjustment} wickets", fontSize = 12.sp, color = Color(0xFFFFB74D))
        }
        Text("Extras ${st.extras.total} (wd ${st.extras.wides}, nb ${st.extras.noBalls}, b ${st.extras.byes}, lb ${st.extras.legByes}, pen ${st.extras.penalty})  •  Wickets left ${st.wicketsRemaining}", fontSize = 12.sp)
    }
}

@Composable
private fun PlayersCard(st: InningsState) {
    SectionCard("At the crease", icon = Ic.Cricket) {
        BatterRow(st.striker, true)
        BatterRow(st.nonStriker, false)
        st.bowler?.let { Text("Bowler: ${it.name}  ${it.figuresText}  (econ ${"%.2f".format(java.util.Locale.ROOT, it.economy)})", fontWeight = FontWeight.Bold) }
            ?: Text("Bowler: not selected", color = Color(0xFFFFB74D))
        st.lastDismissed?.let { Text("Last out: ${it.name} ${it.runs} (${it.balls}) ${it.dismissal ?: ""}", fontSize = 12.sp, color = Color(0xFFFF8A80)) }
        if (st.fallOfWickets.isNotEmpty()) {
            Text("FoW: " + st.fallOfWickets.joinToString("  ") { "${it.wicketNumber}-${it.teamRuns} (${it.batter}, ${it.oversText})" }, fontSize = 11.sp)
        }
    }
}

@Composable
private fun BatterRow(b: BatterStat?, onStrike: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            if (onStrike) AppIcon(Ic.Cricket, size = 18.dp, tint = Gold) else androidx.compose.foundation.layout.Spacer(Modifier.size(18.dp))
            androidx.compose.foundation.layout.Spacer(Modifier.size(6.dp))
            Text(b?.name ?: "—", fontWeight = if (onStrike) FontWeight.Bold else FontWeight.Normal, fontSize = 17.sp)
        }
        Text(b?.let { "${it.runs} (${it.balls})  4s ${it.fours}  6s ${it.sixes}" } ?: "", fontSize = 14.sp, color = Gold)
    }
}

@Composable
private fun RecentBallsRow(st: InningsState) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Over", fontSize = 12.sp)
        st.recentBalls.takeLast(10).forEach { BallChip(it) }
    }
}

@Composable
fun BallChip(r: BallRecord) {
    val l = r.label
    val c = when {
        l.contains("W") && !l.startsWith("Wd") -> Color(0xFFD32F2F)
        l.startsWith("Wd") || l.startsWith("Nb") || l.endsWith("b") || l.endsWith("lb") -> Color(0xFFF57C00)
        l == "6" -> Color(0xFF8E24AA)
        l == "4" -> Color(0xFF1976D2)
        l == "0" -> Color(0xFF455A64)
        else -> Color(0xFF2E7D32)
    }
    Box(Modifier.size(32.dp).clip(CircleShape).background(c), contentAlignment = Alignment.Center) {
        Text(l, fontSize = if (l.length > 2) 9.sp else 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}

@Composable
private fun NewNamePrompt(
    title: String, label: String, hint: String, squad: List<String> = emptyList(), exclude: List<String> = emptyList(),
    onConfirm: (String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    SectionCard(title) {
        Text(hint, fontSize = 12.sp)
        PickFromSquad(squad, exclude) { onConfirm(it); name = "" }
        TextInput(label, name, { name = it })
        BigButton("Confirm", Modifier.fillMaxWidth(), Gold, Color.Black, enabled = name.isNotBlank()) { onConfirm(name.trim()); name = "" }
    }
}

// ------------------------------------------------------------------------------------------------ dialogs

data class BallDialogSpec(val initial: BallEvent?, val type: ExtraType, val wicket: Boolean)

@Composable
private fun BallDialog(
    spec: BallDialogSpec,
    st: InningsState,
    batSquad: List<String>,
    bowlSquad: List<String>,
    onDismiss: () -> Unit,
    onConfirm: (Int, ExtraType, Int, ExtraType, Boolean, WicketInfo?) -> Unit
) {
    val ini = spec.initial
    var extra by remember { mutableStateOf(ini?.extra ?: spec.type) }
    var runs by remember { mutableStateOf(ini?.runsBat ?: 0) }
    var extraRuns by remember { mutableStateOf(ini?.extraRuns ?: if (spec.type == ExtraType.BYE || spec.type == ExtraType.LEG_BYE) 1 else 0) }
    var nbType by remember { mutableStateOf(if (ini != null && ini.noBallRunType != ExtraType.NONE) ini.noBallRunType else ExtraType.BYE) }
    var boundary by remember { mutableStateOf(ini?.boundary ?: false) }
    var wicketOn by remember { mutableStateOf(spec.wicket) }
    var dType by remember { mutableStateOf(ini?.wicket?.type ?: DismissalType.BOWLED) }
    var strikerOut by remember { mutableStateOf(ini?.wicket?.outBatterIsStriker ?: true) }
    var fielder by remember { mutableStateOf(ini?.wicket?.fielder ?: "") }
    var incoming by remember { mutableStateOf(ini?.wicket?.incomingBatter ?: "") }

    val restrictedToRunOutLike = extra == ExtraType.NO_BALL || (st.freeHit && ini == null)
    val dismissalOptions = DismissalType.values().filter {
        when {
            restrictedToRunOutLike -> it.allowedOnNoBall
            extra == ExtraType.WIDE -> it.allowedOnWide
            else -> true
        }
    }
    if (wicketOn && dType !in dismissalOptions) dType = dismissalOptions.first()
    val runsOffBatAllowed = (extra == ExtraType.NONE || extra == ExtraType.NO_BALL) && (!wicketOn || dType.allowsRuns)
    val extraRunsAllowed = !wicketOn || dType.allowsRuns || extra == ExtraType.WIDE || extra == ExtraType.NO_BALL

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (ini != null) "Correct this ball" else "Enter delivery") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Delivery type", fontSize = 12.sp)
                ChipChoice(ExtraType.values().toList(), extra, { it.label }) {
                    extra = it
                    if (it == ExtraType.BYE || it == ExtraType.LEG_BYE) { runs = 0; if (extraRuns < 1) extraRuns = 1 }
                    if (it == ExtraType.WIDE) runs = 0
                    if (it == ExtraType.NONE) extraRuns = 0
                }
                if (runsOffBatAllowed) {
                    Text("Runs off the bat", fontSize = 12.sp)
                    ChipChoice((0..7).toList(), runs, { "$it" }) { runs = it }
                } else runs = 0
                when (extra) {
                    ExtraType.WIDE -> {
                        Text("Additional runs completed (the wide's own penalty run is added automatically)", fontSize = 12.sp)
                        ChipChoice((0..5).toList(), extraRuns, { "$it" }) { extraRuns = it }
                    }
                    ExtraType.NO_BALL -> {
                        Text("Byes / leg-byes run on this no-ball (the no-ball penalty is added automatically)", fontSize = 12.sp)
                        ChipChoice((0..4).toList(), extraRuns, { "$it" }) { extraRuns = it }
                        if (extraRuns > 0) ChipChoice(listOf(ExtraType.BYE, ExtraType.LEG_BYE), nbType, { it.label }) { nbType = it }
                    }
                    ExtraType.BYE, ExtraType.LEG_BYE -> {
                        Text("${extra.label} runs", fontSize = 12.sp)
                        ChipChoice((1..5).toList(), extraRuns, { "$it" }) { extraRuns = it }
                    }
                    ExtraType.NONE -> {}
                }
                if (!extraRunsAllowed) extraRuns = 0
                if (runs + extraRuns >= 4) SwitchRow("Boundary (ball reached the rope, not run)", boundary) { boundary = it }
                else boundary = false

                SwitchRow("Wicket on this ball", wicketOn) { wicketOn = it }
                if (wicketOn) {
                    ChipChoice(dismissalOptions, dType, { it.label }) { dType = it }
                    if (dType.canDismissNonStriker) {
                        Text("Who is out?", fontSize = 12.sp)
                        ChipChoice(listOf(true, false), strikerOut, { if (it) "Striker (${st.striker?.name ?: "-"})" else "Non-striker (${st.nonStriker?.name ?: "-"})" }) { strikerOut = it }
                    } else strikerOut = true
                    PickFromSquad(bowlSquad, emptyList(), "Fielder from the bowling Playing XI") { fielder = it }
                    TextInput("Fielder (optional)", fielder, { fielder = it })
                    PickFromSquad(batSquad, st.batters.map { it.name }, "Incoming batter from the batting Playing XI") { incoming = it }
                    if (ini == null) TextInput("Incoming batter (optional now)", incoming, { incoming = it })
                    else TextInput("Incoming batter (keep identical to avoid conflicts)", incoming, { incoming = it })
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val w = if (wicketOn) WicketInfo(dType, strikerOut, fielder.trim().ifEmpty { null }, incoming.trim().ifEmpty { null }) else null
                onConfirm(runs, extra, extraRuns, if (extra == ExtraType.NO_BALL && extraRuns > 0) nbType else ExtraType.NONE, boundary, w)
            }) { Text(if (ini != null) "Apply correction" else "Add ball", fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun HistoryDialog(vm: AppViewModel, st: InningsState, onDismiss: () -> Unit, onEdit: (BallEvent) -> Unit) {
    val m by vm.match.collectAsState()
    val balls = m.events.filterIsInstance<BallEvent>().associateBy { it.id }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ball-by-ball (newest first)") },
        text = {
            LazyColumn(Modifier.height(380.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(st.allBalls.reversed()) { r ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BallChip(r)
                        Column(Modifier.weight(1f)) {
                            Text("Over ${r.overIndex + 1}  •  ${r.bowler} to ${r.striker}", fontSize = 12.sp)
                            Text("+${r.runsAdded} runs${if (r.legal) "" else "  (not a legal ball)"}", fontSize = 11.sp, color = Gold)
                        }
                        TextButton(onClick = { balls[r.eventId]?.let(onEdit) }) { Text("Edit") }
                        TextButton(onClick = { vm.deleteEvent(r.eventId) }) { Text("Del", color = Crimson) }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun MoreDialog(vm: AppViewModel, st: InningsState, onDismiss: () -> Unit) {
    var penalty by remember { mutableStateOf("5") }
    var adjRuns by remember { mutableStateOf("0") }
    var adjWkts by remember { mutableStateOf("0") }
    var note by remember { mutableStateOf("") }
    var target by remember { mutableStateOf(st.target?.toString() ?: "") }
    var confirmEnd by remember { mutableStateOf(false) }
    var dlsS by remember { mutableStateOf("") }
    var dlsR1 by remember { mutableStateOf("100") }
    var dlsR2 by remember { mutableStateOf("") }
    var dlsG50 by remember { mutableStateOf("245") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("More scoring tools") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Penalty runs (to the batting team, no ball counted)", fontSize = 12.sp)
                TextInput("Penalty runs", penalty, { penalty = it }, numeric = true)
                BigButton("Add penalty", Modifier.fillMaxWidth()) { penalty.toIntOrNull()?.let { vm.penalty(it) }; onDismiss() }
                Text("MANUAL OVERRIDE — exceptional correction. Shown separately from calculated totals; can be undone.", fontSize = 12.sp, color = Color(0xFFFFB74D))
                TextInput("Runs (+/-)", adjRuns, { adjRuns = it })
                TextInput("Wickets (+/-)", adjWkts, { adjWkts = it })
                TextInput("Reason / note", note, { note = it })
                BigButton("Apply manual override", Modifier.fillMaxWidth(), Color(0xFF8D6E63)) {
                    vm.adjust(adjRuns.toIntOrNull() ?: 0, adjWkts.toIntOrNull() ?: 0, note); onDismiss()
                }
                if (st.target != null) {
                    TextInput("Target override (e.g. revised target)", target, { target = it }, numeric = true)
                    BigButton("Set target", Modifier.fillMaxWidth()) { vm.setTarget(target.toIntOrNull()); onDismiss() }
                    Text("DLS revised target. The app only does the arithmetic: read R1 (resources team 1 had) and R2 (resources team 2 has) from the official DLS table or software and enter them.", fontSize = 12.sp, color = Color(0xFFFFB74D))
                    TextInput("Team 1 score (S)", dlsS, { dlsS = it }, numeric = true)
                    TextInput("R1 %", dlsR1, { dlsR1 = it })
                    TextInput("R2 %", dlsR2, { dlsR2 = it })
                    TextInput("G50 (245 for ODI; use your playing conditions for other formats)", dlsG50, { dlsG50 = it }, numeric = true)
                    val dlsResult = Dls.revisedTarget(
                        dlsS.toIntOrNull() ?: -1,
                        dlsR1.replace(',', '.').toDoubleOrNull() ?: 0.0,
                        dlsR2.replace(',', '.').toDoubleOrNull() ?: 0.0,
                        dlsG50.toIntOrNull() ?: 0
                    )
                    if (dlsResult != null) {
                        Text("Revised target: $dlsResult", fontWeight = FontWeight.ExtraBold, color = Gold)
                        BigButton("Use $dlsResult as the target", Modifier.fillMaxWidth(), Gold, Color.Black) { vm.setTarget(dlsResult); onDismiss() }
                    } else {
                        Text("Enter S, R1, R2 and G50 to calculate.", fontSize = 11.sp)
                    }
                }
                if (!st.ended) BigButton("End innings (declare / close)", Modifier.fillMaxWidth(), Crimson) { confirmEnd = true }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
    if (confirmEnd) {
        AlertDialog(
            onDismissRequest = { confirmEnd = false },
            title = { Text("End this innings?") },
            text = { Text("No more balls can be added unless you undo this.") },
            confirmButton = { TextButton(onClick = { vm.endInnings("Innings closed"); confirmEnd = false; onDismiss() }) { Text("End innings", color = Crimson) } },
            dismissButton = { TextButton(onClick = { confirmEnd = false }) { Text("Cancel") } }
        )
    }
}
