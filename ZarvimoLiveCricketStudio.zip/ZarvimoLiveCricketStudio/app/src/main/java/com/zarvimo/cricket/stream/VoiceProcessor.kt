package com.zarvimo.cricket.stream

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

/*
 * Clean-up chain for the commentary microphone (pure Kotlin, no Android classes, unit-tested):
 *
 *   rumble filter -> noise reduction (spectral) -> studio EQ -> compressor -> soft limiter
 *
 * Honest scope: this is noise reduction on the microphone signal that viewers hear (what headsets call ENC).
 * "ANC" (cancelling noise in the listener's ears) is done by the headphones themselves; an app cannot do it.
 * Software cleans and shapes a voice, it cannot turn a poor microphone into a studio microphone.
 */

/** One IIR filter section (RBJ "Audio EQ Cookbook" coefficients). */
internal class Biquad {
    private var b0 = 1.0
    private var b1 = 0.0
    private var b2 = 0.0
    private var a1 = 0.0
    private var a2 = 0.0
    private var z1 = 0.0
    private var z2 = 0.0

    private fun set(nb0: Double, nb1: Double, nb2: Double, a0: Double, na1: Double, na2: Double) {
        b0 = nb0 / a0
        b1 = nb1 / a0
        b2 = nb2 / a0
        a1 = na1 / a0
        a2 = na2 / a0
    }

    fun highPass(sampleRate: Int, f0: Double, q: Double): Biquad {
        val w = 2 * PI * f0 / sampleRate
        val c = cos(w)
        val al = sin(w) / (2 * q)
        set((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al)
        return this
    }

    fun peaking(sampleRate: Int, f0: Double, q: Double, gainDb: Double): Biquad {
        val a = 10.0.pow(gainDb / 40)
        val w = 2 * PI * f0 / sampleRate
        val c = cos(w)
        val al = sin(w) / (2 * q)
        set(1 + al * a, -2 * c, 1 - al * a, 1 + al / a, -2 * c, 1 - al / a)
        return this
    }

    fun highShelf(sampleRate: Int, f0: Double, gainDb: Double): Biquad {
        val a = 10.0.pow(gainDb / 40)
        val w = 2 * PI * f0 / sampleRate
        val c = cos(w)
        val sq = 2 * sqrt(a) * (sin(w) / (2 * 0.707))
        set(
            a * ((a + 1) + (a - 1) * c + sq), -2 * a * ((a - 1) + (a + 1) * c), a * ((a + 1) + (a - 1) * c - sq),
            (a + 1) - (a - 1) * c + sq, 2 * ((a - 1) - (a + 1) * c), (a + 1) - (a - 1) * c - sq
        )
        return this
    }

    fun lowShelf(sampleRate: Int, f0: Double, gainDb: Double): Biquad {
        val a = 10.0.pow(gainDb / 40)
        val w = 2 * PI * f0 / sampleRate
        val c = cos(w)
        val sq = 2 * sqrt(a) * (sin(w) / (2 * 0.707))
        set(
            a * ((a + 1) - (a - 1) * c + sq), 2 * a * ((a - 1) - (a + 1) * c), a * ((a + 1) - (a - 1) * c - sq),
            (a + 1) + (a - 1) * c + sq, -2 * ((a - 1) + (a + 1) * c), (a + 1) + (a - 1) * c - sq
        )
        return this
    }

    fun process(x: Float): Float {
        val y = b0 * x + z1
        z1 = b1 * x - a1 * y + z2
        z2 = b2 * x - a2 * y
        return y.toFloat()
    }
}

/** In-place radix-2 complex FFT. */
internal class Fft(private val n: Int) {
    private val cosT = DoubleArray(n / 2) { cos(2 * PI * it / n) }
    private val sinT = DoubleArray(n / 2) { -sin(2 * PI * it / n) }
    private val rev = IntArray(n)

    init {
        val bits = n.countTrailingZeroBits()
        for (i in 0 until n) {
            var x = i
            var r = 0
            for (b in 0 until bits) {
                r = (r shl 1) or (x and 1)
                x = x shr 1
            }
            rev[i] = r
        }
    }

    fun transform(re: DoubleArray, im: DoubleArray, inverse: Boolean) {
        for (i in 0 until n) {
            val j = rev[i]
            if (j > i) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var size = 2
        while (size <= n) {
            val half = size / 2
            val step = n / size
            var i = 0
            while (i < n) {
                var k = 0
                for (j in i until i + half) {
                    val wr = cosT[k]
                    val wi = if (inverse) -sinT[k] else sinT[k]
                    val tr = re[j + half] * wr - im[j + half] * wi
                    val ti = re[j + half] * wi + im[j + half] * wr
                    re[j + half] = re[j] - tr
                    im[j + half] = im[j] - ti
                    re[j] += tr
                    im[j] += ti
                    k += step
                }
                i += size
            }
            size = size shl 1
        }
        if (inverse) {
            for (i in 0 until n) {
                re[i] /= n
                im[i] /= n
            }
        }
    }
}

/**
 * Streaming spectral noise reducer (one channel): 512-point sqrt-Hann STFT with 50 % overlap, a noise-floor tracker that
 * freezes while speech is present, and a smoothed Wiener-style gain. Adds 256 samples (about 6 ms) of delay.
 * [level]: 1 = light, 2 = medium, 3 = strong.
 */
internal class SpectralNoiseReducer(level: Int) {
    private val n = 512
    private val hop = 256
    private val bins = n / 2 + 1
    private val beta: Double
    private val gMin: Double

    private val window = DoubleArray(n) { sqrt(0.5 - 0.5 * cos(2 * PI * (it + 0.5) / n)) }
    private val fft = Fft(n)
    private val re = DoubleArray(n)
    private val im = DoubleArray(n)
    private val inRing = DoubleArray(n)
    private var inPos = 0
    private var acc = 0
    private val ola = DoubleArray(n)
    private val outRing = FloatArray(1024)
    private var outRead = 0
    private var outWrite = hop
    private val noise = DoubleArray(bins)
    private val noiseRef = DoubleArray(bins) // last noise floor seen while no speech was present
    private val psm = DoubleArray(bins)
    private val gain = DoubleArray(bins)
    private val gPrev = DoubleArray(bins) { 1.0 }
    private val gRaw = DoubleArray(bins)
    private var initialised = false
    private var frozen = 0

    init {
        when (level) {
            1 -> { beta = 1.1; gMin = 0.35 }
            2 -> { beta = 1.6; gMin = 0.18 }
            else -> { beta = 2.2; gMin = 0.08 }
        }
    }

    fun processSample(x: Float): Float {
        inRing[inPos] = x.toDouble()
        inPos = (inPos + 1) % n
        acc++
        if (acc == hop) {
            acc = 0
            frame()
        }
        val y = outRing[outRead]
        outRead = (outRead + 1) % outRing.size
        return y
    }

    private fun frame() {
        for (i in 0 until n) {
            re[i] = inRing[(inPos + i) % n] * window[i]
            im[i] = 0.0
        }
        fft.transform(re, im, false)

        var sumP = 0.0
        var sumN = 0.0
        for (k in 0 until bins) {
            val p = re[k] * re[k] + im[k] * im[k] + 1e-12
            psm[k] = if (initialised) 0.6 * psm[k] + 0.4 * p else p
        }
        if (!initialised) {
            for (k in 0 until bins) {
                noise[k] = psm[k]
                noiseRef[k] = psm[k]
            }
            initialised = true
        }
        for (k in 0 until bins) {
            sumP += psm[k]
            sumN += noise[k]
        }
        // Noise floor: follows the signal while it looks like background noise, stays put during speech.
        if (sumP / sumN < 3.0) {
            for (k in 0 until bins) {
                noise[k] += (psm[k] - noise[k]) * 0.05
                noiseRef[k] = noise[k]
            }
            frozen = 0
        } else {
            frozen++
            if (frozen > 500) {
                // Loud for ~3 s: maybe the crowd got louder. Allow a slow upward drift, but never more than +12 dB over the
                // last known noise floor, so long continuous speech cannot be mistaken for noise.
                for (k in 0 until bins) {
                    if (psm[k] > noise[k]) noise[k] = minOf(noise[k] + (psm[k] - noise[k]) * 0.002, noiseRef[k] * 16.0)
                }
            }
        }
        for (k in 0 until bins) {
            if (noise[k] < 1e-12) noise[k] = 1e-12
            gRaw[k] = (1.0 - beta * noise[k] / psm[k]).coerceIn(gMin, 1.0)
        }
        for (k in 0 until bins) {
            val gs = if (k in 1 until bins - 1) 0.25 * gRaw[k - 1] + 0.5 * gRaw[k] + 0.25 * gRaw[k + 1] else gRaw[k]
            val prev = gPrev[k]
            val gt = if (gs > prev) 0.3 * prev + 0.7 * gs else 0.7 * prev + 0.3 * gs // opens fast, closes a little slower
            gPrev[k] = gt
            gain[k] = gt
        }
        for (k in 0 until n) {
            val kk = if (k < bins) k else n - k
            re[k] *= gain[kk]
            im[k] *= gain[kk]
        }
        fft.transform(re, im, true)
        for (i in 0 until n) ola[i] += re[i] * window[i]
        for (i in 0 until hop) {
            outRing[outWrite] = ola[i].toFloat()
            outWrite = (outWrite + 1) % outRing.size
        }
        System.arraycopy(ola, hop, ola, 0, n - hop)
        java.util.Arrays.fill(ola, n - hop, n, 0.0)
    }
}

/** Feed-forward compressor (level detector in the linear domain, gain computed in dB). */
internal class Compressor(
    sampleRate: Int,
    private val thresholdDb: Double,
    private val ratio: Double,
    attackMs: Double,
    releaseMs: Double,
    private val makeupDb: Double
) {
    private val att = exp(-1.0 / (sampleRate * attackMs / 1000.0))
    private val rel = exp(-1.0 / (sampleRate * releaseMs / 1000.0))
    private var env = 0.0

    fun process(x: Float): Float {
        val l = abs(x).toDouble()
        env = if (l > env) att * env + (1 - att) * l else rel * env + (1 - rel) * l
        val envDb = 20 * log10(max(env, 1e-5))
        val over = envDb - thresholdDb
        val gainDb = if (over > 0) -over * (1 - 1 / ratio) else 0.0
        return (x * 10.0.pow((gainDb + makeupDb) / 20)).toFloat()
    }
}

internal fun softLimit(x: Float): Float {
    val a = abs(x)
    if (a <= 0.8f) return x
    val y = 0.8f + 0.2f * tanh((a - 0.8f) / 0.2f)
    return if (x < 0) -y else y
}

/** The full chain for one audio channel. */
internal class VoiceChannel(sampleRate: Int, noise: Int, private val studio: Int, rumble: Boolean) {
    private val highPass: Biquad? = if (rumble) Biquad().highPass(sampleRate, 95.0, 0.707) else null
    private val reducer: SpectralNoiseReducer? = if (noise > 0) SpectralNoiseReducer(noise) else null
    private val eq: List<Biquad> = when (studio) {
        1 -> listOf(
            Biquad().peaking(sampleRate, 300.0, 0.9, -2.0),
            Biquad().peaking(sampleRate, 3000.0, 0.8, 2.5),
            Biquad().highShelf(sampleRate, 9000.0, 1.5)
        )
        2 -> listOf(
            Biquad().lowShelf(sampleRate, 140.0, 2.0),
            Biquad().peaking(sampleRate, 300.0, 0.9, -3.0),
            Biquad().peaking(sampleRate, 3200.0, 0.8, 4.0),
            Biquad().highShelf(sampleRate, 8000.0, 3.0)
        )
        else -> emptyList()
    }
    private val compressor: Compressor? = when (studio) {
        1 -> Compressor(sampleRate, -26.0, 2.5, 8.0, 160.0, 5.0)
        2 -> Compressor(sampleRate, -30.0, 4.0, 5.0, 120.0, 8.0)
        else -> null
    }

    fun process(x: Float): Float {
        var v = x
        highPass?.let { v = it.process(v) }
        reducer?.let { v = it.processSample(v) }
        for (b in eq) v = b.process(v)
        compressor?.let { v = it.process(v) }
        if (studio > 0) v = softLimit(v)
        return v
    }
}

/**
 * Thread-safe front door: [configure] may be called from any thread; [process] runs on the microphone thread and
 * rebuilds its filters when the configuration changed.
 */
class VoiceProcessor(private val sampleRate: Int) {

    data class Config(val noise: Int, val studio: Int, val rumble: Boolean)

    @Volatile private var wanted = Config(0, 0, false)
    private var active: Config? = null
    private var chains: Array<VoiceChannel> = emptyArray()

    fun configure(noiseReduction: Int, studioVoice: Int, rumbleFilter: Boolean) {
        wanted = Config(noiseReduction.coerceIn(0, 3), studioVoice.coerceIn(0, 2), rumbleFilter)
    }

    /** In place on interleaved 16-bit samples ([frames] x [channels]). */
    fun process(buf: ShortArray, frames: Int, channels: Int) {
        val w = wanted
        if (w.noise == 0 && w.studio == 0 && !w.rumble) {
            active = null
            return
        }
        if (w != active || chains.size != channels) {
            chains = Array(channels) { VoiceChannel(sampleRate, w.noise, w.studio, w.rumble) }
            active = w
        }
        for (f in 0 until frames) {
            for (c in 0 until channels) {
                val i = f * channels + c
                val v = chains[c].process(buf[i] / 32768f)
                buf[i] = PcmMath.clamp16((v * 32768f).toInt())
            }
        }
    }
}
