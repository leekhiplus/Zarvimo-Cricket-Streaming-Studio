package com.zarvimo.cricket.graphics

/** Colour family of an announcement banner. */
enum class AlertTone(val color: Int) {
    RED(0xFFD32F2F.toInt()),
    AMBER(0xFFF9A825.toInt()),
    GREEN(0xFF2E7D32.toInt()),
    BLUE(0xFF1565C0.toInt()),
    PURPLE(0xFF7B1FA2.toInt()),
    GREY(0xFF546E7A.toInt())
}

/**
 * One-tap announcement banners. Short decisions disappear by themselves; breaks and delays ("sticky") stay on air until
 * the scorer hides them.
 */
enum class AlertKind(val label: String, val title: String, val sub: String, val tone: AlertTone, val sticky: Boolean) {
    UMPIRES_CALL("Umpire's call", "UMPIRE'S CALL", "ORIGINAL DECISION STANDS", AlertTone.AMBER, false),
    OUT("Out", "OUT", "DECISION GIVEN: OUT", AlertTone.RED, false),
    NOT_OUT("Not out", "NOT OUT", "DECISION GIVEN: NOT OUT", AlertTone.GREEN, false),
    DRINKS("Drinks break", "DRINKS BREAK", "PLAY WILL RESUME SHORTLY", AlertTone.BLUE, true),
    TIMEOUT("Timeout", "STRATEGIC TIMEOUT", "PLAY WILL RESUME SHORTLY", AlertTone.PURPLE, true),
    RAIN("Rain delay", "RAIN DELAY", "PLAY IS SUSPENDED", AlertTone.GREY, true),
    BAD_LIGHT("Bad light", "BAD LIGHT", "PLAY IS SUSPENDED", AlertTone.GREY, true),
    LUNCH("Lunch", "LUNCH BREAK", "PLAY WILL RESUME SHORTLY", AlertTone.BLUE, true),
    TEA("Tea", "TEA BREAK", "PLAY WILL RESUME SHORTLY", AlertTone.BLUE, true),
    INNINGS_BREAK("Innings break", "INNINGS BREAK", "SECOND INNINGS TO FOLLOW", AlertTone.BLUE, true),
    PLAY_RESUMES("Play resumes", "PLAY RESUMES", "BACK TO THE ACTION", AlertTone.GREEN, false)
}

/** Everything the compositor needs to draw the banner. [shownAtMs] uses the renderer clock (SystemClock.uptimeMillis()). */
data class AlertInfo(
    val title: String,
    val sub: String,
    val color: Int,
    val sticky: Boolean,
    val shownAtMs: Long = 0L
)

/** Text of the DRS banners. */
object DrsText {
    fun review(team: String, reviewsLeft: Int): AlertInfo = AlertInfo(
        title = "DRS REVIEW",
        sub = "REVIEW BY ${team.trim().uppercase()}   \u2022   THIRD UMPIRE IS CHECKING   \u2022   REVIEWS LEFT: $reviewsLeft",
        color = AlertTone.BLUE.color,
        sticky = true
    )
}
