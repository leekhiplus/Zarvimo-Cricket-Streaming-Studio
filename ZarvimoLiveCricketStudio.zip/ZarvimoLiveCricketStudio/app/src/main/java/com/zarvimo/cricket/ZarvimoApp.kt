package com.zarvimo.cricket

import android.app.Application
import com.zarvimo.cricket.stream.StreamEngine

class ZarvimoApp : Application() {
    /** One engine per process => no duplicate encoder sessions. */
    val engine: StreamEngine by lazy { StreamEngine(this) }

    override fun onTerminate() {
        engine.release()
        super.onTerminate()
    }
}
