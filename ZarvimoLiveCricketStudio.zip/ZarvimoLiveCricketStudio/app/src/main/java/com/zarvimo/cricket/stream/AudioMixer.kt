package com.zarvimo.cricket.stream

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.pedro.encoder.input.audio.CustomAudioEffect
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/*
 * Audio side of the broadcast: background music + commentary microphone + local monitoring.
 *
 *   music files --MediaCodec decode--> stereo 44.1 kHz ring buffer --+
 *                                                                    |  MixerEffect.process() (called by RootEncoder for
 *   microphone (RootEncoder MicrophoneSource) ----------------------+-> every microphone buffer) mixes both and the
 *                                                                       result is what gets AAC-encoded and streamed.
 *
 * Monitoring (what the operator hears) is a separate AudioTrack that never blocks the microphone thread.
 * The microphone path itself is untouched RootEncoder code; only a CustomAudioEffect is attached to it.
 */

internal object PcmMath {
    fun clamp16(v: Int): Short = (if (v > 32767) 32767 else if (v < -32768) -32768 else v).toShort()
}

/** Thread-safe circular buffer of 16-bit samples (interleaved stereo). The producer blocks while it is full. */
class PcmRing(private val capacity: Int) {
    private val buf = ShortArray(capacity)
    private var readPos = 0
    private var writePos = 0
    private var size = 0
    private val lock = ReentrantLock()
    private val changed = lock.newCondition()

    /** Blocks until all [count] samples are stored, or [shouldAbort] returns true. */
    fun writeBlocking(src: ShortArray, count: Int, shouldAbort: () -> Boolean) {
        var done = 0
        lock.withLock {
            while (done < count) {
                if (shouldAbort()) return
                val free = capacity - size
                if (free <= 0) {
                    changed.await(20, TimeUnit.MILLISECONDS)
                    continue
                }
                val n = min(free, count - done)
                val first = min(n, capacity - writePos)
                System.arraycopy(src, done, buf, writePos, first)
                if (n > first) System.arraycopy(src, done + first, buf, 0, n - first)
                writePos = (writePos + n) % capacity
                size += n
                done += n
            }
        }
    }

    /** Non-blocking: copies up to [maxSamples] samples into [dst], returns how many were available. */
    fun read(dst: ShortArray, maxSamples: Int): Int = lock.withLock {
        val n = min(maxSamples, size)
        if (n > 0) {
            val first = min(n, capacity - readPos)
            System.arraycopy(buf, readPos, dst, 0, first)
            if (n > first) System.arraycopy(buf, 0, dst, first, n - first)
            readPos = (readPos + n) % capacity
            size -= n
            changed.signalAll()
        }
        max(n, 0)
    }

    fun clear() {
        lock.withLock {
            readPos = 0
            writePos = 0
            size = 0
            changed.signalAll()
        }
    }
}

/** Local playback (monitoring) of music and microphone: one low-latency stereo AudioTrack. */
class MonitorOutput(private val sampleRate: Int) {
    private var track: AudioTrack? = null
    private val lock = Any()

    fun ensureStarted() {
        synchronized(lock) {
            if (track != null) return
            try {
                val minBuf = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                val bytes = max(minBuf, sampleRate * 4 / 5) // about 200 ms of stereo 16-bit audio
                val builder = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(sampleRate)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build()
                    )
                    .setBufferSizeInBytes(bytes)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                if (Build.VERSION.SDK_INT >= 26) builder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                val t = builder.build()
                t.play()
                track = t
            } catch (e: Exception) {
                track = null
            }
        }
    }

    /** Used by the local music pump: blocks until the samples are queued (this paces local playback in real time). */
    fun writeBlocking(data: ShortArray, count: Int) {
        val t = track ?: return
        var off = 0
        while (off < count) {
            val n = try {
                t.write(data, off, count - off)
            } catch (e: Exception) {
                -1
            }
            if (n <= 0) break
            off += n
        }
    }

    /** Used by the microphone thread: never blocks; samples that do not fit are dropped. */
    fun writeNonBlocking(data: ShortArray, count: Int) {
        val t = track ?: return
        try {
            t.write(data, 0, count, AudioTrack.WRITE_NON_BLOCKING)
        } catch (e: Exception) {
        }
    }

    fun flush() {
        val t = track ?: return
        try {
            t.pause()
            t.flush()
            t.play()
        } catch (e: Exception) {
        }
    }

    fun release() {
        synchronized(lock) {
            val t = track
            track = null
            if (t != null) {
                try {
                    t.stop()
                } catch (e: Exception) {
                }
                t.release()
            }
        }
    }
}

/**
 * Decodes the playlist (loops forever) into [ring] as stereo 44.1 kHz PCM.
 * Consumers: the live mixer ([MixerEffect]) while streaming, or the local pump thread otherwise.
 */
class MusicEngine(
    private val monitor: MonitorOutput,
    private val onState: (MusicUiState) -> Unit
) {
    companion object {
        const val RATE = StreamOptions.AUDIO_SAMPLE_RATE
    }

    private val ring = PcmRing(RATE * 12 / 10) // 0.6 s of interleaved stereo samples

    @Volatile private var tracks: List<String> = emptyList()
    @Volatile private var index = 0
    @Volatile private var wantPlay = false
    @Volatile private var released = false
    @Volatile private var reopen = false
    @Volatile private var lastError: String? = null

    /** True while the live mixer pulls the music (the local pump then stays idle). */
    @Volatile var liveConsumer = false

    /** Loudness of the local pump (music volume x monitor volume, or 0 when music monitoring is off). */
    @Volatile var localGain = 0f

    private var decodeThread: Thread? = null
    private var pumpThread: Thread? = null

    // resampler state (decode thread only)
    private var pos = 0.0
    private var carryL = 0
    private var carryR = 0
    private var hasCarry = false

    @Synchronized
    private fun startThreads() {
        if (decodeThread != null) return
        released = false
        decodeThread = Thread({ decodeLoop() }, "music-decoder").also { it.isDaemon = true; it.start() }
        pumpThread = Thread({ pumpLoop() }, "music-local-pump").also { it.isDaemon = true; it.start() }
    }

    @Synchronized
    fun release() {
        released = true
        wantPlay = false
        ring.clear()
        decodeThread = null
        pumpThread = null
    }

    fun setTracks(paths: List<String>) {
        val old = tracks
        if (old == paths) return
        val current = old.getOrNull(index)
        tracks = paths
        val keep = if (current != null) paths.indexOf(current) else -1
        if (keep >= 0) {
            index = keep
        } else {
            index = 0
            reopen = true
            ring.clear()
        }
        if (paths.isEmpty()) wantPlay = false
        publish()
    }

    fun play() {
        if (tracks.isEmpty()) {
            lastError = "Add a music file first"
            publish()
            return
        }
        lastError = null
        startThreads()
        monitor.ensureStarted()
        wantPlay = true
        publish()
    }

    fun pause() {
        wantPlay = false
        publish()
    }

    fun next() {
        val n = tracks.size
        if (n == 0) return
        index = (index + 1) % n
        reopen = true
        ring.clear()
        publish()
    }

    /** Non-blocking. Returns the number of stereo FRAMES copied into [dst] (2 shorts per frame). */
    fun pullStereo(dst: ShortArray, frames: Int): Int = ring.read(dst, frames * 2) / 2

    private fun publish() {
        onState(MusicUiState(playing = wantPlay, index = max(0, index), error = lastError))
    }

    private fun nap(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (_: InterruptedException) {
        }
    }

    // ------------------------------------------------------------------------------------------ local pump

    private fun pumpLoop() {
        val frames = RATE / 50 // 20 ms
        val buf = ShortArray(frames * 2)
        while (!released) {
            if (!wantPlay || liveConsumer) {
                nap(20)
                continue
            }
            val got = pullStereo(buf, frames)
            if (got <= 0) {
                nap(5)
                continue
            }
            val g = localGain
            if (g < 0.999f) {
                for (i in 0 until got * 2) buf[i] = (buf[i] * g).toInt().toShort()
            }
            monitor.writeBlocking(buf, got * 2)
        }
    }

    // ------------------------------------------------------------------------------------------ decoder

    private fun decodeLoop() {
        var extractor: MediaExtractor? = null
        var codec: MediaCodec? = null
        var srcRate = RATE
        var srcCh = 2
        var pcmFloat = false
        var inputDone = false
        var wasPlaying = false
        var failures = 0
        val info = MediaCodec.BufferInfo()

        fun closeCodec() {
            try {
                codec?.stop()
            } catch (_: Exception) {
            }
            try {
                codec?.release()
            } catch (_: Exception) {
            }
            try {
                extractor?.release()
            } catch (_: Exception) {
            }
            codec = null
            extractor = null
        }

        try {
            while (!released) {
                if (!wantPlay) {
                    if (wasPlaying) {
                        ring.clear()
                        monitor.flush()
                        wasPlaying = false
                    }
                    nap(40)
                    continue
                }
                wasPlaying = true
                if (reopen) {
                    closeCodec()
                    reopen = false
                }
                if (codec == null) {
                    val list = tracks
                    if (list.isEmpty()) {
                        nap(100)
                        continue
                    }
                    val path = list[index.coerceIn(0, list.size - 1)]
                    try {
                        val ex = MediaExtractor()
                        extractor = ex
                        ex.setDataSource(path)
                        var trackIdx = -1
                        var fmt: MediaFormat? = null
                        for (i in 0 until ex.trackCount) {
                            val f = ex.getTrackFormat(i)
                            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                            if (mime.startsWith("audio/")) {
                                trackIdx = i
                                fmt = f
                                break
                            }
                        }
                        if (trackIdx < 0 || fmt == null) throw IllegalStateException("no audio track")
                        ex.selectTrack(trackIdx)
                        val c = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
                        c.configure(fmt, null, null, 0)
                        c.start()
                        codec = c
                        srcRate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else RATE
                        srcCh = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
                        pcmFloat = false
                        inputDone = false
                        pos = 0.0
                        hasCarry = false
                        failures = 0
                        if (lastError != null) {
                            lastError = null
                            publish()
                        }
                    } catch (e: Exception) {
                        closeCodec()
                        failures++
                        lastError = "Cannot play: " + File(path).name
                        if (failures >= list.size) {
                            wantPlay = false
                            failures = 0
                        } else {
                            index = (index + 1) % list.size
                        }
                        publish()
                        nap(150)
                        continue
                    }
                }

                val c = codec ?: continue
                val ex = extractor ?: continue

                if (!inputDone) {
                    val ii = c.dequeueInputBuffer(5_000)
                    if (ii >= 0) {
                        val ib = c.getInputBuffer(ii)
                        val n = if (ib != null) ex.readSampleData(ib, 0) else -1
                        if (n < 0) {
                            c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            c.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }

                val oi = c.dequeueOutputBuffer(info, 5_000)
                if (oi >= 0) {
                    val ended = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    if (info.size > 0 && !reopen) {
                        val ob = c.getOutputBuffer(oi)
                        if (ob != null) consume(ob, info, srcRate, srcCh, pcmFloat)
                    }
                    c.releaseOutputBuffer(oi, false)
                    if (ended) {
                        closeCodec()
                        val n = max(1, tracks.size)
                        index = (index + 1) % n
                        publish()
                    }
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = c.outputFormat
                    if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) srcRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) srcCh = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    pcmFloat = f.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        f.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                }
            }
        } catch (e: Throwable) {
            lastError = "Music player stopped unexpectedly"
            wantPlay = false
            publish()
        } finally {
            closeCodec()
        }
    }

    private fun consume(ob: ByteBuffer, info: MediaCodec.BufferInfo, rate: Int, channels: Int, isFloat: Boolean) {
        ob.position(info.offset)
        ob.limit(info.offset + info.size)
        val ordered = ob.order(ByteOrder.nativeOrder())
        val shorts: ShortArray
        if (isFloat) {
            val fb = ordered.asFloatBuffer()
            val tmp = FloatArray(fb.remaining())
            fb.get(tmp)
            shorts = ShortArray(tmp.size) { PcmMath.clamp16((tmp[it] * 32767f).toInt()) }
        } else {
            val sb = ordered.asShortBuffer()
            shorts = ShortArray(sb.remaining())
            sb.get(shorts)
        }
        val ch = max(1, channels)
        val frames = shorts.size / ch
        if (frames <= 0) return
        val stereo = ShortArray(frames * 2)
        for (i in 0 until frames) {
            val l = shorts[i * ch]
            val r = if (ch >= 2) shorts[i * ch + 1] else l
            stereo[2 * i] = l
            stereo[2 * i + 1] = r
        }
        resampleAndWrite(stereo, frames, rate)
    }

    /** Linear-interpolation resampler to [RATE]; keeps one frame of history between buffers. */
    private fun resampleAndWrite(stereo: ShortArray, frames: Int, srcRate: Int) {
        val step = srcRate.toDouble() / RATE
        val offset = if (hasCarry) 1 else 0
        val n = frames + offset
        val w = ShortArray(n * 2)
        if (hasCarry) {
            w[0] = carryL.toShort()
            w[1] = carryR.toShort()
        }
        System.arraycopy(stereo, 0, w, offset * 2, frames * 2)

        val maxFrames = max(0, ((n - pos) / step).toInt() + 2)
        val out = ShortArray(maxFrames * 2)
        var oc = 0
        var p = pos
        while (p + 1 < n && oc + 2 <= out.size) {
            val i = p.toInt()
            val f = (p - i).toFloat()
            val a0 = w[2 * i].toInt()
            val b0 = w[2 * i + 2].toInt()
            val a1 = w[2 * i + 1].toInt()
            val b1 = w[2 * i + 3].toInt()
            out[oc++] = (a0 + (b0 - a0) * f).toInt().toShort()
            out[oc++] = (a1 + (b1 - a1) * f).toInt().toShort()
            p += step
        }
        carryL = w[2 * (n - 1)].toInt()
        carryR = w[2 * (n - 1) + 1].toInt()
        hasCarry = true
        pos = p - (n - 1)
        if (oc > 0) ring.writeBlocking(out, oc) { released || !wantPlay || reopen }
    }
}

/** Queue of synthesized commentary (stereo 44.1 kHz). Filled by VoiceCommentary, drained by the live mixer. */
class VoiceBuffer {
    private val lock = Any()
    private val chunks = java.util.ArrayDeque<ShortArray>()
    private var offset = 0

    fun append(stereo: ShortArray) {
        synchronized(lock) { chunks.addLast(stereo) }
    }

    fun clear() {
        synchronized(lock) {
            chunks.clear()
            offset = 0
        }
    }

    /** Non-blocking. Returns the number of stereo FRAMES written into [dst]. */
    fun pullStereo(dst: ShortArray, frames: Int): Int = synchronized(lock) {
        var need = frames * 2
        var written = 0
        while (need > 0 && chunks.isNotEmpty()) {
            val head = chunks.peekFirst() ?: break
            val n = min(head.size - offset, need)
            System.arraycopy(head, offset, dst, written, n)
            written += n
            need -= n
            offset += n
            if (offset >= head.size) {
                chunks.pollFirst()
                offset = 0
            }
        }
        written / 2
    }
}

/**
 * Attached to RootEncoder's MicrophoneSource. [process] is called for every microphone buffer (16-bit little-endian PCM,
 * mono or stereo at 44.1 kHz). It mixes music and spoken commentary in, applies the volumes, ducks the music while the
 * commentary voice speaks, and feeds the monitor output.
 */
class MixerEffect(
    private val music: MusicEngine,
    private val monitor: MonitorOutput,
    private val voice: VoiceBuffer,
    private val onLevel: (Float) -> Unit
) : CustomAudioEffect() {

    @Volatile var channels = 1
    @Volatile var micMuted = false
    @Volatile var micGain = 1f
    @Volatile var musicGain = 0.35f
    @Volatile var voiceGain = 1f
    /** Level of the music in the operator's monitor (independent of whether the music goes on air). */
    @Volatile var musicMonGain = 0.35f
    @Volatile var duckMusic = true
    @Volatile var duckLevel = 0.35f
    @Volatile var monitorMusic = true
    @Volatile var monitorMic = false
    @Volatile var monitorGain = 0.8f
    @Volatile var lastProcessAt = 0L

    /** Noise reduction + studio voice for the commentary microphone. */
    val fx = VoiceProcessor(StreamOptions.AUDIO_SAMPLE_RATE)

    private var mic = ShortArray(0)
    private var mus = ShortArray(0)
    private var vox = ShortArray(0)
    private var mon = ShortArray(0)
    private var peakAcc = 0
    private var duckCur = 1f
    private var lastTalkAt = 0L
    private var lastLevelAt = 0L

    override fun process(pcmBuffer: ByteArray): ByteArray {
        try {
            val ch = if (channels >= 2) 2 else 1
            val total = pcmBuffer.size / 2
            val frames = total / ch
            if (frames <= 0) return pcmBuffer
            if (mic.size < total) mic = ShortArray(total)
            if (mus.size < frames * 2) mus = ShortArray(frames * 2)
            if (vox.size < frames * 2) vox = ShortArray(frames * 2)
            if (mon.size < frames * 2) mon = ShortArray(frames * 2)

            ByteBuffer.wrap(pcmBuffer).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(mic, 0, total)
            if (!micMuted) fx.process(mic, frames, ch)
            val got = music.pullStereo(mus, frames)
            val vgot = voice.pullStereo(vox, frames)

            val kg = if (micMuted) 0f else micGain
            // Music goes down while the microphone is being spoken into and while the spoken commentary plays.
            var blockPeak = 0
            if (!micMuted) {
                for (i in 0 until total) {
                    val a = abs(mic[i].toInt())
                    if (a > blockPeak) blockPeak = a
                }
            }
            val nowMs = SystemClock.elapsedRealtime()
            if (duckMusic && blockPeak * kg > 1800f) lastTalkAt = nowMs
            val talking = duckMusic && nowMs - lastTalkAt < 700
            val duckTarget = when {
                vgot > 0 -> duckLevel
                talking -> duckLevel
                else -> 1f
            }
            duckCur += (duckTarget - duckCur) * (if (duckTarget < duckCur) 0.45f else 0.07f)
            val mg = musicGain * duckCur
            val vg = voiceGain
            val mm = if (monitorMusic) monitorGain * musicMonGain * duckCur else 0f
            val vm = if (monitorMusic) monitorGain * vg else 0f
            val km = if (monitorMic && !micMuted) monitorGain * kg else 0f
            val doMonitor = mm > 0f || km > 0f || (vm > 0f && vgot > 0)
            var peak = 0

            for (f in 0 until frames) {
                val ml = if (f < got) mus[2 * f].toFloat() else 0f
                val mr = if (f < got) mus[2 * f + 1].toFloat() else 0f
                val vl = if (f < vgot) vox[2 * f].toFloat() else 0f
                val vr = if (f < vgot) vox[2 * f + 1].toFloat() else 0f
                if (ch == 1) {
                    val m = mic[f].toFloat()
                    val a = abs(m * kg).toInt()
                    if (a > peak) peak = a
                    val mono = (ml + mr) * 0.5f
                    val vmono = (vl + vr) * 0.5f
                    mic[f] = PcmMath.clamp16((m * kg + mono * mg + vmono * vg).toInt())
                    if (doMonitor) {
                        val v = PcmMath.clamp16((m * km + mono * mm + vmono * vm).toInt())
                        mon[2 * f] = v
                        mon[2 * f + 1] = v
                    }
                } else {
                    val l = mic[2 * f].toFloat()
                    val r = mic[2 * f + 1].toFloat()
                    val a = abs(max(l, r) * kg).toInt()
                    if (a > peak) peak = a
                    mic[2 * f] = PcmMath.clamp16((l * kg + ml * mg + vl * vg).toInt())
                    mic[2 * f + 1] = PcmMath.clamp16((r * kg + mr * mg + vr * vg).toInt())
                    if (doMonitor) {
                        mon[2 * f] = PcmMath.clamp16((l * km + ml * mm + vl * vm).toInt())
                        mon[2 * f + 1] = PcmMath.clamp16((r * km + mr * mm + vr * vm).toInt())
                    }
                }
            }

            ByteBuffer.wrap(pcmBuffer).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(mic, 0, total)
            if (doMonitor) monitor.writeNonBlocking(mon, frames * 2)

            val now = SystemClock.elapsedRealtime()
            lastProcessAt = now
            if (peak > peakAcc) peakAcc = peak
            if (now - lastLevelAt >= 100) {
                onLevel(min(1f, peakAcc / 32768f))
                peakAcc = 0
                lastLevelAt = now
            }
        } catch (e: Throwable) {
            // never break the microphone thread: on any problem the buffer is passed through as-is
        }
        return pcmBuffer
    }
}

/** Facade used by [StreamEngine]: owns music player, monitor output and the mixing effect. */
class AudioMixerCore(
    context: Context,
    onMusicState: (MusicUiState) -> Unit,
    onLevel: (Float) -> Unit,
    private val onHeadset: (Boolean) -> Unit
) {
    private val monitor = MonitorOutput(StreamOptions.AUDIO_SAMPLE_RATE)
    private val music = MusicEngine(monitor, onMusicState)
    val voice = VoiceBuffer()
    val effect = MixerEffect(music, monitor, voice, onLevel)

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    @Volatile private var settings = AudioMixSettings()

    /** Android's own noise suppressor / echo canceller; read by the engine when it prepares the audio encoder. */
    @Volatile var platformFx = true
        private set
    @Volatile var headsetConnected = false
        private set

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
            refreshHeadset()
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
            refreshHeadset()
        }
    }

    init {
        refreshHeadset()
        try {
            audioManager.registerAudioDeviceCallback(deviceCallback, Handler(Looper.getMainLooper()))
        } catch (_: Exception) {
        }
    }

    private fun refreshHeadset() {
        val has = try {
            audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { it.type in HEADSET_TYPES }
        } catch (e: Exception) {
            false
        }
        headsetConnected = has
        effect.monitorMic = settings.micMonitor && has
        onHeadset(has)
    }

    fun apply(s0: AudioMixSettings) {
        val s = s0.sanitized()
        settings = s
        effect.musicGain = if (s.musicOnAir) s.musicVolume else 0f
        effect.musicMonGain = s.musicVolume
        effect.duckMusic = s.duckMusic
        effect.duckLevel = s.duckLevel
        effect.micGain = s.micVolume
        effect.monitorMusic = s.musicMonitor
        effect.monitorMic = s.micMonitor && headsetConnected
        effect.monitorGain = s.monitorVolume
        effect.fx.configure(s.noiseReduction, s.studioVoice, s.rumbleFilter)
        platformFx = s.platformFx
        music.localGain = if (s.musicMonitor) s.monitorVolume * s.musicVolume else 0f
        music.setTracks(s.tracks.map { it.path })
    }

    @Volatile private var live = false

    /** True from the moment the stream audio is prepared until it stops. */
    fun liveNow(): Boolean = live

    fun setVoiceVolume(v: Float) {
        effect.voiceGain = v.coerceIn(0f, 1.5f)
    }

    fun setMicMuted(muted: Boolean) {
        effect.micMuted = muted
    }

    fun configureStream(stereo: Boolean) {
        effect.channels = if (stereo) 2 else 1
    }

    /** True while the mixing effect is really receiving microphone buffers. */
    fun effectHooked(): Boolean = SystemClock.elapsedRealtime() - effect.lastProcessAt < 1500

    fun setLive(live: Boolean) {
        this.live = live
        music.liveConsumer = live
        if (live) monitor.ensureStarted()
    }

    fun play() = music.play()
    fun pause() = music.pause()
    fun next() = music.next()

    fun release() {
        try {
            audioManager.unregisterAudioDeviceCallback(deviceCallback)
        } catch (_: Exception) {
        }
        music.release()
        monitor.release()
    }

    companion object {
        private val HEADSET_TYPES = setOf(
            AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
            AudioDeviceInfo.TYPE_USB_HEADSET,
            AudioDeviceInfo.TYPE_USB_DEVICE,
            AudioDeviceInfo.TYPE_HEARING_AID,
            AudioDeviceInfo.TYPE_BLE_HEADSET
        )
    }
}
