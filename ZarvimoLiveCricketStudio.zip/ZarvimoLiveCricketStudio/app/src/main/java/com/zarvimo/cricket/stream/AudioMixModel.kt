package com.zarvimo.cricket.stream

/** One imported music file (copied into app-private storage on import). */
data class MusicTrack(val path: String, val name: String)

/**
 * User choices for the audio side of the broadcast.
 *  - [musicVolume] / [micVolume] decide what the VIEWERS hear.
 *  - [musicMonitor] / [micMonitor] / [monitorVolume] decide what the OPERATOR hears locally (monitoring).
 */
data class AudioMixSettings(
    val tracks: List<MusicTrack> = emptyList(),
    /** 0..1 background music level in the stream. */
    val musicVolume: Float = 0.35f,
    /** 0..2 commentary microphone level in the stream (1 = unchanged). */
    val micVolume: Float = 1.0f,
    /** Play the music to the operator's own ears (speaker or headphones). */
    val musicMonitor: Boolean = true,
    /** Play the commentary microphone back into the operator's headphones (only used when a headset is connected). */
    val micMonitor: Boolean = false,
    /** 0..1 loudness of everything the operator hears locally. */
    val monitorVolume: Float = 0.8f,
    /** Commentary microphone noise reduction: 0 off, 1 light, 2 medium, 3 strong. */
    val noiseReduction: Int = 0,
    /** Studio voice (EQ + compressor + limiter): 0 off, 1 natural, 2 radio. */
    val studioVoice: Int = 0,
    /** Removes low rumble and wind thumps (high-pass filter). */
    val rumbleFilter: Boolean = true,
    /** Also use Android's own noise suppressor and echo canceller on the microphone (read when going live). */
    val platformFx: Boolean = true
) {
    fun sanitized(): AudioMixSettings = copy(
        musicVolume = musicVolume.coerceIn(0f, 1f),
        micVolume = micVolume.coerceIn(0f, 2f),
        monitorVolume = monitorVolume.coerceIn(0f, 1f),
        noiseReduction = noiseReduction.coerceIn(0, 3),
        studioVoice = studioVoice.coerceIn(0, 2)
    )
}

/** Playback state of the background music player (independent of the network stream). */
data class MusicUiState(
    val playing: Boolean = false,
    val index: Int = 0,
    val error: String? = null
)
