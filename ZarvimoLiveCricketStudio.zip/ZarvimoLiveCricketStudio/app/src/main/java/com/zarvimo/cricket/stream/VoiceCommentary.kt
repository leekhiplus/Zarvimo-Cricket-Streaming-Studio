package com.zarvimo.cricket.stream

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Spoken commentary with the phone's text-to-speech engine.
 *  - While live (the mixer is processing the microphone): the speech is synthesized to a WAV file, decoded and fed into
 *    the broadcast audio ([VoiceBuffer]) so viewers hear a clean voice and the operator hears it through the monitor.
 *  - Otherwise (practice / not live): it is simply spoken on the phone speaker.
 */
class VoiceCommentary(
    private val context: Context,
    private val voice: VoiceBuffer,
    private val onNotice: (String) -> Unit
) {
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    @Volatile private var wantUrdu = false
    @Volatile private var urduAvailable = false
    private var counter = 0
    private val pending = ConcurrentHashMap<String, File>()
    private var warnedUrdu = false
    /** A request that arrived while the speech engine was still starting; it is spoken as soon as the engine is ready. */
    @Volatile private var queued: Triple<String, String, Boolean>? = null

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}

        override fun onDone(utteranceId: String?) {
            val f = utteranceId?.let { pending.remove(it) } ?: return
            Thread({ decodeAndQueue(f) }, "voice-decode").also { it.isDaemon = true }.start()
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            utteranceId?.let { pending.remove(it)?.delete() }
        }

        override fun onError(utteranceId: String?, errorCode: Int) {
            utteranceId?.let { pending.remove(it)?.delete() }
        }
    }

    @Synchronized
    fun ensure(urdu: Boolean) {
        wantUrdu = urdu
        if (tts != null) {
            if (ready) applyLanguage()
            return
        }
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setOnUtteranceProgressListener(listener)
                ready = true
                applyLanguage()
                queued?.let {
                    queued = null
                    speak(it.first, it.second, it.third)
                }
            } else {
                onNotice("Text-to-speech is not available on this phone, so voice commentary is off")
            }
        }
    }

    private fun applyLanguage() {
        val t = tts ?: return
        if (wantUrdu) {
            val r = t.setLanguage(Locale("ur", "PK"))
            urduAvailable = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            if (!urduAvailable) {
                t.setLanguage(Locale.ENGLISH)
                if (!warnedUrdu) {
                    warnedUrdu = true
                    onNotice("No Urdu voice is installed on this phone, English commentary is used instead. You can install an Urdu voice in Android settings > Text-to-speech.")
                }
            }
        } else {
            t.setLanguage(Locale.ENGLISH)
        }
    }

    /** Speaks the Urdu line only when an Urdu voice exists; otherwise the English line. */
    fun speak(english: String, urdu: String, live: Boolean) {
        val t = tts ?: return
        if (!ready) {
            queued = Triple(english, urdu, live)
            return
        }
        val text = if (wantUrdu && urduAvailable) urdu else english
        val id = "cmt" + (counter++)
        try {
            if (live) {
                val f = File(context.cacheDir, "$id.wav")
                pending[id] = f
                val r = t.synthesizeToFile(text, Bundle(), f, id)
                if (r != TextToSpeech.SUCCESS) {
                    pending.remove(id)
                    t.speak(text, TextToSpeech.QUEUE_ADD, null, id)
                }
            } else {
                t.speak(text, TextToSpeech.QUEUE_ADD, null, id)
            }
        } catch (e: Exception) {
            pending.remove(id)
        }
    }

    fun release() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        }
        tts = null
        ready = false
        voice.clear()
    }

    // ------------------------------------------------------------------------------------------ WAV -> broadcast PCM

    private fun decodeAndQueue(file: File) {
        try {
            val bytes = file.readBytes()
            val stereo = WavDecoder.toStereo44k(bytes)
            if (stereo == null) {
                onNotice("The speech engine produced audio the app cannot mix into the stream, so this commentary line was not sent to viewers")
                return
            }
            voice.append(stereo)
        } catch (_: Exception) {
        } finally {
            file.delete()
        }
    }
}

/** Minimal WAV reader (PCM 16-bit, mono or stereo) that returns interleaved stereo shorts at 44.1 kHz. Pure Kotlin. */
object WavDecoder {

    private fun le16(b: ByteArray, o: Int): Int = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
    private fun le32(b: ByteArray, o: Int): Int = le16(b, o) or (le16(b, o + 2) shl 16)

    private fun sampleAt(b: ByteArray, o: Int, isFloat: Boolean): Short =
        if (isFloat) (Float.fromBits(le32(b, o)) * 32767f).toInt().coerceIn(-32768, 32767).toShort() else le16(b, o).toShort()

    fun toStereo44k(wav: ByteArray): ShortArray? {
        if (wav.size < 44) return null
        if (String(wav, 0, 4, Charsets.US_ASCII) != "RIFF" || String(wav, 8, 4, Charsets.US_ASCII) != "WAVE") return null
        var pos = 12
        var channels = 0
        var rate = 0
        var bits = 0
        var format = 0
        var dataStart = -1
        var dataLen = 0
        while (pos + 8 <= wav.size) {
            val id = String(wav, pos, 4, Charsets.US_ASCII)
            var len = le32(wav, pos + 4)
            val body = pos + 8
            if (len < 0 || body + len > wav.size) len = wav.size - body // streamed WAVs may carry a bogus length
            if (id == "fmt " && len >= 16) {
                format = le16(wav, body)
                if (format == 0xFFFE && len >= 26) format = le16(wav, body + 24) // WAVE_FORMAT_EXTENSIBLE: the real format is the sub-format
                channels = le16(wav, body + 2)
                rate = le32(wav, body + 4)
                bits = le16(wav, body + 14)
            } else if (id == "data") {
                dataStart = body
                dataLen = len
                break
            }
            pos = body + len + (len and 1)
        }
        val isFloat = format == 3 && bits == 32
        if (dataStart < 0 || !((format == 1 && bits == 16) || isFloat) || channels !in 1..2 || rate <= 0) return null
        val bytesPerSample = bits / 8
        val frames = dataLen / (bytesPerSample * channels)
        if (frames <= 0) return null
        val left = ShortArray(frames)
        val right = ShortArray(frames)
        for (i in 0 until frames) {
            val o = dataStart + i * bytesPerSample * channels
            val l = sampleAt(wav, o, isFloat)
            left[i] = l
            right[i] = if (channels == 2) sampleAt(wav, o + bytesPerSample, isFloat) else l
        }
        val target = StreamOptions.AUDIO_SAMPLE_RATE
        val outFrames = ((frames.toLong() * target) / rate).toInt().coerceAtLeast(1)
        val out = ShortArray(outFrames * 2)
        val step = rate.toDouble() / target
        for (i in 0 until outFrames) {
            val p = i * step
            val i0 = p.toInt().coerceAtMost(frames - 1)
            val i1 = (i0 + 1).coerceAtMost(frames - 1)
            val f = (p - i0).toFloat()
            out[2 * i] = (left[i0] + (left[i1] - left[i0]) * f).toInt().toShort()
            out[2 * i + 1] = (right[i0] + (right[i1] - right[i0]) * f).toInt().toShort()
        }
        return out
    }
}
