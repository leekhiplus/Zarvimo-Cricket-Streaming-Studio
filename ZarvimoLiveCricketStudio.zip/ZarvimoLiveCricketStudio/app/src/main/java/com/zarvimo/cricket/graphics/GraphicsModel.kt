package com.zarvimo.cricket.graphics

import com.zarvimo.cricket.scoring.InningsState
import com.zarvimo.cricket.scoring.MatchSession
import com.zarvimo.cricket.scoring.MatchSetup
import kotlin.math.min

/** All geometry is expressed in a fixed 1920x1080 reference canvas and scaled uniformly to the output size. */
object Ref {
    const val W = 1920f
    const val H = 1080f
    const val TICKER_H = 52f
    const val TICKER_GAP = 14f
}

enum class ScoreboardTemplate(val label: String, val baseWidth: Float, val baseHeight: Float) {
    CLASSIC("Classic Lower Third", 1560f, 214f),
    MODERN_BAR("Modern Bar", 1780f, 132f),
    COMPACT("Compact Corner", 660f, 300f)
}

enum class FontChoice(val label: String, val family: String) {
    SANS("Sans", "sans-serif"),
    CONDENSED("Condensed", "sans-serif-condensed"),
    SERIF("Serif", "serif"),
    MONO("Mono", "monospace")
}

data class SafeArea(
    val left: Float = 0.04f,
    val top: Float = 0.06f,
    val right: Float = 0.04f,
    val bottom: Float = 0.06f
)

/** Simple rectangle (kept free of android.graphics so layout can be unit-tested on the JVM). */
data class Box(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
    fun contains(o: Box, eps: Float = 0.01f) =
        o.left >= left - eps && o.top >= top - eps && o.right <= right + eps && o.bottom <= bottom + eps
}

data class Placement(val box: Box, val scale: Float)

data class GraphicsConfig(
    val name: String = "Default",
    val template: ScoreboardTemplate = ScoreboardTemplate.CLASSIC,
    /** 0 = left/top of the available area, 1 = right/bottom. */
    val posX: Float = 0.5f,
    val posY: Float = 1f,
    val scale: Float = 1f,
    /** Extra margin inside the safe area, in reference pixels. */
    val marginPx: Float = 8f,
    val safeArea: SafeArea = SafeArea(),
    val primaryColor: Int = 0xFF0B1E4B.toInt(),
    val accentColor: Int = 0xFFFFC107.toInt(),
    val textColor: Int = 0xFFFFFFFF.toInt(),
    val borderColor: Int = 0xFFFFC107.toInt(),
    val borderWidthPx: Float = 3f,
    val panelOpacity: Float = 0.88f,
    val font: FontChoice = FontChoice.SANS,
    val showMatchTitle: Boolean = true,
    val showTicker: Boolean = true,
    val tickerText: String = "",
    val showSponsor: Boolean = true,
    val showTeamLogos: Boolean = true,
    // channel logo / sponsor (normalised 0..1 inside the safe area; scale 1 = 96 ref px tall)
    val logoX: Float = 1f,
    val logoY: Float = 0f,
    val logoScale: Float = 1f,
    val sponsorX: Float = 0f,
    val sponsorY: Float = 0f,
    val sponsorScale: Float = 0.8f,
    // media (content:// or file URIs imported by the user; resolved by the data layer)
    val backgroundUri: String? = null,
    val logoUri: String? = null,
    val sponsorUri: String? = null
) {
    fun sanitized(): GraphicsConfig = copy(
        posX = posX.coerceIn(0f, 1f),
        posY = posY.coerceIn(0f, 1f),
        scale = scale.coerceIn(0.5f, 1.6f),
        marginPx = marginPx.coerceIn(0f, 80f),
        borderWidthPx = borderWidthPx.coerceIn(0f, 10f),
        panelOpacity = panelOpacity.coerceIn(0.2f, 1f),
        logoX = logoX.coerceIn(0f, 1f), logoY = logoY.coerceIn(0f, 1f), logoScale = logoScale.coerceIn(0.3f, 3f),
        sponsorX = sponsorX.coerceIn(0f, 1f), sponsorY = sponsorY.coerceIn(0f, 1f), sponsorScale = sponsorScale.coerceIn(0.3f, 3f),
        safeArea = SafeArea(
            safeArea.left.coerceIn(0f, 0.2f), safeArea.top.coerceIn(0f, 0.2f),
            safeArea.right.coerceIn(0f, 0.2f), safeArea.bottom.coerceIn(0f, 0.2f)
        )
    )
}

object BroadcastLayout {

    fun safeBox(cfg: GraphicsConfig): Box {
        val s = cfg.sanitized().safeArea
        return Box(Ref.W * s.left, Ref.H * s.top, Ref.W * (1 - s.right), Ref.H * (1 - s.bottom))
    }

    /** Small outputs need relatively larger graphics to stay readable on a phone. */
    fun legibilityBoost(outputHeight: Int): Float = when {
        outputHeight >= 700 -> 1.0f
        outputHeight >= 450 -> 1.12f
        else -> 1.25f
    }

    fun tickerBox(cfg: GraphicsConfig): Box? {
        if (!cfg.showTicker) return null
        val safe = safeBox(cfg)
        return Box(safe.left, safe.bottom - Ref.TICKER_H, safe.right, safe.bottom)
    }

    /** Where the scoreboard goes (always inside the safe area, never overlapping the ticker). */
    fun scoreboard(cfgIn: GraphicsConfig, outputHeight: Int): Placement {
        val cfg = cfgIn.sanitized()
        val safe = safeBox(cfg)
        val bottomLimit = if (cfg.showTicker) safe.bottom - Ref.TICKER_H - Ref.TICKER_GAP else safe.bottom
        val area = Box(
            safe.left + cfg.marginPx, safe.top + cfg.marginPx,
            safe.right - cfg.marginPx, bottomLimit - cfg.marginPx
        )
        val desired = cfg.scale * legibilityBoost(outputHeight)
        val fit = min(1f, min(area.width / (cfg.template.baseWidth * desired), area.height / (cfg.template.baseHeight * desired)))
        val s = desired * fit
        val w = cfg.template.baseWidth * s
        val h = cfg.template.baseHeight * s
        val left = area.left + cfg.posX * (area.width - w).coerceAtLeast(0f)
        val top = area.top + cfg.posY * (area.height - h).coerceAtLeast(0f)
        return Placement(Box(left, top, left + w, top + h), s)
    }

    /** Box for an image (logo / sponsor) of the given aspect ratio, positioned inside the safe area. */
    fun imageBox(cfgIn: GraphicsConfig, nx: Float, ny: Float, scale: Float, aspect: Float): Box {
        val cfg = cfgIn.sanitized()
        val safe = safeBox(cfg)
        val h = 96f * scale
        val w = h * aspect.coerceIn(0.2f, 6f)
        val fitted = min(1f, min(safe.width / w, safe.height / h))
        val fw = w * fitted
        val fh = h * fitted
        val left = safe.left + nx.coerceIn(0f, 1f) * (safe.width - fw).coerceAtLeast(0f)
        val top = safe.top + ny.coerceIn(0f, 1f) * (safe.height - fh).coerceAtLeast(0f)
        return Box(left, top, left + fw, top + fh)
    }
}

// -------------------------------------------------------------------------------------------------
// Overlay data: everything the renderer draws, derived from the real scoring state.
// -------------------------------------------------------------------------------------------------

data class BatterLine(val name: String, val runs: Int, val balls: Int, val onStrike: Boolean)

data class OverlayData(
    val title: String = "",
    val venue: String = "",
    val battingTeam: String = "",
    val battingShort: String = "",
    val bowlingTeam: String = "",
    val bowlingShort: String = "",
    val battingColor: Int = 0xFF1B5E20.toInt(),
    val bowlingColor: Int = 0xFF0D47A1.toInt(),
    val inningsNumber: Int = 1,
    /** True when Team A (as named in match setup) is the batting side. Used to pick the right team logo. */
    val battingIsTeamA: Boolean = true,
    val score: String = "0/0",
    val overs: String = "0.0",
    val oversLimit: Int = 20,
    val striker: BatterLine? = null,
    val nonStriker: BatterLine? = null,
    val bowlerName: String? = null,
    val bowlerFigures: String? = null,
    val recentBalls: List<String> = emptyList(),
    val currentRunRate: String = "0.00",
    val targetText: String? = null,
    val chaseText: String? = null,
    val requiredRunRate: String? = null,
    val lastWicket: String? = null,
    val banner: String? = null,
    val resultText: String? = null
)

/** Per-match visual choices that are not part of scoring (team colours etc.). */
data class MatchVisuals(
    val teamAColor: Int = 0xFF1B5E20.toInt(),
    val teamBColor: Int = 0xFF0D47A1.toInt(),
    val teamAShort: String = "",
    val teamBShort: String = ""
)

object OverlayBuilder {

    fun shortName(name: String): String {
        val words = name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return ""
        return if (words.size >= 2) words.take(3).joinToString("") { it.first().uppercaseChar().toString() }
        else words[0].take(3).uppercase()
    }

    fun from(setup: MatchSetup, session: MatchSession?, visuals: MatchVisuals, title: String = setup.title): OverlayData {
        val aShort = visuals.teamAShort.ifBlank { shortName(setup.teamA) }
        val bShort = visuals.teamBShort.ifBlank { shortName(setup.teamB) }
        val base = OverlayData(
            title = title, venue = setup.venue, oversLimit = setup.oversLimit,
            battingTeam = setup.teamA, battingShort = aShort, bowlingTeam = setup.teamB, bowlingShort = bShort,
            battingColor = visuals.teamAColor, bowlingColor = visuals.teamBColor,
            banner = "MATCH STARTING SOON"
        )
        if (session == null || session.innings.isEmpty()) return base
        val idx = session.currentIndex
        val st = session.currentState ?: return base.copy(banner = "SCORER ERROR - CHECK EVENTS")
        val battingIsA = st.battingTeam.trim().equals(setup.teamA.trim(), ignoreCase = true)
        val batName = st.battingTeam
        val bowlName = st.bowlingTeam
        val batColor = if (battingIsA) visuals.teamAColor else visuals.teamBColor
        val bowlColor = if (battingIsA) visuals.teamBColor else visuals.teamAColor
        val batShort = if (battingIsA) aShort else bShort
        val bowlShort = if (battingIsA) bShort else aShort

        val chase = if (idx >= 1) chaseInfo(st) else null
        val result = if (idx >= 1 && st.ended) resultText(st, batName, bowlName) else null
        val banner = when {
            result != null -> null
            idx == 0 && st.ended -> "INNINGS BREAK"
            st.freeHit -> "FREE HIT"
            st.batterRequired -> "NEW BATTER"
            st.bowlerRequired -> "END OF OVER"
            else -> null
        }
        val lw = st.lastDismissed?.let { "${it.name} ${it.runs} (${it.balls})" + (it.dismissal?.let { d -> "  $d" } ?: "") }

        return OverlayData(
            title = title, venue = setup.venue,
            battingTeam = batName, battingShort = batShort, bowlingTeam = bowlName, bowlingShort = bowlShort,
            battingColor = batColor, bowlingColor = bowlColor,
            inningsNumber = idx + 1,
            battingIsTeamA = battingIsA,
            score = st.scoreText, overs = st.oversText, oversLimit = st.oversLimit,
            striker = st.striker?.let { BatterLine(it.name, it.runs, it.balls, true) },
            nonStriker = st.nonStriker?.let { BatterLine(it.name, it.runs, it.balls, false) },
            bowlerName = st.bowler?.name, bowlerFigures = st.bowler?.figuresText,
            recentBalls = st.recentBalls.map { it.label },
            currentRunRate = String.format(java.util.Locale.ROOT, "%.2f", st.runRate),
            targetText = st.target?.let { "TARGET $it" },
            chaseText = chase,
            requiredRunRate = st.requiredRunRate?.let { String.format(java.util.Locale.ROOT, "%.2f", it) },
            lastWicket = lw, banner = banner, resultText = result
        )
    }

    private fun chaseInfo(st: InningsState): String? {
        val req = st.requiredRuns ?: return null
        if (st.ended) return null
        return "NEED $req RUN${if (req == 1) "" else "S"} FROM ${st.ballsRemaining} BALL${if (st.ballsRemaining == 1) "" else "S"}"
    }

    fun resultText(st: InningsState, batting: String, bowling: String): String? {
        val target = st.target ?: return null
        return when {
            st.runs >= target -> {
                val w = st.wicketsRemaining
                "$batting WON BY $w WICKET${if (w == 1) "" else "S"}"
            }
            st.runs == target - 1 -> "MATCH TIED"
            else -> {
                val margin = target - 1 - st.runs
                "$bowling WON BY $margin RUN${if (margin == 1) "" else "S"}"
            }
        }
    }
}
