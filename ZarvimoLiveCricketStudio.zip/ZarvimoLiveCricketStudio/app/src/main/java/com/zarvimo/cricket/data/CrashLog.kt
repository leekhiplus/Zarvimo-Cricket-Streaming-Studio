package com.zarvimo.cricket.data

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Keeps the reason of a crash so it can be shown the next time the app opens (there is no other way to see it on a phone).
 *  - [install] records uncaught Java/Kotlin exceptions before the app closes.
 *  - [write] records problems the app survived (handled errors), so they are visible too.
 *  - [systemReport] adds what Android itself knows about how the last run ended (native crash, freeze, out of memory...).
 */
object CrashLog {
    private const val MAX_BYTES = 24_000
    private var file: File? = null

    fun install(context: Context) {
        val f = File(context.filesDir, "crash_log.txt")
        file = f
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { write("APP CLOSED by an error on thread \"${t.name}\"", e) } catch (_: Throwable) { }
            previous?.uncaughtException(t, e)
        }
    }

    fun write(what: String, e: Throwable) {
        val f = file ?: return
        try {
            val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT).format(Date())
            val entry = "[$stamp] $what\n${Log.getStackTraceString(e).take(5000)}\n\n"
            val old = if (f.exists()) f.readText() else ""
            f.writeText((old + entry).takeLast(MAX_BYTES))
        } catch (_: Throwable) {
        }
    }

    fun read(): String? = try { file?.takeIf { it.exists() }?.readText()?.ifBlank { null } } catch (_: Throwable) { null }

    fun clear() { try { file?.delete() } catch (_: Throwable) { } }

    /** How the previous run ended, from Android's own record (API 30+). Null when it ended normally or nothing is known. */
    fun systemReport(context: Context): String? {
        if (Build.VERSION.SDK_INT < 30) return null
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val list = am.getHistoricalProcessExitReasons(context.packageName, 0, 3)
            val prefs = context.getSharedPreferences("crashlog", Context.MODE_PRIVATE)
            val seen = prefs.getLong("seen", 0L)
            val bad = list.firstOrNull {
                it.timestamp > seen && it.reason in setOf(
                    ApplicationExitInfo.REASON_CRASH, ApplicationExitInfo.REASON_CRASH_NATIVE, ApplicationExitInfo.REASON_ANR,
                    ApplicationExitInfo.REASON_LOW_MEMORY, ApplicationExitInfo.REASON_SIGNALED, ApplicationExitInfo.REASON_INITIALIZATION_FAILURE,
                    ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE
                )
            } ?: return null
            prefs.edit().putLong("seen", bad.timestamp).apply()
            val name = when (bad.reason) {
                ApplicationExitInfo.REASON_CRASH -> "Java crash"
                ApplicationExitInfo.REASON_CRASH_NATIVE -> "NATIVE crash (inside video, audio or graphics code)"
                ApplicationExitInfo.REASON_ANR -> "App stopped responding (freeze)"
                ApplicationExitInfo.REASON_LOW_MEMORY -> "Android closed the app: out of memory"
                ApplicationExitInfo.REASON_SIGNALED -> "Killed by a signal"
                ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "Failed to start"
                else -> "Excessive resource use"
            }
            "Android reports: $name\nDetails: ${bad.description ?: "-"}\nDevice: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}"
        } catch (_: Throwable) {
            null
        }
    }
}
