package com.zarvimo.cricket.stream

import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max

/**
 * Turns any audio file the phone can play (mp3, wav, m4a, ogg...) into 44.1 kHz 16-bit stereo, with the loudness
 * evened out, so real recordings can be used as sound-effect pads.
 */
object SfxDecoder {
    private const val RATE = CrowdSynth.RATE

    /** Reads at most [maxSeconds] of the file. Returns null when it is not audio or cannot be decoded. */
    fun decode(path: String, maxSeconds: Int = 40): ShortArray? = try {
        decodeFile(path, maxSeconds)
    } catch (e: Throwable) {
        null
    }

    private fun decodeFile(path: String, maxSeconds: Int): ShortArray? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(path)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null) return null
            ex.selectTrack(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: return null
            var srcRate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else RATE
            var ch = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var pcmFloat = false
            val c = MediaCodec.createDecoderByType(mime)
            codec = c
            c.configure(fmt, null, null, 0)
            c.start()

            val chunks = ArrayList<ShortArray>()
            var frames = 0
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var idle = 0
            while (!outputDone && frames < maxSeconds * srcRate) {
                if (!inputDone) {
                    val ii = c.dequeueInputBuffer(5_000)
                    if (ii >= 0) {
                        val buf = c.getInputBuffer(ii)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            c.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = c.dequeueOutputBuffer(info, 5_000)
                if (oi >= 0) {
                    idle = 0
                    val ob = c.getOutputBuffer(oi)
                    if (ob != null && info.size > 0) {
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        ob.order(ByteOrder.LITTLE_ENDIAN)
                        val chunk = toStereo(ob, ch, pcmFloat)
                        chunks += chunk
                        frames += chunk.size / 2
                    }
                    c.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = c.outputFormat
                    if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) srcRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    pcmFloat = f.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        f.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                } else if (++idle > 400) {
                    break // the decoder stopped producing: give up instead of hanging
                }
            }
            if (frames == 0) return null
            val all = ShortArray(frames * 2)
            var pos = 0
            for (k in chunks) { System.arraycopy(k, 0, all, pos, k.size); pos += k.size }
            return normalize(resampleStereo(all, srcRate, RATE), 0.85f)
        } catch (e: Exception) {
            return null
        } finally {
            try { codec?.stop() } catch (_: Exception) { }
            try { codec?.release() } catch (_: Exception) { }
            try { ex.release() } catch (_: Exception) { }
        }
    }

    private fun toStereo(b: java.nio.ByteBuffer, ch: Int, isFloat: Boolean): ShortArray {
        val channels = max(1, ch)
        return if (isFloat) {
            val fb = b.asFloatBuffer()
            val frames = fb.remaining() / channels
            val out = ShortArray(frames * 2)
            for (i in 0 until frames) {
                val l = (fb.get() * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                var r = l
                for (k in 1 until channels) { val v = (fb.get() * 32767f).toInt().coerceIn(-32768, 32767).toShort(); if (k == 1) r = v }
                out[2 * i] = l; out[2 * i + 1] = if (channels == 1) l else r
            }
            out
        } else {
            val sb = b.asShortBuffer()
            val frames = sb.remaining() / channels
            val out = ShortArray(frames * 2)
            for (i in 0 until frames) {
                val l = sb.get()
                var r = l
                for (k in 1 until channels) { val v = sb.get(); if (k == 1) r = v }
                out[2 * i] = l; out[2 * i + 1] = if (channels == 1) l else r
            }
            out
        }
    }

    /** Linear-interpolation resampling of interleaved stereo. */
    fun resampleStereo(src: ShortArray, srcRate: Int, dstRate: Int): ShortArray {
        if (srcRate == dstRate || src.size < 4) return src
        val inFrames = src.size / 2
        val outFrames = (inFrames.toLong() * dstRate / srcRate).toInt()
        val out = ShortArray(outFrames * 2)
        val step = srcRate.toDouble() / dstRate
        for (i in 0 until outFrames) {
            val p = i * step
            val i0 = p.toInt().coerceAtMost(inFrames - 1)
            val i1 = (i0 + 1).coerceAtMost(inFrames - 1)
            val f = (p - i0).toFloat()
            for (c in 0..1) {
                val a = src[2 * i0 + c].toFloat()
                val b = src[2 * i1 + c].toFloat()
                out[2 * i + c] = (a + (b - a) * f).toInt().coerceIn(-32768, 32767).toShort()
            }
        }
        return out
    }

    /** Scales so the loudest sample reaches [level] (0..1) of full scale; silence stays silent. */
    fun normalize(src: ShortArray, level: Float): ShortArray {
        var peak = 0
        for (v in src) peak = max(peak, abs(v.toInt()))
        if (peak < 64) return src
        val k = level * 32767f / peak
        val out = ShortArray(src.size)
        for (i in src.indices) out[i] = (src[i] * k).toInt().coerceIn(-32768, 32767).toShort()
        return out
    }
}
