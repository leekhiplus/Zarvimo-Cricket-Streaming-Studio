package com.zarvimo.cricket.stream

import android.Manifest
import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.view.SurfaceView
import androidx.core.content.ContextCompat
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.sources.audio.MicrophoneSource
import com.pedro.library.base.recording.RecordController
import com.pedro.library.generic.GenericStream
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.min

/** Local preview status. Deliberately separate from the network status ([StreamStatus]). */
data class PreviewStatus(
    val running: Boolean = false,
    val width: Int = 0,
    val height: Int = 0,
    /** Frames per second actually produced by the compositor in the last second; null when not running. */
    val compositorFps: Int? = null,
    val error: String? = null
)

data class AudioUiState(
    val userMuted: Boolean = false,
    /** Muted automatically because another app / a call took audio focus. */
    val autoMuted: Boolean = false,
    val micPermissionLost: Boolean = false,
    /** False while live when the mixer (music, spoken commentary, effects) is not receiving the microphone buffers. */
    val chainHooked: Boolean = true
) {
    val effectivelyMuted: Boolean get() = userMuted || autoMuted
}

sealed class StartResult {
    object Started : StartResult()
    data class Rejected(val reasons: List<String>) : StartResult()
}

/**
 * Owns the one-and-only streaming pipeline in the process:
 *   BroadcastVideoSource (compositor) -> RootEncoder GL -> MediaCodec H.264 + AAC -> RTMP/RTMPS.
 *
 * Every [StreamState] change is caused by a real RootEncoder callback or an explicit user action, never by timers.
 * The stream key is never logged: this class contains no logging of endpoints, and library error text is scrubbed.
 */
class StreamEngine(private val app: Application) : ConnectChecker {

    val broadcast = BroadcastState()

    private val lock = Any()
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "stream-engine-worker") }

    /** Runs [block] on the engine thread. An error inside it is recorded and survived instead of closing the whole app. */
    private fun exec(block: () -> Unit) {
        worker.execute {
            try {
                block()
            } catch (t: Throwable) {
                com.zarvimo.cricket.data.CrashLog.write("engine worker (handled)", t)
            }
        }
    }
    private val policy = ReconnectPolicy()

    private val _status = MutableStateFlow(StreamStatus(maxReconnectAttempts = policy.maxAttempts))
    val status: StateFlow<StreamStatus> = _status.asStateFlow()

    private val _preview = MutableStateFlow(PreviewStatus())
    val preview: StateFlow<PreviewStatus> = _preview.asStateFlow()

    private val _audio = MutableStateFlow(AudioUiState())
    val audio: StateFlow<AudioUiState> = _audio.asStateFlow()

    private val _musicState = MutableStateFlow(MusicUiState())
    /** Background music player state (independent of the network stream). */
    val musicState: StateFlow<MusicUiState> = _musicState.asStateFlow()

    private val _micLevel = MutableStateFlow(0f)
    /** 0..1 peak level of the commentary microphone while live. */
    val micLevel: StateFlow<Float> = _micLevel.asStateFlow()

    private val _headset = MutableStateFlow(false)
    /** True when headphones / a headset are connected (required for hearing the microphone back safely). */
    val headset: StateFlow<Boolean> = _headset.asStateFlow()

    private val _videoMode = MutableStateFlow(VideoSourceMode.BACKGROUND)
    /** The video source really in use (falls back to BACKGROUND when the camera cannot be used). */
    val videoMode: StateFlow<VideoSourceMode> = _videoMode.asStateFlow()

    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice.asStateFlow()
    fun consumeNotice() { _notice.value = null }

    private val _recording = MutableStateFlow(false)
    /** True while a local copy of the broadcast is being recorded. */
    val recording: StateFlow<Boolean> = _recording.asStateFlow()

    private val _liveBitrateKbps = MutableStateFlow(0)
    /** Video bitrate the encoder is currently asked for (changes with adaptive bitrate); 0 = not live. */
    val liveBitrateKbps: StateFlow<Int> = _liveBitrateKbps.asStateFlow()

    private val _bubbleEnabled = MutableStateFlow(false)
    /** Whether the round camera picture over the background is really on (turns itself off if the camera fails). */
    val bubbleEnabled: StateFlow<Boolean> = _bubbleEnabled.asStateFlow()

    @Volatile private var desiredMode = VideoSourceMode.BACKGROUND
    @Volatile private var desiredRotation = 0
    @Volatile private var desiredBubble = BubbleConfig.OFF

    // adaptive bitrate + recording bookkeeping (worker thread / lock)
    private var recordFile: File? = null
    private var congestedTicks = 0
    private var calmTicks = 0
    private var lastAdaptAt = 0L
    private var lastDropped = 0L

    private val mixer = AudioMixerCore(
        app,
        onMusicState = { st ->
            _musicState.value = st
            exec { synchronized(lock) { applyMute() } }
        },
        onLevel = { lvl -> _micLevel.value = lvl },
        onHeadset = { has -> _headset.value = has }
    )

    private val voiceCommentary = VoiceCommentary(app, mixer.voice) { msg -> _notice.value = msg }

    private var stream: GenericStream? = null
    @Volatile private var source: BroadcastVideoSource? = null
    private var mic: MicrophoneSource? = null
    @Volatile private var previewView: SurfaceView? = null
    private var preparedProfile: ResolutionProfile? = null
    private var preparedFps = 0
    private var preparedBitrateKbps = 0

    /** Held only in memory while a session is active; used to scrub library error text. */
    @Volatile private var activeKey: String = ""
    @Volatile private var settings: StreamSettings = StreamSettings()

    private val audioManager = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var focusRequest: AudioFocusRequest? = null

    // ------------------------------------------------------------------------------------ preview

    /**
     * Starts / restarts local preview using the same compositor + GL pipeline the encoder uses.
     * Navigating between screens creates the NEW surface before the OLD one is destroyed, so every call is tied to its
     * own SurfaceView: a late "destroyed" from an old view must never stop the preview of the new one (that was the
     * cause of the preview freezing on a single frame).
     */
    fun attachPreview(view: SurfaceView, profile: ResolutionProfile, fps: Int) {
        previewView = view
        startWatchdog()
        exec { synchronized(lock) { if (previewView === view) startPreviewLocked(profile, fps) } }
    }

    fun onPreviewSurfaceSize(width: Int, height: Int) {
        exec {
            synchronized(lock) {
                try {
                    stream?.getGlInterface()?.setPreviewResolution(width, height)
                } catch (_: Exception) {
                }
            }
        }
    }

    fun detachPreview(view: SurfaceView) {
        if (previewView !== view) return // a newer surface has already taken over: leave it running
        previewView = null
        exec { synchronized(lock) { if (previewView == null) stopPreviewLocked() } }
    }

    /** Apply new output settings while NOT streaming (resolution/fps changes need the encoder to be re-prepared). */
    fun reconfigurePreview(profile: ResolutionProfile, fps: Int) {
        if (isActive()) return
        exec {
            synchronized(lock) {
                if (_status.value.state != StreamState.IDLE && _status.value.state != StreamState.ERROR) return@exec
                // Any unrelated setting change (key, bitrate, camera...) used to restart the preview: skip when nothing changed.
                if (_preview.value.running && preparedProfile == profile && preparedFps == fps) return@exec
                val v = previewView
                stopPreviewLocked()
                if (v != null) startPreviewLocked(profile, fps)
            }
        }
    }

    // ------------------------------------------------------------------------------------ preview watchdog

    private val watchdogHandler = Handler(Looper.getMainLooper())
    private var watchdogOn = false
    private var stalledChecks = 0

    private val watchdogTick = object : Runnable {
        override fun run() {
            checkPreviewHealth()
            watchdogHandler.postDelayed(this, 2000)
        }
    }

    private fun startWatchdog() {
        if (watchdogOn) return
        watchdogOn = true
        watchdogHandler.postDelayed(watchdogTick, 2000)
    }

    /** Detects a frozen frame pump (no new frame for 4 s), kicks it, and rebuilds the preview if it stays frozen. */
    private fun checkPreviewHealth() {
        val src = source
        if (src == null || previewView == null || !_preview.value.running) {
            stalledChecks = 0
            return
        }
        if (src.msSinceLastFrame() < 4000) {
            stalledChecks = 0
            return
        }
        stalledChecks++
        src.ensurePumping()
        if (stalledChecks >= 2 && !isActive()) {
            stalledChecks = 0
            val p = preparedProfile ?: return
            val f = preparedFps
            exec {
                synchronized(lock) {
                    if (isActive() || previewView == null) return@exec
                    stopPreviewLocked()
                    startPreviewLocked(p, f)
                }
            }
        }
    }

    private fun ensureStreamLocked(): GenericStream {
        stream?.let { return it }
        val src = BroadcastVideoSource(
            app,
            broadcast,
            onCompositorFps = { f -> _preview.value = _preview.value.copy(compositorFps = if (_preview.value.running || isActive()) f else null) },
            onFatalError = { msg -> _preview.value = _preview.value.copy(running = false, error = msg) },
            onModeFallback = { mode, msg ->
                desiredMode = mode
                desiredBubble = BubbleConfig.OFF
                _videoMode.value = mode
                _bubbleEnabled.value = false
                _notice.value = msg
            }
        )
        src.setBubble(desiredBubble)
        src.setMode(desiredMode)
        src.setRotationOffset(desiredRotation)
        source = src
        val micSource = MicrophoneSource()
        try {
            micSource.setAudioEffect(mixer.effect)
        } catch (_: Exception) {
        }
        mic = micSource
        val s = GenericStream(app, this, src, micSource)
        stream = s
        return s
    }

    private fun startPreviewLocked(profile: ResolutionProfile, fps: Int) {
        val view = previewView ?: return
        if (!view.holder.surface.isValid) return // surfaceCreated will call attachPreview again
        try {
            val s = ensureStreamLocked()
            if (s.isOnPreview) s.stopPreview()
            if (!s.isStreaming) {
                val ok = s.prepareVideo(profile.width, profile.height, profile.defaultKbps * 1000, fps, StreamOptions.KEYFRAME_INTERVAL_SEC, 0)
                if (!ok) {
                    _preview.value = PreviewStatus(running = false, error = "This device's encoder rejected ${profile.label} @ ${fps}fps. Try a lower profile.")
                    return
                }
                preparedProfile = profile
                preparedFps = fps
                preparedBitrateKbps = profile.defaultKbps
            }
            s.startPreview(view)
            _preview.value = PreviewStatus(running = true, width = profile.width, height = profile.height)
        } catch (e: Exception) {
            _preview.value = PreviewStatus(running = false, error = "Preview failed: ${e.javaClass.simpleName}")
        }
    }

    private fun stopPreviewLocked() {
        try {
            val s = stream ?: return
            if (s.isOnPreview) s.stopPreview()
        } catch (_: Exception) {
        }
        _preview.value = PreviewStatus(running = false)
    }

    // ------------------------------------------------------------------------------------ streaming

    fun isActive(): Boolean = when (_status.value.state) {
        StreamState.IDLE, StreamState.ERROR -> false
        else -> true
    }

    fun hasMicPermission(): Boolean =
        ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /** Validates input, then starts the real pipeline. Never changes state when validation fails. */
    fun startStream(s: StreamSettings): StartResult {
        val validation = StreamValidator.validate(s.serverUrl, s.streamKey)
        if (validation is ValidationResult.Invalid) return StartResult.Rejected(validation.problems + StreamValidator.HELP)
        validation as ValidationResult.Valid
        if (!hasMicPermission()) return StartResult.Rejected(listOf("Microphone permission is required to transmit commentary audio"))

        val accepted = dispatch(StreamEvent.StartRequested) {
            StreamStatus(state = it.state, maxReconnectAttempts = policy.maxAttempts)
        }
        if (!accepted) return StartResult.Rejected(listOf("A stream session is already active"))

        settings = s
        activeKey = s.streamKey.trim()
        exec { synchronized(lock) { startPipelineLocked(s, validation.endpoint) } }
        return StartResult.Started
    }

    private fun startPipelineLocked(s: StreamSettings, endpoint: String) {
        try {
            val gs = ensureStreamLocked()
            val view = previewView
            if (gs.isOnPreview) gs.stopPreview() // re-preparing the encoder requires preview/stream to be stopped
            val profile = s.profile
            val vOk = gs.prepareVideo(profile.width, profile.height, profile.clampBitrate(s.videoBitrateKbps) * 1000, s.fps, StreamOptions.KEYFRAME_INTERVAL_SEC, 0)
            mixer.configureStream(s.stereo)
            val platformFx = mixer.platformFx
            val aOk = gs.prepareAudio(StreamOptions.AUDIO_SAMPLE_RATE, s.stereo, s.audioBitrateKbps * 1000, platformFx, platformFx)
            if (!vOk || !aOk) {
                val msg = if (!vOk) "Video encoder could not be prepared for ${profile.label} @ ${s.fps}fps on this device" else "Audio encoder / microphone could not be prepared"
                dispatch(StreamEvent.PrepareFailed(msg)) { it.copy(errorMessage = msg) }
                if (view != null) startPreviewLocked(profile, s.fps)
                return
            }
            preparedProfile = profile
            preparedFps = s.fps
            preparedBitrateKbps = profile.clampBitrate(s.videoBitrateKbps)
            if (view != null) {
                gs.startPreview(view)
                _preview.value = PreviewStatus(running = true, width = profile.width, height = profile.height)
            }
            try {
                gs.getStreamClient().setReTries(policy.maxAttempts)
            } catch (_: Exception) {
            }
            try {
                mic?.setAudioEffect(mixer.effect)
            } catch (_: Exception) {
            }
            liveStartedAt = SystemClock.elapsedRealtime()
            mixer.setLive(true)
            requestAudioFocus()
            applyMute()
            dispatch(StreamEvent.PrepareSucceeded)
            congestedTicks = 0
            calmTicks = 0
            lastAdaptAt = SystemClock.elapsedRealtime()
            lastDropped = 0L
            try {
                gs.getStreamClient().resetDroppedVideoFrames()
            } catch (_: Exception) {
            }
            _liveBitrateKbps.value = preparedBitrateKbps
            gs.startStream(endpoint) // real connection; result arrives via ConnectChecker callbacks
            if (s.recordLocally) startRecordingLocked(gs)
        } catch (e: Exception) {
            val msg = "Could not start: " + StreamValidator.scrub(e.message ?: e.javaClass.simpleName, activeKey)
            val st = _status.value.state
            if (st == StreamState.PREPARING) dispatch(StreamEvent.PrepareFailed(msg)) { it.copy(errorMessage = msg) }
            else if (st == StreamState.CONNECTING) dispatch(StreamEvent.ConnectionFailed(msg)) { it.copy(errorMessage = msg) }
            teardownTransportLocked()
        }
    }

    /** User pressed Stop Live (or the notification action). Really stops transmission and releases the mic. */
    fun stopStream() {
        val accepted = dispatch(StreamEvent.StopRequested) { it }
        if (!accepted) return
        exec {
            synchronized(lock) {
                teardownTransportLocked()
                abandonAudioFocus()
                activeKey = ""
                dispatch(StreamEvent.StopCompleted) {
                    StreamStatus(state = it.state, maxReconnectAttempts = policy.maxAttempts)
                }
            }
        }
    }

    /** Stop sending, close the connection, stop mic capture. Preview keeps running (it uses no network / mic). */
    private fun teardownTransportLocked() {
        stopRecordingLocked()
        _liveBitrateKbps.value = 0
        try {
            val s = stream
            if (s != null && s.isStreaming) s.stopStream()
        } catch (_: Exception) {
        }
        mixer.setLive(false)
        _micLevel.value = 0f
        abandonAudioFocus()
    }

    /** Bitrate change while live (no reconnect needed). */
    fun setVideoBitrateOnFly(kbps: Int) {
        val p = preparedProfile ?: return
        val v = p.clampBitrate(kbps)
        exec {
            synchronized(lock) {
                try {
                    if (stream?.isStreaming == true) {
                        stream?.setVideoBitrateOnFly(v * 1000)
                        preparedBitrateKbps = v
                        _liveBitrateKbps.value = v
                    }
                } catch (_: Exception) {
                }
            }
        }
    }

    /** Called periodically by the service: revoked mic permission must stop the stream safely. */
    fun checkMicPermissionStillGranted() {
        if (isActive() && !hasMicPermission()) {
            _audio.value = _audio.value.copy(micPermissionLost = true)
            failActiveSession("Microphone permission was revoked. Stream stopped.")
        }
    }

    private fun failActiveSession(message: String) {
        val st = _status.value.state
        val ev: StreamEvent? = when (st) {
            StreamState.PREPARING -> StreamEvent.PrepareFailed(message)
            StreamState.CONNECTING -> StreamEvent.ConnectionFailed(message)
            StreamState.STREAMING -> StreamEvent.AuthFailed(message)
            StreamState.RECONNECTING -> StreamEvent.RetriesExhausted(message)
            else -> null
        }
        if (ev != null) {
            dispatch(ev) { it.copy(errorMessage = message) }
            exec { synchronized(lock) { teardownTransportLocked() } }
        }
    }

    // ------------------------------------------------------------------------------------ audio

    fun setUserMuted(muted: Boolean) {
        _audio.value = _audio.value.copy(userMuted = muted)
        exec { synchronized(lock) { applyMute() } }
    }

    /** Elapsed-realtime when the audio of the current live session was prepared. */
    @Volatile private var liveStartedAt = 0L

    /**
     * Mute rules:
     *  - Muting (by the operator, or automatically when a call / another app takes audio focus) silences ONLY the commentary
     *    microphone, inside the mixer. Music and the spoken commentary keep going on air.
     *    (Muting the microphone natively would stop the mixer completely, and with it everything else the app sends.)
     *  - Safety net: if the mixer is not receiving the microphone at all (so the mixer cannot mute it), a muted microphone
     *    is muted natively after 3 seconds, so "MUTED" can never leave a live microphone transmitting.
     */
    private fun applyMute() {
        val micOff = _audio.value.userMuted || _audio.value.autoMuted
        mixer.setMicMuted(micOff)
        val since = SystemClock.elapsedRealtime() - liveStartedAt
        val mixerDead = isActive() && micOff && !mixer.effectHooked() && since > 3000
        try {
            val m = mic ?: return
            if (mixerDead) m.mute() else m.unMute()
        } catch (_: Exception) {
        }
    }

    /** Once a second while live: re-attaches the mixer if the encoder stopped using it, and reports whether audio really flows. */
    private fun audioHealthLocked() {
        if (!isActive()) {
            if (!_audio.value.chainHooked) _audio.value = _audio.value.copy(chainHooked = true)
            return
        }
        val since = SystemClock.elapsedRealtime() - liveStartedAt
        val micOff = _audio.value.userMuted || _audio.value.autoMuted
        val hooked = mixer.effectHooked()
        if (since > 3000 && !hooked && !micOff) {
            try {
                mic?.setAudioEffect(mixer.effect)
                mic?.unMute()
            } catch (_: Exception) {
            }
        }
        val ok = hooked || since <= 3000 || micOff
        if (_audio.value.chainHooked != ok) _audio.value = _audio.value.copy(chainHooked = ok)
        applyMute()
    }

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS, AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                _audio.value = _audio.value.copy(autoMuted = true)
            }
            AudioManager.AUDIOFOCUS_GAIN -> _audio.value = _audio.value.copy(autoMuted = false)
        }
        exec { synchronized(lock) { applyMute() } }
    }

    private fun requestAudioFocus() {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setOnAudioFocusChangeListener(focusListener)
                    .build()
                focusRequest = req
                audioManager.requestAudioFocus(req)
            } else {
                @Suppress("DEPRECATION")
                audioManager.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            }
        } catch (_: Exception) {
        }
    }

    private fun abandonAudioFocus() {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
                focusRequest = null
            } else {
                @Suppress("DEPRECATION")
                audioManager.abandonAudioFocus(focusListener)
            }
        } catch (_: Exception) {
        }
        _audio.value = _audio.value.copy(autoMuted = false)
    }

    // ------------------------------------------------------------------------------------ adaptive bitrate

    /** Called once per second by the foreground service while a session is active. */
    fun adaptiveTick() {
        exec { synchronized(lock) { audioHealthLocked() } }
        if (!settings.adaptiveBitrate) return
        exec { synchronized(lock) { adaptLocked() } }
    }

    private fun adaptLocked() {
        val gs = stream ?: return
        val p = preparedProfile ?: return
        if (_status.value.state != StreamState.STREAMING || !gs.isStreaming) {
            congestedTicks = 0
            calmTicks = 0
            return
        }
        val client = try {
            gs.getStreamClient()
        } catch (_: Exception) {
            return
        }
        val congested = try {
            client.hasCongestion()
        } catch (_: Exception) {
            false
        }
        val dropped = try {
            client.getDroppedVideoFrames()
        } catch (_: Exception) {
            lastDropped
        }
        val newDrops = (dropped - lastDropped).coerceAtLeast(0L)
        lastDropped = dropped
        if (congested || newDrops > 3) {
            congestedTicks++
            calmTicks = 0
        } else {
            calmTicks++
            congestedTicks = 0
        }
        val now = SystemClock.elapsedRealtime()
        val target = p.clampBitrate(settings.videoBitrateKbps)
        if (congestedTicks >= 3 && now - lastAdaptAt > 5_000) {
            congestedTicks = 0
            val lowered = BitrateAdvisor.reduced(preparedBitrateKbps, p)
            if (lowered < preparedBitrateKbps) {
                try {
                    gs.setVideoBitrateOnFly(lowered * 1000)
                    preparedBitrateKbps = lowered
                    _liveBitrateKbps.value = lowered
                    lastAdaptAt = now
                } catch (_: Exception) {
                }
            }
        } else if (calmTicks >= 25 && now - lastAdaptAt > 20_000 && preparedBitrateKbps < target) {
            calmTicks = 0
            val raised = min(target, (preparedBitrateKbps * 1.15).toInt() + 1)
            try {
                gs.setVideoBitrateOnFly(raised * 1000)
                preparedBitrateKbps = raised
                _liveBitrateKbps.value = raised
                lastAdaptAt = now
            } catch (_: Exception) {
            }
        }
    }

    // ------------------------------------------------------------------------------------ local recording

    private fun startRecordingLocked(gs: GenericStream) {
        try {
            val dir = app.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: app.filesDir
            dir.mkdirs()
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val f = File(dir, "Zarvimo_$stamp.mp4")
            gs.startRecord(f.absolutePath, null, RecordController.Listener { })
            recordFile = f
            _recording.value = true
        } catch (e: Exception) {
            recordFile = null
            _recording.value = false
            _notice.value = "Local recording could not start (${e.javaClass.simpleName}). The live stream continues."
        }
    }

    private fun stopRecordingLocked() {
        val f = recordFile ?: return
        recordFile = null
        _recording.value = false
        try {
            val s = stream
            if (s != null && s.isRecording) s.stopRecord()
        } catch (_: Exception) {
        }
        publishRecording(f)
    }

    /** Moves the finished recording to the gallery (Movies/Zarvimo) on Android 10+, otherwise keeps it in the app folder. */
    private fun publishRecording(file: File) {
        Thread({ publishRecordingBlocking(file) }, "recording-publisher").also { it.isDaemon = true }.start()
    }

    private fun publishRecordingBlocking(file: File) {
        try {
            if (!file.exists() || file.length() < 2048) {
                file.delete()
                return
            }
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Zarvimo")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val resolver = app.contentResolver
                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                    values.clear()
                    values.put(MediaStore.Video.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    file.delete()
                    _notice.value = "Recording saved: Movies/Zarvimo/${file.name}"
                    return
                }
            }
            _notice.value = "Recording saved: ${file.absolutePath}"
        } catch (e: Exception) {
            _notice.value = "Recording kept in the app folder: ${file.absolutePath}"
        }
    }

    // ------------------------------------------------------------------------------------ spoken commentary

    fun applyAutoShow(s: AutoShowSettings) {
        mixer.setVoiceVolume(s.voiceVolume)
        if (s.voiceEnabled) voiceCommentary.ensure(s.voiceUrdu)
    }

    /** [english] / [urdu] are the same sentence; the Urdu one is used only when it was asked for and a voice exists. */
    fun speakCommentary(english: String, urdu: String, wantUrdu: Boolean) {
        voiceCommentary.ensure(wantUrdu)
        // While live the voice must go into the stream; only when the mixer is really not working is it spoken on the speaker.
        voiceCommentary.speak(english, urdu, live = mixer.liveNow() && _audio.value.chainHooked)
    }

    // ------------------------------------------------------------------------------------ video source & music

    fun hasCameraPermission(): Boolean =
        ContextCompat.checkSelfPermission(app, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    /** Live switching: preview and stream follow on the very next frame. */
    fun setVideoSource(mode: VideoSourceMode, rotationOffset: Int) {
        desiredMode = mode
        desiredRotation = rotationOffset
        _videoMode.value = mode
        source?.setMode(mode)
        source?.setRotationOffset(rotationOffset)
    }

    /** Round camera picture over the background picture; position / size changes apply on the next frame. */
    fun setBubble(b: BubbleConfig) {
        desiredBubble = b
        _bubbleEnabled.value = b.enabled
        source?.setBubble(b)
    }

    fun applyAudioMix(s: AudioMixSettings) = mixer.apply(s)
    fun musicPlay() = mixer.play()
    fun musicPause() = mixer.pause()
    fun musicNext() = mixer.next()

    // ------------------------------------------------------------------------------------ state

    private fun dispatch(event: StreamEvent, update: (StreamStatus) -> StreamStatus = { it }): Boolean {
        synchronized(lock) {
            val cur = _status.value
            val next = StreamStateMachine.next(cur.state, event) ?: return false
            _status.value = update(cur).copy(state = next)
            return true
        }
    }

    // ------------------------------------------------------------------------------------ ConnectChecker
    // These callbacks arrive on RootEncoder threads. They are the ONLY source of CONNECTING -> STREAMING etc.

    override fun onConnectionStarted(url: String) {
        // Intentionally empty: the URL contains the stream key and must never be logged.
    }

    override fun onConnectionSuccess() {
        exec { synchronized(lock) { applyMute() } }
        dispatch(StreamEvent.ConnectionSucceeded) {
            it.copy(
                liveSinceMs = it.liveSinceMs ?: SystemClock.elapsedRealtime(),
                reconnectAttempt = 0,
                errorMessage = null
            )
        }
    }

    override fun onConnectionFailed(reason: String) {
        handleDrop(StreamValidator.scrub(reason, activeKey).ifBlank { "Connection failed" })
    }

    override fun onDisconnect() {
        // Expected after our own stopStream() (state is STOPPING/IDLE then). Unexpected while STREAMING = drop.
        if (_status.value.state == StreamState.STREAMING) handleDrop("Disconnected by the server")
    }

    override fun onAuthError() {
        val msg = "The server rejected the stream key / authentication. Check that the stream is active and the key is correct."
        if (dispatch(StreamEvent.AuthFailed(msg)) { it.copy(errorMessage = msg) }) {
            exec { synchronized(lock) { teardownTransportLocked() } }
        }
    }

    override fun onAuthSuccess() {}

    override fun onNewBitrate(bitrate: Long) {
        // Real bits-per-second reported by the transport.
        synchronized(lock) {
            val cur = _status.value
            if (cur.state == StreamState.STREAMING) _status.value = cur.copy(measuredBitrateBps = bitrate)
        }
    }

    /** Connection failed or dropped: bounded exponential backoff, otherwise surface the REAL error. */
    private fun handleDrop(message: String) {
        val cur = _status.value
        when (cur.state) {
            StreamState.CONNECTING -> {
                // First connection attempt never succeeded: do not loop on a bad URL/key. Show the real error + Retry.
                if (dispatch(StreamEvent.ConnectionFailed(message)) { it.copy(errorMessage = message) }) {
                    exec { synchronized(lock) { teardownTransportLocked() } }
                }
            }
            StreamState.STREAMING, StreamState.RECONNECTING -> {
                val made = if (cur.state == StreamState.RECONNECTING) cur.reconnectAttempt else 0
                val next = made + 1
                val scheduled = policy.shouldRetry(made) && try {
                    // Library-level retry releases the stale socket and reconnects after our computed delay.
                    stream?.getStreamClient()?.reTry(policy.delayForAttempt(next), message) == true
                } catch (_: Exception) {
                    false
                }
                if (scheduled) {
                    if (settings.lowerBitrateOnReconnect) {
                        val p = preparedProfile
                        if (p != null) {
                            val lowered = BitrateAdvisor.reduced(preparedBitrateKbps, p)
                            if (lowered < preparedBitrateKbps) {
                                try {
                                    stream?.setVideoBitrateOnFly(lowered * 1000)
                                    preparedBitrateKbps = lowered
                                    _liveBitrateKbps.value = lowered
                                } catch (_: Exception) {
                                }
                            }
                        }
                    }
                    val ev = if (cur.state == StreamState.STREAMING) StreamEvent.ConnectionLost(message) else StreamEvent.ReconnectAttemptFailed(message)
                    dispatch(ev) { it.copy(reconnectAttempt = next, errorMessage = message) }
                } else {
                    if (cur.state == StreamState.STREAMING) dispatch(StreamEvent.ConnectionLost(message)) { it }
                    val final = "Connection lost. Gave up after $made reconnect attempt(s): $message"
                    dispatch(StreamEvent.RetriesExhausted(final)) { it.copy(errorMessage = final) }
                    exec { synchronized(lock) { teardownTransportLocked() } }
                }
            }
            else -> Unit
        }
    }

    // ------------------------------------------------------------------------------------ lifecycle

    /** Full release of encoder, GL, audio and network resources (process shutdown / user leaves the app for good). */
    fun release() {
        exec {
            synchronized(lock) {
                teardownTransportLocked()
                try {
                    stream?.let {
                        if (it.isOnPreview) it.stopPreview()
                        it.release()
                    }
                } catch (_: Exception) {
                }
                stream = null
                source = null
                mic = null
                voiceCommentary.release()
                mixer.release()
                _preview.value = PreviewStatus()
                _status.value = StreamStatus(maxReconnectAttempts = policy.maxAttempts)
            }
        }
    }

    /** Wall-clock-free elapsed seconds since the server accepted the connection; null if never connected. */
    fun elapsedSeconds(): Long? {
        val since = _status.value.liveSinceMs ?: return null
        return (SystemClock.elapsedRealtime() - since) / 1000
    }
}
