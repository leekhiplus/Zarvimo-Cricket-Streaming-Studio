package com.zarvimo.cricket.stream

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.SystemClock
import android.view.SurfaceView
import androidx.core.content.ContextCompat
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.sources.audio.MicrophoneSource
import com.pedro.library.generic.GenericStream
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.Executors

/** Local preview status. Deliberately separate from the network status ([StreamStatus]). */
data class PreviewStatus(
    val running: Boolean = false,
    val width: Int = 0,
    val height: Int = 0,
    /** Frames per second actually produced by the compositor in the last second; null when not running. */
    val compositorFps: Int? = null,
    val error: String? = null
)

data class AudioUiState(
    val userMuted: Boolean = false,
    /** Muted automatically because another app / a call took audio focus. */
    val autoMuted: Boolean = false,
    val micPermissionLost: Boolean = false
) {
    val effectivelyMuted: Boolean get() = userMuted || autoMuted
}

sealed class StartResult {
    object Started : StartResult()
    data class Rejected(val reasons: List<String>) : StartResult()
}

/**
 * Owns the one-and-only streaming pipeline in the process:
 *   BroadcastVideoSource (compositor) -> RootEncoder GL -> MediaCodec H.264 + AAC -> RTMP/RTMPS.
 *
 * Every [StreamState] change is caused by a real RootEncoder callback or an explicit user action, never by timers.
 * The stream key is never logged: this class contains no logging of endpoints, and library error text is scrubbed.
 */
class StreamEngine(private val app: Application) : ConnectChecker {

    val broadcast = BroadcastState()

    private val lock = Any()
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "stream-engine-worker") }
    private val policy = ReconnectPolicy()

    private val _status = MutableStateFlow(StreamStatus(maxReconnectAttempts = policy.maxAttempts))
    val status: StateFlow<StreamStatus> = _status.asStateFlow()

    private val _preview = MutableStateFlow(PreviewStatus())
    val preview: StateFlow<PreviewStatus> = _preview.asStateFlow()

    private val _audio = MutableStateFlow(AudioUiState())
    val audio: StateFlow<AudioUiState> = _audio.asStateFlow()

    private var stream: GenericStream? = null
    private var source: BroadcastVideoSource? = null
    private var mic: MicrophoneSource? = null
    private var previewView: SurfaceView? = null
    private var preparedProfile: ResolutionProfile? = null
    private var preparedFps = 0
    private var preparedBitrateKbps = 0

    /** Held only in memory while a session is active; used to scrub library error text. */
    @Volatile private var activeKey: String = ""
    @Volatile private var settings: StreamSettings = StreamSettings()

    private val audioManager = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var focusRequest: AudioFocusRequest? = null

    // ------------------------------------------------------------------------------------ preview

    /** Starts / restarts local preview using the same compositor + GL pipeline the encoder uses. */
    fun attachPreview(view: SurfaceView, profile: ResolutionProfile, fps: Int) {
        previewView = view
        worker.execute { synchronized(lock) { startPreviewLocked(profile, fps) } }
    }

    fun onPreviewSurfaceSize(width: Int, height: Int) {
        worker.execute {
            synchronized(lock) {
                try {
                    stream?.getGlInterface()?.setPreviewResolution(width, height)
                } catch (_: Exception) {
                }
            }
        }
    }

    fun detachPreview() {
        previewView = null
        worker.execute { synchronized(lock) { stopPreviewLocked() } }
    }

    /** Apply new output settings while NOT streaming (resolution/fps changes need the encoder to be re-prepared). */
    fun reconfigurePreview(profile: ResolutionProfile, fps: Int) {
        if (isActive()) return
        worker.execute {
            synchronized(lock) {
                if (_status.value.state != StreamState.IDLE && _status.value.state != StreamState.ERROR) return@execute
                val v = previewView
                stopPreviewLocked()
                if (v != null) startPreviewLocked(profile, fps)
            }
        }
    }

    private fun ensureStreamLocked(): GenericStream {
        stream?.let { return it }
        val src = BroadcastVideoSource(
            broadcast,
            onCompositorFps = { f -> _preview.value = _preview.value.copy(compositorFps = if (_preview.value.running || isActive()) f else null) },
            onFatalError = { msg -> _preview.value = _preview.value.copy(running = false, error = msg) }
        )
        source = src
        val micSource = MicrophoneSource()
        mic = micSource
        val s = GenericStream(app, this, src, micSource)
        stream = s
        return s
    }

    private fun startPreviewLocked(profile: ResolutionProfile, fps: Int) {
        val view = previewView ?: return
        try {
            val s = ensureStreamLocked()
            if (s.isOnPreview) s.stopPreview()
            if (!s.isStreaming) {
                val ok = s.prepareVideo(profile.width, profile.height, profile.defaultKbps * 1000, fps, StreamOptions.KEYFRAME_INTERVAL_SEC, 0)
                if (!ok) {
                    _preview.value = PreviewStatus(running = false, error = "This device's encoder rejected ${profile.label} @ ${fps}fps. Try a lower profile.")
                    return
                }
                preparedProfile = profile
                preparedFps = fps
                preparedBitrateKbps = profile.defaultKbps
            }
            s.startPreview(view)
            _preview.value = PreviewStatus(running = true, width = profile.width, height = profile.height)
        } catch (e: Exception) {
            _preview.value = PreviewStatus(running = false, error = "Preview failed: ${e.javaClass.simpleName}")
        }
    }

    private fun stopPreviewLocked() {
        try {
            val s = stream ?: return
            if (s.isOnPreview) s.stopPreview()
        } catch (_: Exception) {
        }
        _preview.value = PreviewStatus(running = false)
    }

    // ------------------------------------------------------------------------------------ streaming

    fun isActive(): Boolean = when (_status.value.state) {
        StreamState.IDLE, StreamState.ERROR -> false
        else -> true
    }

    fun hasMicPermission(): Boolean =
        ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /** Validates input, then starts the real pipeline. Never changes state when validation fails. */
    fun startStream(s: StreamSettings): StartResult {
        val validation = StreamValidator.validate(s.serverUrl, s.streamKey)
        if (validation is ValidationResult.Invalid) return StartResult.Rejected(validation.problems + StreamValidator.HELP)
        validation as ValidationResult.Valid
        if (!hasMicPermission()) return StartResult.Rejected(listOf("Microphone permission is required to transmit commentary audio"))

        val accepted = dispatch(StreamEvent.StartRequested) {
            StreamStatus(state = it.state, maxReconnectAttempts = policy.maxAttempts)
        }
        if (!accepted) return StartResult.Rejected(listOf("A stream session is already active"))

        settings = s
        activeKey = s.streamKey.trim()
        worker.execute { synchronized(lock) { startPipelineLocked(s, validation.endpoint) } }
        return StartResult.Started
    }

    private fun startPipelineLocked(s: StreamSettings, endpoint: String) {
        try {
            val gs = ensureStreamLocked()
            val view = previewView
            if (gs.isOnPreview) gs.stopPreview() // re-preparing the encoder requires preview/stream to be stopped
            val profile = s.profile
            val vOk = gs.prepareVideo(profile.width, profile.height, profile.clampBitrate(s.videoBitrateKbps) * 1000, s.fps, StreamOptions.KEYFRAME_INTERVAL_SEC, 0)
            val aOk = gs.prepareAudio(StreamOptions.AUDIO_SAMPLE_RATE, s.stereo, s.audioBitrateKbps * 1000, true, true)
            if (!vOk || !aOk) {
                val msg = if (!vOk) "Video encoder could not be prepared for ${profile.label} @ ${s.fps}fps on this device" else "Audio encoder / microphone could not be prepared"
                dispatch(StreamEvent.PrepareFailed(msg)) { it.copy(errorMessage = msg) }
                if (view != null) startPreviewLocked(profile, s.fps)
                return
            }
            preparedProfile = profile
            preparedFps = s.fps
            preparedBitrateKbps = profile.clampBitrate(s.videoBitrateKbps)
            if (view != null) {
                gs.startPreview(view)
                _preview.value = PreviewStatus(running = true, width = profile.width, height = profile.height)
            }
            try {
                gs.getStreamClient().setReTries(policy.maxAttempts)
            } catch (_: Exception) {
            }
            requestAudioFocus()
            applyMute()
            dispatch(StreamEvent.PrepareSucceeded)
            gs.startStream(endpoint) // real connection; result arrives via ConnectChecker callbacks
        } catch (e: Exception) {
            val msg = "Could not start: " + StreamValidator.scrub(e.message ?: e.javaClass.simpleName, activeKey)
            val st = _status.value.state
            if (st == StreamState.PREPARING) dispatch(StreamEvent.PrepareFailed(msg)) { it.copy(errorMessage = msg) }
            else if (st == StreamState.CONNECTING) dispatch(StreamEvent.ConnectionFailed(msg)) { it.copy(errorMessage = msg) }
            teardownTransportLocked()
        }
    }

    /** User pressed Stop Live (or the notification action). Really stops transmission and releases the mic. */
    fun stopStream() {
        val accepted = dispatch(StreamEvent.StopRequested) { it }
        if (!accepted) return
        worker.execute {
            synchronized(lock) {
                teardownTransportLocked()
                abandonAudioFocus()
                activeKey = ""
                dispatch(StreamEvent.StopCompleted) {
                    StreamStatus(state = it.state, maxReconnectAttempts = policy.maxAttempts)
                }
            }
        }
    }

    /** Stop sending, close the connection, stop mic capture. Preview keeps running (it uses no network / mic). */
    private fun teardownTransportLocked() {
        try {
            val s = stream
            if (s != null && s.isStreaming) s.stopStream()
        } catch (_: Exception) {
        }
        abandonAudioFocus()
    }

    /** Bitrate change while live (no reconnect needed). */
    fun setVideoBitrateOnFly(kbps: Int) {
        val p = preparedProfile ?: return
        val v = p.clampBitrate(kbps)
        worker.execute {
            synchronized(lock) {
                try {
                    if (stream?.isStreaming == true) {
                        stream?.setVideoBitrateOnFly(v * 1000)
                        preparedBitrateKbps = v
                    }
                } catch (_: Exception) {
                }
            }
        }
    }

    /** Called periodically by the service: revoked mic permission must stop the stream safely. */
    fun checkMicPermissionStillGranted() {
        if (isActive() && !hasMicPermission()) {
            _audio.value = _audio.value.copy(micPermissionLost = true)
            failActiveSession("Microphone permission was revoked. Stream stopped.")
        }
    }

    private fun failActiveSession(message: String) {
        val st = _status.value.state
        val ev: StreamEvent? = when (st) {
            StreamState.PREPARING -> StreamEvent.PrepareFailed(message)
            StreamState.CONNECTING -> StreamEvent.ConnectionFailed(message)
            StreamState.STREAMING -> StreamEvent.AuthFailed(message)
            StreamState.RECONNECTING -> StreamEvent.RetriesExhausted(message)
            else -> null
        }
        if (ev != null) {
            dispatch(ev) { it.copy(errorMessage = message) }
            worker.execute { synchronized(lock) { teardownTransportLocked() } }
        }
    }

    // ------------------------------------------------------------------------------------ audio

    fun setUserMuted(muted: Boolean) {
        _audio.value = _audio.value.copy(userMuted = muted)
        worker.execute { synchronized(lock) { applyMute() } }
    }

    private fun applyMute() {
        try {
            val m = mic ?: return
            if (_audio.value.effectivelyMuted) m.mute() else m.unMute()
        } catch (_: Exception) {
        }
    }

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS, AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                _audio.value = _audio.value.copy(autoMuted = true)
            }
            AudioManager.AUDIOFOCUS_GAIN -> _audio.value = _audio.value.copy(autoMuted = false)
        }
        worker.execute { synchronized(lock) { applyMute() } }
    }

    private fun requestAudioFocus() {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setOnAudioFocusChangeListener(focusListener)
                    .build()
                focusRequest = req
                audioManager.requestAudioFocus(req)
            } else {
                @Suppress("DEPRECATION")
                audioManager.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            }
        } catch (_: Exception) {
        }
    }

    private fun abandonAudioFocus() {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
                focusRequest = null
            } else {
                @Suppress("DEPRECATION")
                audioManager.abandonAudioFocus(focusListener)
            }
        } catch (_: Exception) {
        }
        _audio.value = _audio.value.copy(autoMuted = false)
    }

    // ------------------------------------------------------------------------------------ state

    private fun dispatch(event: StreamEvent, update: (StreamStatus) -> StreamStatus = { it }): Boolean {
        synchronized(lock) {
            val cur = _status.value
            val next = StreamStateMachine.next(cur.state, event) ?: return false
            _status.value = update(cur).copy(state = next)
            return true
        }
    }

    // ------------------------------------------------------------------------------------ ConnectChecker
    // These callbacks arrive on RootEncoder threads. They are the ONLY source of CONNECTING -> STREAMING etc.

    override fun onConnectionStarted(url: String) {
        // Intentionally empty: the URL contains the stream key and must never be logged.
    }

    override fun onConnectionSuccess() {
        dispatch(StreamEvent.ConnectionSucceeded) {
            it.copy(
                liveSinceMs = it.liveSinceMs ?: SystemClock.elapsedRealtime(),
                reconnectAttempt = 0,
                errorMessage = null
            )
        }
    }

    override fun onConnectionFailed(reason: String) {
        handleDrop(StreamValidator.scrub(reason, activeKey).ifBlank { "Connection failed" })
    }

    override fun onDisconnect() {
        // Expected after our own stopStream() (state is STOPPING/IDLE then). Unexpected while STREAMING = drop.
        if (_status.value.state == StreamState.STREAMING) handleDrop("Disconnected by the server")
    }

    override fun onAuthError() {
        val msg = "The server rejected the stream key / authentication. Check that the stream is active and the key is correct."
        if (dispatch(StreamEvent.AuthFailed(msg)) { it.copy(errorMessage = msg) }) {
            worker.execute { synchronized(lock) { teardownTransportLocked() } }
        }
    }

    override fun onAuthSuccess() {}

    override fun onNewBitrate(bitrate: Long) {
        // Real bits-per-second reported by the transport.
        synchronized(lock) {
            val cur = _status.value
            if (cur.state == StreamState.STREAMING) _status.value = cur.copy(measuredBitrateBps = bitrate)
        }
    }

    /** Connection failed or dropped: bounded exponential backoff, otherwise surface the REAL error. */
    private fun handleDrop(message: String) {
        val cur = _status.value
        when (cur.state) {
            StreamState.CONNECTING -> {
                // First connection attempt never succeeded: do not loop on a bad URL/key. Show the real error + Retry.
                if (dispatch(StreamEvent.ConnectionFailed(message)) { it.copy(errorMessage = message) }) {
                    worker.execute { synchronized(lock) { teardownTransportLocked() } }
                }
            }
            StreamState.STREAMING, StreamState.RECONNECTING -> {
                val made = if (cur.state == StreamState.RECONNECTING) cur.reconnectAttempt else 0
                val next = made + 1
                val scheduled = policy.shouldRetry(made) && try {
                    // Library-level retry releases the stale socket and reconnects after our computed delay.
                    stream?.getStreamClient()?.reTry(policy.delayForAttempt(next), message) == true
                } catch (_: Exception) {
                    false
                }
                if (scheduled) {
                    if (settings.lowerBitrateOnReconnect) {
                        val p = preparedProfile
                        if (p != null) {
                            val lowered = BitrateAdvisor.reduced(preparedBitrateKbps, p)
                            if (lowered < preparedBitrateKbps) {
                                try {
                                    stream?.setVideoBitrateOnFly(lowered * 1000)
                                    preparedBitrateKbps = lowered
                                } catch (_: Exception) {
                                }
                            }
                        }
                    }
                    val ev = if (cur.state == StreamState.STREAMING) StreamEvent.ConnectionLost(message) else StreamEvent.ReconnectAttemptFailed(message)
                    dispatch(ev) { it.copy(reconnectAttempt = next, errorMessage = message) }
                } else {
                    if (cur.state == StreamState.STREAMING) dispatch(StreamEvent.ConnectionLost(message)) { it }
                    val final = "Connection lost. Gave up after $made reconnect attempt(s): $message"
                    dispatch(StreamEvent.RetriesExhausted(final)) { it.copy(errorMessage = final) }
                    worker.execute { synchronized(lock) { teardownTransportLocked() } }
                }
            }
            else -> Unit
        }
    }

    // ------------------------------------------------------------------------------------ lifecycle

    /** Full release of encoder, GL, audio and network resources (process shutdown / user leaves the app for good). */
    fun release() {
        worker.execute {
            synchronized(lock) {
                teardownTransportLocked()
                try {
                    stream?.let {
                        if (it.isOnPreview) it.stopPreview()
                        it.release()
                    }
                } catch (_: Exception) {
                }
                stream = null
                source = null
                mic = null
                _preview.value = PreviewStatus()
                _status.value = StreamStatus(maxReconnectAttempts = policy.maxAttempts)
            }
        }
    }

    /** Wall-clock-free elapsed seconds since the server accepted the connection; null if never connected. */
    fun elapsedSeconds(): Long? {
        val since = _status.value.liveSinceMs ?: return null
        return (SystemClock.elapsedRealtime() - since) / 1000
    }
}
