package com.zarvimo.cricket.graphics

import com.zarvimo.cricket.scoring.BatterStat
import com.zarvimo.cricket.scoring.BowlerStat
import com.zarvimo.cricket.scoring.InningsState
import java.util.Locale

/** Full-screen FOUR / SIX / WICKET burst. [startMs] uses the same clock as the renderer (SystemClock.uptimeMillis()). */
enum class BurstKind(val text: String, val color: Int) {
    FOUR("FOUR", 0xFF1E88E5.toInt()),
    SIX("SIX", 0xFF8E24AA.toInt()),
    WICKET("WICKET", 0xFFD32F2F.toInt())
}

data class BurstInfo(val kind: BurstKind, val detail: String, val startMs: Long) {
    companion object {
        const val DURATION_MS = 2800L
    }
}

enum class PanelKind(val label: String) {
    SCORECARD("Full scorecard"),
    STRIKER("Striker stats"),
    NON_STRIKER("Non-striker stats"),
    BOWLER("Bowler stats"),
    PARTNERSHIP("Partnership"),
    RUN_RATE("Run-rate graph"),
    COMMENT("Viewer comment"),
    PLAYING_XI("Playing XI")
}

/** One table row of the scorecard: a name and up to five right-aligned columns. */
data class PanelRow(
    val name: String,
    val sub: String = "",
    val c1: String = "",
    val c2: String = "",
    val c3: String = "",
    val c4: String = "",
    val c5: String = "",
    val highlight: Boolean = false
)

/** Everything the compositor needs to draw an on-air panel. Built from the scoring state (pure Kotlin). */
data class PanelInfo(
    val kind: PanelKind,
    val title: String,
    val subtitle: String = "",
    val batHeader: List<String> = emptyList(),
    val bat: List<PanelRow> = emptyList(),
    val bowlHeader: List<String> = emptyList(),
    val bowl: List<PanelRow> = emptyList(),
    val footer: String = "",
    /** key / value chips of the player and partnership cards. */
    val stats: List<Pair<String, String>> = emptyList(),
    /** runs per over (graph). */
    val overRuns: List<Int> = emptyList(),
    /** wickets per over (graph markers), same length as [overRuns]. */
    val overWickets: List<Int> = emptyList(),
    val oversLimit: Int = 20,
    /** required run rate shown as a reference line in a chase. */
    val requiredRate: Float? = null,
    val currentRate: Float = 0f,
    val shownAtMs: Long = 0L,
    /** Team colours of the Playing XI panel (0 = use the accent colour). */
    val colorA: Int = 0,
    val colorB: Int = 0
)

object PanelBuilder {

    /** Both squads side by side. Works before the first ball. [bat] = team A rows, [bowl] = team B rows; headers carry the team names. */
    fun playingXi(setup: com.zarvimo.cricket.scoring.MatchSetup, colorA: Int, colorB: Int): PanelInfo {
        fun rows(names: List<String>) = names.mapIndexed { i, n -> PanelRow(name = n, c1 = (i + 1).toString()) }
        return PanelInfo(
            kind = PanelKind.PLAYING_XI,
            title = "PLAYING XI",
            subtitle = setup.title.ifBlank { "${setup.teamA} vs ${setup.teamB}" },
            batHeader = listOf(setup.teamA), bat = rows(setup.squadA),
            bowlHeader = listOf(setup.teamB), bowl = rows(setup.squadB),
            footer = setup.venue,
            colorA = colorA, colorB = colorB
        )
    }

    private fun f1(v: Double) = String.format(Locale.ROOT, "%.1f", v)
    private fun f2(v: Double) = String.format(Locale.ROOT, "%.2f", v)

    private fun batRow(b: BatterStat, atCrease: Boolean) = PanelRow(
        name = b.name,
        sub = if (b.out) (b.dismissal ?: "out") else if (atCrease) "not out" else "",
        c1 = b.runs.toString(), c2 = b.balls.toString(), c3 = b.fours.toString(), c4 = b.sixes.toString(), c5 = f1(b.strikeRate),
        highlight = atCrease
    )

    private fun bowlRow(b: BowlerStat, current: Boolean) = PanelRow(
        name = b.name, c1 = b.oversText, c2 = b.maidens.toString(), c3 = b.runs.toString(), c4 = b.wickets.toString(), c5 = f1(b.economy),
        highlight = current
    )

    fun scorecard(st: InningsState): PanelInfo {
        val atCrease = setOfNotNull(st.striker?.name, st.nonStriker?.name)
        val bat = st.batters.map { batRow(it, !it.out && it.name in atCrease) }
        val bowl = st.bowlers.map { bowlRow(it, it.name == st.bowler?.name) }
        val fow = st.fallOfWickets.joinToString("  ") { "${it.wicketNumber}-${it.teamRuns} (${it.batter}, ${it.oversText})" }
        val ex = st.extras
        val extras = "Extras ${ex.total} (w ${ex.wides}, nb ${ex.noBalls}, b ${ex.byes}, lb ${ex.legByes}" + (if (ex.penalty > 0) ", pen ${ex.penalty}" else "") + ")"
        return PanelInfo(
            kind = PanelKind.SCORECARD,
            title = st.battingTeam.uppercase(),
            subtitle = "${st.scoreText}  (${st.oversText} ov)  •  RR ${f2(st.runRate)}",
            batHeader = listOf("BATTING", "R", "B", "4s", "6s", "SR"),
            bat = bat,
            bowlHeader = listOf("BOWLING", "O", "M", "R", "W", "ECO"),
            bowl = bowl,
            footer = extras + (if (fow.isNotEmpty()) "     FOW: $fow" else "")
        )
    }

    /** Striker / non-striker / bowler card. Returns null when that player is not at the crease yet. */
    fun player(st: InningsState, kind: PanelKind): PanelInfo? = when (kind) {
        PanelKind.STRIKER, PanelKind.NON_STRIKER -> {
            val b = (if (kind == PanelKind.STRIKER) st.striker else st.nonStriker) ?: return null
            PanelInfo(
                kind = kind, title = b.name.uppercase(),
                subtitle = (if (kind == PanelKind.STRIKER) "ON STRIKE" else "AT THE OTHER END") + "  •  ${st.battingTeam}",
                stats = listOf("RUNS" to b.runs.toString(), "BALLS" to b.balls.toString(), "4s" to b.fours.toString(), "6s" to b.sixes.toString(), "SR" to f1(b.strikeRate))
            )
        }
        PanelKind.BOWLER -> {
            val b = st.bowler ?: return null
            PanelInfo(
                kind = kind, title = b.name.uppercase(), subtitle = "BOWLING  •  ${st.bowlingTeam}",
                stats = listOf("OVERS" to b.oversText, "MAIDENS" to b.maidens.toString(), "RUNS" to b.runs.toString(), "WKTS" to b.wickets.toString(), "ECON" to f1(b.economy))
            )
        }
        else -> null
    }

    /** Balls faced in the current partnership: legal balls now minus legal balls when the last wicket fell. */
    fun partnership(st: InningsState): PanelInfo? {
        val s = st.striker ?: return null
        val n = st.nonStriker ?: return null
        val last = st.fallOfWickets.lastOrNull()
        val startRuns = last?.teamRuns ?: st.partnershipStartRuns ?: 0
        val startBalls = last?.let { ballsFromOversText(it.oversText, st.ballsPerOver) } ?: st.partnershipStartBalls ?: 0
        val runs = (st.runs - startRuns).coerceAtLeast(0)
        val balls = (st.legalBalls - startBalls).coerceAtLeast(0)
        val wicketNo = st.wickets + 1
        return PanelInfo(
            kind = PanelKind.PARTNERSHIP, title = "PARTNERSHIP",
            subtitle = "${ordinal(wicketNo)} WICKET  •  ${st.battingTeam}",
            stats = listOf("RUNS" to runs.toString(), "BALLS" to balls.toString(), "RATE" to (if (balls == 0) "0.00" else f2(runs * st.ballsPerOver.toDouble() / balls))),
            bat = listOf(
                PanelRow(s.name, c1 = s.runs.toString(), c2 = "(${s.balls})", highlight = true),
                PanelRow(n.name, c1 = n.runs.toString(), c2 = "(${n.balls})")
            )
        )
    }

    fun runRate(st: InningsState): PanelInfo {
        val overs = maxOf(1, st.allBalls.maxOfOrNull { it.overIndex + 1 } ?: 0, st.seedOverRuns.size)
        val runs = IntArray(overs)
        val wk = IntArray(overs)
        st.seedOverRuns.forEachIndexed { i, r -> if (i < overs) runs[i] = r }
        for (b in st.allBalls) {
            if (b.overIndex in 0 until overs) {
                runs[b.overIndex] += b.runsAdded
                if (b.wicket) wk[b.overIndex] += 1
            }
        }
        return PanelInfo(
            kind = PanelKind.RUN_RATE, title = "RUN RATE",
            subtitle = "${st.battingTeam}  •  ${st.scoreText} (${st.oversText} ov)",
            overRuns = runs.toList(), overWickets = wk.toList(), oversLimit = st.oversLimit,
            requiredRate = st.requiredRunRate?.toFloat(), currentRate = st.runRate.toFloat(),
            footer = "CRR ${f2(st.runRate)}" + (st.requiredRunRate?.let { "     RRR ${f2(it)}" } ?: "") +
                (if (st.seedOvers > 0 && st.seedOverRuns.isEmpty()) "     (overs before ${st.seedOvers + 1} were not recorded ball by ball)" else "")
        )
    }

    fun comment(author: String, text: String, highlight: String?): PanelInfo = PanelInfo(
        kind = PanelKind.COMMENT,
        title = author.uppercase(),
        subtitle = highlight ?: "VIEWER COMMENT",
        footer = text
    )

    /** Splits a comment into at most two lines of about [perLine] characters (the second line ends with an ellipsis when cut). */
    fun wrapTwoLines(text: String, perLine: Int): List<String> {
        val words = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val lines = ArrayList<String>()
        var cur = ""
        for (w in words) {
            val t = if (cur.isEmpty()) w else "$cur $w"
            if (t.length > perLine && cur.isNotEmpty()) {
                lines.add(cur)
                cur = w
            } else {
                cur = t
            }
        }
        if (cur.isNotEmpty()) lines.add(cur)
        return if (lines.size <= 2) lines else listOf(lines[0], lines[1].take(perLine - 1) + "\u2026")
    }

    fun ballsFromOversText(text: String, ballsPerOver: Int): Int {
        val parts = text.split('.')
        val o = parts.getOrNull(0)?.toIntOrNull() ?: 0
        val b = parts.getOrNull(1)?.toIntOrNull() ?: 0
        return o * ballsPerOver + b
    }

    private fun ordinal(n: Int): String = when {
        n % 100 in 11..13 -> "${n}TH"
        n % 10 == 1 -> "${n}ST"
        n % 10 == 2 -> "${n}ND"
        n % 10 == 3 -> "${n}RD"
        else -> "${n}TH"
    }
}
