package com.zarvimo.cricket.graphics

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Bitmaps supplied by the data layer. Fields are volatile because the render thread reads them. */
class BroadcastAssets {
    @Volatile var background: Bitmap? = null
    @Volatile var logo: Bitmap? = null
    @Volatile var sponsor: Bitmap? = null
    @Volatile var teamALogo: Bitmap? = null
    @Volatile var teamBLogo: Bitmap? = null
}

/**
 * THE single compositor. The same instance + the same [OverlayData] / [GraphicsConfig] snapshot drive
 * every frame that is previewed AND encoded (RootEncoder's GL pipeline fans the surface out to both).
 * It draws in a fixed 1920x1080 reference space and scales uniformly to the output size.
 *
 * Not thread-safe: call [render] from ONE thread (the frame-pump thread).
 */
class BroadcastRenderer {

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val typefaces = HashMap<String, Typeface>()
    private var proceduralBg: Bitmap? = null

    fun render(
        canvas: Canvas,
        outW: Int,
        outH: Int,
        data: OverlayData,
        cfgIn: GraphicsConfig,
        assets: BroadcastAssets,
        timeMs: Long,
        /** False in camera mode: the camera image is the background and this canvas is a transparent overlay. */
        withBackground: Boolean = true
    ) {
        val cfg = cfgIn.sanitized()
        canvas.save()
        canvas.scale(outW / Ref.W, outH / Ref.H)

        if (withBackground) drawBackground(canvas, assets.background)
        drawImageBox(canvas, assets.logo, cfg, cfg.logoX, cfg.logoY, cfg.logoScale)
        if (cfg.showSponsor) drawImageBox(canvas, assets.sponsor, cfg, cfg.sponsorX, cfg.sponsorY, cfg.sponsorScale)

        val placement = BroadcastLayout.scoreboard(cfg, outH)
        val safe = BroadcastLayout.safeBox(cfg)

        // Cards (scorecard, Playing XI, toss, summary...) are drawn FIRST and fitted above/below the score strip, and the strip
        // is drawn on top of them, so the score stays visible with every card, like on an international broadcast.
        data.panel?.let { drawPanel(canvas, it, cfg, safe, placement.box, timeMs, assets) }

        canvas.save()
        canvas.translate(placement.box.left, placement.box.top)
        canvas.scale(placement.scale, placement.scale)
        when (cfg.template) {
            ScoreboardTemplate.CLASSIC -> drawClassic(canvas, data, cfg, assets)
            ScoreboardTemplate.MODERN_BAR -> drawModernBar(canvas, data, cfg, assets)
            ScoreboardTemplate.COMPACT -> drawCompact(canvas, data, cfg, assets)
            ScoreboardTemplate.TOP_STRIP -> drawTopStrip(canvas, data, cfg)
            ScoreboardTemplate.MINIMAL_PILL -> drawMinimalPill(canvas, data, cfg)
            ScoreboardTemplate.PRO_BROADCAST -> drawProBroadcast(canvas, data, cfg, assets)
            ScoreboardTemplate.TWO_TEAM_CARD -> drawTwoTeamCard(canvas, data, cfg, assets)
            ScoreboardTemplate.SIDE_CARD -> drawSideCard(canvas, data, cfg)
            ScoreboardTemplate.LED_BOARD -> drawLedBoard(canvas, data, cfg)
            else -> STRIPS[cfg.template]?.let { drawStrip(canvas, data, cfg, assets, cfg.template, it) }
        }
        canvas.restore()

        drawBanner(canvas, data, cfg, placement.box, safe)
        if (cfg.showMatchTitle && data.panel?.kind?.fullScreen != true) drawTitle(canvas, data, cfg, safe, placement.box)
        BroadcastLayout.tickerBox(cfg)?.let { drawTicker(canvas, it, data, cfg, timeMs) }
        drawExtras(canvas, data, cfg, safe, placement.box, timeMs, assets)

        canvas.restore()
    }

    // -------------------------------------------------------------------------------- background

    private fun drawBackground(c: Canvas, user: Bitmap?) {
        if (user != null && !user.isRecycled) {
            // centre-crop to 16:9
            val scale = max(Ref.W / user.width, Ref.H / user.height)
            val w = user.width * scale
            val h = user.height * scale
            rect.set((Ref.W - w) / 2f, (Ref.H - h) / 2f, (Ref.W + w) / 2f, (Ref.H + h) / 2f)
            fill.shader = null
            fill.alpha = 255
            c.drawBitmap(user, null, rect, fill)
            return
        }
        val bg = proceduralBg ?: buildProceduralBackground().also { proceduralBg = it }
        rect.set(0f, 0f, Ref.W, Ref.H)
        fill.shader = null
        fill.alpha = 255
        c.drawBitmap(bg, null, rect, fill)
    }

    /** Default stadium look (no external asset needed). Rendered once at half size and cached. */
    private fun buildProceduralBackground(): Bitmap {
        val bw = 960
        val bh = 540
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, bh * 0.55f, 0xFF050B1E.toInt(), 0xFF1D3F73.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), p)
        // floodlight glows
        for (cx in listOf(bw * 0.14f, bw * 0.86f)) {
            p.shader = RadialGradient(cx, bh * 0.12f, bw * 0.28f, 0x99FFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), p)
        }
        // stands
        p.shader = null
        p.color = 0xFF0A1022.toInt()
        c.drawRect(0f, bh * 0.30f, bw.toFloat(), bh * 0.43f, p)
        p.color = 0x55FFE082
        var i = 0
        while (i < 160) { // deterministic crowd lights
            val x = (i * 97 % bw).toFloat()
            val y = bh * 0.31f + (i * 53 % (bh * 0.11f).toInt())
            c.drawCircle(x, y, 1.6f, p)
            i++
        }
        // outfield
        p.shader = LinearGradient(0f, bh * 0.42f, 0f, bh.toFloat(), 0xFF2E7D32.toInt(), 0xFF14501A.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, bh * 0.42f, bw.toFloat(), bh.toFloat(), p)
        // mowing stripes
        p.shader = null
        p.color = 0x14FFFFFF
        var x = 0f
        var on = true
        while (x < bw) {
            if (on) c.drawRect(x, bh * 0.42f, x + 60f, bh.toFloat(), p)
            on = !on
            x += 60f
        }
        // pitch
        val path = Path()
        path.moveTo(bw * 0.465f, bh * 0.52f)
        path.lineTo(bw * 0.535f, bh * 0.52f)
        path.lineTo(bw * 0.63f, bh.toFloat())
        path.lineTo(bw * 0.37f, bh.toFloat())
        path.close()
        p.color = 0xCCC8A96A.toInt()
        c.drawPath(path, p)
        // vignette
        p.shader = RadialGradient(bw / 2f, bh / 2f, bw * 0.75f, 0x00000000, 0x88000000.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), p)
        return bmp
    }

    private fun drawImageBox(c: Canvas, bmp: Bitmap?, cfg: GraphicsConfig, nx: Float, ny: Float, scale: Float) {
        if (bmp == null || bmp.isRecycled || bmp.height == 0) return
        val box = BroadcastLayout.imageBox(cfg, nx, ny, scale, bmp.width.toFloat() / bmp.height)
        rect.set(box.left, box.top, box.right, box.bottom)
        fill.shader = null
        fill.alpha = 255
        c.drawBitmap(bmp, null, rect, fill)
    }

    // -------------------------------------------------------------------------------- templates

    private fun drawClassic(c: Canvas, d: OverlayData, cfg: GraphicsConfig, assets: BroadcastAssets) {
        val w = ScoreboardTemplate.CLASSIC.baseWidth
        val h = ScoreboardTemplate.CLASSIC.baseHeight

        // chip row (recent balls + chase)
        panel(c, 0f, 0f, w, 40f, cfg, alphaMul = 0.7f, radius = 10f)
        text(c, cfg, "THIS OVER", 18f, 29f, 22f, cfg.accentColor)
        drawBallChips(c, cfg, d.recentBalls.takeLast(10), 150f, 20f, 26f)
        val chase = d.chaseText ?: d.targetText
        if (chase != null) text(c, cfg, chase, w - 18f, 29f, 26f, cfg.textColor, align = Paint.Align.RIGHT, maxW = 560f)

        // main panel
        val top = 48f
        panel(c, 0f, top, w, h, cfg, radius = 14f)

        // team block
        fill.shader = null
        fill.color = d.battingColor
        rect.set(0f, top, 470f, h)
        c.drawRoundRect(rect, 14f, 14f, fill)
        val logo = if (cfg.showTeamLogos) (if (d.battingIsTeamA) assets.teamALogo else assets.teamBLogo) else null
        var tx = 22f
        if (logo != null) {
            drawBitmapFit(c, logo, 18f, top + 14f, 84f, 84f)
            tx = 116f
        }
        text(c, cfg, d.battingShort.ifEmpty { d.battingTeam }, tx, top + 54f, 50f, Color.WHITE, maxW = 330f)
        text(c, cfg, d.battingTeam, tx, top + 86f, 24f, 0xF0FFFFFF.toInt(), bold = false, maxW = 330f)
        text(c, cfg, d.score, 22f, top + 150f, 78f, Color.WHITE, maxW = 280f)
        text(c, cfg, "${d.overs}/${d.oversLimit} ov", 448f, top + 150f, 34f, cfg.accentColor, align = Paint.Align.RIGHT, maxW = 160f)

        // batters
        val bx = 500f
        batterRow(c, cfg, d.striker, bx, top + 52f, 600f)
        batterRow(c, cfg, d.nonStriker, bx, top + 112f, 600f)
        text(c, cfg, "CRR ${d.currentRunRate}" + (d.requiredRunRate?.let { "   RRR $it" } ?: ""), bx, top + 156f, 26f, 0xF0FFFFFF.toInt(), bold = false, maxW = 600f)

        // divider
        fill.color = withAlpha(cfg.accentColor, 200)
        rect.set(1120f, top + 18f, 1123f, h - 18f)
        c.drawRect(rect, fill)

        // bowler + last wicket
        text(c, cfg, "BOWLER", 1146f, top + 34f, 22f, cfg.accentColor)
        text(c, cfg, d.bowlerName ?: "-", 1146f, top + 74f, 38f, cfg.textColor, maxW = 400f)
        text(c, cfg, d.bowlerFigures ?: "", 1146f, top + 112f, 34f, cfg.accentColor, maxW = 400f)
        d.lastWicket?.let {
            text(c, cfg, "LAST WKT  $it", 1146f, top + 154f, 22f, 0xFFFF8A80.toInt(), bold = false, maxW = 400f)
        }
    }

    private fun drawModernBar(c: Canvas, d: OverlayData, cfg: GraphicsConfig, assets: BroadcastAssets) {
        val w = ScoreboardTemplate.MODERN_BAR.baseWidth
        val h = ScoreboardTemplate.MODERN_BAR.baseHeight
        panel(c, 0f, 0f, w, h, cfg, radius = 66f)
        // team capsule
        fill.shader = null
        fill.color = d.battingColor
        rect.set(0f, 0f, 520f, h)
        c.drawRoundRect(rect, 66f, 66f, fill)
        text(c, cfg, d.battingShort.ifEmpty { d.battingTeam }, 46f, 56f, 40f, Color.WHITE, maxW = 150f)
        text(c, cfg, d.score, 46f, 112f, 62f, Color.WHITE, maxW = 240f)
        text(c, cfg, d.overs, 496f, 56f, 40f, cfg.accentColor, align = Paint.Align.RIGHT, maxW = 150f)
        text(c, cfg, "/${d.oversLimit} ov", 496f, 106f, 26f, 0xF0FFFFFF.toInt(), align = Paint.Align.RIGHT, bold = false)

        batterRow(c, cfg, d.striker, 560f, 54f, 400f, size = 34f)
        batterRow(c, cfg, d.nonStriker, 560f, 106f, 400f, size = 34f)

        text(c, cfg, d.bowlerName ?: "-", 990f, 54f, 34f, cfg.textColor, maxW = 300f)
        text(c, cfg, d.bowlerFigures ?: "", 990f, 106f, 32f, cfg.accentColor, maxW = 300f)

        drawBallChips(c, cfg, d.recentBalls.takeLast(7), 1320f, 36f, 26f)
        val extra = d.chaseText ?: d.targetText ?: "CRR ${d.currentRunRate}"
        text(c, cfg, extra, 1760f, 108f, 24f, cfg.textColor, align = Paint.Align.RIGHT, maxW = 440f, bold = false)
    }

    private fun drawCompact(c: Canvas, d: OverlayData, cfg: GraphicsConfig, assets: BroadcastAssets) {
        val w = ScoreboardTemplate.COMPACT.baseWidth
        val h = ScoreboardTemplate.COMPACT.baseHeight
        panel(c, 0f, 0f, w, h, cfg, radius = 18f)
        fill.shader = null
        fill.color = d.battingColor
        rect.set(0f, 0f, w, 62f)
        c.drawRoundRect(rect, 18f, 18f, fill)
        text(c, cfg, d.battingTeam.ifEmpty { d.battingShort }, 20f, 42f, 34f, Color.WHITE, maxW = 400f)
        text(c, cfg, "${d.overs}/${d.oversLimit} ov", w - 20f, 42f, 28f, cfg.accentColor, align = Paint.Align.RIGHT, maxW = 200f)
        text(c, cfg, d.score, 20f, 134f, 76f, cfg.textColor, maxW = 300f)
        text(c, cfg, "CRR ${d.currentRunRate}", w - 20f, 104f, 26f, 0xF0FFFFFF.toInt(), align = Paint.Align.RIGHT, bold = false)
        (d.chaseText ?: d.targetText)?.let {
            text(c, cfg, it, w - 20f, 138f, 24f, cfg.accentColor, align = Paint.Align.RIGHT, maxW = 320f)
        }
        batterRow(c, cfg, d.striker, 20f, 178f, 380f, size = 28f)
        batterRow(c, cfg, d.nonStriker, 20f, 212f, 380f, size = 28f)
        text(c, cfg, "${d.bowlerName ?: "-"}  ${d.bowlerFigures ?: ""}", 20f, 250f, 26f, cfg.accentColor, maxW = 620f)
        drawBallChips(c, cfg, d.recentBalls.takeLast(8), 20f, 276f, 17f)
    }

    // -------------------------------------------------------------------------------- on-air extras

    /** Background picture only (used as the base layer when the camera bubble is on). */
    fun renderBackground(canvas: Canvas, outW: Int, outH: Int, assets: BroadcastAssets) {
        canvas.save()
        canvas.scale(outW / Ref.W, outH / Ref.H)
        drawBackground(canvas, assets.background)
        canvas.restore()
    }

    private fun drawExtras(c: Canvas, d: OverlayData, cfg: GraphicsConfig, safe: Box, board: Box, timeMs: Long, assets: BroadcastAssets) {
        if (d.preMatch != null) drawPreMatch(c, d, cfg, safe, board)
        d.alert?.let { drawAlert(c, it, cfg, safe, board, timeMs) }
        d.burst?.let { drawBurst(c, it, cfg, timeMs) }
    }

    /** Announcement banner: a coloured title band over a dark body with one line of detail. Slides in from the top. */
    private fun drawAlert(c: Canvas, a: AlertInfo, cfg: GraphicsConfig, safe: Box, board: Box, timeMs: Long) {
        val el = (timeMs - a.shownAtMs).coerceAtLeast(0L)
        val ease = easeOutBack(el / 450f)
        val w = min(safe.width, 1240f)
        val titleH = 96f
        val bodyH = if (a.sub.isBlank()) 0f else 62f
        val h = titleH + bodyH
        val x = (Ref.W - w) / 2f
        // keep clear of a scoreboard that sits at the top
        val top = if (board.top < Ref.H * 0.3f) board.bottom + 24f else safe.top + 36f
        val y = top - (1f - ease) * (h + 60f)
        c.saveLayerAlpha(0f, 0f, Ref.W, Ref.H, (255 * easeOut(el / 250f)).toInt().coerceIn(0, 255))
        panel(c, x, y, x + w, y + h, cfg, radius = 22f)
        fill.shader = LinearGradient(0f, y, 0f, y + titleH, shade(a.color, 1.2f), shade(a.color, 0.8f), Shader.TileMode.CLAMP)
        rect.set(x, y, x + w, y + titleH)
        c.drawRoundRect(rect, 22f, 22f, fill)
        if (bodyH > 0f) {
            rect.set(x, y + titleH - 24f, x + w, y + titleH)
            c.drawRect(rect, fill)
        }
        fill.shader = null
        text(c, cfg, a.title, x + w / 2f, y + 68f, 62f, Color.WHITE, align = Paint.Align.CENTER, maxW = w - 80f)
        if (bodyH > 0f) text(c, cfg, a.sub, x + w / 2f, y + titleH + 41f, 30f, cfg.textColor, bold = false, align = Paint.Align.CENTER, maxW = w - 60f)
        c.restore()
    }

    private fun drawPreMatch(c: Canvas, d: OverlayData, cfg: GraphicsConfig, safe: Box, board: Box) {
        val l1 = d.preMatch ?: return
        val l2 = d.preMatchSub
        val w1 = measure(cfg, l1, 40f)
        val w2 = if (l2 != null) measure(cfg, l2, 30f, false) else 0f
        val bw = min(max(w1, w2) + 100f, safe.width)
        val bh = if (l2 != null) 150f else 96f
        val x = (Ref.W - bw) / 2f
        val above = board.top - bh - 24f
        val y = if (above >= safe.top + 60f) above else safe.top + 70f
        panel(c, x, y, x + bw, y + bh, cfg, radius = 22f)
        fill.shader = null
        fill.color = cfg.accentColor
        rect.set(x, y, x + 12f, y + bh)
        c.drawRoundRect(rect, 6f, 6f, fill)
        text(c, cfg, l1, x + bw / 2f, y + 62f, 40f, cfg.accentColor, align = Paint.Align.CENTER, maxW = bw - 60f)
        if (l2 != null) text(c, cfg, l2, x + bw / 2f, y + 114f, 30f, cfg.textColor, bold = false, align = Paint.Align.CENTER, maxW = bw - 60f)
    }

    private fun easeOut(p: Float): Float {
        val q = 1f - p.coerceIn(0f, 1f)
        return 1f - q * q * q
    }

    private fun easeOutBack(p: Float): Float {
        val x = p.coerceIn(0f, 1f) - 1f
        val c1 = 1.70158f
        return 1f + (c1 + 1f) * x * x * x + c1 * x * x
    }

    /** Full-width ribbon with a big word that pops in, holds and fades. Time-based: nothing is stored between frames. */
    private fun drawBurst(c: Canvas, b: BurstInfo, cfg: GraphicsConfig, timeMs: Long) {
        val el = timeMs - b.startMs
        if (el < 0 || el > BurstInfo.DURATION_MS) return
        val t = el / 1000f
        val total = BurstInfo.DURATION_MS / 1000f
        val inP = (t / 0.35f).coerceIn(0f, 1f)
        val outP = ((total - t) / 0.45f).coerceIn(0f, 1f)
        val vis = min(inP, outP)
        val cy = Ref.H * 0.42f
        val band = 230f
        c.saveLayerAlpha(0f, 0f, Ref.W, Ref.H, (255 * vis).toInt().coerceIn(0, 255))

        fill.shader = null
        fill.color = Color.argb(95, 0, 0, 0)
        rect.set(0f, 0f, Ref.W, Ref.H)
        c.drawRect(rect, fill)

        val slide = (1f - easeOut(inP)) * -Ref.W
        val shake = if (b.kind == BurstKind.WICKET) sin(t * 70f) * 16f * max(0f, 1f - t / 0.5f) else 0f
        c.save()
        c.translate(slide + shake, 0f)
        fill.color = b.kind.color
        rect.set(0f, cy - band / 2f, Ref.W, cy + band / 2f)
        c.drawRect(rect, fill)
        fill.color = Color.WHITE
        rect.set(0f, cy - band / 2f, Ref.W, cy - band / 2f + 6f)
        c.drawRect(rect, fill)
        rect.set(0f, cy + band / 2f - 6f, Ref.W, cy + band / 2f)
        c.drawRect(rect, fill)
        c.restore()

        if (b.kind == BurstKind.SIX) {
            stroke.color = Color.WHITE
            stroke.strokeWidth = 6f
            for (i in 0 until 3) {
                val r = (t * 640f + i * 190f) % 760f
                stroke.alpha = (200 * (1f - r / 760f)).toInt().coerceIn(0, 255)
                c.drawCircle(Ref.W / 2f, cy, r, stroke)
            }
            stroke.alpha = 255
        }

        val pop = 0.55f + 0.45f * easeOutBack(inP)
        c.save()
        c.translate(shake, 0f)
        c.scale(pop, pop, Ref.W / 2f, cy + 50f)
        text(c, cfg, b.kind.text, Ref.W / 2f, cy + 62f, 190f, Color.WHITE, align = Paint.Align.CENTER, maxW = Ref.W - 200f)
        c.restore()
        if (b.detail.isNotBlank()) {
            text(c, cfg, b.detail.uppercase(), Ref.W / 2f, cy + band / 2f - 26f, 42f, 0xFFFFFFFF.toInt(), align = Paint.Align.CENTER, maxW = Ref.W - 260f)
        }
        c.restore()
    }

    // ---- card animation state (set by drawPanel, read by the card drawers; the renderer is single-threaded)
    private var cardEl = 0L
    private var cardExit = 0f

    /** The part of the frame a card may use: above the score strip when it is at the bottom, below it when it is at the top. */
    private fun panelArea(safe: Box, board: Box): Box {
        val gap = 20f
        val onBottom = (board.top + board.bottom) / 2f > Ref.H / 2f
        return if (onBottom) {
            Box(safe.left, safe.top, safe.right, min(safe.bottom, board.top - gap).coerceAtLeast(safe.top + 240f))
        } else {
            Box(safe.left, max(safe.top, board.bottom + gap).coerceAtMost(safe.bottom - 240f), safe.right, safe.bottom)
        }
    }

    /** 0..1 progress of the i-th item of a card: items appear one after the other after the card has settled. */
    private fun reveal(i: Int, startMs: Long = 380L, stepMs: Long = 65L, durMs: Float = 340f): Float =
        easeOut((cardEl - startMs - i * stepMs) / durMs)

    /** Draws [block] sliding in sideways by [dx] and fading in as [p] goes from 0 to 1 (and out again while the card leaves). */
    private fun withReveal(c: Canvas, p: Float, dx: Float, l: Float, t: Float, r: Float, b: Float, block: () -> Unit) {
        val q = p * (1f - cardExit)
        if (q >= 0.995f) { block(); return }
        if (q <= 0.01f) return
        c.save()
        c.translate((1f - p) * dx, 0f)
        c.saveLayerAlpha(l - 80f, t - 20f, r + 80f, b + 20f, (255 * q).toInt().coerceIn(0, 255))
        block()
        c.restore()
        c.restore()
    }

    private fun drawPanel(c: Canvas, p: PanelInfo, cfg: GraphicsConfig, safe: Box, board: Box, timeMs: Long, assets: BroadcastAssets) {
        val el = (timeMs - p.shownAtMs).coerceAtLeast(0L)
        val exit = if (p.exitAtMs > 0L) ((timeMs - p.exitAtMs) / 380f).coerceIn(0f, 1f) else 0f
        cardEl = el
        cardExit = exit
        val alpha = (255 * easeOut(el / 380f) * (1f - exit)).toInt().coerceIn(0, 255)
        if (alpha <= 0) return
        val area = panelArea(safe, board)
        val full = p.kind.fullScreen
        val designW = if (full) Ref.W else safe.width
        val designH = if (full) Ref.H else safe.height
        val designCx = if (full) Ref.W / 2f else (safe.left + safe.right) / 2f
        val designCy = if (full) Ref.H / 2f else (safe.top + safe.bottom) / 2f

        c.saveLayerAlpha(0f, 0f, Ref.W, Ref.H, alpha)
        if (full) drawCardBackdrop(c, p, cfg, el)

        // fit the card into the free area, slide it up into place and let it grow a little as it settles
        val fit = min(1f, min(area.width / designW, area.height / designH))
        val pop = 0.93f + 0.07f * easeOutBack(el / 650f)
        val slide = (1f - easeOut(el / 480f)) * 80f + exit * 60f
        c.save()
        c.translate((area.left + area.right) / 2f, (area.top + area.bottom) / 2f + slide)
        c.scale(fit * pop, fit * pop)
        c.translate(-designCx, -designCy)
        when (p.kind) {
            PanelKind.SCORECARD -> drawScorecard(c, p, cfg, safe)
            PanelKind.STRIKER, PanelKind.NON_STRIKER, PanelKind.BOWLER -> drawPlayerCard(c, p, cfg, safe, board)
            PanelKind.PARTNERSHIP -> drawPartnershipCard(c, p, cfg, safe, board)
            PanelKind.RUN_RATE -> drawRunRateGraph(c, p, cfg, safe)
            PanelKind.COMMENT -> drawCommentCard(c, p, cfg, safe, board)
            PanelKind.PLAYING_XI -> drawPlayingXi(c, p, cfg, safe)
            PanelKind.TOSS_CARD -> drawTossCard(c, p, cfg, assets)
            PanelKind.MAN_OF_MATCH -> drawManOfMatch(c, p, cfg, assets)
            PanelKind.RESULT_CARD -> drawResultCard(c, p, cfg, assets)
            PanelKind.MATCH_SUMMARY -> drawSummaryCard(c, p, cfg)
        }
        c.restore()
        c.restore()
    }

    /** Playing XI: two columns (one per team), numbered, in batting order. Row height shrinks for 12 to 15 players. */
    private fun drawPlayingXi(c: Canvas, p: PanelInfo, cfg: GraphicsConfig, safe: Box) {
        val w = min(safe.width, 1500f)
        val rows = max(1, max(p.bat.size, p.bowl.size))
        val headH = 84f
        val teamH = 62f
        val footH = if (p.footer.isNotBlank()) 46f else 20f
        val maxH = min(safe.height - 10f, 900f)
        val rowH = min(54f, (maxH - headH - teamH - footH) / rows)
        val h = headH + teamH + rows * rowH + footH
        val x = (Ref.W - w) / 2f
        val y = safe.top + (safe.height - h) / 2f
        panel(c, x, y, x + w, y + h, cfg, radius = 24f)
        fill.shader = null
        fill.color = withAlpha(cfg.accentColor, 240)
        rect.set(x, y, x + w, y + headH)
        c.drawRoundRect(rect, 24f, 24f, fill)
        rect.set(x, y + 50f, x + w, y + headH)
        c.drawRect(rect, fill)
        val dark = 0xFF111111.toInt()
        text(c, cfg, p.title, x + 30f, y + 58f, 44f, dark, maxW = w * 0.4f)
        text(c, cfg, p.subtitle, x + w - 30f, y + 56f, 30f, dark, align = Paint.Align.RIGHT, maxW = w * 0.55f)

        val colW = w / 2f
        val sz = (rowH * 0.56f).coerceIn(20f, 32f)
        val cols = listOf(
            Triple(p.batHeader.firstOrNull().orEmpty(), p.bat, if (p.colorA != 0) p.colorA else cfg.accentColor),
            Triple(p.bowlHeader.firstOrNull().orEmpty(), p.bowl, if (p.colorB != 0) p.colorB else cfg.accentColor)
        )
        cols.forEachIndexed { ci, (team, list, color) ->
            val cx = x + ci * colW
            val ty = y + headH
            fill.color = color
            rect.set(cx + 14f, ty + 8f, cx + colW - 14f, ty + teamH - 6f)
            c.drawRoundRect(rect, 14f, 14f, fill)
            text(c, cfg, team.uppercase(), cx + colW / 2f, ty + 46f, 34f, Color.WHITE, align = Paint.Align.CENTER, maxW = colW - 80f)
            if (list.isEmpty()) {
                text(c, cfg, "SQUAD NOT ENTERED", cx + colW / 2f, ty + teamH + rowH, sz, 0xDDFFFFFF.toInt(), bold = false, align = Paint.Align.CENTER)
            }
            list.forEachIndexed { i, r ->
                val ry = ty + teamH + i * rowH
                withReveal(c, reveal(i, 300L, 55L), if (ci == 0) -90f else 90f, cx + 14f, ry, cx + colW - 14f, ry + rowH) {
                    if (i % 2 == 0) {
                        fill.color = 0x16FFFFFF
                        rect.set(cx + 14f, ry, cx + colW - 14f, ry + rowH)
                        c.drawRect(rect, fill)
                    }
                    text(c, cfg, r.c1, cx + 62f, ry + rowH / 2f + sz * 0.35f, sz, cfg.accentColor, align = Paint.Align.RIGHT)
                    text(c, cfg, r.name, cx + 84f, ry + rowH / 2f + sz * 0.35f, sz, cfg.textColor, maxW = colW - 130f)
                }
            }
        }
        if (p.footer.isNotBlank()) text(c, cfg, p.footer, x + w / 2f, y + h - 16f, 22f, 0xF0FFFFFF.toInt(), bold = false, align = Paint.Align.CENTER, maxW = w - 60f)
    }

    // -------------------------------------------------------------------------------- full-screen cards

    /** Dark full-frame backdrop with a team-coloured diagonal band on each side (they slide in from the edges) and an accent line. */
    private fun drawCardBackdrop(c: Canvas, p: PanelInfo, cfg: GraphicsConfig, el: Long) {
        fill.shader = LinearGradient(0f, 0f, 0f, Ref.H, 0xF2070C1A.toInt(), 0xF2020510.toInt(), Shader.TileMode.CLAMP)
        rect.set(0f, 0f, Ref.W, Ref.H)
        c.drawRect(rect, fill)
        fill.shader = null
        val ca = if (p.colorA != 0) p.colorA else cfg.accentColor
        val cb = if (p.colorB != 0) p.colorB else ca
        val off = (1f - easeOut(el / 600f)) * Ref.W * 0.45f
        val left = Path().apply { moveTo(0f - off, 0f); lineTo(Ref.W * 0.36f - off, 0f); lineTo(Ref.W * 0.22f - off, Ref.H); lineTo(0f - off, Ref.H); close() }
        val right = Path().apply { moveTo(Ref.W + off, 0f); lineTo(Ref.W * 0.64f + off, 0f); lineTo(Ref.W * 0.78f + off, Ref.H); lineTo(Ref.W + off, Ref.H); close() }
        fill.color = withAlpha(ca, 95)
        c.drawPath(left, fill)
        fill.color = withAlpha(cb, 95)
        c.drawPath(right, fill)
        fill.color = cfg.accentColor
        val grow = easeOut(el / 700f)
        rect.set(Ref.W * (0.5f - 0.5f * grow), 0f, Ref.W * (0.5f + 0.5f * grow), 10f)
        c.drawRect(rect, fill)
        rect.set(Ref.W * (0.5f - 0.5f * grow), Ref.H - 10f, Ref.W * (0.5f + 0.5f * grow), Ref.H)
        c.drawRect(rect, fill)
    }

    private fun drawCardTitle(c: Canvas, p: PanelInfo, cfg: GraphicsConfig) {
        withReveal(c, reveal(0, 120L), 0f, 0f, 90f, Ref.W, 190f) {
            text(c, cfg, p.title, Ref.W / 2f, 150f, 78f, cfg.accentColor, align = Paint.Align.CENTER, maxW = Ref.W - 500f)
            fill.shader = null
            fill.color = cfg.accentColor
            rect.set(Ref.W / 2f - 220f, 176f, Ref.W / 2f + 220f, 181f)
            c.drawRect(rect, fill)
        }
    }

    /** Row of small label / value chips along the bottom of a card. */
    private fun drawCardChips(c: Canvas, cfg: GraphicsConfig, chips: List<Pair<String, String>>, y: Float) {
        if (chips.isEmpty()) return
        val gap = 28f
        val widths = chips.map { (k, v) -> max(measure(cfg, k, 22f, false), measure(cfg, v, 36f)) + 60f }
        val total = widths.sum() + gap * (chips.size - 1)
        var x = (Ref.W - min(total, Ref.W - 160f)) / 2f
        val scale = if (total > Ref.W - 160f) (Ref.W - 160f) / total else 1f
        chips.forEachIndexed { i, (k, v) ->
            val w = widths[i] * scale
            fill.color = 0x33FFFFFF
            rect.set(x, y, x + w, y + 112f)
            c.drawRoundRect(rect, 20f, 20f, fill)
            text(c, cfg, k, x + w / 2f, y + 38f, 22f, 0xF0FFFFFF.toInt(), bold = false, align = Paint.Align.CENTER, maxW = w - 20f)
            text(c, cfg, v, x + w / 2f, y + 86f, 36f, Color.WHITE, align = Paint.Align.CENTER, maxW = w - 20f)
            x += w + gap * scale
        }
    }

    private fun drawBigLogo(c: Canvas, cfg: GraphicsConfig, bmp: Bitmap?, name: String, cx: Float, cy: Float, size: Float, color: Int) {
        fill.shader = null
        fill.color = 0x26FFFFFF
        c.drawCircle(cx, cy, size * 0.62f, fill)
        if (bmp != null && !bmp.isRecycled) {
            drawBitmapFit(c, bmp, cx - size / 2f, cy - size / 2f, size, size)
        } else {
            fill.color = withAlpha(color, 230)
            c.drawCircle(cx, cy, size * 0.46f, fill)
            text(c, cfg, name.trim().take(1).uppercase(), cx, cy + size * 0.2f, size * 0.55f, Color.WHITE, align = Paint.Align.CENTER)
        }
        text(c, cfg, name.uppercase(), cx, cy + size * 0.62f + 52f, 40f, Color.WHITE, align = Paint.Align.CENTER, maxW = size * 1.8f)
    }

    private fun drawTossCard(c: Canvas, p: PanelInfo, cfg: GraphicsConfig, assets: BroadcastAssets) {
        drawCardTitle(c, p, cfg)
        val a = p.batHeader.firstOrNull().orEmpty()
        val b = p.bowlHeader.firstOrNull().orEmpty()
        withReveal(c, reveal(1), -160f, 100f, 300f, 520f, 800f) {
            drawBigLogo(c, cfg, assets.teamALogo, a, 300f, 470f, 250f, if (p.colorA != 0) p.colorA else cfg.accentColor)
        }
        withReveal(c, reveal(2), 160f, Ref.W - 520f, 300f, Ref.W - 100f, 800f) {
            drawBigLogo(c, cfg, assets.teamBLogo, b, Ref.W - 300f, 470f, 250f, if (p.colorB != 0) p.colorB else cfg.accentColor)
        }
        withReveal(c, reveal(3), 0f, 400f, 340f, Ref.W - 400f, 600f) {
            text(c, cfg, p.subtitle, Ref.W / 2f, 460f, 104f, Color.WHITE, align = Paint.Align.CENTER, maxW = 1000f)
            text(c, cfg, p.footer, Ref.W / 2f, 560f, 46f, cfg.accentColor, align = Paint.Align.CENTER, maxW = 1000f)
        }
        withReveal(c, reveal(5), 0f, 0f, 780f, Ref.W, 930f) { drawCardChips(c, cfg, p.stats, 800f) }
    }

    private fun drawManOfMatch(c: Canvas, p: PanelInfo, cfg: GraphicsConfig, assets: BroadcastAssets) {
        drawCardTitle(c, p, cfg)
        val logo = when (p.teamSide) { 1 -> assets.teamALogo; 2 -> assets.teamBLogo; else -> null }
        val team = p.stats.firstOrNull()?.second.orEmpty()
        withReveal(c, reveal(1), 0f, Ref.W / 2f - 300f, 240f, Ref.W / 2f + 300f, 700f) {
            drawBigLogo(c, cfg, logo, team, Ref.W / 2f, 400f, 230f, if (p.colorA != 0) p.colorA else cfg.accentColor)
        }
        withReveal(c, reveal(3), 0f, 100f, 650f, Ref.W - 100f, 780f) {
            text(c, cfg, p.subtitle, Ref.W / 2f, 760f, 110f, Color.WHITE, align = Paint.Align.CENTER, maxW = Ref.W - 360f)
        }
        if (p.footer.isNotBlank()) {
            withReveal(c, reveal(5), 0f, 100f, 800f, Ref.W - 100f, 880f) {
                text(c, cfg, p.footer, Ref.W / 2f, 850f, 52f, cfg.accentColor, align = Paint.Align.CENTER, maxW = Ref.W - 360f)
            }
        }
    }

    private fun drawResultCard(c: Canvas, p: PanelInfo, cfg: GraphicsConfig, assets: BroadcastAssets) {
        drawCardTitle(c, p, cfg)
        val first = p.stats.getOrNull(0)
        val second = p.stats.getOrNull(1)
        val logoFirst = if (p.teamSide == 1) assets.teamALogo else assets.teamBLogo
        val logoSecond = if (p.teamSide == 1) assets.teamBLogo else assets.teamALogo
        if (first != null) {
            withReveal(c, reveal(1), -160f, 40f, 280f, 600f, 800f) {
                drawBigLogo(c, cfg, logoFirst, first.first, 310f, 430f, 220f, if (p.colorA != 0) p.colorA else cfg.accentColor)
                text(c, cfg, first.second, 310f, 760f, 56f, Color.WHITE, align = Paint.Align.CENTER, maxW = 520f)
            }
        }
        if (second != null) {
            withReveal(c, reveal(2), 160f, Ref.W - 600f, 280f, Ref.W - 40f, 800f) {
                drawBigLogo(c, cfg, logoSecond, second.first, Ref.W - 310f, 430f, 220f, if (p.colorB != 0) p.colorB else cfg.accentColor)
                text(c, cfg, second.second, Ref.W - 310f, 760f, 56f, Color.WHITE, align = Paint.Align.CENTER, maxW = 520f)
            }
        }
        withReveal(c, reveal(3), 0f, 520f, 380f, Ref.W - 520f, 520f) {
            text(c, cfg, p.subtitle, Ref.W / 2f, 470f, 84f, cfg.accentColor, align = Paint.Align.CENTER, maxW = 880f)
        }
        if (p.footer.isNotBlank()) {
            withReveal(c, reveal(5), 0f, 100f, 880f, Ref.W - 100f, 960f) {
                text(c, cfg, p.footer, Ref.W / 2f, 930f, 46f, Color.WHITE, align = Paint.Align.CENTER, maxW = Ref.W - 300f)
            }
        }
    }

    private fun drawSummaryCard(c: Canvas, p: PanelInfo, cfg: GraphicsConfig) {
        drawCardTitle(c, p, cfg)
        text(c, cfg, p.subtitle, Ref.W / 2f, 232f, 34f, 0xF0FFFFFF.toInt(), bold = false, align = Paint.Align.CENTER, maxW = Ref.W - 300f)
        val colW = 820f
        val xs = listOf(Ref.W / 2f - colW - 30f, Ref.W / 2f + 30f)
        val cols = listOf(
            Triple(p.batHeader.firstOrNull().orEmpty(), p.bat, if (p.colorA != 0) p.colorA else cfg.accentColor),
            Triple(p.bowlHeader.firstOrNull().orEmpty(), p.bowl, if (p.colorB != 0) p.colorB else cfg.accentColor)
        )
        val top = 270f
        cols.forEachIndexed { ci, (head, rows, color) ->
            val x = xs[ci]
            fill.color = withAlpha(color, 235)
            rect.set(x, top, x + colW, top + 80f)
            c.drawRoundRect(rect, 18f, 18f, fill)
            text(c, cfg, head, x + 28f, top + 55f, 38f, Color.WHITE, maxW = colW - 56f)
            rows.forEachIndexed { i, r ->
                val ry = top + 100f + i * 78f
                withReveal(c, reveal(i + ci * 2), if (ci == 0) -120f else 120f, x, ry, x + colW, ry + 70f) {
                    fill.color = if (i % 2 == 0) 0x22FFFFFF else 0x10FFFFFF
                    rect.set(x, ry, x + colW, ry + 70f)
                    c.drawRoundRect(rect, 12f, 12f, fill)
                    text(c, cfg, r.sub, x + 22f, ry + 44f, 20f, cfg.accentColor, bold = false)
                    text(c, cfg, r.name.uppercase(), x + 100f, ry + 46f, 32f, Color.WHITE, maxW = colW - 330f)
                    text(c, cfg, r.c1, x + colW - 150f, ry + 48f, 38f, cfg.accentColor, align = Paint.Align.RIGHT)
                    text(c, cfg, r.c2, x + colW - 24f, ry + 46f, 26f, 0xF0FFFFFF.toInt(), bold = false, align = Paint.Align.RIGHT)
                }
            }
        }
        var y = top + 100f + 5 * 78f + 24f
        p.stats.forEach { (k, v) ->
            text(c, cfg, "$k:  $v", Ref.W / 2f, y, 30f, 0xF0FFFFFF.toInt(), bold = false, align = Paint.Align.CENTER, maxW = Ref.W - 300f)
            y += 40f
        }
        text(c, cfg, p.footer, Ref.W / 2f, Ref.H - 70f, 52f, cfg.accentColor, align = Paint.Align.CENTER, maxW = Ref.W - 240f)
    }

    private fun drawScorecard(c: Canvas, p: PanelInfo, cfg: GraphicsConfig, safe: Box) {
        val w = min(safe.width, 1640f)
        val h = min(safe.height - 10f, 820f)
        val x = (Ref.W - w) / 2f
        val y = safe.top + (safe.height - h) / 2f
        panel(c, x, y, x + w, y + h, cfg, radius = 24f)
        fill.shader = null
        fill.color = withAlpha(cfg.accentColor, 240)
        rect.set(x, y, x + w, y + 84f)
        c.drawRoundRect(rect, 24f, 24f, fill)
        rect.set(x, y + 50f, x + w, y + 84f)
        c.drawRect(rect, fill)
        val dark = 0xFF111111.toInt()
        text(c, cfg, p.title, x + 30f, y + 58f, 44f, dark, maxW = w * 0.45f)
        text(c, cfg, p.subtitle, x + w - 30f, y + 56f, 32f, dark, align = Paint.Align.RIGHT, maxW = w * 0.5f)

        val split = x + w * 0.60f
        val rowH = 54f
        val top = y + 84f
        val colGap = 84f
        // ---- batting table (left)
        val x0 = x + 28f
        val xr = split - 22f
        val batCols = FloatArray(5) { xr - (4 - it) * colGap }
        if (p.batHeader.size >= 6) {
            text(c, cfg, p.batHeader[0], x0, top + 40f, 22f, cfg.accentColor)
            for (i in 0 until 5) text(c, cfg, p.batHeader[i + 1], batCols[i], top + 40f, 22f, cfg.accentColor, align = Paint.Align.RIGHT)
        }
        val maxRows = max(1, ((h - 84f - 56f - 64f) / rowH).toInt())
        p.bat.take(maxRows).forEachIndexed { i, r ->
            val rt = top + 56f + i * rowH
            if (i % 2 == 0) {
                fill.color = 0x16FFFFFF
                rect.set(x + 14f, rt, split - 8f, rt + rowH)
                c.drawRect(rect, fill)
            }
            val nameColor = if (r.highlight) cfg.accentColor else cfg.textColor
            text(c, cfg, r.name, x0, rt + 28f, 28f, nameColor, maxW = batCols[0] - x0 - 70f)
            text(c, cfg, r.sub, x0, rt + 48f, 18f, 0xE6FFFFFF.toInt(), bold = false, maxW = batCols[0] - x0 - 70f)
            val vals = listOf(r.c1, r.c2, r.c3, r.c4, r.c5)
            for (k in 0 until 5) text(c, cfg, vals[k], batCols[k], rt + 36f, 28f, if (k == 0) cfg.accentColor else cfg.textColor, align = Paint.Align.RIGHT)
        }
        // divider
        fill.color = withAlpha(cfg.accentColor, 160)
        rect.set(split, top + 12f, split + 3f, y + h - 70f)
        c.drawRect(rect, fill)
        // ---- bowling table (right)
        val bx0 = split + 24f
        val bxr = x + w - 28f
        val bowlGap = 74f
        val bowlCols = FloatArray(5) { bxr - (4 - it) * bowlGap }
        if (p.bowlHeader.size >= 6) {
            text(c, cfg, p.bowlHeader[0], bx0, top + 40f, 22f, cfg.accentColor)
            for (i in 0 until 5) text(c, cfg, p.bowlHeader[i + 1], bowlCols[i], top + 40f, 22f, cfg.accentColor, align = Paint.Align.RIGHT)
        }
        p.bowl.take(maxRows).forEachIndexed { i, r ->
            val rt = top + 56f + i * rowH
            if (i % 2 == 0) {
                fill.color = 0x16FFFFFF
                rect.set(split + 12f, rt, x + w - 14f, rt + rowH)
                c.drawRect(rect, fill)
            }
            text(c, cfg, r.name, bx0, rt + 36f, 26f, if (r.highlight) cfg.accentColor else cfg.textColor, maxW = bowlCols[0] - bx0 - 50f)
            val vals = listOf(r.c1, r.c2, r.c3, r.c4, r.c5)
            for (k in 0 until 5) text(c, cfg, vals[k], bowlCols[k], rt + 36f, 26f, if (k == 3) cfg.accentColor else cfg.textColor, align = Paint.Align.RIGHT)
        }
        text(c, cfg, p.footer, x + 30f, y + h - 26f, 21f, 0xF0FFFFFF.toInt(), bold = false, maxW = w - 60f)
    }

    /** Lower-third position: above the scoreboard when there is room, otherwise just below it. */
    private fun lowerThirdY(safe: Box, board: Box, h: Float): Float {
        val above = board.top - h - 16f
        if (above >= safe.top + 8f) return above
        val below = board.bottom + 16f
        return if (below + h <= safe.bottom) below else safe.top + 8f
    }

    private fun drawPlayerCard(c: Canvas, p: PanelInfo, cfg: GraphicsConfig, safe: Box, board: Box) {
        val w = min(1240f, safe.width)
        val h = 150f
        val x = board.left.coerceIn(safe.left, max(safe.left, safe.right - w))
        val y = lowerThirdY(safe, board, h)
        panel(c, x, y, x + w, y + h, cfg, radius = 20f)
        val nameW = 430f
        fill.shader = null
        fill.color = cfg.accentColor
        rect.set(x, y, x + nameW, y + h)
        c.drawRoundRect(rect, 20f, 20f, fill)
        rect.set(x + nameW - 24f, y, x + nameW, y + h)
        c.drawRect(rect, fill)
        val dark = 0xFF111111.toInt()
        text(c, cfg, p.title, x + 26f, y + 70f, 44f, dark, maxW = nameW - 44f)
        text(c, cfg, p.subtitle, x + 26f, y + 112f, 21f, dark, bold = false, maxW = nameW - 44f)
        val n = max(1, p.stats.size)
        val slot = (w - nameW - 20f) / n
        p.stats.forEachIndexed { i, kv ->
            val cx = x + nameW + 10f + slot * (i + 0.5f)
            text(c, cfg, kv.first, cx, y + 54f, 22f, cfg.accentColor, align = Paint.Align.CENTER)
            text(c, cfg, kv.second, cx, y + 114f, 56f, cfg.textColor, align = Paint.Align.CENTER, maxW = slot - 10f)
        }
    }

    private fun drawCommentCard(c: Canvas, p: PanelInfo, cfg: GraphicsConfig, safe: Box, board: Box) {
        val w = min(1240f, safe.width)
        val h = 190f
        val x = board.left.coerceIn(safe.left, max(safe.left, safe.right - w))
        val y = lowerThirdY(safe, board, h)
        panel(c, x, y, x + w, y + h, cfg, radius = 20f)
        val leftW = 330f
        fill.shader = null
        fill.color = cfg.accentColor
        rect.set(x, y, x + leftW, y + h)
        c.drawRoundRect(rect, 20f, 20f, fill)
        rect.set(x + leftW - 24f, y, x + leftW, y + h)
        c.drawRect(rect, fill)
        val dark = 0xFF111111.toInt()
        text(c, cfg, p.title, x + 24f, y + 92f, 34f, dark, maxW = leftW - 44f)
        text(c, cfg, p.subtitle, x + 24f, y + 130f, 21f, dark, bold = false, maxW = leftW - 44f)
        val lines = PanelBuilder.wrapTwoLines(p.footer, 46)
        lines.forEachIndexed { i, line ->
            text(c, cfg, line, x + leftW + 28f, y + 84f + i * 54f, 36f, cfg.textColor, bold = false, maxW = w - leftW - 56f)
        }
    }

    private fun drawPartnershipCard(c: Canvas, p: PanelInfo, cfg: GraphicsConfig, safe: Box, board: Box) {
        val w = min(1240f, safe.width)
        val h = 170f
        val x = board.left.coerceIn(safe.left, max(safe.left, safe.right - w))
        val y = lowerThirdY(safe, board, h)
        panel(c, x, y, x + w, y + h, cfg, radius = 20f)
        val leftW = 380f
        fill.shader = null
        fill.color = cfg.accentColor
        rect.set(x, y, x + leftW, y + h)
        c.drawRoundRect(rect, 20f, 20f, fill)
        rect.set(x + leftW - 24f, y, x + leftW, y + h)
        c.drawRect(rect, fill)
        val dark = 0xFF111111.toInt()
        text(c, cfg, p.title, x + 26f, y + 76f, 42f, dark, maxW = leftW - 44f)
        text(c, cfg, p.subtitle, x + 26f, y + 118f, 21f, dark, bold = false, maxW = leftW - 44f)
        val statsW = 470f
        val slot = statsW / max(1, p.stats.size)
        p.stats.forEachIndexed { i, kv ->
            val cx = x + leftW + slot * (i + 0.5f)
            text(c, cfg, kv.first, cx, y + 58f, 22f, cfg.accentColor, align = Paint.Align.CENTER)
            text(c, cfg, kv.second, cx, y + 124f, 60f, cfg.textColor, align = Paint.Align.CENTER, maxW = slot - 10f)
        }
        val bx = x + leftW + statsW + 20f
        p.bat.take(2).forEachIndexed { i, r ->
            val base = y + 66f + i * 56f
            text(c, cfg, r.name, bx, base, 30f, if (r.highlight) cfg.accentColor else cfg.textColor, maxW = x + w - bx - 190f)
            text(c, cfg, r.c1, x + w - 96f, base, 34f, cfg.accentColor, align = Paint.Align.RIGHT)
            text(c, cfg, r.c2, x + w - 24f, base, 26f, 0xF0FFFFFF.toInt(), bold = false, align = Paint.Align.RIGHT)
        }
    }

    private fun drawRunRateGraph(c: Canvas, p: PanelInfo, cfg: GraphicsConfig, safe: Box) {
        val w = min(1320f, safe.width)
        val h = min(safe.height - 10f, 600f)
        val x = (Ref.W - w) / 2f
        val y = safe.top + (safe.height - h) / 2f
        panel(c, x, y, x + w, y + h, cfg, radius = 24f)
        fill.shader = null
        fill.color = withAlpha(cfg.accentColor, 240)
        rect.set(x, y, x + w, y + 76f)
        c.drawRoundRect(rect, 24f, 24f, fill)
        rect.set(x, y + 44f, x + w, y + 76f)
        c.drawRect(rect, fill)
        val dark = 0xFF111111.toInt()
        text(c, cfg, p.title, x + 30f, y + 54f, 42f, dark)
        text(c, cfg, p.subtitle, x + w - 30f, y + 52f, 28f, dark, align = Paint.Align.RIGHT, maxW = w * 0.62f)

        val left = x + 90f
        val right = x + w - 40f
        val plotTop = y + 120f
        val plotBottom = y + h - 90f
        val slots = max(1, max(p.oversLimit, p.overRuns.size))
        val maxRuns = max(12, p.overRuns.maxOrNull() ?: 0)
        val yMax = (ceil(maxRuns / 6f) * 6f).coerceAtLeast(12f)
        val plotH = plotBottom - plotTop
        val slotW = (right - left) / slots

        // grid + y labels
        var g = 0f
        while (g <= yMax + 0.1f) {
            val gy = plotBottom - plotH * (g / yMax)
            fill.color = 0x26FFFFFF
            rect.set(left, gy - 1f, right, gy + 1f)
            c.drawRect(rect, fill)
            text(c, cfg, g.toInt().toString(), left - 12f, gy + 7f, 20f, 0xF0FFFFFF.toInt(), bold = false, align = Paint.Align.RIGHT)
            g += 6f
        }
        // bars
        p.overRuns.forEachIndexed { i, r ->
            val bh = plotH * (r / yMax)
            val bx = left + i * slotW + slotW * 0.15f
            fill.color = cfg.accentColor
            rect.set(bx, plotBottom - bh, bx + slotW * 0.7f, plotBottom)
            c.drawRect(rect, fill)
            text(c, cfg, r.toString(), bx + slotW * 0.35f, plotBottom - bh - 8f, 20f, cfg.textColor, align = Paint.Align.CENTER)
            if ((p.overWickets.getOrNull(i) ?: 0) > 0) {
                fill.color = 0xFFE53935.toInt()
                c.drawCircle(bx + slotW * 0.35f, plotBottom - bh - 34f, 13f, fill)
                text(c, cfg, "W", bx + slotW * 0.35f, plotBottom - bh - 27f, 16f, Color.WHITE, align = Paint.Align.CENTER)
            }
        }
        // x labels
        val step = if (slots > 30) 5 else if (slots > 15) 2 else 1
        for (i in 0 until slots) {
            if ((i + 1) % step == 0 || i == 0) text(c, cfg, (i + 1).toString(), left + i * slotW + slotW / 2f, plotBottom + 30f, 20f, 0xF0FFFFFF.toInt(), bold = false, align = Paint.Align.CENTER)
        }
        text(c, cfg, "OVERS", (left + right) / 2f, plotBottom + 62f, 20f, cfg.accentColor, align = Paint.Align.CENTER)
        // reference lines (dashed): current run rate and required run rate
        stroke.strokeWidth = 4f
        stroke.pathEffect = DashPathEffect(floatArrayOf(18f, 12f), 0f)
        if (p.currentRate > 0f) {
            val ly = plotBottom - plotH * (p.currentRate / yMax).coerceIn(0f, 1f)
            stroke.color = Color.WHITE
            c.drawLine(left, ly, right, ly, stroke)
        }
        p.requiredRate?.let { rr ->
            val ly = plotBottom - plotH * (rr / yMax).coerceIn(0f, 1f)
            stroke.color = 0xFFFF4081.toInt()
            c.drawLine(left, ly, right, ly, stroke)
        }
        stroke.pathEffect = null
        text(c, cfg, p.footer, x + 30f, y + h - 24f, 24f, 0xFFFFFFFF.toInt(), maxW = w - 60f)
    }

    // -------------------------------------------------------------------------------- more templates

    private fun drawTopStrip(c: Canvas, d: OverlayData, cfg: GraphicsConfig) {
        val w = ScoreboardTemplate.TOP_STRIP.baseWidth
        val h = ScoreboardTemplate.TOP_STRIP.baseHeight
        panel(c, 0f, 0f, w, h, cfg, radius = 16f)
        fill.shader = null
        fill.color = d.battingColor
        rect.set(0f, 0f, 250f, h)
        c.drawRoundRect(rect, 16f, 16f, fill)
        text(c, cfg, d.battingShort.ifEmpty { d.battingTeam }, 22f, 62f, 44f, Color.WHITE, maxW = 210f)
        text(c, cfg, d.score, 266f, 66f, 56f, cfg.textColor, maxW = 230f)
        text(c, cfg, "${d.overs}/${d.oversLimit} ov", 520f, 42f, 30f, cfg.accentColor, maxW = 160f)
        text(c, cfg, d.targetText ?: "CRR ${d.currentRunRate}", 520f, 78f, 24f, 0xF0FFFFFF.toInt(), bold = false, maxW = 160f)
        batterRow(c, cfg, d.striker, 706f, 40f, 360f, size = 27f)
        batterRow(c, cfg, d.nonStriker, 706f, 78f, 360f, size = 27f)
        text(c, cfg, d.bowlerName ?: "-", 1100f, 40f, 27f, cfg.textColor, maxW = 230f)
        text(c, cfg, d.bowlerFigures ?: "", 1100f, 78f, 27f, cfg.accentColor, maxW = 230f)
        drawBallChips(c, cfg, d.recentBalls.takeLast(5), 1306f, 48f, 15f)
    }

    private fun drawMinimalPill(c: Canvas, d: OverlayData, cfg: GraphicsConfig) {
        val w = ScoreboardTemplate.MINIMAL_PILL.baseWidth
        val h = ScoreboardTemplate.MINIMAL_PILL.baseHeight
        panel(c, 0f, 0f, w, h, cfg, radius = h / 2f)
        fill.shader = null
        fill.color = d.battingColor
        rect.set(0f, 0f, 136f, h)
        c.drawRoundRect(rect, h / 2f, h / 2f, fill)
        text(c, cfg, d.battingShort.ifEmpty { d.battingTeam }, 24f, 50f, 34f, Color.WHITE, maxW = 96f)
        text(c, cfg, d.score, 152f, 54f, 46f, cfg.textColor, maxW = 250f)
        text(c, cfg, "${d.overs} ov", w - 22f, 36f, 26f, cfg.accentColor, align = Paint.Align.RIGHT, maxW = 120f)
        text(c, cfg, "CRR ${d.currentRunRate}", w - 22f, 62f, 20f, 0xF0FFFFFF.toInt(), align = Paint.Align.RIGHT, bold = false, maxW = 120f)
    }

    private fun drawProBroadcast(c: Canvas, d: OverlayData, cfg: GraphicsConfig, assets: BroadcastAssets) {
        val w = ScoreboardTemplate.PRO_BROADCAST.baseWidth
        val h = ScoreboardTemplate.PRO_BROADCAST.baseHeight
        val top = 14f
        // accent line on top of the panel
        fill.shader = null
        fill.color = cfg.accentColor
        rect.set(0f, 0f, w, 9f)
        c.drawRoundRect(rect, 4f, 4f, fill)
        panel(c, 0f, top, w, h, cfg, radius = 14f)
        // slanted team block
        val block = Path()
        block.moveTo(0f, top)
        block.lineTo(580f, top)
        block.lineTo(530f, h)
        block.lineTo(0f, h)
        block.close()
        fill.shader = null
        fill.color = d.battingColor
        c.drawPath(block, fill)
        val logo = if (cfg.showTeamLogos) (if (d.battingIsTeamA) assets.teamALogo else assets.teamBLogo) else null
        var tx = 26f
        if (logo != null) {
            drawBitmapFit(c, logo, 20f, top + 18f, 80f, 80f)
            tx = 112f
        }
        text(c, cfg, d.battingShort.ifEmpty { d.battingTeam }, tx, top + 62f, 54f, Color.WHITE, maxW = 330f)
        text(c, cfg, d.battingTeam, tx, top + 92f, 22f, 0xF0FFFFFF.toInt(), bold = false, maxW = 330f)
        text(c, cfg, d.score, 26f, h - 14f, 64f, Color.WHITE, maxW = 330f)
        text(c, cfg, "${d.overs}/${d.oversLimit} ov", 500f, h - 18f, 30f, cfg.accentColor, align = Paint.Align.RIGHT, maxW = 140f)
        // batters
        batterRow(c, cfg, d.striker, 612f, top + 62f, 540f, size = 36f)
        batterRow(c, cfg, d.nonStriker, 612f, top + 118f, 540f, size = 36f)
        // divider
        fill.color = withAlpha(cfg.accentColor, 200)
        rect.set(1190f, top + 18f, 1193f, h - 18f)
        c.drawRect(rect, fill)
        // bowler + this over
        text(c, cfg, "BOWLING", 1220f, top + 30f, 20f, cfg.accentColor)
        text(c, cfg, d.bowlerName ?: "-", 1220f, top + 70f, 34f, cfg.textColor, maxW = 270f)
        text(c, cfg, d.bowlerFigures ?: "", 1220f, top + 108f, 32f, cfg.accentColor, maxW = 270f)
        drawBallChips(c, cfg, d.recentBalls.takeLast(6), 1220f, h - 22f, 14f)
        // run rate / chase
        text(c, cfg, "CRR", 1530f, top + 30f, 20f, cfg.accentColor)
        text(c, cfg, d.currentRunRate, 1530f, top + 72f, 42f, cfg.textColor, maxW = 140f)
        (d.chaseText ?: d.targetText)?.let { text(c, cfg, it, w - 20f, h - 18f, 22f, cfg.textColor, align = Paint.Align.RIGHT, maxW = 240f) }
    }

    private fun drawTwoTeamCard(c: Canvas, d: OverlayData, cfg: GraphicsConfig, assets: BroadcastAssets) {
        val w = ScoreboardTemplate.TWO_TEAM_CARD.baseWidth
        val h = ScoreboardTemplate.TWO_TEAM_CARD.baseHeight
        panel(c, 0f, 0f, w, h, cfg, radius = 18f)
        fill.shader = null
        fill.color = d.battingColor
        rect.set(0f, 0f, 500f, h)
        c.drawRoundRect(rect, 18f, 18f, fill)
        fill.color = d.bowlingColor
        rect.set(w - 500f, 0f, w, h)
        c.drawRoundRect(rect, 18f, 18f, fill)
        val logo = if (cfg.showTeamLogos) (if (d.battingIsTeamA) assets.teamALogo else assets.teamBLogo) else null
        var tx = 28f
        if (logo != null) {
            drawBitmapFit(c, logo, 18f, 14f, 70f, 70f)
            tx = 100f
        }
        text(c, cfg, d.battingShort.ifEmpty { d.battingTeam }, tx, 64f, 52f, Color.WHITE, maxW = 380f)
        text(c, cfg, "BATTING", 28f, 100f, 22f, cfg.accentColor)
        drawBallChips(c, cfg, d.recentBalls.takeLast(6), 28f, 124f, 12f)
        text(c, cfg, d.score, w / 2f, 92f, 76f, cfg.textColor, align = Paint.Align.CENTER, maxW = 230f)
        text(c, cfg, "${d.overs} / ${d.oversLimit} ov", w / 2f, 134f, 28f, cfg.accentColor, align = Paint.Align.CENTER, maxW = 230f)
        text(c, cfg, d.bowlingShort.ifEmpty { d.bowlingTeam }, w - 28f, 64f, 52f, Color.WHITE, align = Paint.Align.RIGHT, maxW = 440f)
        val right = d.targetText ?: if (d.inningsNumber <= 1) "YET TO BAT" else ""
        text(c, cfg, right, w - 28f, 108f, 28f, cfg.accentColor, align = Paint.Align.RIGHT, maxW = 440f)
        (d.chaseText)?.let { text(c, cfg, it, w - 28f, 138f, 20f, 0xFFFFFFFF.toInt(), align = Paint.Align.RIGHT, bold = false, maxW = 440f) }
    }

    private fun drawSideCard(c: Canvas, d: OverlayData, cfg: GraphicsConfig) {
        val w = ScoreboardTemplate.SIDE_CARD.baseWidth
        val h = ScoreboardTemplate.SIDE_CARD.baseHeight
        panel(c, 0f, 0f, w, h, cfg, radius = 22f)
        fill.shader = null
        fill.color = d.battingColor
        rect.set(0f, 0f, w, 96f)
        c.drawRoundRect(rect, 22f, 22f, fill)
        text(c, cfg, d.battingShort.ifEmpty { d.battingTeam }, 26f, 64f, 50f, Color.WHITE, maxW = 290f)
        text(c, cfg, "${d.overs}/${d.oversLimit}", w - 26f, 62f, 32f, cfg.accentColor, align = Paint.Align.RIGHT, maxW = 150f)
        text(c, cfg, d.score, 26f, 196f, 100f, cfg.textColor, maxW = 450f)
        text(c, cfg, "CRR ${d.currentRunRate}" + (d.requiredRunRate?.let { "   RRR $it" } ?: ""), 26f, 238f, 26f, 0xF0FFFFFF.toInt(), bold = false, maxW = 450f)
        (d.chaseText ?: d.targetText)?.let { text(c, cfg, it, 26f, 274f, 26f, cfg.accentColor, maxW = 450f) }
        fill.color = withAlpha(cfg.accentColor, 200)
        rect.set(26f, 292f, w - 26f, 295f)
        c.drawRect(rect, fill)
        batterRow(c, cfg, d.striker, 26f, 342f, 448f, size = 32f)
        batterRow(c, cfg, d.nonStriker, 26f, 390f, 448f, size = 32f)
        text(c, cfg, "BOWLER", 26f, 434f, 20f, cfg.accentColor)
        text(c, cfg, "${d.bowlerName ?: "-"}  ${d.bowlerFigures ?: ""}", 26f, 470f, 30f, cfg.textColor, maxW = 448f)
        drawBallChips(c, cfg, d.recentBalls.takeLast(8), 26f, 510f, 15f)
    }

    private fun drawLedBoard(c: Canvas, d: OverlayData, cfg: GraphicsConfig) {
        val w = ScoreboardTemplate.LED_BOARD.baseWidth
        val h = ScoreboardTemplate.LED_BOARD.baseHeight
        rect.set(0f, 0f, w, h)
        fill.shader = null
        fill.color = 0xFF070707.toInt()
        fill.alpha = (cfg.panelOpacity * 255).toInt().coerceIn(0, 255)
        c.drawRoundRect(rect, 14f, 14f, fill)
        fill.alpha = 255
        stroke.strokeWidth = max(2f, cfg.borderWidthPx)
        stroke.color = cfg.accentColor
        c.drawRoundRect(rect, 14f, 14f, stroke)
        val led = cfg.accentColor
        text(c, cfg, d.battingShort.ifEmpty { d.battingTeam }, 30f, 40f, 30f, 0xF0FFFFFF.toInt(), maxW = 300f)
        text(c, cfg, d.score, 30f, 108f, 78f, led, maxW = 340f)
        text(c, cfg, "OVERS", 410f, 40f, 20f, 0xDDFFFFFF.toInt())
        text(c, cfg, d.overs, 410f, 108f, 62f, led, maxW = 190f)
        text(c, cfg, "CRR", 660f, 40f, 20f, 0xDDFFFFFF.toInt())
        text(c, cfg, d.currentRunRate, 660f, 108f, 62f, led, maxW = 200f)
        text(c, cfg, d.chaseText ?: d.targetText ?: "${d.battingTeam} vs ${d.bowlingTeam}", 900f, 44f, 28f, cfg.textColor, maxW = 440f)
        d.striker?.let { text(c, cfg, "${it.name}  ${it.runs} (${it.balls})", 900f, 84f, 28f, led, maxW = 440f) }
        text(c, cfg, "${d.bowlerName ?: "-"}  ${d.bowlerFigures ?: ""}", 900f, 116f, 24f, 0xF0FFFFFF.toInt(), bold = false, maxW = 440f)
    }


    // -------------------------------------------------------------------------------- broadcast strips (10 designs)

    private enum class StripShape { CAPSULE, ANGLED, CHEVRON, TRAPEZOID }

    private class StripStyle(
        val shape: StripShape,
        val skew: Float,
        val bgTop: Int,
        val bgBottom: Int,
        val edge: Int,
        val glow: Int,
        val text: Int,
        val sub: Int,
        val accent: Int,
        val doubleEdge: Boolean = false,
        val light: Boolean = false,
        /** Colour of a pill behind the score (0 = none). */
        val pill: Int = 0
    )

    private val STRIPS: Map<ScoreboardTemplate, StripStyle> = mapOf(
        ScoreboardTemplate.NEON_ARENA to StripStyle(StripShape.ANGLED, 30f, 0xFF0A1F52.toInt(), 0xFF061230.toInt(), 0xFF2BD9FF.toInt(), 0xFF2BD9FF.toInt(), Color.WHITE, 0xFFB8D4FF.toInt(), 0xFF4DD0FF.toInt()),
        ScoreboardTemplate.CAPSULE_FLAG to StripStyle(StripShape.CAPSULE, 0f, 0xFF1A5FD6.toInt(), 0xFF0B3592.toInt(), 0xFF8DBBFF.toInt(), 0xFF3D8BFF.toInt(), Color.WHITE, 0xFFD6E6FF.toInt(), 0xFFBFD8FF.toInt(), pill = 0xFFFFFFFF.toInt()),
        ScoreboardTemplate.GOLD_CHEVRON to StripStyle(StripShape.CHEVRON, 42f, 0xFF1D1D1D.toInt(), 0xFF050505.toInt(), 0xFFE0A526.toInt(), 0xFFE0A526.toInt(), Color.WHITE, 0xFFD9D2C0.toInt(), 0xFFFFC94D.toInt(), doubleEdge = true),
        ScoreboardTemplate.VIOLET_RUSH to StripStyle(StripShape.ANGLED, 46f, 0xFF5B1FA8.toInt(), 0xFF2A0C5E.toInt(), 0xFFD35BFF.toInt(), 0xFFB43CFF.toInt(), Color.WHITE, 0xFFE6D2FF.toInt(), 0xFFFFD6FF.toInt()),
        ScoreboardTemplate.GLASS_WHITE to StripStyle(StripShape.CAPSULE, 0f, 0xFFFFFFFF.toInt(), 0xFFD9E5F2.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0xFF0B1B33.toInt(), 0xFF3D4D66.toInt(), 0xFF1B8A3A.toInt(), light = true),
        ScoreboardTemplate.ROYAL_HEX to StripStyle(StripShape.CHEVRON, 34f, 0xFF0D2A66.toInt(), 0xFF061540.toInt(), 0xFFB9CCFF.toInt(), 0xFF3D6BFF.toInt(), Color.WHITE, 0xFFC4D3F5.toInt(), 0xFFFFD27A.toInt(), doubleEdge = true),
        ScoreboardTemplate.BLUE_GLOW to StripStyle(StripShape.CAPSULE, 0f, 0xFF1E88FF.toInt(), 0xFF0A47B8.toInt(), 0xFF9FD3FF.toInt(), 0xFF00B0FF.toInt(), Color.WHITE, 0xFFE1F0FF.toInt(), 0xFFE1F5FF.toInt()),
        ScoreboardTemplate.BLACK_GOLD to StripStyle(StripShape.TRAPEZOID, 30f, 0xFF161616.toInt(), 0xFF000000.toInt(), 0xFFFFC107.toInt(), 0xFFFFC107.toInt(), Color.WHITE, 0xFFD8D0B8.toInt(), 0xFFFFC107.toInt()),
        ScoreboardTemplate.LIGHT_CAPSULE to StripStyle(StripShape.CAPSULE, 0f, 0xFFF4F8FF.toInt(), 0xFFCFE0F7.toInt(), 0xFF8DB4E8.toInt(), 0xFF8DB4E8.toInt(), 0xFF0B1B33.toInt(), 0xFF3D4D66.toInt(), 0xFF0B5ED7.toInt(), light = true),
        ScoreboardTemplate.CRIMSON_GOLD to StripStyle(StripShape.CHEVRON, 38f, 0xFF7A0F14.toInt(), 0xFF3A0508.toInt(), 0xFFF2B63D.toInt(), 0xFFF2B63D.toInt(), Color.WHITE, 0xFFF1D9C8.toInt(), 0xFFFFD27A.toInt(), doubleEdge = true)
    )

    private fun stripPath(shape: StripShape, l: Float, t: Float, r: Float, b: Float, k: Float): Path {
        val p = Path()
        when (shape) {
            StripShape.CAPSULE -> p.addRoundRect(RectF(l, t, r, b), (b - t) / 2f, (b - t) / 2f, Path.Direction.CW)
            StripShape.ANGLED -> {
                p.moveTo(l + k, t); p.lineTo(r, t); p.lineTo(r - k, b); p.lineTo(l, b); p.close()
            }
            StripShape.CHEVRON -> {
                val m = (t + b) / 2f
                p.moveTo(l + k, t); p.lineTo(r - k, t); p.lineTo(r, m); p.lineTo(r - k, b); p.lineTo(l + k, b); p.lineTo(l, m); p.close()
            }
            StripShape.TRAPEZOID -> {
                p.moveTo(l + k, t); p.lineTo(r - k, t); p.lineTo(r, b); p.lineTo(l, b); p.close()
            }
        }
        return p
    }

    /** Team badge: the team logo when there is one, otherwise a round monogram. */
    private fun drawBadge(c: Canvas, cfg: GraphicsConfig, bmp: Bitmap?, label: String, x: Float, y: Float, w: Float, h: Float, st: StripStyle) {
        if (bmp != null && !bmp.isRecycled) {
            rect.set(x - 4f, y - 4f, x + w + 4f, y + h + 4f)
            fill.shader = null
            fill.color = 0x33FFFFFF
            c.drawRoundRect(rect, 12f, 12f, fill)
            drawBitmapFit(c, bmp, x, y, w, h)
            return
        }
        val r = min(w, h) / 2f
        fill.shader = null
        fill.color = if (st.light) 0x22000000 else 0x33FFFFFF
        c.drawCircle(x + w / 2f, y + h / 2f, r, fill)
        stroke.strokeWidth = 3f
        stroke.color = 0xCCFFFFFF.toInt()
        c.drawCircle(x + w / 2f, y + h / 2f, r - 1.5f, stroke)
        text(c, cfg, label.take(1), x + w / 2f, y + h / 2f + r * 0.42f, r * 1.25f, Color.WHITE, align = Paint.Align.CENTER)
    }

    private fun drawStrip(c: Canvas, d: OverlayData, cfg: GraphicsConfig, assets: BroadcastAssets, t: ScoreboardTemplate, st: StripStyle) {
        val w = t.baseWidth
        val totalH = t.baseHeight
        val mainH = 108f
        val op = (cfg.panelOpacity * 255).toInt().coerceIn(0, 255)
        val blockW = 270f

        // ---- bottom info bar (drawn first, the main bar overlaps its top edge)
        val bx0 = blockW + 20f
        val bx1 = w - blockW - 20f
        val bar = Path().apply {
            moveTo(bx0, mainH - 8f); lineTo(bx1, mainH - 8f); lineTo(bx1 - 28f, totalH); lineTo(bx0 + 28f, totalH); close()
        }
        fill.shader = LinearGradient(0f, mainH, 0f, totalH, shade(st.bgTop, 1.0f), shade(st.bgBottom, 0.9f), Shader.TileMode.CLAMP)
        fill.alpha = op
        c.drawPath(bar, fill)
        fill.shader = null
        fill.alpha = 255
        stroke.strokeJoin = Paint.Join.ROUND
        stroke.strokeWidth = 2f
        stroke.color = withAlpha(st.edge, 200)
        c.drawPath(bar, stroke)

        val parts = ArrayList<Pair<String, Int>>()
        parts += "CRR: ${d.currentRunRate}" to st.text
        d.targetValue?.let { parts += "TARGET: $it" to st.text }
        if (d.requiredRuns != null && d.ballsLeft != null) {
            parts += "REQUIRED: ${d.requiredRuns} RUN${if (d.requiredRuns == 1) "" else "S"} IN ${d.ballsLeft} BALL${if (d.ballsLeft == 1) "" else "S"}" to st.accent
        } else if (d.targetValue == null) {
            parts += "${d.oversLimit} OVERS MATCH" to st.text
        }
        val sep = "   |   "
        var size = 25f
        var total = parts.sumOf { measure(cfg, it.first, size).toDouble() }.toFloat() + measure(cfg, sep, size, false) * (parts.size - 1)
        val maxTotal = (bx1 - bx0) - 90f
        if (total > maxTotal) {
            size = 25f * maxTotal / total
            total = maxTotal
        }
        var tx = (bx0 + bx1) / 2f - total / 2f
        parts.forEachIndexed { i, (txt, col) ->
            text(c, cfg, txt, tx, mainH + 28f, size, col, align = Paint.Align.LEFT)
            tx += measure(cfg, txt, size)
            if (i < parts.size - 1) {
                text(c, cfg, sep, tx, mainH + 28f, size, withAlpha(st.text, 150), bold = false)
                tx += measure(cfg, sep, size, false)
            }
        }

        // ---- main body: glow, fill, edge
        val body = stripPath(st.shape, 0f, 0f, w, mainH, st.skew)
        for ((i, gw) in listOf(16f, 10f, 5f).withIndex()) {
            stroke.strokeWidth = gw
            stroke.color = withAlpha(st.glow, 26 + i * 22)
            c.drawPath(body, stroke)
        }
        fill.shader = LinearGradient(0f, 0f, 0f, mainH, st.bgTop, st.bgBottom, Shader.TileMode.CLAMP)
        fill.alpha = op
        c.drawPath(body, fill)
        fill.shader = null
        fill.alpha = 255

        // ---- team blocks (clipped to the body)
        c.save()
        c.clipPath(body)
        val left = Path().apply { moveTo(0f, 0f); lineTo(blockW, 0f); lineTo(blockW - 34f, mainH); lineTo(0f, mainH); close() }
        val right = Path().apply { moveTo(w - blockW + 34f, 0f); lineTo(w, 0f); lineTo(w, mainH); lineTo(w - blockW, mainH); close() }
        fill.shader = LinearGradient(0f, 0f, 0f, mainH, shade(d.battingColor, 1.25f), shade(d.battingColor, 0.75f), Shader.TileMode.CLAMP)
        c.drawPath(left, fill)
        fill.shader = LinearGradient(0f, 0f, 0f, mainH, shade(d.bowlingColor, 1.25f), shade(d.bowlingColor, 0.75f), Shader.TileMode.CLAMP)
        c.drawPath(right, fill)
        fill.shader = null
        // thin highlight at the block edges
        stroke.strokeWidth = 3f
        stroke.color = withAlpha(st.edge, 230)
        c.drawLine(blockW, 0f, blockW - 34f, mainH, stroke)
        c.drawLine(w - blockW + 34f, 0f, w - blockW, mainH, stroke)
        c.restore()

        stroke.strokeWidth = max(2.5f, cfg.borderWidthPx)
        stroke.color = st.edge
        c.drawPath(body, stroke)
        if (st.doubleEdge) {
            stroke.strokeWidth = 3f
            stroke.color = withAlpha(st.bgBottom, 255)
            c.drawPath(body, stroke)
        }
        stroke.strokeJoin = Paint.Join.MITER

        // ---- teams
        val logoBat = if (cfg.showTeamLogos) (if (d.battingIsTeamA) assets.teamALogo else assets.teamBLogo) else null
        val logoBowl = if (cfg.showTeamLogos) (if (d.battingIsTeamA) assets.teamBLogo else assets.teamALogo) else null
        val batCode = d.battingShort.ifEmpty { d.battingTeam }
        val bowlCode = d.bowlingShort.ifEmpty { d.bowlingTeam }
        val bh = 58f
        val by = (mainH - bh) / 2f
        val codeMaxW = blockW - 118f - 44f
        drawBadge(c, cfg, logoBat, batCode, 26f + st.skew * 0.3f, by, 78f, bh, st)
        text(c, cfg, batCode, 118f + st.skew * 0.3f, mainH / 2f + 17f, 50f, Color.WHITE, maxW = codeMaxW)
        drawBadge(c, cfg, logoBowl, bowlCode, w - 104f - st.skew * 0.3f, by, 78f, bh, st)
        text(c, cfg, bowlCode, w - 118f - st.skew * 0.3f, mainH / 2f + 17f, 50f, Color.WHITE, align = Paint.Align.RIGHT, maxW = codeMaxW)

        // ---- score + overs
        val sx = blockW + 28f
        if (st.pill != 0) {
            rect.set(sx - 16f, 15f, sx + 206f, mainH - 15f)
            fill.color = st.pill
            c.drawRoundRect(rect, (mainH - 30f) / 2f, (mainH - 30f) / 2f, fill)
            text(c, cfg, d.score, sx + 95f, mainH / 2f + 21f, 60f, 0xFF0B1E4B.toInt(), align = Paint.Align.CENTER, maxW = 200f)
        } else {
            text(c, cfg, d.score, sx, mainH / 2f + 21f, 62f, st.text, maxW = 200f)
        }
        val ox = sx + 224f
        text(c, cfg, "(${d.overs})", ox, mainH / 2f + 2f, 32f, st.accent, maxW = 100f)
        text(c, cfg, "OVERS", ox, mainH / 2f + 28f, 17f, st.sub, bold = true)

        // ---- batters: big names, runs in the same strong colour as the name, balls smaller
        val x0 = 612f
        stripBatter(c, cfg, d.striker, x0, 45f, 330f, st)
        stripBatter(c, cfg, d.nonStriker, x0, 88f, 330f, st)

        // ---- divider + bowler (name on the first line, figures and the last balls on the second: nothing overlaps)
        fill.color = withAlpha(st.edge, 190)
        rect.set(958f, 18f, 961f, mainH - 18f)
        c.drawRect(rect, fill)
        val bwx = 984f
        val bowlW = (w - blockW) - 22f - bwx
        fill.shader = null
        fill.color = st.text
        c.drawCircle(bwx + 10f, 34f, 10f, fill)
        stroke.strokeWidth = 2f
        stroke.color = withAlpha(st.bgBottom, 220)
        c.drawArc(RectF(bwx + 3f, 27f, bwx + 17f, 41f), 200f, 140f, false, stroke)
        text(c, cfg, d.bowlerName ?: "-", bwx + 30f, 44f, 29f, st.text, maxW = bowlW - 30f)
        text(c, cfg, d.bowlerFigures ?: "", bwx, 90f, 30f, st.accent, maxW = 128f)
        drawBallChips(c, cfg, d.recentBalls.takeLast(6), bwx + 136f, 80f, 11f)
    }

    private fun stripBatter(c: Canvas, cfg: GraphicsConfig, b: BatterLine?, x: Float, baseline: Float, width: Float, st: StripStyle) {
        if (b == null) {
            text(c, cfg, "-", x + 22f, baseline, 28f, withAlpha(st.sub, 160), bold = false)
            return
        }
        if (b.onStrike) {
            val tri = Path().apply { moveTo(x, baseline - 20f); lineTo(x + 14f, baseline - 10f); lineTo(x, baseline); close() }
            fill.shader = null
            fill.color = st.accent
            c.drawPath(tri, fill)
        }
        text(c, cfg, b.name.uppercase(), x + 24f, baseline, 29f, st.text, maxW = 208f)
        text(c, cfg, "${b.runs}", x + 282f, baseline, 33f, st.text, align = Paint.Align.RIGHT)
        text(c, cfg, "(${b.balls})", x + width, baseline, 24f, st.sub, align = Paint.Align.RIGHT)
    }

    // -------------------------------------------------------------------------------- pieces

    private fun batterRow(c: Canvas, cfg: GraphicsConfig, b: BatterLine?, x: Float, baseline: Float, width: Float, size: Float = 38f) {
        if (b == null) {
            text(c, cfg, "-", x, baseline, size, 0x88FFFFFF.toInt(), bold = false)
            return
        }
        val marker = if (b.onStrike) "\u25B6 " else "   "
        text(c, cfg, marker + b.name, x, baseline, size, if (b.onStrike) cfg.textColor else 0xFFFFFFFF.toInt(), maxW = width * 0.62f)
        text(c, cfg, "${b.runs}", x + width * 0.78f, baseline, size * 1.1f, cfg.accentColor, align = Paint.Align.RIGHT)
        text(c, cfg, "(${b.balls})", x + width, baseline, size * 0.8f, 0xF0FFFFFF.toInt(), align = Paint.Align.RIGHT, bold = false)
    }

    private fun drawBallChips(c: Canvas, cfg: GraphicsConfig, labels: List<String>, x: Float, centerY: Float, r: Float) {
        var cx = x + r
        for (l in labels) {
            fill.shader = null
            fill.color = chipColor(l)
            c.drawCircle(cx, centerY, r, fill)
            val sz = if (l.length <= 2) r * 1.05f else r * 0.7f
            text(c, cfg, l, cx, centerY + sz * 0.35f, sz, Color.WHITE, align = Paint.Align.CENTER, maxW = r * 1.9f)
            cx += r * 2.35f
        }
    }

    private fun chipColor(l: String): Int = when {
        l.contains("W") && !l.startsWith("Wd") -> 0xFFD32F2F.toInt()
        l.startsWith("Wd") || l.startsWith("Nb") || l.endsWith("b") || l.endsWith("lb") -> 0xFFF57C00.toInt()
        l == "6" -> 0xFF8E24AA.toInt()
        l == "4" -> 0xFF1976D2.toInt()
        l == "0" -> 0xFF455A64.toInt()
        else -> 0xFF2E7D32.toInt()
    }

    private fun panel(c: Canvas, l: Float, t: Float, r: Float, b: Float, cfg: GraphicsConfig, alphaMul: Float = 1f, radius: Float = 12f) {
        rect.set(l, t, r, b)
        fill.shader = LinearGradient(l, t, l, b, shade(cfg.primaryColor, 1.18f), shade(cfg.primaryColor, 0.78f), Shader.TileMode.CLAMP)
        fill.alpha = (cfg.panelOpacity * alphaMul * 255).toInt().coerceIn(0, 255)
        c.drawRoundRect(rect, radius, radius, fill)
        fill.shader = null
        fill.alpha = 255
        if (cfg.borderWidthPx > 0f) {
            stroke.strokeWidth = cfg.borderWidthPx
            stroke.color = cfg.borderColor
            c.drawRoundRect(rect, radius, radius, stroke)
        }
    }

    private fun drawBitmapFit(c: Canvas, bmp: Bitmap, x: Float, y: Float, w: Float, h: Float) {
        if (bmp.isRecycled || bmp.width == 0 || bmp.height == 0) return
        val s = min(w / bmp.width, h / bmp.height)
        val dw = bmp.width * s
        val dh = bmp.height * s
        rect.set(x + (w - dw) / 2f, y + (h - dh) / 2f, x + (w + dw) / 2f, y + (h + dh) / 2f)
        fill.shader = null
        fill.alpha = 255
        c.drawBitmap(bmp, null, rect, fill)
    }

    private fun drawBanner(c: Canvas, d: OverlayData, cfg: GraphicsConfig, board: Box, safe: Box) {
        val msg = d.resultText ?: d.banner ?: return
        val isFreeHit = d.banner == "FREE HIT" && d.resultText == null
        val size = 34f
        val tw = measure(cfg, msg, size) + 56f
        val bw = min(tw, safe.width)
        val x = ((Ref.W - bw) / 2f).coerceIn(safe.left, safe.right - bw)
        val above = board.top - 56f
        val y = if (above >= safe.top) above else min(board.bottom + 10f, safe.bottom - 50f)
        rect.set(x, y, x + bw, y + 46f)
        fill.shader = null
        fill.color = if (isFreeHit) 0xFFD81B60.toInt() else withAlpha(cfg.accentColor, 235)
        c.drawRoundRect(rect, 23f, 23f, fill)
        val fg = if (isFreeHit) Color.WHITE else 0xFF111111.toInt()
        text(c, cfg, msg, x + bw / 2f, y + 34f, size, fg, align = Paint.Align.CENTER, maxW = bw - 24f)
    }

    private fun drawTitle(c: Canvas, d: OverlayData, cfg: GraphicsConfig, safe: Box, board: Box) {
        val t = listOf(d.title, d.venue).filter { it.isNotBlank() }.joinToString("  \u2022  ")
        if (t.isBlank()) return
        val size = 26f
        val bw = min(measure(cfg, t, size) + 44f, safe.width * 0.5f)
        val x = (Ref.W - bw) / 2f
        var y = safe.top + cfg.marginPx
        // A scoreboard parked at the top must not be covered by the title tag: move the tag just below it.
        val overlapsBoard = y < board.bottom && y + 40f > board.top && x < board.right && x + bw > board.left
        if (overlapsBoard) {
            y = board.bottom + 10f
            if (y + 40f > safe.bottom) return
        }
        rect.set(x, y, x + bw, y + 40f)
        fill.shader = null
        fill.color = withAlpha(shade(cfg.primaryColor, 0.7f), (cfg.panelOpacity * 255).toInt())
        c.drawRoundRect(rect, 20f, 20f, fill)
        text(c, cfg, t, x + bw / 2f, y + 29f, size, cfg.textColor, align = Paint.Align.CENTER, maxW = bw - 24f)
    }

    private fun drawTicker(c: Canvas, box: Box, d: OverlayData, cfg: GraphicsConfig, timeMs: Long) {
        val msg = cfg.tickerText.ifBlank { tickerFallback(d) }
        rect.set(box.left, box.top, box.right, box.bottom)
        fill.shader = null
        fill.color = withAlpha(shade(cfg.primaryColor, 0.65f), (cfg.panelOpacity * 255).toInt())
        c.drawRoundRect(rect, 12f, 12f, fill)
        c.save()
        c.clipRect(rect)
        val size = 30f
        val tw = measure(cfg, msg, size)
        val gap = 260f
        val period = tw + gap
        val offset = (timeMs * 0.09f) % period
        var x = box.left - offset
        while (x < box.right) {
            text(c, cfg, msg, x, box.top + 37f, size, cfg.textColor, bold = false)
            x += period
        }
        c.restore()
    }

    private fun tickerFallback(d: OverlayData): String {
        val parts = mutableListOf<String>()
        if (d.battingTeam.isNotBlank() && d.bowlingTeam.isNotBlank()) parts += "${d.battingTeam} vs ${d.bowlingTeam}"
        if (d.score != "0/0" || d.overs != "0.0") parts += "${d.battingShort} ${d.score} (${d.overs} ov)"
        d.targetText?.let { parts += it }
        d.lastWicket?.let { parts += "Last wicket: $it" }
        return parts.joinToString("   \u2022   ").ifBlank { "Welcome to the live broadcast" }
    }

    // -------------------------------------------------------------------------------- text utils

    private fun typeface(cfg: GraphicsConfig, bold: Boolean): Typeface =
        typefaces.getOrPut("${cfg.font.family}/$bold") {
            Typeface.create(cfg.font.family, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }

    private fun measure(cfg: GraphicsConfig, s: String, size: Float, bold: Boolean = true): Float {
        textPaint.typeface = typeface(cfg, bold)
        textPaint.textSize = size
        return textPaint.measureText(s)
    }

    private fun text(
        c: Canvas, cfg: GraphicsConfig, s: String, x: Float, baseline: Float, size: Float, color: Int,
        bold: Boolean = true, align: Paint.Align = Paint.Align.LEFT, maxW: Float = Float.MAX_VALUE
    ) {
        if (s.isEmpty()) return
        textPaint.typeface = typeface(cfg, bold)
        textPaint.textAlign = align
        var sz = size
        textPaint.textSize = sz
        var out = s
        if (maxW != Float.MAX_VALUE) {
            var w = textPaint.measureText(out)
            if (w > maxW) { // shrink up to 70%, then ellipsize
                sz = max(size * 0.8f, size * maxW / w)
                textPaint.textSize = sz
                w = textPaint.measureText(out)
                while (w > maxW && out.length > 1) {
                    out = out.dropLast(1)
                    w = textPaint.measureText("$out\u2026")
                }
                if (out.length < s.length) out += "\u2026"
            }
        }
        textPaint.setShadowLayer(4f, 0f, 2f, if (isDark(color)) 0x66FFFFFF else 0xCC000000.toInt())
        textPaint.color = color
        c.drawText(out, x, baseline, textPaint)
        textPaint.clearShadowLayer()
    }

    /** Dark text gets a light halo, light text a dark one, so it stays readable on any panel colour. */
    private fun isDark(color: Int): Boolean {
        val r = Color.red(color); val g = Color.green(color); val b = Color.blue(color)
        return (0.299f * r + 0.587f * g + 0.114f * b) < 110f
    }

    private fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    private fun shade(color: Int, f: Float): Int {
        val r = (Color.red(color) * f).toInt().coerceIn(0, 255)
        val g = (Color.green(color) * f).toInt().coerceIn(0, 255)
        val b = (Color.blue(color) * f).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }

    fun release() {
        proceduralBg?.recycle()
        proceduralBg = null
        typefaces.clear()
    }
}
