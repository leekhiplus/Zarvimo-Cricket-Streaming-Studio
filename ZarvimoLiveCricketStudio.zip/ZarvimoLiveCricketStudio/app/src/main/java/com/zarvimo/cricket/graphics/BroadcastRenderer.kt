package com.zarvimo.cricket.graphics

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.max
import kotlin.math.min

/** Bitmaps supplied by the data layer. Fields are volatile because the render thread reads them. */
class BroadcastAssets {
    @Volatile var background: Bitmap? = null
    @Volatile var logo: Bitmap? = null
    @Volatile var sponsor: Bitmap? = null
    @Volatile var teamALogo: Bitmap? = null
    @Volatile var teamBLogo: Bitmap? = null
}

/**
 * THE single compositor. The same instance + the same [OverlayData] / [GraphicsConfig] snapshot drive
 * every frame that is previewed AND encoded (RootEncoder's GL pipeline fans the surface out to both).
 * It draws in a fixed 1920x1080 reference space and scales uniformly to the output size.
 *
 * Not thread-safe: call [render] from ONE thread (the frame-pump thread).
 */
class BroadcastRenderer {

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val typefaces = HashMap<String, Typeface>()
    private var proceduralBg: Bitmap? = null

    fun render(
        canvas: Canvas,
        outW: Int,
        outH: Int,
        data: OverlayData,
        cfgIn: GraphicsConfig,
        assets: BroadcastAssets,
        timeMs: Long
    ) {
        val cfg = cfgIn.sanitized()
        canvas.save()
        canvas.scale(outW / Ref.W, outH / Ref.H)

        drawBackground(canvas, assets.background)
        drawImageBox(canvas, assets.logo, cfg, cfg.logoX, cfg.logoY, cfg.logoScale)
        if (cfg.showSponsor) drawImageBox(canvas, assets.sponsor, cfg, cfg.sponsorX, cfg.sponsorY, cfg.sponsorScale)

        val placement = BroadcastLayout.scoreboard(cfg, outH)
        val safe = BroadcastLayout.safeBox(cfg)

        canvas.save()
        canvas.translate(placement.box.left, placement.box.top)
        canvas.scale(placement.scale, placement.scale)
        when (cfg.template) {
            ScoreboardTemplate.CLASSIC -> drawClassic(canvas, data, cfg, assets)
            ScoreboardTemplate.MODERN_BAR -> drawModernBar(canvas, data, cfg, assets)
            ScoreboardTemplate.COMPACT -> drawCompact(canvas, data, cfg, assets)
        }
        canvas.restore()

        drawBanner(canvas, data, cfg, placement.box, safe)
        if (cfg.showMatchTitle) drawTitle(canvas, data, cfg, safe)
        BroadcastLayout.tickerBox(cfg)?.let { drawTicker(canvas, it, data, cfg, timeMs) }

        canvas.restore()
    }

    // -------------------------------------------------------------------------------- background

    private fun drawBackground(c: Canvas, user: Bitmap?) {
        if (user != null && !user.isRecycled) {
            // centre-crop to 16:9
            val scale = max(Ref.W / user.width, Ref.H / user.height)
            val w = user.width * scale
            val h = user.height * scale
            rect.set((Ref.W - w) / 2f, (Ref.H - h) / 2f, (Ref.W + w) / 2f, (Ref.H + h) / 2f)
            fill.shader = null
            fill.alpha = 255
            c.drawBitmap(user, null, rect, fill)
            return
        }
        val bg = proceduralBg ?: buildProceduralBackground().also { proceduralBg = it }
        rect.set(0f, 0f, Ref.W, Ref.H)
        fill.shader = null
        fill.alpha = 255
        c.drawBitmap(bg, null, rect, fill)
    }

    /** Default stadium look (no external asset needed). Rendered once at half size and cached. */
    private fun buildProceduralBackground(): Bitmap {
        val bw = 960
        val bh = 540
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, bh * 0.55f, 0xFF050B1E.toInt(), 0xFF1D3F73.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), p)
        // floodlight glows
        for (cx in listOf(bw * 0.14f, bw * 0.86f)) {
            p.shader = RadialGradient(cx, bh * 0.12f, bw * 0.28f, 0x99FFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), p)
        }
        // stands
        p.shader = null
        p.color = 0xFF0A1022.toInt()
        c.drawRect(0f, bh * 0.30f, bw.toFloat(), bh * 0.43f, p)
        p.color = 0x55FFE082
        var i = 0
        while (i < 160) { // deterministic crowd lights
            val x = (i * 97 % bw).toFloat()
            val y = bh * 0.31f + (i * 53 % (bh * 0.11f).toInt())
            c.drawCircle(x, y, 1.6f, p)
            i++
        }
        // outfield
        p.shader = LinearGradient(0f, bh * 0.42f, 0f, bh.toFloat(), 0xFF2E7D32.toInt(), 0xFF14501A.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, bh * 0.42f, bw.toFloat(), bh.toFloat(), p)
        // mowing stripes
        p.shader = null
        p.color = 0x14FFFFFF
        var x = 0f
        var on = true
        while (x < bw) {
            if (on) c.drawRect(x, bh * 0.42f, x + 60f, bh.toFloat(), p)
            on = !on
            x += 60f
        }
        // pitch
        val path = Path()
        path.moveTo(bw * 0.465f, bh * 0.52f)
        path.lineTo(bw * 0.535f, bh * 0.52f)
        path.lineTo(bw * 0.63f, bh.toFloat())
        path.lineTo(bw * 0.37f, bh.toFloat())
        path.close()
        p.color = 0xCCC8A96A.toInt()
        c.drawPath(path, p)
        // vignette
        p.shader = RadialGradient(bw / 2f, bh / 2f, bw * 0.75f, 0x00000000, 0x88000000.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), p)
        return bmp
    }

    private fun drawImageBox(c: Canvas, bmp: Bitmap?, cfg: GraphicsConfig, nx: Float, ny: Float, scale: Float) {
        if (bmp == null || bmp.isRecycled || bmp.height == 0) return
        val box = BroadcastLayout.imageBox(cfg, nx, ny, scale, bmp.width.toFloat() / bmp.height)
        rect.set(box.left, box.top, box.right, box.bottom)
        fill.shader = null
        fill.alpha = 255
        c.drawBitmap(bmp, null, rect, fill)
    }

    // -------------------------------------------------------------------------------- templates

    private fun drawClassic(c: Canvas, d: OverlayData, cfg: GraphicsConfig, assets: BroadcastAssets) {
        val w = ScoreboardTemplate.CLASSIC.baseWidth
        val h = ScoreboardTemplate.CLASSIC.baseHeight

        // chip row (recent balls + chase)
        panel(c, 0f, 0f, w, 40f, cfg, alphaMul = 0.7f, radius = 10f)
        text(c, cfg, "THIS OVER", 18f, 29f, 22f, cfg.accentColor)
        drawBallChips(c, cfg, d.recentBalls.takeLast(10), 150f, 20f, 26f)
        val chase = d.chaseText ?: d.targetText
        if (chase != null) text(c, cfg, chase, w - 18f, 29f, 26f, cfg.textColor, align = Paint.Align.RIGHT, maxW = 560f)

        // main panel
        val top = 48f
        panel(c, 0f, top, w, h, cfg, radius = 14f)

        // team block
        fill.shader = null
        fill.color = d.battingColor
        rect.set(0f, top, 470f, h)
        c.drawRoundRect(rect, 14f, 14f, fill)
        val logo = if (cfg.showTeamLogos) (if (d.battingIsTeamA) assets.teamALogo else assets.teamBLogo) else null
        var tx = 22f
        if (logo != null) {
            drawBitmapFit(c, logo, 18f, top + 14f, 84f, 84f)
            tx = 116f
        }
        text(c, cfg, d.battingShort.ifEmpty { d.battingTeam }, tx, top + 54f, 50f, Color.WHITE, maxW = 330f)
        text(c, cfg, d.battingTeam, tx, top + 86f, 24f, 0xCCFFFFFF.toInt(), bold = false, maxW = 330f)
        text(c, cfg, d.score, 22f, top + 150f, 78f, Color.WHITE, maxW = 280f)
        text(c, cfg, "${d.overs}/${d.oversLimit} ov", 448f, top + 150f, 34f, cfg.accentColor, align = Paint.Align.RIGHT, maxW = 160f)

        // batters
        val bx = 500f
        batterRow(c, cfg, d.striker, bx, top + 52f, 600f)
        batterRow(c, cfg, d.nonStriker, bx, top + 112f, 600f)
        text(c, cfg, "CRR ${d.currentRunRate}" + (d.requiredRunRate?.let { "   RRR $it" } ?: ""), bx, top + 156f, 26f, 0xCCFFFFFF.toInt(), bold = false, maxW = 600f)

        // divider
        fill.color = withAlpha(cfg.accentColor, 200)
        rect.set(1120f, top + 18f, 1123f, h - 18f)
        c.drawRect(rect, fill)

        // bowler + last wicket
        text(c, cfg, "BOWLER", 1146f, top + 34f, 22f, cfg.accentColor)
        text(c, cfg, d.bowlerName ?: "-", 1146f, top + 74f, 38f, cfg.textColor, maxW = 400f)
        text(c, cfg, d.bowlerFigures ?: "", 1146f, top + 112f, 34f, cfg.accentColor, maxW = 400f)
        d.lastWicket?.let {
            text(c, cfg, "LAST WKT  $it", 1146f, top + 154f, 22f, 0xFFFF8A80.toInt(), bold = false, maxW = 400f)
        }
    }

    private fun drawModernBar(c: Canvas, d: OverlayData, cfg: GraphicsConfig, assets: BroadcastAssets) {
        val w = ScoreboardTemplate.MODERN_BAR.baseWidth
        val h = ScoreboardTemplate.MODERN_BAR.baseHeight
        panel(c, 0f, 0f, w, h, cfg, radius = 66f)
        // team capsule
        fill.shader = null
        fill.color = d.battingColor
        rect.set(0f, 0f, 520f, h)
        c.drawRoundRect(rect, 66f, 66f, fill)
        text(c, cfg, d.battingShort.ifEmpty { d.battingTeam }, 46f, 56f, 40f, Color.WHITE, maxW = 150f)
        text(c, cfg, d.score, 46f, 112f, 62f, Color.WHITE, maxW = 240f)
        text(c, cfg, d.overs, 496f, 56f, 40f, cfg.accentColor, align = Paint.Align.RIGHT, maxW = 150f)
        text(c, cfg, "/${d.oversLimit} ov", 496f, 106f, 26f, 0xCCFFFFFF.toInt(), align = Paint.Align.RIGHT, bold = false)

        batterRow(c, cfg, d.striker, 560f, 54f, 400f, size = 34f)
        batterRow(c, cfg, d.nonStriker, 560f, 106f, 400f, size = 34f)

        text(c, cfg, d.bowlerName ?: "-", 990f, 54f, 34f, cfg.textColor, maxW = 300f)
        text(c, cfg, d.bowlerFigures ?: "", 990f, 106f, 32f, cfg.accentColor, maxW = 300f)

        drawBallChips(c, cfg, d.recentBalls.takeLast(7), 1320f, 36f, 26f)
        val extra = d.chaseText ?: d.targetText ?: "CRR ${d.currentRunRate}"
        text(c, cfg, extra, 1760f, 108f, 24f, cfg.textColor, align = Paint.Align.RIGHT, maxW = 440f, bold = false)
    }

    private fun drawCompact(c: Canvas, d: OverlayData, cfg: GraphicsConfig, assets: BroadcastAssets) {
        val w = ScoreboardTemplate.COMPACT.baseWidth
        val h = ScoreboardTemplate.COMPACT.baseHeight
        panel(c, 0f, 0f, w, h, cfg, radius = 18f)
        fill.shader = null
        fill.color = d.battingColor
        rect.set(0f, 0f, w, 62f)
        c.drawRoundRect(rect, 18f, 18f, fill)
        text(c, cfg, d.battingTeam.ifEmpty { d.battingShort }, 20f, 42f, 34f, Color.WHITE, maxW = 400f)
        text(c, cfg, "${d.overs}/${d.oversLimit} ov", w - 20f, 42f, 28f, cfg.accentColor, align = Paint.Align.RIGHT, maxW = 200f)
        text(c, cfg, d.score, 20f, 134f, 76f, cfg.textColor, maxW = 300f)
        text(c, cfg, "CRR ${d.currentRunRate}", w - 20f, 104f, 26f, 0xCCFFFFFF.toInt(), align = Paint.Align.RIGHT, bold = false)
        (d.chaseText ?: d.targetText)?.let {
            text(c, cfg, it, w - 20f, 138f, 24f, cfg.accentColor, align = Paint.Align.RIGHT, maxW = 320f)
        }
        batterRow(c, cfg, d.striker, 20f, 178f, 380f, size = 28f)
        batterRow(c, cfg, d.nonStriker, 20f, 212f, 380f, size = 28f)
        text(c, cfg, "${d.bowlerName ?: "-"}  ${d.bowlerFigures ?: ""}", 20f, 250f, 26f, cfg.accentColor, maxW = 620f)
        drawBallChips(c, cfg, d.recentBalls.takeLast(8), 20f, 276f, 17f)
    }

    // -------------------------------------------------------------------------------- pieces

    private fun batterRow(c: Canvas, cfg: GraphicsConfig, b: BatterLine?, x: Float, baseline: Float, width: Float, size: Float = 38f) {
        if (b == null) {
            text(c, cfg, "-", x, baseline, size, 0x88FFFFFF.toInt(), bold = false)
            return
        }
        val marker = if (b.onStrike) "\u25B6 " else "   "
        text(c, cfg, marker + b.name, x, baseline, size, if (b.onStrike) cfg.textColor else 0xDDFFFFFF.toInt(), maxW = width * 0.62f)
        text(c, cfg, "${b.runs}", x + width * 0.78f, baseline, size * 1.1f, cfg.accentColor, align = Paint.Align.RIGHT)
        text(c, cfg, "(${b.balls})", x + width, baseline, size * 0.8f, 0xCCFFFFFF.toInt(), align = Paint.Align.RIGHT, bold = false)
    }

    private fun drawBallChips(c: Canvas, cfg: GraphicsConfig, labels: List<String>, x: Float, centerY: Float, r: Float) {
        var cx = x + r
        for (l in labels) {
            fill.shader = null
            fill.color = chipColor(l)
            c.drawCircle(cx, centerY, r, fill)
            val sz = if (l.length <= 2) r * 1.05f else r * 0.7f
            text(c, cfg, l, cx, centerY + sz * 0.35f, sz, Color.WHITE, align = Paint.Align.CENTER, maxW = r * 1.9f)
            cx += r * 2.35f
        }
    }

    private fun chipColor(l: String): Int = when {
        l.contains("W") && !l.startsWith("Wd") -> 0xFFD32F2F.toInt()
        l.startsWith("Wd") || l.startsWith("Nb") || l.endsWith("b") || l.endsWith("lb") -> 0xFFF57C00.toInt()
        l == "6" -> 0xFF8E24AA.toInt()
        l == "4" -> 0xFF1976D2.toInt()
        l == "0" -> 0xFF455A64.toInt()
        else -> 0xFF2E7D32.toInt()
    }

    private fun panel(c: Canvas, l: Float, t: Float, r: Float, b: Float, cfg: GraphicsConfig, alphaMul: Float = 1f, radius: Float = 12f) {
        rect.set(l, t, r, b)
        fill.shader = LinearGradient(l, t, l, b, shade(cfg.primaryColor, 1.18f), shade(cfg.primaryColor, 0.78f), Shader.TileMode.CLAMP)
        fill.alpha = (cfg.panelOpacity * alphaMul * 255).toInt().coerceIn(0, 255)
        c.drawRoundRect(rect, radius, radius, fill)
        fill.shader = null
        fill.alpha = 255
        if (cfg.borderWidthPx > 0f) {
            stroke.strokeWidth = cfg.borderWidthPx
            stroke.color = cfg.borderColor
            c.drawRoundRect(rect, radius, radius, stroke)
        }
    }

    private fun drawBitmapFit(c: Canvas, bmp: Bitmap, x: Float, y: Float, w: Float, h: Float) {
        if (bmp.isRecycled || bmp.width == 0 || bmp.height == 0) return
        val s = min(w / bmp.width, h / bmp.height)
        val dw = bmp.width * s
        val dh = bmp.height * s
        rect.set(x + (w - dw) / 2f, y + (h - dh) / 2f, x + (w + dw) / 2f, y + (h + dh) / 2f)
        fill.shader = null
        fill.alpha = 255
        c.drawBitmap(bmp, null, rect, fill)
    }

    private fun drawBanner(c: Canvas, d: OverlayData, cfg: GraphicsConfig, board: Box, safe: Box) {
        val msg = d.resultText ?: d.banner ?: return
        val isFreeHit = d.banner == "FREE HIT" && d.resultText == null
        val size = 34f
        val tw = measure(cfg, msg, size) + 56f
        val bw = min(tw, safe.width)
        val x = ((Ref.W - bw) / 2f).coerceIn(safe.left, safe.right - bw)
        val above = board.top - 56f
        val y = if (above >= safe.top) above else min(board.bottom + 10f, safe.bottom - 50f)
        rect.set(x, y, x + bw, y + 46f)
        fill.shader = null
        fill.color = if (isFreeHit) 0xFFD81B60.toInt() else withAlpha(cfg.accentColor, 235)
        c.drawRoundRect(rect, 23f, 23f, fill)
        val fg = if (isFreeHit) Color.WHITE else 0xFF111111.toInt()
        text(c, cfg, msg, x + bw / 2f, y + 34f, size, fg, align = Paint.Align.CENTER, maxW = bw - 24f)
    }

    private fun drawTitle(c: Canvas, d: OverlayData, cfg: GraphicsConfig, safe: Box) {
        val t = listOf(d.title, d.venue).filter { it.isNotBlank() }.joinToString("  \u2022  ")
        if (t.isBlank()) return
        val size = 26f
        val bw = min(measure(cfg, t, size) + 44f, safe.width * 0.5f)
        val x = (Ref.W - bw) / 2f
        val y = safe.top + cfg.marginPx
        rect.set(x, y, x + bw, y + 40f)
        fill.shader = null
        fill.color = withAlpha(shade(cfg.primaryColor, 0.7f), (cfg.panelOpacity * 255).toInt())
        c.drawRoundRect(rect, 20f, 20f, fill)
        text(c, cfg, t, x + bw / 2f, y + 29f, size, cfg.textColor, align = Paint.Align.CENTER, maxW = bw - 24f)
    }

    private fun drawTicker(c: Canvas, box: Box, d: OverlayData, cfg: GraphicsConfig, timeMs: Long) {
        val msg = cfg.tickerText.ifBlank { tickerFallback(d) }
        rect.set(box.left, box.top, box.right, box.bottom)
        fill.shader = null
        fill.color = withAlpha(shade(cfg.primaryColor, 0.65f), (cfg.panelOpacity * 255).toInt())
        c.drawRoundRect(rect, 12f, 12f, fill)
        c.save()
        c.clipRect(rect)
        val size = 30f
        val tw = measure(cfg, msg, size)
        val gap = 260f
        val period = tw + gap
        val offset = (timeMs * 0.09f) % period
        var x = box.left - offset
        while (x < box.right) {
            text(c, cfg, msg, x, box.top + 37f, size, cfg.textColor, bold = false)
            x += period
        }
        c.restore()
    }

    private fun tickerFallback(d: OverlayData): String {
        val parts = mutableListOf<String>()
        if (d.battingTeam.isNotBlank() && d.bowlingTeam.isNotBlank()) parts += "${d.battingTeam} vs ${d.bowlingTeam}"
        if (d.score != "0/0" || d.overs != "0.0") parts += "${d.battingShort} ${d.score} (${d.overs} ov)"
        d.targetText?.let { parts += it }
        d.lastWicket?.let { parts += "Last wicket: $it" }
        return parts.joinToString("   \u2022   ").ifBlank { "Welcome to the live broadcast" }
    }

    // -------------------------------------------------------------------------------- text utils

    private fun typeface(cfg: GraphicsConfig, bold: Boolean): Typeface =
        typefaces.getOrPut("${cfg.font.family}/$bold") {
            Typeface.create(cfg.font.family, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }

    private fun measure(cfg: GraphicsConfig, s: String, size: Float, bold: Boolean = true): Float {
        textPaint.typeface = typeface(cfg, bold)
        textPaint.textSize = size
        return textPaint.measureText(s)
    }

    private fun text(
        c: Canvas, cfg: GraphicsConfig, s: String, x: Float, baseline: Float, size: Float, color: Int,
        bold: Boolean = true, align: Paint.Align = Paint.Align.LEFT, maxW: Float = Float.MAX_VALUE
    ) {
        if (s.isEmpty()) return
        textPaint.typeface = typeface(cfg, bold)
        textPaint.textAlign = align
        var sz = size
        textPaint.textSize = sz
        var out = s
        if (maxW != Float.MAX_VALUE) {
            var w = textPaint.measureText(out)
            if (w > maxW) { // shrink up to 70%, then ellipsize
                sz = max(size * 0.7f, size * maxW / w)
                textPaint.textSize = sz
                w = textPaint.measureText(out)
                while (w > maxW && out.length > 1) {
                    out = out.dropLast(1)
                    w = textPaint.measureText("$out\u2026")
                }
                if (out.length < s.length) out += "\u2026"
            }
        }
        textPaint.setShadowLayer(3f, 0f, 2f, 0xAA000000.toInt())
        textPaint.color = color
        c.drawText(out, x, baseline, textPaint)
        textPaint.clearShadowLayer()
    }

    private fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    private fun shade(color: Int, f: Float): Int {
        val r = (Color.red(color) * f).toInt().coerceIn(0, 255)
        val g = (Color.green(color) * f).toInt().coerceIn(0, 255)
        val b = (Color.blue(color) * f).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }

    fun release() {
        proceduralBg?.recycle()
        proceduralBg = null
        typefaces.clear()
    }
}
