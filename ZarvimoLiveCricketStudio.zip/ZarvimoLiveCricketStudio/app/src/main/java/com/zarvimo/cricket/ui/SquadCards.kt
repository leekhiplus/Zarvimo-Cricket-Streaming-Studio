package com.zarvimo.cricket.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.cricket.scoring.SquadParser

/**
 * Editor for one team's Playing XI: add one name at a time, paste a whole list, reorder (batting order), remove.
 * It only edits the list it is given; the caller stores the result.
 */
@Composable
fun SquadEditor(teamName: String, target: Int, names: List<String>, accent: Color, onChange: (List<String>) -> Unit) {
    var newName by remember { mutableStateOf("") }
    var pasteOpen by remember { mutableStateOf(false) }
    var pasted by remember { mutableStateOf("") }

    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.width(6.dp).height(22.dp).clip(RoundedCornerShape(3.dp)).background(accent))
        Text(teamName.ifBlank { "Team" }, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("${names.size} / $target", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = if (names.size == target) Mint else Gold)
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TextInput("Player name", newName, { newName = it }, Modifier.weight(1f), placeholder = "e.g. Babar Azam (c)")
        BigButton("", Modifier.heightIn(min = 56.dp), Gold, Color.Black, enabled = newName.isNotBlank() && names.size < SquadParser.MAX_PLAYERS, icon = Ic.Plus) {
            onChange(SquadParser.add(names, newName))
            newName = ""
        }
    }
    names.forEachIndexed { i, n ->
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(if (i % 2 == 0) PanelHi else Color.Transparent).padding(start = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("${i + 1}", Modifier.width(26.dp), color = accent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(n, Modifier.weight(1f), fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            AppIcon(Ic.ArrowUp, Modifier.clickable(enabled = i > 0) { onChange(SquadParser.move(names, i, -1)) }.padding(8.dp), 20.dp, if (i > 0) Muted else Color(0xFF3A4568))
            AppIcon(Ic.ArrowDown, Modifier.clickable(enabled = i < names.lastIndex) { onChange(SquadParser.move(names, i, 1)) }.padding(8.dp), 20.dp, if (i < names.lastIndex) Muted else Color(0xFF3A4568))
            AppIcon(Ic.Close, Modifier.clickable { onChange(names.filterIndexed { k, _ -> k != i }) }.padding(8.dp), 20.dp, Color(0xFFFF6B6B))
        }
    }
    if (names.isEmpty()) Text("No players yet. Add them one by one or paste a full list.", fontSize = 12.sp, color = Muted)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        BigButton(if (pasteOpen) "Close paste box" else "Paste a list", Modifier.weight(1f).heightIn(min = 44.dp), icon = Ic.Upload) { pasteOpen = !pasteOpen }
        if (names.isNotEmpty()) BigButton("Clear all", Modifier.weight(1f).heightIn(min = 44.dp), Color(0xFF5A2A2A), icon = Ic.Trash) { onChange(emptyList()) }
    }
    if (pasteOpen) {
        TextInput(
            "One name per line (numbers like 1. or 2) are removed)", pasted, { pasted = it },
            singleLine = false, placeholder = "1. Fakhar Zaman\n2. Babar Azam (c)\n3. Mohammad Rizwan (wk)"
        )
        BigButton("Use this list", Modifier.fillMaxWidth(), Gold, Color.Black, enabled = pasted.isNotBlank(), icon = Ic.Check) {
            onChange(SquadParser.parse(pasted))
            pasted = ""
            pasteOpen = false
        }
    }
}

/** Tap a name from the squad to fill a field. Names in [exclude] (already batting, already chosen...) are hidden. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PickFromSquad(squad: List<String>, exclude: Collection<String> = emptyList(), label: String = "Pick from the Playing XI", onPick: (String) -> Unit) {
    val ex = exclude.map { it.trim().lowercase() }.toSet()
    val available = squad.filter { it.trim().lowercase() !in ex }
    if (squad.isEmpty()) return
    Text(label, fontSize = 12.sp, color = Muted)
    if (available.isEmpty()) {
        Text("Everyone in the list has been used.", fontSize = 12.sp, color = Muted)
        return
    }
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        available.forEach { n ->
            Box(
                Modifier.clip(RoundedCornerShape(10.dp)).background(PanelHi).border(1.dp, Line, RoundedCornerShape(10.dp))
                    .clickable { onPick(n) }.padding(horizontal = 12.dp, vertical = 8.dp)
            ) { Text(n, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1) }
        }
    }
}
