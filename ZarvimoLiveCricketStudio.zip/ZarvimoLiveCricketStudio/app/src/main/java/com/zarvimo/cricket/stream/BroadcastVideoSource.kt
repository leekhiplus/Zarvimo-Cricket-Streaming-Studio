package com.zarvimo.cricket.stream

import android.content.Context
import android.graphics.Canvas
import android.graphics.SurfaceTexture
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.Surface
import com.pedro.encoder.input.sources.video.VideoSource
import com.zarvimo.cricket.graphics.BroadcastRenderer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.max

/**
 * RootEncoder video source that feeds the app's own compositor into the library's GL pipeline.
 *
 * Frame pump: a dedicated thread produces frames at the configured fps into the Surface backed by the SurfaceTexture
 * RootEncoder hands us. RootEncoder's GL interface then fans those exact frames out to (a) the MediaCodec H.264 encoder
 * and (b) the on-screen preview SurfaceView. There is no second render path.
 *
 * Two interchangeable backends (the user can switch live, preview and stream follow):
 *  - BACKGROUND: [BroadcastRenderer] draws background picture + graphics with a Canvas.
 *  - CAMERA_BACK / CAMERA_FRONT: [CameraGlCompositor] draws the camera with OpenGL and the same graphics on top.
 * If the camera cannot be used the source falls back to BACKGROUND and tells the caller why.
 *
 * RootEncoder-specific API usage is confined to this class and [StreamEngine].
 */
class BroadcastVideoSource(
    private val context: Context,
    private val broadcast: BroadcastState,
    private val onCompositorFps: (Int) -> Unit,
    private val onFatalError: (String) -> Unit,
    private val onModeFallback: (VideoSourceMode, String) -> Unit
) : VideoSource() {

    private var outW = 0
    private var outH = 0
    // Named pumpFps (not fps): RootEncoder 2.8.x VideoSource already declares a member called fps.
    private var pumpFps = 24

    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var outTexture: SurfaceTexture? = null
    private var surface: Surface? = null
    private var gl: CameraGlCompositor? = null
    private var activeMode: VideoSourceMode? = null
    private val renderer = BroadcastRenderer()

    @Volatile private var desiredMode = VideoSourceMode.BACKGROUND
    @Volatile private var rotationOffset = 0
    @Volatile private var pendingProblem: String? = null

    @Volatile private var running = false
    private var nextFrameAt = 0L
    private var framesThisSecond = 0
    private var secondStart = 0L
    private var consecutiveErrors = 0

    /** Thread-safe; takes effect on the next frame (live switching). */
    fun setMode(mode: VideoSourceMode) {
        desiredMode = mode
    }

    fun setRotationOffset(degrees: Int) {
        rotationOffset = degrees
        gl?.rotationOffset = degrees
    }

    override fun create(width: Int, height: Int, fps: Int, rotation: Int): Boolean {
        outW = width
        outH = height
        this.pumpFps = fps.coerceIn(5, 60)
        return true
    }

    override fun start(surfaceTexture: SurfaceTexture) {
        if (running) return
        surfaceTexture.setDefaultBufferSize(outW, outH)
        outTexture = surfaceTexture
        val t = HandlerThread("BroadcastFramePump").also { it.start() }
        thread = t
        handler = Handler(t.looper)
        running = true
        consecutiveErrors = 0
        nextFrameAt = SystemClock.uptimeMillis()
        secondStart = nextFrameAt
        framesThisSecond = 0
        handler?.post(tick)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            ensureBackend()
            drawFrame()
            val interval = 1000L / pumpFps
            nextFrameAt += interval
            val now = SystemClock.uptimeMillis()
            if (nextFrameAt < now - 2 * interval) nextFrameAt = now // fell behind: skip, never queue frames up
            handler?.postDelayed(this, max(0L, nextFrameAt - now))
        }
    }

    // ------------------------------------------------------------------------------------------ backends

    /** Runs on the pump thread before every frame: switches backend when the wanted mode changed or the camera failed. */
    private fun ensureBackend() {
        val problem = pendingProblem
        if (problem != null) {
            pendingProblem = null
            if (activeMode?.isCamera == true) {
                fallbackToBackground(problem)
                return
            }
        }
        val want = desiredMode
        if (activeMode == want) return
        val st = outTexture ?: return
        teardownBackend()
        if (want.isCamera) {
            val h = handler ?: return
            try {
                val s = Surface(st)
                surface = s
                val g = CameraGlCompositor(context, h) { msg -> pendingProblem = msg }
                g.rotationOffset = rotationOffset
                g.start(s, outW, outH, pumpFps, want == VideoSourceMode.CAMERA_FRONT)
                gl = g
                activeMode = want
            } catch (e: Throwable) {
                fallbackToBackground("Camera mode could not start (${e.javaClass.simpleName}). Using the background picture instead.")
            }
        } else {
            surface = Surface(st)
            activeMode = VideoSourceMode.BACKGROUND
        }
    }

    private fun fallbackToBackground(message: String) {
        teardownBackend()
        desiredMode = VideoSourceMode.BACKGROUND
        onModeFallback(VideoSourceMode.BACKGROUND, message)
        val st = outTexture ?: return
        surface = Surface(st)
        activeMode = VideoSourceMode.BACKGROUND
    }

    private fun teardownBackend() {
        try {
            gl?.release()
        } catch (_: Exception) {
        }
        gl = null
        try {
            surface?.release()
        } catch (_: Exception) {
        }
        surface = null
        activeMode = null
    }

    // ------------------------------------------------------------------------------------------ frames

    private fun drawFrame() {
        val mode = activeMode ?: return
        val snap = broadcast.snapshot()
        if (mode.isCamera) drawCameraFrame(snap) else drawCanvasFrame(snap)
        val now = SystemClock.uptimeMillis()
        if (now - secondStart >= 1000) {
            onCompositorFps(framesThisSecond)
            framesThisSecond = 0
            secondStart = now
        }
    }

    private fun drawCameraFrame(snap: BroadcastState.Snapshot) {
        val g = gl ?: return
        try {
            g.drawFrame { canvas ->
                renderer.render(canvas, outW, outH, snap.overlay, snap.config, broadcast.assets, SystemClock.uptimeMillis(), withBackground = false)
            }
            consecutiveErrors = 0
            framesThisSecond++
        } catch (e: Throwable) {
            consecutiveErrors++
            if (consecutiveErrors >= 10) {
                consecutiveErrors = 0
                fallbackToBackground("Camera rendering failed (${e.javaClass.simpleName}). Using the background picture instead.")
            }
        }
    }

    private fun drawCanvasFrame(snap: BroadcastState.Snapshot) {
        val s = surface ?: return
        if (!s.isValid) return
        var canvas: Canvas? = null
        try {
            canvas = try {
                s.lockHardwareCanvas()
            } catch (e: Exception) {
                s.lockCanvas(null)
            }
            renderer.render(canvas, outW, outH, snap.overlay, snap.config, broadcast.assets, SystemClock.uptimeMillis(), withBackground = true)
            consecutiveErrors = 0
            framesThisSecond++
        } catch (e: Exception) {
            consecutiveErrors++
            if (consecutiveErrors >= 20) {
                running = false
                onFatalError("Compositor stopped: ${e.javaClass.simpleName}")
            }
        } finally {
            if (canvas != null) {
                try {
                    s.unlockCanvasAndPost(canvas)
                } catch (e: Exception) {
                    consecutiveErrors++
                }
            }
        }
    }

    // ------------------------------------------------------------------------------------------ lifecycle

    override fun stop() {
        running = false
        val h = handler
        val t = thread
        if (h != null && t != null) {
            h.removeCallbacksAndMessages(null)
            // GL and camera objects must be released on the thread that owns the EGL context.
            val done = CountDownLatch(1)
            h.post {
                try {
                    teardownBackend()
                } finally {
                    done.countDown()
                }
            }
            try {
                done.await(1500, TimeUnit.MILLISECONDS)
            } catch (_: InterruptedException) {
            }
            t.quitSafely()
            try {
                t.join(500)
            } catch (_: InterruptedException) {
            }
        }
        thread = null
        handler = null
        outTexture = null
        onCompositorFps(0)
    }

    override fun release() {
        stop()
        renderer.release()
    }

    override fun isRunning(): Boolean = running
}
