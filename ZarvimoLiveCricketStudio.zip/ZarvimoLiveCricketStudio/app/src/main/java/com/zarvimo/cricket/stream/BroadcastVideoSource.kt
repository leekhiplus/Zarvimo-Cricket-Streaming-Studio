package com.zarvimo.cricket.stream

import android.graphics.SurfaceTexture
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.Surface
import com.pedro.encoder.input.sources.video.VideoSource
import com.zarvimo.cricket.graphics.BroadcastRenderer
import kotlin.math.max

/**
 * RootEncoder video source that feeds the app's own compositor into the library's GL pipeline.
 *
 * Frame pump: a dedicated thread draws [BroadcastRenderer] output at the configured fps into the Surface backed by the
 * SurfaceTexture RootEncoder hands us. RootEncoder's GL interface then fans those exact frames out to (a) the
 * MediaCodec H.264 encoder and (b) the on-screen preview SurfaceView. There is no second render path.
 *
 * RootEncoder-specific API usage is confined to this class and [StreamEngine] so a signature difference between
 * library versions can be fixed in one place.
 */
class BroadcastVideoSource(
    private val broadcast: BroadcastState,
    private val onCompositorFps: (Int) -> Unit,
    private val onFatalError: (String) -> Unit
) : VideoSource() {

    private var outW = 0
    private var outH = 0
    private var fps = 24

    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var surface: Surface? = null
    private val renderer = BroadcastRenderer()

    @Volatile private var running = false
    private var nextFrameAt = 0L
    private var framesThisSecond = 0
    private var secondStart = 0L
    private var consecutiveErrors = 0

    override fun create(width: Int, height: Int, fps: Int, rotation: Int): Boolean {
        outW = width
        outH = height
        this.fps = fps.coerceIn(5, 60)
        return true
    }

    override fun start(surfaceTexture: SurfaceTexture) {
        if (running) return
        surfaceTexture.setDefaultBufferSize(outW, outH)
        surface = Surface(surfaceTexture)
        val t = HandlerThread("BroadcastFramePump").also { it.start() }
        thread = t
        handler = Handler(t.looper)
        running = true
        consecutiveErrors = 0
        nextFrameAt = SystemClock.uptimeMillis()
        secondStart = nextFrameAt
        framesThisSecond = 0
        handler?.post(tick)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            drawFrame()
            val interval = 1000L / fps
            nextFrameAt += interval
            val now = SystemClock.uptimeMillis()
            if (nextFrameAt < now - 2 * interval) nextFrameAt = now // fell behind: skip, never queue frames up
            handler?.postDelayed(this, max(0L, nextFrameAt - now))
        }
    }

    private fun drawFrame() {
        val s = surface ?: return
        if (!s.isValid) return
        var canvas: android.graphics.Canvas? = null
        try {
            canvas = try {
                s.lockHardwareCanvas()
            } catch (e: Exception) {
                s.lockCanvas(null)
            }
            val snap = broadcast.snapshot()
            renderer.render(canvas, outW, outH, snap.overlay, snap.config, broadcast.assets, SystemClock.uptimeMillis())
            consecutiveErrors = 0
            framesThisSecond++
        } catch (e: Exception) {
            consecutiveErrors++
            if (consecutiveErrors >= 20) {
                running = false
                onFatalError("Compositor stopped: ${e.javaClass.simpleName}")
            }
        } finally {
            if (canvas != null) {
                try {
                    s.unlockCanvasAndPost(canvas)
                } catch (e: Exception) {
                    consecutiveErrors++
                }
            }
        }
        val now = SystemClock.uptimeMillis()
        if (now - secondStart >= 1000) {
            onCompositorFps(framesThisSecond)
            framesThisSecond = 0
            secondStart = now
        }
    }

    override fun stop() {
        running = false
        handler?.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        try {
            thread?.join(500)
        } catch (_: InterruptedException) {
        }
        thread = null
        handler = null
        surface?.release()
        surface = null
        onCompositorFps(0)
    }

    override fun release() {
        stop()
        renderer.release()
    }

    override fun isRunning(): Boolean = running
}
