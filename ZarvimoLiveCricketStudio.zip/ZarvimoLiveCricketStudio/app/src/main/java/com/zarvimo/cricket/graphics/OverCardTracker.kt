package com.zarvimo.cricket.graphics

/**
 * Decides when the automatic "random graphic after an over" should appear. Pure logic, so it is unit-tested.
 * A card is wanted only when the number of completed overs GROWS in an innings that was already being watched:
 * never when a match is loaded, a new match / innings starts, the scorer undoes a ball, or the innings has ended.
 */
class OverCardTracker {
    private var key: String? = null
    private var count = 0

    fun reset() { key = null }

    /** [key] identifies match + innings. Returns true when a card should be scheduled now. */
    fun update(key: String, completedOvers: Int, ended: Boolean, enabled: Boolean, every: Int): Boolean {
        if (key != this.key) { // first sight of this innings: just remember where it is
            this.key = key
            count = completedOvers
            return false
        }
        val grew = completedOvers > count
        count = completedOvers
        return grew && enabled && !ended && every >= 1 && completedOvers % every == 0
    }
}
