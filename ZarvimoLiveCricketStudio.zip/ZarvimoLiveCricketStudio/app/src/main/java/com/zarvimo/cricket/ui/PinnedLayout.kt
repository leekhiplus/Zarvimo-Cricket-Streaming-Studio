package com.zarvimo.cricket.ui

import android.content.res.Configuration
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Screen layout with the Program Output preview PINNED in place: only [content] (the options) scrolls.
 *  - Portrait: status + preview at the top, options scroll underneath.
 *  - Landscape: preview on the left, options scroll on the right.
 *
 * The preview lives outside every scroll container, so it never moves and its surface is not recreated while scrolling.
 */
@Composable
fun PinnedPreviewScreen(
    vm: AppViewModel,
    hint: String? = null,
    previewOverlay: (@Composable BoxScope.() -> Unit)? = null,
    previewNotes: @Composable ColumnScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    val header: @Composable ColumnScope.() -> Unit = {
        StatusStrip(vm)
        if (hint != null) Text(hint, fontSize = 12.sp, color = Gold, fontWeight = FontWeight.Bold)
        Box {
            ProgramPreview(vm)
            previewOverlay?.invoke(this)
        }
        previewNotes()
    }

    if (landscape) {
        Row(Modifier.fillMaxSize()) {
            Column(
                Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                content = header
            )
            Column(
                Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                content = content
            )
        }
    } else {
        Column(Modifier.fillMaxSize()) {
            Column(
                Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                content = header
            )
            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                content = content
            )
        }
    }
}
