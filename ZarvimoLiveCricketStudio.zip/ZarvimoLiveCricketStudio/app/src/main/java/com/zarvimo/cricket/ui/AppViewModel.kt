package com.zarvimo.cricket.ui

import android.app.Application
import android.net.Uri
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zarvimo.cricket.ZarvimoApp
import com.zarvimo.cricket.data.Json
import com.zarvimo.cricket.data.LocalStore
import com.zarvimo.cricket.data.MediaImporter
import com.zarvimo.cricket.data.SecretStore
import com.zarvimo.cricket.graphics.BurstInfo
import com.zarvimo.cricket.graphics.BurstKind
import com.zarvimo.cricket.graphics.GraphicsConfig
import com.zarvimo.cricket.graphics.MatchVisuals
import com.zarvimo.cricket.graphics.OverlayBuilder
import com.zarvimo.cricket.graphics.OverlayData
import com.zarvimo.cricket.graphics.PanelBuilder
import com.zarvimo.cricket.graphics.PanelInfo
import com.zarvimo.cricket.graphics.PanelKind
import com.zarvimo.cricket.scoring.AdjustmentEvent
import com.zarvimo.cricket.scoring.BallEvent
import com.zarvimo.cricket.scoring.BatterInEvent
import com.zarvimo.cricket.scoring.EndInningsEvent
import com.zarvimo.cricket.scoring.InningsSetup
import com.zarvimo.cricket.scoring.InningsState
import com.zarvimo.cricket.scoring.MatchSession
import com.zarvimo.cricket.scoring.MatchSetup
import com.zarvimo.cricket.scoring.OpResult
import com.zarvimo.cricket.scoring.PenaltyEvent
import com.zarvimo.cricket.scoring.ScoreEvent
import com.zarvimo.cricket.scoring.SetBowlerEvent
import com.zarvimo.cricket.scoring.SwapStrikeEvent
import com.zarvimo.cricket.stream.AudioMixSettings
import com.zarvimo.cricket.stream.AutoShowSettings
import com.zarvimo.cricket.stream.CommentaryEvent
import com.zarvimo.cricket.stream.CommentaryLines
import com.zarvimo.cricket.stream.MusicTrack
import com.zarvimo.cricket.stream.StartResult
import com.zarvimo.cricket.stream.StreamService
import com.zarvimo.cricket.stream.StreamSettings
import com.zarvimo.cricket.stream.VideoSourceMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

/** Immutable snapshot of the match for the UI. */
data class MatchUi(
    val setup: MatchSetup = MatchSetup(),
    val visuals: MatchVisuals = MatchVisuals(),
    val matchId: String = UUID.randomUUID().toString(),
    val inningsIndex: Int = -1,
    val state: InningsState? = null,
    val events: List<ScoreEvent> = emptyList(),
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val firstInningsText: String? = null,
    val teamALogoPath: String? = null,
    val teamBLogoPath: String? = null,
    /** Transient message (rule violation, info). Cleared by the next successful action. */
    val message: String? = null
)

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val engine = (app as ZarvimoApp).engine
    private val store = LocalStore(app)
    private var session: MatchSession? = null

    val streamStatus = engine.status
    val previewStatus = engine.preview
    val audioState = engine.audio
    val musicState = engine.musicState
    val micLevel = engine.micLevel
    val headset = engine.headset
    val videoMode = engine.videoMode

    private val _audioMix = MutableStateFlow(AudioMixSettings())
    val audioMix: StateFlow<AudioMixSettings> = _audioMix.asStateFlow()

    private val _autoShow = MutableStateFlow(AutoShowSettings())
    val autoShow: StateFlow<AutoShowSettings> = _autoShow.asStateFlow()
    val recording = engine.recording
    val liveBitrateKbps = engine.liveBitrateKbps

    // on-air extras layered over the scoring overlay
    private var baseOverlay = OverlayData()
    private var currentPanel: PanelInfo? = null
    private var currentBurst: BurstInfo? = null
    private var panelKind: PanelKind? = null
    private var panelShownAt = 0L
    private var panelJob: Job? = null
    private val _panelOnAir = MutableStateFlow<PanelKind?>(null)
    val panelOnAir: StateFlow<PanelKind?> = _panelOnAir.asStateFlow()

    private val _match = MutableStateFlow(MatchUi())
    val match: StateFlow<MatchUi> = _match.asStateFlow()

    private val _graphics = MutableStateFlow(GraphicsConfig())
    val graphics: StateFlow<GraphicsConfig> = _graphics.asStateFlow()

    private val _stream = MutableStateFlow(StreamSettings())
    val stream: StateFlow<StreamSettings> = _stream.asStateFlow()

    private val _rememberKey = MutableStateFlow(false)
    val rememberKey: StateFlow<Boolean> = _rememberKey.asStateFlow()

    private val _liveProblems = MutableStateFlow<List<String>>(emptyList())
    val liveProblems: StateFlow<List<String>> = _liveProblems.asStateFlow()

    private val _savedMatches = MutableStateFlow<List<Json.SavedMatch>>(emptyList())
    val savedMatches: StateFlow<List<Json.SavedMatch>> = _savedMatches.asStateFlow()

    private val _presets = MutableStateFlow<List<GraphicsConfig>>(emptyList())
    val presets: StateFlow<List<GraphicsConfig>> = _presets.asStateFlow()

    private val _toast = MutableStateFlow<String?>(null)
    val toast: StateFlow<String?> = _toast.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            store.loadGraphics()?.let { _graphics.value = it }
            store.loadStreamSettings()?.let { _stream.value = it }
            val key = SecretStore.load(getApplication<Application>())
            if (key.isNotEmpty()) {
                _rememberKey.value = true
                _stream.update { it.copy(streamKey = key) }
            }
            store.loadAudioMix()?.let { _audioMix.value = it }
            engine.applyAudioMix(_audioMix.value)
            store.loadAutoShow()?.let { _autoShow.value = it }
            engine.applyAutoShow(_autoShow.value)
            val saved = _stream.value
            if (saved.videoSource.isCamera) {
                if (engine.hasCameraPermission()) {
                    engine.setVideoSource(saved.videoSource, saved.cameraRotationOffset)
                } else {
                    _stream.update { it.copy(videoSource = VideoSourceMode.BACKGROUND) }
                }
            }
            store.loadAutosave()?.let { restore(it) }
            loadAllBitmaps()
            engine.broadcast.update(config = _graphics.value)
            refreshSaved()
            publish()
        }
    }

    init {
        // The engine may fall back to the background picture (camera unplugged / permission lost): keep the UI in step.
        viewModelScope.launch {
            engine.videoMode.collect { m ->
                if (_stream.value.videoSource != m) {
                    _stream.update { it.copy(videoSource = m) }
                    val s = _stream.value
                    launch(Dispatchers.IO) { store.saveStreamSettings(s) }
                }
            }
        }
        viewModelScope.launch {
            engine.notice.collect { n ->
                if (n != null) {
                    _toast.value = n
                    engine.consumeNotice()
                }
            }
        }
    }

    fun consumeToast() { _toast.value = null }
    fun reportMessage(text: String) { _toast.value = text }

    // ====================================================================== match / scoring

    fun newMatch(setup: MatchSetup, visuals: MatchVisuals) {
        val err = setup.validate()
        if (err != null) { _toast.value = err; return }
        session = MatchSession(setup)
        _match.value = MatchUi(setup = setup, visuals = visuals)
        publish()
    }

    fun updateSetup(setup: MatchSetup, visuals: MatchVisuals) {
        val err = setup.validate()
        if (err != null) { _toast.value = err; return }
        val s = session
        if (s == null || s.innings.isEmpty()) {
            session = MatchSession(setup)
            _match.update { it.copy(setup = setup, visuals = visuals) }
        } else {
            // Rules for an in-progress match are locked to avoid rewriting history; only labels/colours change.
            val locked = _match.value.setup.copy(title = setup.title, venue = setup.venue,
                tossWinner = setup.tossWinner, tossDecision = setup.tossDecision, startTime = setup.startTime)
            _match.update { it.copy(setup = locked, visuals = visuals) }
            if (locked != setup) _toast.value = "Match already started: only title, venue and colours were updated"
        }
        publish()
    }

    fun startInnings(setup: InningsSetup, targetOverride: Int? = null) {
        val s = session ?: run { _toast.value = "Create the match first"; return }
        handle(s.startInnings(setup, targetOverride))
    }

    fun addBall(runs: Int, boundary: Boolean = false) = addEvent { BallEvent(it, runsBat = runs, boundary = boundary) }
    fun addEvent(factory: (Long) -> ScoreEvent) {
        val s = session ?: return
        var createdId = -1L
        val r = s.add { id ->
            createdId = id
            factory(id)
        }
        handle(r)
        if (r is OpResult.Ok) onEventAdded(createdId)
    }

    /** Four / six / wicket just recorded: full-screen animation and spoken commentary (each can be switched off). */
    private fun onEventAdded(id: Long) {
        val s = session ?: return
        val st = s.currentState ?: return
        val ev = s.current?.events?.lastOrNull { it.id == id } as? BallEvent ?: return
        val kind = when {
            ev.wicket != null -> BurstKind.WICKET
            ev.runsBat == 6 -> BurstKind.SIX
            ev.runsBat == 4 -> BurstKind.FOUR
            else -> return
        }
        val rec = st.allBalls.lastOrNull { it.eventId == id }
        val auto = _autoShow.value
        val batter = if (kind == BurstKind.WICKET) st.lastDismissed?.name.orEmpty() else rec?.striker.orEmpty()
        val detail = if (kind == BurstKind.WICKET) {
            st.lastDismissed?.let { d -> d.name + (d.dismissal?.let { "  $it" } ?: "") }.orEmpty()
        } else {
            batter
        }
        if (auto.burstAnimations) {
            currentBurst = BurstInfo(kind, detail, SystemClock.uptimeMillis())
            pushOverlay()
        }
        val wanted = when (kind) {
            BurstKind.FOUR -> auto.onFour
            BurstKind.SIX -> auto.onSix
            BurstKind.WICKET -> auto.onWicket
        }
        if (auto.voiceEnabled && wanted) {
            val event = when (kind) {
                BurstKind.FOUR -> CommentaryEvent.FOUR
                BurstKind.SIX -> CommentaryEvent.SIX
                BurstKind.WICKET -> CommentaryEvent.WICKET
            }
            val type = ev.wicket?.type
            engine.speakCommentary(
                CommentaryLines.line(event, batter, rec?.bowler, type, urdu = false),
                CommentaryLines.line(event, batter, rec?.bowler, type, urdu = true),
                auto.voiceUrdu
            )
        }
    }

    fun setBowler(name: String) = addEvent { SetBowlerEvent(it, name) }
    fun batterIn(name: String) = addEvent { BatterInEvent(it, name) }
    fun swapStrike() = addEvent { SwapStrikeEvent(it) }
    fun penalty(runs: Int) = addEvent { PenaltyEvent(it, runs) }
    fun adjust(runs: Int, wickets: Int, note: String) = addEvent { AdjustmentEvent(it, runs, wickets, note.ifBlank { "Manual correction" }) }
    fun endInnings(reason: String) = addEvent { EndInningsEvent(it, reason) }

    fun undo() { session?.let { handle(it.undo()) } }
    fun redo() { session?.let { handle(it.redo()) } }

    fun replaceEvent(id: Long, factory: (Long) -> ScoreEvent) { session?.let { handle(it.replaceEvent(id, factory)) } }
    fun deleteEvent(id: Long) { session?.let { handle(it.deleteEvent(id)) } }
    fun setTarget(target: Int?) { session?.let { handle(it.setTargetOverride(it.currentIndex, target)) } }

    private fun handle(r: OpResult) {
        when (r) {
            is OpResult.Ok -> publish(null)
            is OpResult.Error -> publish(r.message)
        }
    }

    /** Rebuilds the UI snapshot and pushes the new overlay to the compositor (picked up by the very next frame). */
    private fun publish(message: String? = null) {
        val s = session
        val cur = _match.value
        val state = s?.currentState
        val first = if (s != null && s.innings.size >= 2) s.stateOf(0)?.let { "${it.battingTeam} ${it.scoreText} (${it.oversText})" } else null
        val next = cur.copy(
            inningsIndex = s?.currentIndex ?: -1,
            state = state,
            events = s?.current?.events?.toList() ?: emptyList(),
            canUndo = s?.current?.events?.isNotEmpty() == true,
            canRedo = s?.current?.redoStack?.isNotEmpty() == true,
            firstInningsText = first,
            message = message
        )
        _match.value = next
        baseOverlay = OverlayBuilder.from(next.setup, s, next.visuals)
        // a panel on air (scorecard, graph...) follows the live score
        panelKind?.let { k ->
            val info = buildPanel(k)
            if (info != null) currentPanel = info.copy(shownAtMs = panelShownAt) else clearPanelState()
        }
        pushOverlay()
        autosave(next)
    }

    private fun pushOverlay() {
        engine.broadcast.update(overlay = baseOverlay.copy(panel = currentPanel, burst = currentBurst))
    }

    // ====================================================================== on-air panels & automatic extras

    private fun buildPanel(kind: PanelKind): PanelInfo? {
        val st = session?.currentState ?: return null
        return when (kind) {
            PanelKind.SCORECARD -> PanelBuilder.scorecard(st)
            PanelKind.STRIKER, PanelKind.NON_STRIKER, PanelKind.BOWLER -> PanelBuilder.player(st, kind)
            PanelKind.PARTNERSHIP -> PanelBuilder.partnership(st)
            PanelKind.RUN_RATE -> PanelBuilder.runRate(st)
        }
    }

    private fun clearPanelState() {
        panelJob?.cancel()
        panelJob = null
        panelKind = null
        currentPanel = null
        _panelOnAir.value = null
    }

    /** Puts a panel on air; it hides itself after the configured number of seconds (tap again or Hide to remove it sooner). */
    fun showPanel(kind: PanelKind) {
        val info = buildPanel(kind)
        if (info == null) {
            _toast.value = "Nothing to show yet: start an innings and put the batters at the crease first"
            return
        }
        panelJob?.cancel()
        panelKind = kind
        panelShownAt = SystemClock.uptimeMillis()
        currentPanel = info.copy(shownAtMs = panelShownAt)
        _panelOnAir.value = kind
        pushOverlay()
        val seconds = _autoShow.value.panelSeconds
        panelJob = viewModelScope.launch {
            delay(seconds * 1000L)
            hidePanel()
        }
    }

    fun hidePanel() {
        clearPanelState()
        pushOverlay()
    }

    fun updateAutoShow(block: (AutoShowSettings) -> AutoShowSettings) {
        _autoShow.update { block(it).sanitized() }
        val a = _autoShow.value
        engine.applyAutoShow(a)
        viewModelScope.launch(Dispatchers.IO) { store.saveAutoShow(a) }
    }

    fun testVoice() {
        val a = _autoShow.value
        engine.applyAutoShow(a.copy(voiceEnabled = true))
        engine.speakCommentary("Test. FOUR! A beautiful shot from the batter.", "ٹیسٹ۔ چوکا! بہت شاندار شاٹ۔", a.voiceUrdu)
    }

    fun testBurst(kind: BurstKind) {
        currentBurst = BurstInfo(kind, "Preview", SystemClock.uptimeMillis())
        pushOverlay()
    }

    private fun autosave(m: MatchUi) {
        val s = session ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                store.saveAutosave(toSaved(m, s, "autosave"))
            } catch (_: Exception) {
            }
        }
    }

    private fun toSaved(m: MatchUi, s: MatchSession?, name: String) =
        Json.SavedMatch(m.matchId, name, System.currentTimeMillis(), m.setup, m.visuals, s, m.teamALogoPath, m.teamBLogoPath)

    private fun restore(saved: Json.SavedMatch) {
        session = saved.session ?: MatchSession(saved.setup)
        _match.value = MatchUi(
            setup = saved.setup, visuals = saved.visuals, matchId = saved.id.ifBlank { UUID.randomUUID().toString() },
            teamALogoPath = saved.teamALogoPath, teamBLogoPath = saved.teamBLogoPath
        )
    }

    fun resetMatch() {
        session = null
        _match.value = MatchUi(visuals = _match.value.visuals)
        engine.broadcast.assets.teamALogo = null
        engine.broadcast.assets.teamBLogo = null
        publish()
    }

    // ====================================================================== saved matches & presets

    fun saveMatchAs(name: String) {
        val m = _match.value
        val s = session
        viewModelScope.launch(Dispatchers.IO) {
            store.saveMatch(toSaved(m, s, name.ifBlank { "${m.setup.teamA} vs ${m.setup.teamB}" }))
            refreshSaved()
            _toast.value = "Match saved"
        }
    }

    fun loadMatch(saved: Json.SavedMatch) {
        restore(saved)
        viewModelScope.launch(Dispatchers.IO) {
            loadTeamLogos()
            publish()
        }
    }

    fun deleteMatch(id: String) {
        viewModelScope.launch(Dispatchers.IO) { store.deleteMatch(id); refreshSaved() }
    }

    fun savePreset(name: String) {
        val g = _graphics.value.copy(name = name.ifBlank { "Preset" })
        viewModelScope.launch(Dispatchers.IO) { store.savePreset(g); refreshSaved(); _toast.value = "Preset saved" }
    }

    fun applyPreset(g: GraphicsConfig) { setGraphics(g.sanitized()); viewModelScope.launch(Dispatchers.IO) { loadAllBitmaps() } }

    fun deletePreset(name: String) {
        viewModelScope.launch(Dispatchers.IO) { store.deletePreset(name); refreshSaved() }
    }

    private fun refreshSaved() {
        _savedMatches.value = store.listMatches()
        _presets.value = store.listPresets()
    }

    // ====================================================================== graphics

    fun setGraphics(g: GraphicsConfig) {
        val clean = g.sanitized()
        _graphics.value = clean
        engine.broadcast.update(config = clean) // visible in preview AND stream on the next frame
        viewModelScope.launch(Dispatchers.IO) {
            try { store.saveGraphics(clean) } catch (_: Exception) { }
        }
    }

    fun updateGraphics(block: (GraphicsConfig) -> GraphicsConfig) = setGraphics(block(_graphics.value))

    fun importMedia(uri: Uri, kind: MediaKind) {
        viewModelScope.launch(Dispatchers.IO) {
            val path = MediaImporter.importImage(getApplication<Application>(), uri, kind.name.lowercase())
            if (path == null) { _toast.value = "That file could not be read as an image"; return@launch }
            when (kind) {
                MediaKind.BACKGROUND -> { _graphics.update { it.copy(backgroundUri = path) }; engine.broadcast.assets.background = MediaImporter.load(path, 1920) }
                MediaKind.LOGO -> { _graphics.update { it.copy(logoUri = path) }; engine.broadcast.assets.logo = MediaImporter.load(path, 512) }
                MediaKind.SPONSOR -> { _graphics.update { it.copy(sponsorUri = path) }; engine.broadcast.assets.sponsor = MediaImporter.load(path, 512) }
                MediaKind.TEAM_A -> { _match.update { it.copy(teamALogoPath = path) }; engine.broadcast.assets.teamALogo = MediaImporter.load(path, 384) }
                MediaKind.TEAM_B -> { _match.update { it.copy(teamBLogoPath = path) }; engine.broadcast.assets.teamBLogo = MediaImporter.load(path, 384) }
            }
            setGraphics(_graphics.value)
        }
    }

    fun clearMedia(kind: MediaKind) {
        when (kind) {
            MediaKind.BACKGROUND -> { _graphics.update { it.copy(backgroundUri = null) }; engine.broadcast.assets.background = null }
            MediaKind.LOGO -> { _graphics.update { it.copy(logoUri = null) }; engine.broadcast.assets.logo = null }
            MediaKind.SPONSOR -> { _graphics.update { it.copy(sponsorUri = null) }; engine.broadcast.assets.sponsor = null }
            MediaKind.TEAM_A -> { _match.update { it.copy(teamALogoPath = null) }; engine.broadcast.assets.teamALogo = null }
            MediaKind.TEAM_B -> { _match.update { it.copy(teamBLogoPath = null) }; engine.broadcast.assets.teamBLogo = null }
        }
        setGraphics(_graphics.value)
    }

    private fun loadAllBitmaps() {
        val g = _graphics.value
        val a = engine.broadcast.assets
        a.background = MediaImporter.load(g.backgroundUri, 1920)
        a.logo = MediaImporter.load(g.logoUri, 512)
        a.sponsor = MediaImporter.load(g.sponsorUri, 512)
        loadTeamLogos()
    }

    private fun loadTeamLogos() {
        val m = _match.value
        engine.broadcast.assets.teamALogo = MediaImporter.load(m.teamALogoPath, 384)
        engine.broadcast.assets.teamBLogo = MediaImporter.load(m.teamBLogoPath, 384)
    }

    // ====================================================================== streaming

    fun updateStream(block: (StreamSettings) -> StreamSettings) {
        _stream.update(block)
        val s = _stream.value
        viewModelScope.launch(Dispatchers.IO) { store.saveStreamSettings(s) }
        if (!engine.isActive()) engine.reconfigurePreview(s.profile, s.fps)
    }

    // ====================================================================== video source (camera / background)

    fun hasCameraPermission(): Boolean = engine.hasCameraPermission()

    fun setVideoSource(mode: VideoSourceMode) {
        _stream.update { it.copy(videoSource = mode) }
        val s = _stream.value
        viewModelScope.launch(Dispatchers.IO) { store.saveStreamSettings(s) }
        engine.setVideoSource(mode, s.cameraRotationOffset)
    }

    fun setCameraRotation(degrees: Int) {
        _stream.update { it.copy(cameraRotationOffset = degrees) }
        val s = _stream.value
        viewModelScope.launch(Dispatchers.IO) { store.saveStreamSettings(s) }
        engine.setVideoSource(s.videoSource, degrees)
    }

    // ====================================================================== background music & monitoring

    fun updateAudioMix(block: (AudioMixSettings) -> AudioMixSettings) {
        _audioMix.update { block(it).sanitized() }
        val a = _audioMix.value
        engine.applyAudioMix(a)
        viewModelScope.launch(Dispatchers.IO) { store.saveAudioMix(a) }
    }

    fun addMusic(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            var added = 0
            for (u in uris) {
                val imported = MediaImporter.importAudio(ctx, u) ?: continue
                updateAudioMix { a -> a.copy(tracks = a.tracks + MusicTrack(imported.first, imported.second)) }
                added++
            }
            _toast.value = if (added == uris.size) "Music added ($added)" else "$added of ${uris.size} files could be used; the rest are not audio files"
        }
    }

    fun removeMusic(track: MusicTrack) {
        updateAudioMix { a -> a.copy(tracks = a.tracks.filter { it.path != track.path }) }
        viewModelScope.launch(Dispatchers.IO) { runCatching { File(track.path).delete() } }
    }

    fun musicPlay() = engine.musicPlay()
    fun musicPause() = engine.musicPause()
    fun musicNext() = engine.musicNext()

    fun setRememberKey(remember: Boolean) {
        _rememberKey.value = remember
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            if (remember) SecretStore.save(ctx, _stream.value.streamKey) else SecretStore.clear(ctx)
        }
    }

    /** Called by the UI when the user presses Start Live (after the mic permission has been granted). */
    fun startLive() {
        val s = _stream.value
        when (val r = engine.startStream(s)) {
            is StartResult.Rejected -> _liveProblems.value = r.reasons
            StartResult.Started -> {
                _liveProblems.value = emptyList()
                if (_rememberKey.value) {
                    val ctx = getApplication<Application>()
                    viewModelScope.launch(Dispatchers.IO) { SecretStore.save(ctx, s.streamKey) }
                }
                StreamService.start(getApplication<Application>())
            }
        }
    }

    fun stopLive() {
        engine.stopStream()
        StreamService.stop(getApplication<Application>())
    }

    fun setMuted(muted: Boolean) = engine.setUserMuted(muted)
    fun lowerBitrateNow() {
        val s = _stream.value
        val lowered = com.zarvimo.cricket.stream.BitrateAdvisor.reduced(s.videoBitrateKbps, s.profile)
        engine.setVideoBitrateOnFly(lowered)
        _stream.update { it.copy(videoBitrateKbps = lowered) }
    }

    fun elapsedSeconds(): Long? = engine.elapsedSeconds()
    fun hasMic(): Boolean = engine.hasMicPermission()
    fun engineRef() = engine

    fun clearLiveProblems() { _liveProblems.value = emptyList() }
}

enum class MediaKind { BACKGROUND, LOGO, SPONSOR, TEAM_A, TEAM_B }
