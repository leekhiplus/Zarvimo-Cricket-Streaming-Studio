package com.zarvimo.cricket.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.cricket.stream.StreamState
import com.zarvimo.cricket.stream.VideoSourceMode

private val Warn = Color(0xFFFFB74D)
private val Bad = Color(0xFFFF6B6B)

/** Camera (back / front) or background picture (optionally with a round camera picture). Switching is live. */
@Composable
fun VideoSourceCard(vm: AppViewModel) {
    val settings by vm.stream.collectAsState()
    val g by vm.graphics.collectAsState()
    var pending by remember { mutableStateOf<VideoSourceMode?>(null) }
    var pendingBubble by remember { mutableStateOf(false) }
    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val wanted = pending
        val bubbleWanted = pendingBubble
        pending = null
        pendingBubble = false
        if (granted) {
            if (wanted != null) vm.setVideoSource(wanted)
            if (bubbleWanted) vm.updateBubble { it.copy(bubbleEnabled = true) }
        } else {
            vm.reportMessage("Camera permission is needed to use the camera")
        }
    }
    val pickBackground = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> vm.importMedia(u, MediaKind.BACKGROUND) } }

    SectionCard("Video source", icon = Ic.Video) {
        ChipChoice(VideoSourceMode.values().toList(), settings.videoSource, { it.label }) { mode ->
            if (mode.isCamera && !vm.hasCameraPermission()) {
                pending = mode
                cameraPermission.launch(Manifest.permission.CAMERA)
            } else {
                vm.setVideoSource(mode)
            }
        }
        if (settings.videoSource.isCamera) {
            Text("Camera picture rotation (only if the picture looks sideways or upside-down)", fontSize = 12.sp)
            ChipChoice(listOf(0, 90, 180, 270), settings.cameraRotationOffset, { if (it == 0) "Auto" else "+$it°" }) { vm.setCameraRotation(it) }
            Text(
                "The scoreboard is drawn on top of the camera picture. For a full-screen picture hold the phone sideways (landscape).",
                fontSize = 11.sp
            )
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton("Choose background", Modifier.weight(1f), icon = Ic.Image) { pickBackground.launch("image/*") }
                if (g.backgroundUri != null) BigButton("Use default", Modifier.weight(1f), Color(0xFF5A2A2A), icon = Ic.Trash) { vm.clearMedia(MediaKind.BACKGROUND) }
            }
            SwitchRow("Camera in a circle over the background (optional)", settings.bubbleEnabled) { on ->
                if (on && !vm.hasCameraPermission()) {
                    pendingBubble = true
                    cameraPermission.launch(Manifest.permission.CAMERA)
                } else {
                    vm.updateBubble { it.copy(bubbleEnabled = on) }
                }
            }
            if (settings.bubbleEnabled) {
                ChipChoice(listOf(true, false), settings.bubbleFront, { if (it) "Front camera" else "Back camera" }) { v -> vm.updateBubble { it.copy(bubbleFront = v) } }
                LabeledSlider("Circle size", settings.bubbleSize, 0.12f..0.6f, "${(settings.bubbleSize * 100).toInt()} %") { v -> vm.updateBubble { it.copy(bubbleSize = v) } }
                Text("Position", fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    BigButton("Top left", Modifier.weight(1f).heightIn(min = 44.dp)) { vm.updateBubble { it.copy(bubbleX = 0.14f, bubbleY = 0.26f) } }
                    BigButton("Top right", Modifier.weight(1f).heightIn(min = 44.dp)) { vm.updateBubble { it.copy(bubbleX = 0.86f, bubbleY = 0.26f) } }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    BigButton("Bottom left", Modifier.weight(1f).heightIn(min = 44.dp)) { vm.updateBubble { it.copy(bubbleX = 0.14f, bubbleY = 0.74f) } }
                    BigButton("Bottom right", Modifier.weight(1f).heightIn(min = 44.dp)) { vm.updateBubble { it.copy(bubbleX = 0.86f, bubbleY = 0.74f) } }
                }
                LabeledSlider("Left to right", settings.bubbleX, 0f..1f, "${(settings.bubbleX * 100).toInt()} %") { v -> vm.updateBubble { it.copy(bubbleX = v) } }
                LabeledSlider("Top to bottom", settings.bubbleY, 0f..1f, "${(settings.bubbleY * 100).toInt()} %") { v -> vm.updateBubble { it.copy(bubbleY = v) } }
                Text("Switch it on or off at any time, even while live. Scoreboard and graphics stay on top of the circle.", fontSize = 11.sp)
            }
        }
    }
}

/** One glance: what is really going to the viewers right now, and a warning when the mixer is not working. */
@Composable
fun AudioOnAirCard(vm: AppViewModel) {
    val mix by vm.audioMix.collectAsState()
    val music by vm.musicState.collectAsState()
    val audio by vm.audioState.collectAsState()
    val auto by vm.autoShow.collectAsState()
    val level by vm.micLevel.collectAsState()
    val ss by vm.streamStatus.collectAsState()
    val live = ss.state != StreamState.IDLE && ss.state != StreamState.ERROR
    SectionCard("What viewers hear", icon = Ic.Radio) {
        if (!live) Text("Not live yet. This shows what will be sent once you go live.", fontSize = 12.sp)
        if (live && !audio.chainHooked) {
            WarnLine("Music, spoken commentary and effects are NOT reaching the stream: the audio mixer is not receiving the microphone. Stop the live and start it again; if it stays like this, tell me.")
        }
        if (audio.autoMuted) {
            WarnLine("Your microphone is muted because a call or another app took the audio. Music and effects still go on air. It resumes by itself.", color = Warn)
        }
        OnAirRow(Ic.Mic, "Commentary microphone", if (audio.effectivelyMuted) "MUTED" else "ON AIR", !audio.effectivelyMuted)
        if (live && !audio.effectivelyMuted) {
            val shown = level.coerceIn(0f, 1f)
            Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(PanelHi)) {
                Box(Modifier.fillMaxWidth(shown).height(6.dp).background(if (shown > 0.9f) Crimson else Mint))
            }
        }
        OnAirRow(
            Ic.Music, "Background music",
            when {
                mix.tracks.isEmpty() -> "NO MUSIC ADDED"
                !music.playing -> "STOPPED"
                !mix.musicOnAir -> "PLAYING (only you hear it)"
                else -> "ON AIR"
            },
            music.playing && mix.musicOnAir
        )
        OnAirRow(Ic.Mic, "Spoken commentary (computer voice)", if (auto.voiceEnabled) "ON" else "OFF", auto.voiceEnabled)
    }
}

@Composable
private fun OnAirRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, state: String, good: Boolean) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        AppIcon(icon, size = 18.dp, tint = if (good) Mint else Muted)
        Spacer(Modifier.width(8.dp))
        Text(label, Modifier.weight(1f), fontSize = 13.sp)
        Text(state, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (good) Mint else Muted)
    }
}

/** Background music only: the playlist, whether it goes to the viewers, its loudness and the operator's own monitoring of it. */
@Composable
fun MusicCard(vm: AppViewModel) {
    val mix by vm.audioMix.collectAsState()
    val music by vm.musicState.collectAsState()
    val pickMusic = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris -> vm.addMusic(uris) }

    SectionCard("Background music", icon = Ic.Music) {
        BigButton("Add music files", Modifier.fillMaxWidth(), icon = Ic.Upload) { pickMusic.launch("audio/*") }
        if (mix.tracks.isEmpty()) {
            Text("No music yet. Add one or more audio files; they play one after another in a loop.", fontSize = 12.sp)
        }
        mix.tracks.forEachIndexed { i, t ->
            val current = music.playing && music.index == i
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                AppIcon(if (current) Ic.Play else Ic.Music, size = 16.dp, tint = if (current) Gold else Muted)
                Spacer(Modifier.width(8.dp))
                Text(
                    t.name,
                    Modifier.weight(1f),
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = if (current) Gold else Color.White
                )
                AppIcon(Ic.Close, Modifier.clickable { vm.removeMusic(t) }.padding(horizontal = 12.dp, vertical = 8.dp), size = 22.dp, tint = Bad)
            }
        }
        if (mix.tracks.isNotEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton(if (music.playing) "Pause music" else "Play music", Modifier.weight(2f).heightIn(min = 48.dp), icon = if (music.playing) Ic.Pause else Ic.Play) {
                    if (music.playing) vm.musicPause() else vm.musicPlay()
                }
                BigButton("Next", Modifier.weight(1f).heightIn(min = 48.dp), icon = Ic.Next) { vm.musicNext() }
            }
        }
        music.error?.let { Text(it, color = Bad, fontSize = 12.sp) }

        SwitchRow("Send the music to the viewers", mix.musicOnAir) { v -> vm.updateAudioMix { it.copy(musicOnAir = v) } }
        LabeledSlider("Music volume", mix.musicVolume, 0f..1f, "${(mix.musicVolume * 100).toInt()} %") { v -> vm.updateAudioMix { it.copy(musicVolume = v) } }
        SwitchRow("Hear the music myself", mix.musicMonitor) { v -> vm.updateAudioMix { it.copy(musicMonitor = v) } }
        LabeledSlider("My monitor volume", mix.monitorVolume, 0f..1f, "${(mix.monitorVolume * 100).toInt()} %") { v -> vm.updateAudioMix { it.copy(monitorVolume = v) } }
        Text("Tip: through the phone speaker the microphone can pick the music up a second time. Headphones give the cleanest sound.", fontSize = 11.sp, color = Muted)
    }
}

/** Commentary microphone only: its loudness, mute, automatic music ducking, and hearing yourself in headphones. */
@Composable
fun CommentaryMicCard(vm: AppViewModel) {
    val mix by vm.audioMix.collectAsState()
    val audio by vm.audioState.collectAsState()
    val headset by vm.headset.collectAsState()
    val level by vm.micLevel.collectAsState()
    val ss by vm.streamStatus.collectAsState()
    val live = ss.state != StreamState.IDLE && ss.state != StreamState.ERROR

    SectionCard("Commentary microphone", icon = Ic.Mic) {
        BigButton(
            if (audio.userMuted) "Microphone is MUTED: tap to speak" else "Microphone is ON: tap to mute",
            Modifier.fillMaxWidth().height(52.dp), if (audio.userMuted) Color(0xFF6C7A89) else Color(0xFF1B5E20),
            icon = if (audio.userMuted) Ic.MicOff else Ic.Mic
        ) { vm.setMuted(!audio.userMuted) }
        Text("Muting only silences your voice. The music and the spoken commentary keep going on air.", fontSize = 12.sp)
        LabeledSlider("Commentary mic volume", mix.micVolume, 0f..2f, "${(mix.micVolume * 100).toInt()} %") { v -> vm.updateAudioMix { it.copy(micVolume = v) } }
        SwitchRow("Lower the music automatically while I speak", mix.duckMusic) { v -> vm.updateAudioMix { it.copy(duckMusic = v) } }
        if (mix.duckMusic) {
            LabeledSlider("Music level while I speak", mix.duckLevel, 0.05f..1f, "${(mix.duckLevel * 100).toInt()} %") { v -> vm.updateAudioMix { it.copy(duckLevel = v) } }
        }
        SwitchRow("Hear my microphone in my headphones", mix.micMonitor) { v -> vm.updateAudioMix { it.copy(micMonitor = v) } }
        if (mix.micMonitor && !headset) {
            Text(
                "No headphones detected. Plug in headphones or a headset to hear your microphone; through the speaker it would cause howling feedback, so it stays silent.",
                fontSize = 12.sp, color = Warn
            )
        } else if (mix.micMonitor && !live) {
            Text("Your microphone is heard back while you are live.", fontSize = 12.sp)
        }
        if (live) {
            Text("Commentary mic level", fontSize = 12.sp)
            val shown = level.coerceIn(0f, 1f)
            Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(PanelHi)) {
                Box(Modifier.fillMaxWidth(shown).height(8.dp).background(if (shown > 0.9f) Crimson else Mint))
            }
        }
    }
}

/** Noise cancelling and studio sound for the commentary microphone (what the viewers hear). */
@Composable
fun VoiceFxCard(vm: AppViewModel) {
    val mix by vm.audioMix.collectAsState()
    SectionCard("Commentary voice: noise cancelling & studio sound", icon = Ic.Mic) {
        Text(
            "Cleans the sound of your microphone for the viewers. It does not change what you hear in your headphones.",
            fontSize = 12.sp
        )
        Text("Quick presets", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Gold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            BigButton("Off", Modifier.weight(1f).heightIn(min = 44.dp)) { vm.updateAudioMix { it.copy(noiseReduction = 0, studioVoice = 0, rumbleFilter = false) } }
            BigButton("Clean", Modifier.weight(1f).heightIn(min = 44.dp)) { vm.updateAudioMix { it.copy(noiseReduction = 1, studioVoice = 0, rumbleFilter = true) } }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            BigButton("Studio voice", Modifier.weight(1f).heightIn(min = 44.dp)) { vm.updateAudioMix { it.copy(noiseReduction = 2, studioVoice = 1, rumbleFilter = true) } }
            BigButton("Noisy ground", Modifier.weight(1f).heightIn(min = 44.dp)) { vm.updateAudioMix { it.copy(noiseReduction = 3, studioVoice = 2, rumbleFilter = true) } }
        }
        Text("Noise cancelling (fan, crowd, traffic, hiss)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Gold)
        ChipChoice(listOf(0, 1, 2, 3), mix.noiseReduction, { when (it) { 0 -> "Off"; 1 -> "Light"; 2 -> "Medium"; else -> "Strong" } }) { v ->
            vm.updateAudioMix { it.copy(noiseReduction = v) }
        }
        Text("Studio voice (fuller, clearer, even loudness)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Gold)
        ChipChoice(listOf(0, 1, 2), mix.studioVoice, { when (it) { 0 -> "Off"; 1 -> "Natural"; else -> "Radio" } }) { v ->
            vm.updateAudioMix { it.copy(studioVoice = v) }
        }
        SwitchRow("Remove low rumble and wind thumps", mix.rumbleFilter) { v -> vm.updateAudioMix { it.copy(rumbleFilter = v) } }
        SwitchRow("Also use the phone's own noise and echo canceller (applies the next time you go live)", mix.platformFx) { v -> vm.updateAudioMix { it.copy(platformFx = v) } }
        Text(
            "Good to know: this is noise cancelling on your microphone (what headsets call ENC). ANC, which quiets the world in your own ears, is done by the headphones; no app can do it. " +
                "For the clearest sound use a wired handsfree (Bluetooth microphones are low quality), keep the microphone 5 to 10 cm from your mouth, and keep the phone speaker away. " +
                "Strong settings can make a voice sound slightly processed; try Medium first. Turn on \"Hear my microphone\" with headphones to judge the result.",
            fontSize = 11.sp
        )
    }
}
