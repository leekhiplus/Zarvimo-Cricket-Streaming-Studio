package com.zarvimo.cricket.stream

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.zarvimo.cricket.MainActivity
import com.zarvimo.cricket.R
import com.zarvimo.cricket.ZarvimoApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Foreground service (type: microphone) that keeps the process alive while a stream session is active.
 * The pipeline itself lives in [StreamEngine]; this service only provides process priority, the persistent
 * notification with a "Stop Live" action, a CPU wake-lock, and the periodic mic-permission watchdog.
 *
 * START_NOT_STICKY: if Android kills the process, we must NOT silently resume transmitting.
 */
class StreamService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var watcher: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var inForeground = false

    private val engine: StreamEngine get() = (application as ZarvimoApp).engine

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                engine.stopStream()
                shutdown()
            }
            else -> {
                if (!engine.hasMicPermission()) {
                    // Android 14+ forbids a microphone-type FGS without the runtime permission.
                    stopSelf()
                    return START_NOT_STICKY
                }
                startForegroundNow()
                startWatching()
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundNow() {
        createChannel()
        val n = buildNotification("Starting stream…")
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        inForeground = true
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "zarvimo:stream").apply {
                setReferenceCounted(false)
                acquire(12 * 60 * 60 * 1000L) // hard upper bound; released as soon as the stream ends
            }
        }
    }

    private fun startWatching() {
        if (watcher?.isActive == true) return
        watcher = scope.launch {
            var seenActive = false
            val startedAt = System.currentTimeMillis()
            while (isActive) {
                val st = engine.status.value
                val active = st.state != StreamState.IDLE && st.state != StreamState.ERROR
                if (active) seenActive = true
                if (!seenActive && System.currentTimeMillis() - startedAt > 10_000) {
                    shutdown() // service was started but no stream session exists: never linger as a fake "live" notification
                    return@launch
                }
                if (!active && seenActive) {
                    // Session ended (stopped, failed or retries exhausted): leave foreground.
                    shutdown()
                    return@launch
                }
                if (active) {
                    engine.checkMicPermissionStillGranted()
                    val elapsed = engine.elapsedSeconds()
                    val text = StatusLabels.stream(st.state) +
                        (elapsed?.let { "  " + DurationFormat.hhmmss(it) } ?: "") +
                        (if (st.state == StreamState.RECONNECTING) "  (attempt ${st.reconnectAttempt}/${st.maxReconnectAttempts})" else "")
                    getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
                }
                delay(1000)
            }
        }
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, StreamService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_live)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(open)
            .addAction(0, "Stop Live", stop)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL_ID, "Live streaming", NotificationManager.IMPORTANCE_LOW)
            ch.description = "Shown while a live stream is running"
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun shutdown() {
        watcher?.cancel()
        watcher = null
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        wakeLock = null
        if (inForeground) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            inForeground = false
        }
        stopSelf()
    }

    override fun onDestroy() {
        scope.cancel()
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        // If the service is destroyed while a session is still active, stop transmitting rather than leak it.
        if (engine.isActive()) engine.stopStream()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.zarvimo.cricket.action.START"
        const val ACTION_STOP = "com.zarvimo.cricket.action.STOP"
        private const val CHANNEL_ID = "live_stream"
        private const val NOTIF_ID = 4101

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, StreamService::class.java).setAction(ACTION_START))
        }

        fun stop(context: Context) {
            context.startService(Intent(context, StreamService::class.java).setAction(ACTION_STOP))
        }
    }
}
