package com.zarvimo.cricket.data

import com.zarvimo.cricket.graphics.FontChoice
import com.zarvimo.cricket.graphics.GraphicsConfig
import com.zarvimo.cricket.graphics.MatchVisuals
import com.zarvimo.cricket.graphics.SafeArea
import com.zarvimo.cricket.graphics.ScoreboardTemplate
import com.zarvimo.cricket.scoring.AdjustmentEvent
import com.zarvimo.cricket.scoring.BallEvent
import com.zarvimo.cricket.scoring.BatterInEvent
import com.zarvimo.cricket.scoring.DismissalType
import com.zarvimo.cricket.scoring.EndInningsEvent
import com.zarvimo.cricket.scoring.ExtraType
import com.zarvimo.cricket.scoring.InningsData
import com.zarvimo.cricket.scoring.InningsSeed
import com.zarvimo.cricket.scoring.InningsSetup
import com.zarvimo.cricket.scoring.SeedBatter
import com.zarvimo.cricket.scoring.SeedBowler
import com.zarvimo.cricket.scoring.MatchSession
import com.zarvimo.cricket.scoring.MatchSetup
import com.zarvimo.cricket.scoring.PenaltyEvent
import com.zarvimo.cricket.scoring.ScoreEvent
import com.zarvimo.cricket.scoring.SetBowlerEvent
import com.zarvimo.cricket.scoring.SwapStrikeEvent
import com.zarvimo.cricket.scoring.WicketInfo
import com.zarvimo.cricket.scoring.TossDecision
import com.zarvimo.cricket.stream.AudioMixSettings
import com.zarvimo.cricket.stream.AutoShowSettings
import com.zarvimo.cricket.stream.MusicTrack
import com.zarvimo.cricket.stream.ResolutionProfile
import com.zarvimo.cricket.stream.StreamSettings
import org.json.JSONArray
import org.json.JSONObject

/**
 * Hand-written JSON codecs (org.json) so saved matches / presets are stable, human-readable and independent of any
 * reflection library. The stream key is NEVER serialised here.
 */
object Json {

    private inline fun <reified E : Enum<E>> JSONObject.enumOr(key: String, default: E): E =
        try {
            enumValueOf<E>(optString(key, default.name))
        } catch (e: IllegalArgumentException) {
            default
        }

    private fun JSONObject.strOrNull(key: String): String? =
        if (has(key) && !isNull(key)) optString(key).takeIf { it.isNotEmpty() } else null

    // ------------------------------------------------------------------ scoring

    fun wicketToJson(w: WicketInfo) = JSONObject()
        .put("type", w.type.name)
        .put("strikerOut", w.outBatterIsStriker)
        .put("fielder", w.fielder ?: JSONObject.NULL)
        .put("incoming", w.incomingBatter ?: JSONObject.NULL)

    fun wicketFromJson(o: JSONObject) = WicketInfo(
        type = o.enumOr("type", DismissalType.BOWLED),
        outBatterIsStriker = o.optBoolean("strikerOut", true),
        fielder = o.strOrNull("fielder"),
        incomingBatter = o.strOrNull("incoming")
    )

    fun eventToJson(e: ScoreEvent): JSONObject = when (e) {
        is BallEvent -> JSONObject().put("t", "ball").put("id", e.id).put("runsBat", e.runsBat)
            .put("extra", e.extra.name).put("extraRuns", e.extraRuns).put("nbType", e.noBallRunType.name)
            .put("boundary", e.boundary).apply { e.wicket?.let { put("wicket", wicketToJson(it)) } }
        is SetBowlerEvent -> JSONObject().put("t", "bowler").put("id", e.id).put("name", e.name)
        is BatterInEvent -> JSONObject().put("t", "batter").put("id", e.id).put("name", e.name)
        is SwapStrikeEvent -> JSONObject().put("t", "swap").put("id", e.id)
        is PenaltyEvent -> JSONObject().put("t", "penalty").put("id", e.id).put("runs", e.runs)
        is AdjustmentEvent -> JSONObject().put("t", "adjust").put("id", e.id).put("runs", e.runs)
            .put("wickets", e.wickets).put("note", e.note)
        is EndInningsEvent -> JSONObject().put("t", "end").put("id", e.id).put("reason", e.reason)
    }

    fun eventFromJson(o: JSONObject): ScoreEvent? {
        val id = o.optLong("id", -1)
        if (id < 0) return null
        return when (o.optString("t")) {
            "ball" -> BallEvent(
                id = id, runsBat = o.optInt("runsBat"), extra = o.enumOr("extra", ExtraType.NONE),
                extraRuns = o.optInt("extraRuns"), noBallRunType = o.enumOr("nbType", ExtraType.NONE),
                boundary = o.optBoolean("boundary"), wicket = o.optJSONObject("wicket")?.let { wicketFromJson(it) }
            )
            "bowler" -> SetBowlerEvent(id, o.optString("name"))
            "batter" -> BatterInEvent(id, o.optString("name"))
            "swap" -> SwapStrikeEvent(id)
            "penalty" -> PenaltyEvent(id, o.optInt("runs"))
            "adjust" -> AdjustmentEvent(id, o.optInt("runs"), o.optInt("wickets"), o.optString("note"))
            "end" -> EndInningsEvent(id, o.optString("reason", "Declared"))
            else -> null
        }
    }

    fun setupToJson(s: MatchSetup) = JSONObject()
        .put("teamA", s.teamA).put("teamB", s.teamB).put("title", s.title).put("venue", s.venue)
        .put("overs", s.oversLimit).put("ballsPerOver", s.ballsPerOver).put("players", s.playersPerSide)
        .put("widePenalty", s.widePenalty).put("noBallPenalty", s.noBallPenalty)
        .put("freeHit", s.enforceFreeHit).put("consecutiveOvers", s.allowConsecutiveOvers)
        .put("maxOversPerBowler", s.maxOversPerBowler ?: JSONObject.NULL)
        .put("tossWinner", s.tossWinner).put("tossDecision", s.tossDecision.name).put("startTime", s.startTime)

    fun setupFromJson(o: JSONObject) = MatchSetup(
        teamA = o.optString("teamA", "Team A"), teamB = o.optString("teamB", "Team B"),
        title = o.optString("title"), venue = o.optString("venue"),
        oversLimit = o.optInt("overs", 20), ballsPerOver = o.optInt("ballsPerOver", 6),
        playersPerSide = o.optInt("players", 11), widePenalty = o.optInt("widePenalty", 1),
        noBallPenalty = o.optInt("noBallPenalty", 1), enforceFreeHit = o.optBoolean("freeHit", true),
        allowConsecutiveOvers = o.optBoolean("consecutiveOvers", false),
        maxOversPerBowler = if (o.has("maxOversPerBowler") && !o.isNull("maxOversPerBowler")) o.optInt("maxOversPerBowler") else null,
        tossWinner = o.optString("tossWinner", ""),
        tossDecision = o.enumOr("tossDecision", TossDecision.NONE),
        startTime = o.optString("startTime", "")
    )

    fun visualsToJson(v: MatchVisuals) = JSONObject()
        .put("colorA", v.teamAColor).put("colorB", v.teamBColor)
        .put("shortA", v.teamAShort).put("shortB", v.teamBShort)

    fun visualsFromJson(o: JSONObject) = MatchVisuals(
        teamAColor = o.optInt("colorA", MatchVisuals().teamAColor), teamBColor = o.optInt("colorB", MatchVisuals().teamBColor),
        teamAShort = o.optString("shortA"), teamBShort = o.optString("shortB")
    )

    fun inningsSetupToJson(s: InningsSetup): JSONObject {
        val o = JSONObject()
            .put("bat", s.battingTeam).put("bowl", s.bowlingTeam)
            .put("striker", s.striker).put("nonStriker", s.nonStriker).put("bowler", s.bowler)
        s.seed?.let { o.put("seed", seedToJson(it)) }
        return o
    }

    fun inningsSetupFromJson(o: JSONObject) = InningsSetup(
        o.optString("bat"), o.optString("bowl"), o.optString("striker"), o.optString("nonStriker"), o.optString("bowler"),
        o.optJSONObject("seed")?.let { seedFromJson(it) }
    )

    private fun seedToJson(d: InningsSeed): JSONObject {
        val outs = JSONArray()
        d.outBatters.forEach {
            outs.put(JSONObject().put("n", it.name).put("r", it.runs).put("b", it.balls).put("f", it.fours).put("s", it.sixes).put("d", it.dismissal))
        }
        val bowls = JSONArray()
        d.otherBowlers.forEach {
            bowls.put(JSONObject().put("n", it.name).put("b", it.legalBalls).put("m", it.maidens).put("r", it.runs).put("w", it.wickets))
        }
        val overs = JSONArray()
        d.overRuns.forEach { overs.put(it) }
        val o = JSONObject()
            .put("runs", d.runs).put("wk", d.wickets).put("lb", d.legalBalls)
            .put("wd", d.wides).put("nb", d.noBalls).put("by", d.byes).put("lby", d.legByes).put("pen", d.penalty)
            .put("sr", d.strikerRuns).put("sb", d.strikerBalls).put("s4", d.strikerFours).put("s6", d.strikerSixes)
            .put("nr", d.nonStrikerRuns).put("nbl", d.nonStrikerBalls).put("n4", d.nonStrikerFours).put("n6", d.nonStrikerSixes)
            .put("bwb", d.bowlerLegalBalls).put("bwm", d.bowlerMaidens).put("bwr", d.bowlerRuns).put("bww", d.bowlerWickets)
            .put("cor", d.currentOverRuns)
            .put("out", outs).put("others", bowls).put("overRuns", overs)
        d.partnershipRuns?.let { o.put("pr", it) }
        d.partnershipBalls?.let { o.put("pb", it) }
        return o
    }

    private fun seedFromJson(o: JSONObject): InningsSeed {
        val outs = ArrayList<SeedBatter>()
        o.optJSONArray("out")?.let { a ->
            for (i in 0 until a.length()) {
                val x = a.optJSONObject(i) ?: continue
                outs.add(SeedBatter(x.optString("n"), x.optInt("r"), x.optInt("b"), x.optInt("f"), x.optInt("s"), x.optString("d", "out")))
            }
        }
        val bowls = ArrayList<SeedBowler>()
        o.optJSONArray("others")?.let { a ->
            for (i in 0 until a.length()) {
                val x = a.optJSONObject(i) ?: continue
                bowls.add(SeedBowler(x.optString("n"), x.optInt("b"), x.optInt("m"), x.optInt("r"), x.optInt("w")))
            }
        }
        val overs = ArrayList<Int>()
        o.optJSONArray("overRuns")?.let { a -> for (i in 0 until a.length()) overs.add(a.optInt(i)) }
        return InningsSeed(
            runs = o.optInt("runs"), wickets = o.optInt("wk"), legalBalls = o.optInt("lb"),
            wides = o.optInt("wd"), noBalls = o.optInt("nb"), byes = o.optInt("by"), legByes = o.optInt("lby"), penalty = o.optInt("pen"),
            strikerRuns = o.optInt("sr"), strikerBalls = o.optInt("sb"), strikerFours = o.optInt("s4"), strikerSixes = o.optInt("s6"),
            nonStrikerRuns = o.optInt("nr"), nonStrikerBalls = o.optInt("nbl"), nonStrikerFours = o.optInt("n4"), nonStrikerSixes = o.optInt("n6"),
            bowlerLegalBalls = o.optInt("bwb"), bowlerMaidens = o.optInt("bwm"), bowlerRuns = o.optInt("bwr"), bowlerWickets = o.optInt("bww"),
            currentOverRuns = o.optInt("cor"),
            outBatters = outs, otherBowlers = bowls, overRuns = overs,
            partnershipRuns = if (o.has("pr")) o.optInt("pr") else null,
            partnershipBalls = if (o.has("pb")) o.optInt("pb") else null
        )
    }

    /** A whole match: setup + visuals + every innings with its full ordered event list. */
    data class SavedMatch(
        val id: String,
        val name: String,
        val updatedAtMs: Long,
        val setup: MatchSetup,
        val visuals: MatchVisuals,
        val session: MatchSession?,
        val teamALogoPath: String? = null,
        val teamBLogoPath: String? = null
    )

    fun matchToJson(m: SavedMatch): JSONObject {
        val innings = JSONArray()
        m.session?.innings?.forEach { d ->
            innings.put(
                JSONObject()
                    .put("setup", inningsSetupToJson(d.setup))
                    .put("targetOverride", d.targetOverride ?: JSONObject.NULL)
                    .put("events", JSONArray().also { arr -> d.events.forEach { arr.put(eventToJson(it)) } })
            )
        }
        return JSONObject()
            .put("version", 1).put("id", m.id).put("name", m.name).put("updatedAt", m.updatedAtMs)
            .put("setup", setupToJson(m.setup)).put("visuals", visualsToJson(m.visuals))
            .put("teamALogo", m.teamALogoPath ?: JSONObject.NULL).put("teamBLogo", m.teamBLogoPath ?: JSONObject.NULL)
            .put("innings", innings)
    }

    fun matchFromJson(o: JSONObject): SavedMatch {
        val setup = setupFromJson(o.getJSONObject("setup"))
        val session = MatchSession(setup)
        val arr = o.optJSONArray("innings") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val io = arr.getJSONObject(i)
            val data = InningsData(
                inningsSetupFromJson(io.getJSONObject("setup")),
                if (io.has("targetOverride") && !io.isNull("targetOverride")) io.optInt("targetOverride") else null
            )
            val evs = io.optJSONArray("events") ?: JSONArray()
            for (j in 0 until evs.length()) eventFromJson(evs.getJSONObject(j))?.let { data.events.add(it) }
            session.innings.add(data)
        }
        session.restoreIds()
        return SavedMatch(
            id = o.optString("id"), name = o.optString("name"), updatedAtMs = o.optLong("updatedAt"),
            setup = setup, visuals = visualsFromJson(o.optJSONObject("visuals") ?: JSONObject()),
            session = if (session.innings.isEmpty()) null else session,
            teamALogoPath = o.strOrNull("teamALogo"), teamBLogoPath = o.strOrNull("teamBLogo")
        )
    }

    // ------------------------------------------------------------------ graphics

    fun graphicsToJson(g: GraphicsConfig) = JSONObject()
        .put("name", g.name).put("template", g.template.name).put("posX", g.posX.toDouble()).put("posY", g.posY.toDouble())
        .put("scale", g.scale.toDouble()).put("margin", g.marginPx.toDouble())
        .put("safeL", g.safeArea.left.toDouble()).put("safeT", g.safeArea.top.toDouble())
        .put("safeR", g.safeArea.right.toDouble()).put("safeB", g.safeArea.bottom.toDouble())
        .put("primary", g.primaryColor).put("accent", g.accentColor).put("text", g.textColor).put("border", g.borderColor)
        .put("borderWidth", g.borderWidthPx.toDouble()).put("opacity", g.panelOpacity.toDouble()).put("font", g.font.name)
        .put("showTitle", g.showMatchTitle).put("showTicker", g.showTicker).put("ticker", g.tickerText)
        .put("showSponsor", g.showSponsor).put("showTeamLogos", g.showTeamLogos)
        .put("logoX", g.logoX.toDouble()).put("logoY", g.logoY.toDouble()).put("logoScale", g.logoScale.toDouble())
        .put("sponsorX", g.sponsorX.toDouble()).put("sponsorY", g.sponsorY.toDouble()).put("sponsorScale", g.sponsorScale.toDouble())
        .put("bg", g.backgroundUri ?: JSONObject.NULL).put("logo", g.logoUri ?: JSONObject.NULL).put("sponsor", g.sponsorUri ?: JSONObject.NULL)

    fun graphicsFromJson(o: JSONObject): GraphicsConfig {
        val d = GraphicsConfig()
        return GraphicsConfig(
            name = o.optString("name", d.name), template = o.enumOr("template", d.template),
            posX = o.optDouble("posX", d.posX.toDouble()).toFloat(), posY = o.optDouble("posY", d.posY.toDouble()).toFloat(),
            scale = o.optDouble("scale", d.scale.toDouble()).toFloat(), marginPx = o.optDouble("margin", d.marginPx.toDouble()).toFloat(),
            safeArea = SafeArea(
                o.optDouble("safeL", d.safeArea.left.toDouble()).toFloat(), o.optDouble("safeT", d.safeArea.top.toDouble()).toFloat(),
                o.optDouble("safeR", d.safeArea.right.toDouble()).toFloat(), o.optDouble("safeB", d.safeArea.bottom.toDouble()).toFloat()
            ),
            primaryColor = o.optInt("primary", d.primaryColor), accentColor = o.optInt("accent", d.accentColor),
            textColor = o.optInt("text", d.textColor), borderColor = o.optInt("border", d.borderColor),
            borderWidthPx = o.optDouble("borderWidth", d.borderWidthPx.toDouble()).toFloat(),
            panelOpacity = o.optDouble("opacity", d.panelOpacity.toDouble()).toFloat(), font = o.enumOr("font", d.font),
            showMatchTitle = o.optBoolean("showTitle", d.showMatchTitle), showTicker = o.optBoolean("showTicker", d.showTicker),
            tickerText = o.optString("ticker"), showSponsor = o.optBoolean("showSponsor", d.showSponsor),
            showTeamLogos = o.optBoolean("showTeamLogos", d.showTeamLogos),
            logoX = o.optDouble("logoX", d.logoX.toDouble()).toFloat(), logoY = o.optDouble("logoY", d.logoY.toDouble()).toFloat(),
            logoScale = o.optDouble("logoScale", d.logoScale.toDouble()).toFloat(),
            sponsorX = o.optDouble("sponsorX", d.sponsorX.toDouble()).toFloat(), sponsorY = o.optDouble("sponsorY", d.sponsorY.toDouble()).toFloat(),
            sponsorScale = o.optDouble("sponsorScale", d.sponsorScale.toDouble()).toFloat(),
            backgroundUri = o.strOrNull("bg"), logoUri = o.strOrNull("logo"), sponsorUri = o.strOrNull("sponsor")
        ).sanitized()
    }

    // ------------------------------------------------------------------ stream settings (NO KEY)

    fun streamSettingsToJson(s: StreamSettings) = JSONObject()
        .put("server", s.serverUrl).put("profile", s.profile.name).put("fps", s.fps)
        .put("videoKbps", s.videoBitrateKbps).put("audioKbps", s.audioBitrateKbps)
        .put("stereo", s.stereo).put("lowerOnReconnect", s.lowerBitrateOnReconnect)
        .put("videoSource", s.videoSource.name).put("camRot", s.cameraRotationOffset)
        .put("adaptive", s.adaptiveBitrate).put("recordLocal", s.recordLocally)
        .put("bubbleOn", s.bubbleEnabled).put("bubbleFront", s.bubbleFront)
        .put("bubbleSize", s.bubbleSize.toDouble()).put("bubbleX", s.bubbleX.toDouble()).put("bubbleY", s.bubbleY.toDouble())

    fun streamSettingsFromJson(o: JSONObject): StreamSettings {
        val d = StreamSettings()
        val profile = o.enumOr("profile", d.profile)
        return StreamSettings(
            serverUrl = o.optString("server", d.serverUrl), streamKey = "", profile = profile,
            fps = o.optInt("fps", d.fps), videoBitrateKbps = profile.clampBitrate(o.optInt("videoKbps", profile.defaultKbps)),
            audioBitrateKbps = o.optInt("audioKbps", d.audioBitrateKbps), stereo = o.optBoolean("stereo", false),
            lowerBitrateOnReconnect = o.optBoolean("lowerOnReconnect", true),
            videoSource = o.enumOr("videoSource", d.videoSource),
            cameraRotationOffset = o.optInt("camRot", 0).let { if (it == 0 || it == 90 || it == 180 || it == 270) it else 0 },
            adaptiveBitrate = o.optBoolean("adaptive", true),
            recordLocally = o.optBoolean("recordLocal", false),
            bubbleEnabled = o.optBoolean("bubbleOn", false),
            bubbleFront = o.optBoolean("bubbleFront", true),
            bubbleSize = o.optDouble("bubbleSize", 0.28).toFloat().coerceIn(0.12f, 0.6f),
            bubbleX = o.optDouble("bubbleX", 0.86).toFloat().coerceIn(0f, 1f),
            bubbleY = o.optDouble("bubbleY", 0.30).toFloat().coerceIn(0f, 1f)
        )
    }

    // ------------------------------------------------------------------ audio mix (music + monitor)

    fun audioMixToJson(a: AudioMixSettings): JSONObject {
        val arr = JSONArray()
        a.tracks.forEach { arr.put(JSONObject().put("path", it.path).put("name", it.name)) }
        return JSONObject().put("tracks", arr)
            .put("musicVol", a.musicVolume.toDouble()).put("micVol", a.micVolume.toDouble())
            .put("musicMon", a.musicMonitor).put("micMon", a.micMonitor).put("monVol", a.monitorVolume.toDouble())
            .put("nr", a.noiseReduction).put("studio", a.studioVoice).put("rumble", a.rumbleFilter).put("platformFx", a.platformFx)
    }

    fun autoShowToJson(a: AutoShowSettings): JSONObject = JSONObject()
        .put("burst", a.burstAnimations).put("voice", a.voiceEnabled).put("urdu", a.voiceUrdu)
        .put("voiceVol", a.voiceVolume.toDouble()).put("onFour", a.onFour).put("onSix", a.onSix).put("onWicket", a.onWicket)
        .put("autoHide", a.panelSeconds)

    fun autoShowFromJson(o: JSONObject): AutoShowSettings {
        val d = AutoShowSettings()
        return AutoShowSettings(
            burstAnimations = o.optBoolean("burst", d.burstAnimations),
            voiceEnabled = o.optBoolean("voice", d.voiceEnabled),
            voiceUrdu = o.optBoolean("urdu", d.voiceUrdu),
            voiceVolume = o.optDouble("voiceVol", d.voiceVolume.toDouble()).toFloat(),
            onFour = o.optBoolean("onFour", d.onFour),
            onSix = o.optBoolean("onSix", d.onSix),
            onWicket = o.optBoolean("onWicket", d.onWicket),
            panelSeconds = o.optInt("autoHide", d.panelSeconds)
        ).sanitized()
    }

    fun audioMixFromJson(o: JSONObject): AudioMixSettings {
        val d = AudioMixSettings()
        val arr = o.optJSONArray("tracks") ?: JSONArray()
        val tracks = ArrayList<MusicTrack>()
        for (i in 0 until arr.length()) {
            val t = arr.optJSONObject(i) ?: continue
            val path = t.optString("path")
            if (path.isNotBlank()) tracks.add(MusicTrack(path, t.optString("name", "Track")))
        }
        return AudioMixSettings(
            tracks = tracks,
            musicVolume = o.optDouble("musicVol", d.musicVolume.toDouble()).toFloat(),
            micVolume = o.optDouble("micVol", d.micVolume.toDouble()).toFloat(),
            musicMonitor = o.optBoolean("musicMon", d.musicMonitor),
            micMonitor = o.optBoolean("micMon", d.micMonitor),
            monitorVolume = o.optDouble("monVol", d.monitorVolume.toDouble()).toFloat(),
            noiseReduction = o.optInt("nr", d.noiseReduction),
            studioVoice = o.optInt("studio", d.studioVoice),
            rumbleFilter = o.optBoolean("rumble", d.rumbleFilter),
            platformFx = o.optBoolean("platformFx", d.platformFx)
        ).sanitized()
    }
}
