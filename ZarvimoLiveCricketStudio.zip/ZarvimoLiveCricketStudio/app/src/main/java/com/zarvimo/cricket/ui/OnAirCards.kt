package com.zarvimo.cricket.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.cricket.graphics.BurstKind
import com.zarvimo.cricket.graphics.AlertKind
import com.zarvimo.cricket.graphics.AlertTone
import com.zarvimo.cricket.graphics.PanelKind

private fun shortLabel(k: PanelKind): String = when (k) {
    PanelKind.SCORECARD -> "Scorecard"
    PanelKind.STRIKER -> "Striker"
    PanelKind.NON_STRIKER -> "Non-striker"
    PanelKind.BOWLER -> "Bowler"
    PanelKind.PARTNERSHIP -> "Partnership"
    PanelKind.RUN_RATE -> "Run rate graph"
    PanelKind.COMMENT -> "Comment"
    PanelKind.PLAYING_XI -> "Playing XI"
    PanelKind.TOSS_CARD -> "Toss"
    PanelKind.MATCH_SUMMARY -> "Summary"
    PanelKind.RESULT_CARD -> "Result"
    PanelKind.MAN_OF_MATCH -> "Man of the match"
}

@Composable
private fun PanelButtons(vm: AppViewModel, on: PanelKind?, kinds: List<PanelKind>) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        kinds.forEach { k ->
            val selected = on == k
            BigButton(
                shortLabel(k),
                Modifier.weight(1f).height(48.dp),
                if (selected) Gold else PanelHi,
                if (selected) Color.Black else Color.White
            ) { if (selected) vm.hidePanel() else vm.showPanel(k) }
        }
    }
}

/** Buttons that put a full scorecard, player card, partnership card or run-rate graph on air. */
@Composable
fun OnAirGraphicsCard(vm: AppViewModel) {
    val on by vm.panelOnAir.collectAsState()
    val auto by vm.autoShow.collectAsState()
    SectionCard("On-air graphics", icon = Ic.Tv) {
        Text(
            "Tap a button to put that graphic on air. It hides itself after ${auto.panelSeconds} seconds, follows the live score while it is up, and tapping it again hides it at once.",
            fontSize = 12.sp
        )
        PanelButtons(vm, on, listOf(PanelKind.SCORECARD, PanelKind.RUN_RATE, PanelKind.PARTNERSHIP))
        PanelButtons(vm, on, listOf(PanelKind.STRIKER, PanelKind.NON_STRIKER, PanelKind.BOWLER))
        PanelButtons(vm, on, listOf(PanelKind.PLAYING_XI, PanelKind.TOSS_CARD))
        Text("Full-screen cards", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Gold)
        PanelButtons(vm, on, listOf(PanelKind.MATCH_SUMMARY, PanelKind.RESULT_CARD, PanelKind.MAN_OF_MATCH))
        if (on != null) BigButton("Hide graphic now", Modifier.fillMaxWidth(), Color(0xFF5A2A2A), icon = Ic.Close) { vm.hidePanel() }
    }
}

/** Automatic FOUR / SIX / WICKET animation and spoken commentary. */
@Composable
fun AutoShowCard(vm: AppViewModel) {
    val a by vm.autoShow.collectAsState()
    SectionCard("Automatic animations & voice commentary", icon = Ic.Mic) {
        SwitchRow("Full-screen FOUR / SIX / WICKET animation", a.burstAnimations) { v -> vm.updateAutoShow { it.copy(burstAnimations = v) } }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BigButton("Try FOUR", Modifier.weight(1f).height(44.dp)) { vm.testBurst(BurstKind.FOUR) }
            BigButton("Try SIX", Modifier.weight(1f).height(44.dp)) { vm.testBurst(BurstKind.SIX) }
            BigButton("Try WICKET", Modifier.weight(1f).height(44.dp)) { vm.testBurst(BurstKind.WICKET) }
        }
        SwitchRow("Spoken commentary on four, six and wicket", a.voiceEnabled) { v -> vm.updateAutoShow { it.copy(voiceEnabled = v) } }
        if (a.voiceEnabled) {
            ChipChoice(listOf(false, true), a.voiceUrdu, { if (it) "Urdu" else "English" }) { v -> vm.updateAutoShow { it.copy(voiceUrdu = v) } }
            SwitchRow("Speak on a four", a.onFour) { v -> vm.updateAutoShow { it.copy(onFour = v) } }
            SwitchRow("Speak on a six", a.onSix) { v -> vm.updateAutoShow { it.copy(onSix = v) } }
            SwitchRow("Speak on a wicket", a.onWicket) { v -> vm.updateAutoShow { it.copy(onWicket = v) } }
            LabeledSlider("Commentary voice volume", a.voiceVolume, 0f..1.5f, "${(a.voiceVolume * 100).toInt()} %") { v -> vm.updateAutoShow { it.copy(voiceVolume = v) } }
            BigButton("Test the voice", Modifier.fillMaxWidth(), icon = Ic.Volume) { vm.testVoice() }
            Text(
                "While live, the voice is mixed into the broadcast and the music dips while it speaks. When not live it plays on the phone speaker. " +
                    "Urdu needs an Urdu voice installed in Android settings > Text-to-speech; without it English is used.",
                fontSize = 11.sp
            )
        }
        LabeledSlider("Graphics stay on air for", a.panelSeconds.toFloat(), 4f..60f, "${a.panelSeconds} s") { v -> vm.updateAutoShow { it.copy(panelSeconds = v.toInt()) } }
    }
}


/** One-tap announcement banners: DRS review and decision, umpire's call, drinks break, timeout, rain delay... */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun AnnouncementsCard(vm: AppViewModel) {
    val m by vm.match.collectAsState()
    val on by vm.alertOnAir.collectAsState()
    val reviews by vm.reviews.collectAsState()
    var custom by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    SectionCard("Announcements & DRS", icon = Ic.Flag) {
        Text("One tap puts a banner on air. Decisions hide themselves; breaks and delays stay until you hide them.", fontSize = 12.sp)
        Text("DRS review", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Gold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BigButton("Review: ${m.setup.teamA}", Modifier.weight(1f).height(48.dp), Color(0xFF1565C0)) { vm.showReview(true) }
            BigButton("Review: ${m.setup.teamB}", Modifier.weight(1f).height(48.dp), Color(0xFF1565C0)) { vm.showReview(false) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BigButton("OUT", Modifier.weight(1f).height(48.dp), Color(0xFFB71C1C)) { vm.showAlert(AlertKind.OUT) }
            BigButton("NOT OUT", Modifier.weight(1f).height(48.dp), Color(0xFF1B5E20)) { vm.showAlert(AlertKind.NOT_OUT) }
            BigButton("UMPIRE'S CALL", Modifier.weight(1.4f).height(48.dp), Color(0xFFF9A825), Color.Black) { vm.showAlert(AlertKind.UMPIRES_CALL) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text("Reviews left", Modifier.weight(1f), fontSize = 13.sp)
            BigButton("${m.setup.teamA.take(8)}: ${reviews.first}  (lost -1)", Modifier.weight(1.4f).height(44.dp), PanelHi) { vm.reviewLost(true) }
            BigButton("${m.setup.teamB.take(8)}: ${reviews.second}  (lost -1)", Modifier.weight(1.4f).height(44.dp), PanelHi) { vm.reviewLost(false) }
        }
        Text("Press \"lost\" only when the review failed. An umpire's call keeps the review.", fontSize = 11.sp, color = Muted)
        Text("Breaks and delays", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Gold)
        androidx.compose.foundation.layout.FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                AlertKind.DRINKS, AlertKind.TIMEOUT, AlertKind.RAIN, AlertKind.BAD_LIGHT,
                AlertKind.LUNCH, AlertKind.TEA, AlertKind.INNINGS_BREAK, AlertKind.PLAY_RESUMES
            ).forEach { k ->
                BigButton(k.label, Modifier.height(44.dp), if (on == k.title) Gold else PanelHi, if (on == k.title) Color.Black else Color.White) {
                    vm.showAlert(k)
                }
            }
        }
        TextInput("Own banner text", custom, { custom = it }, placeholder = "e.g. PITCH INSPECTION")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BigButton("Show my text", Modifier.weight(1f).height(48.dp), enabled = custom.isNotBlank(), icon = Ic.Tv) {
                vm.showAlertText(custom, "", AlertTone.BLUE, sticky = true)
            }
            if (on != null) BigButton("Hide banner", Modifier.weight(1f).height(48.dp), Color(0xFF5A2A2A), icon = Ic.Close) { vm.hideAlert() }
        }
    }
}
