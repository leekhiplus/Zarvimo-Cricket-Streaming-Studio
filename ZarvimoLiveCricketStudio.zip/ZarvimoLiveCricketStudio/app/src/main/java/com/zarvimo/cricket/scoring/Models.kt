package com.zarvimo.cricket.scoring

/**
 * Pure-Kotlin cricket scoring domain. No Android dependencies so it is fully unit-testable.
 *
 * RULE DEFINITIONS (documented and covered by tests):
 *  - Wide: penalty (default 1) + additional completed runs. NOT a legal ball. Batter does NOT face a ball.
 *    All wide runs are charged to the bowler. Strike rotates if the additional completed runs are odd.
 *  - No-ball: penalty (default 1) + runs off the bat (credited to batter, charged to bowler)
 *    and/or byes / leg-byes (extras, NOT charged to bowler). NOT a legal ball. Batter DOES face a ball.
 *    The next delivery is a free hit (if enabled).
 *  - Bye / Leg-bye: legal ball, runs are extras (not charged to bowler). Batter DOES face a ball.
 *  - Boundary: a 4/6 flagged as boundary does not rotate strike (no runs were physically run).
 *  - Wicket: only RUN_OUT / OBSTRUCTING_FIELD / HIT_BALL_TWICE may dismiss on a no-ball or free hit.
 *    Only RUN_OUT / OBSTRUCTING_FIELD may dismiss the non-striker. Runs completed before a run-out count.
 *    For other dismissals no runs are credited off the bat.
 *  - After a run-out the incoming batter takes the END where the dismissed batter was after the completed
 *    runs. If the real crossing differed, use the manual SwapStrike correction.
 *  - Over end: strike swaps after the final legal ball; the bowler must be re-selected and may not bowl
 *    consecutive overs (configurable).
 *  - Maiden: a completed over in which the bowler was charged zero runs (byes / leg-byes do not count).
 *  - Manual adjustments are tracked separately and never hidden inside normal ball events.
 */

enum class ExtraType(val label: String) {
    NONE("Runs"),
    WIDE("Wide"),
    NO_BALL("No Ball"),
    BYE("Bye"),
    LEG_BYE("Leg Bye");

    /** Does a delivery of this type consume a legal ball of the over? */
    val isLegalDelivery: Boolean get() = this == NONE || this == BYE || this == LEG_BYE
}

enum class DismissalType(
    val label: String,
    val creditsBowler: Boolean,
    val allowedOnNoBall: Boolean,
    val allowedOnWide: Boolean,
    /** Completed runs before the dismissal count (run-out style dismissals). */
    val allowsRuns: Boolean,
    val canDismissNonStriker: Boolean
) {
    BOWLED("Bowled", true, false, false, false, false),
    CAUGHT("Caught", true, false, false, false, false),
    LBW("LBW", true, false, false, false, false),
    STUMPED("Stumped", true, false, true, false, false),
    HIT_WICKET("Hit wicket", true, false, true, false, false),
    RUN_OUT("Run out", false, true, true, true, true),
    OBSTRUCTING_FIELD("Obstructing the field", false, true, true, true, true),
    HIT_BALL_TWICE("Hit ball twice", false, true, true, false, false);
}

enum class StrikeEnd { STRIKER, NON_STRIKER }

data class WicketInfo(
    val type: DismissalType,
    val outBatterIsStriker: Boolean = true,
    val fielder: String? = null,
    val incomingBatter: String? = null
)

sealed class ScoreEvent {
    abstract val id: Long
}

/**
 * One delivery.
 *  - runsBat: runs off the bat (NONE or NO_BALL only).
 *  - extraRuns: WIDE -> additional runs beyond the automatic penalty;
 *               NO_BALL -> byes/leg-byes run (see [noBallRunType]);
 *               BYE / LEG_BYE -> total byes / leg-byes.
 *  - boundary: the runs were a boundary (4/6) and not physically run (no strike rotation).
 */
data class BallEvent(
    override val id: Long,
    val runsBat: Int = 0,
    val extra: ExtraType = ExtraType.NONE,
    val extraRuns: Int = 0,
    val noBallRunType: ExtraType = ExtraType.NONE,
    val boundary: Boolean = false,
    val wicket: WicketInfo? = null
) : ScoreEvent()

data class SetBowlerEvent(override val id: Long, val name: String) : ScoreEvent()
data class BatterInEvent(override val id: Long, val name: String) : ScoreEvent()
data class SwapStrikeEvent(override val id: Long) : ScoreEvent()
data class PenaltyEvent(override val id: Long, val runs: Int) : ScoreEvent()

/** Exceptional manual correction. Reported separately from calculated totals. */
data class AdjustmentEvent(
    override val id: Long,
    val runs: Int = 0,
    val wickets: Int = 0,
    val note: String = ""
) : ScoreEvent()

data class EndInningsEvent(override val id: Long, val reason: String = "Declared") : ScoreEvent()

// ---------------------------------------------------------------------------------------------
// Configuration & setup
// ---------------------------------------------------------------------------------------------

data class InningsConfig(
    val oversLimit: Int = 20,
    val ballsPerOver: Int = 6,
    val maxWickets: Int = 10,
    val widePenalty: Int = 1,
    val noBallPenalty: Int = 1,
    val enforceFreeHit: Boolean = true,
    val allowConsecutiveOvers: Boolean = false,
    val maxOversPerBowler: Int? = null,
    /** Runs needed to WIN (i.e. first innings total + 1). Null in the first innings. */
    val target: Int? = null
) {
    val maxBalls: Int get() = oversLimit * ballsPerOver
}

data class InningsSetup(
    val battingTeam: String,
    val bowlingTeam: String,
    val striker: String,
    val nonStriker: String,
    val bowler: String
)

// ---------------------------------------------------------------------------------------------
// Derived state (snapshots)
// ---------------------------------------------------------------------------------------------

data class Extras(
    val wides: Int = 0,
    val noBalls: Int = 0,
    val byes: Int = 0,
    val legByes: Int = 0,
    val penalty: Int = 0
) {
    val total: Int get() = wides + noBalls + byes + legByes + penalty
}

data class BatterStat(
    val name: String,
    val order: Int,
    val runs: Int,
    val balls: Int,
    val fours: Int,
    val sixes: Int,
    val out: Boolean,
    val dismissal: String?
) {
    val strikeRate: Double get() = if (balls == 0) 0.0 else runs * 100.0 / balls
    val scoreText: String get() = "$runs ($balls)"
}

data class BowlerStat(
    val name: String,
    val legalBalls: Int,
    val ballsPerOver: Int,
    val maidens: Int,
    val runs: Int,
    val wickets: Int,
    val wides: Int,
    val noBalls: Int
) {
    val oversText: String get() = "${legalBalls / ballsPerOver}.${legalBalls % ballsPerOver}"
    val economy: Double get() = if (legalBalls == 0) 0.0 else runs * ballsPerOver.toDouble() / legalBalls
    val figuresText: String get() = "$oversText-$maidens-$runs-$wickets"
}

data class FallOfWicket(
    val wicketNumber: Int,
    val teamRuns: Int,
    val batter: String,
    val batterRuns: Int,
    val oversText: String
)

data class BallRecord(
    val eventId: Long,
    val overIndex: Int,
    val label: String,
    val runsAdded: Int,
    val legal: Boolean,
    val wicket: Boolean,
    val bowler: String,
    val striker: String
)

data class InningsState(
    val battingTeam: String,
    val bowlingTeam: String,
    val runs: Int,
    val wickets: Int,
    val legalBalls: Int,
    val ballsPerOver: Int,
    val oversLimit: Int,
    val maxWickets: Int,
    val extras: Extras,
    val manualRunsAdjustment: Int,
    val manualWicketsAdjustment: Int,
    val striker: BatterStat?,
    val nonStriker: BatterStat?,
    val bowler: BowlerStat?,
    val batters: List<BatterStat>,
    val bowlers: List<BowlerStat>,
    val fallOfWickets: List<FallOfWicket>,
    val lastDismissed: BatterStat?,
    val currentOver: List<BallRecord>,
    val allBalls: List<BallRecord>,
    val freeHit: Boolean,
    val pendingBatterEnd: StrikeEnd?,
    val ended: Boolean,
    val endReason: String?,
    val target: Int?
) {
    val oversText: String get() = "${legalBalls / ballsPerOver}.${legalBalls % ballsPerOver}"
    val scoreText: String get() = "$runs/$wickets"
    val wicketsRemaining: Int get() = maxWickets - wickets
    val bowlerRequired: Boolean get() = bowler == null && !ended
    val batterRequired: Boolean get() = pendingBatterEnd != null && !ended
    val ballsRemaining: Int get() = maxOf(0, oversLimit * ballsPerOver - legalBalls)
    val runRate: Double get() = if (legalBalls == 0) 0.0 else runs * ballsPerOver.toDouble() / legalBalls
    val requiredRuns: Int? get() = target?.let { maxOf(0, it - runs) }
    val requiredRunRate: Double?
        get() {
            val req = requiredRuns ?: return null
            if (ballsRemaining <= 0) return null
            return req * ballsPerOver.toDouble() / ballsRemaining
        }
    val recentBalls: List<BallRecord> get() = allBalls.takeLast(12)
    val canScoreNextBall: Boolean get() = !ended && !bowlerRequired && !batterRequired && striker != null && nonStriker != null
}

sealed class ReplayResult {
    data class Ok(val state: InningsState) : ReplayResult()
    data class Failed(val eventIndex: Int, val eventId: Long, val reason: String) : ReplayResult()
}

sealed class OpResult {
    data class Ok(val state: InningsState) : OpResult()
    data class Error(val message: String) : OpResult()
}
