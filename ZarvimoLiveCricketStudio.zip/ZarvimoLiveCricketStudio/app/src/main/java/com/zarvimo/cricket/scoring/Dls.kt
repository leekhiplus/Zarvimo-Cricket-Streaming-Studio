package com.zarvimo.cricket.scoring

/**
 * Arithmetic of the Duckworth-Lewis-Stern revised target.
 *
 * IMPORTANT: this does NOT contain the official resource table. The scorer reads the two resource percentages
 * (R1 = resources team 1 had, R2 = resources team 2 has) from the official DLS table / software, and this class only
 * does the final calculation:
 *   - R2 <= R1 : par = S x R2 / R1
 *   - R2 >  R1 : par = S + G50 x (R2 - R1) / 100
 *   - target = floor(par) + 1
 * where S is team 1's score and G50 is the average 50-over score used by the playing conditions (245 for ODIs).
 */
object Dls {
    fun revisedTarget(team1Score: Int, r1Percent: Double, r2Percent: Double, g50: Int): Int? {
        if (team1Score < 0 || r1Percent <= 0.0 || r2Percent <= 0.0 || g50 <= 0) return null
        if (r1Percent > 100.0 || r2Percent > 400.0) return null
        val par = if (r2Percent <= r1Percent) {
            team1Score * (r2Percent / r1Percent)
        } else {
            team1Score + g50 * (r2Percent - r1Percent) / 100.0
        }
        return Math.floor(par + 1e-9).toInt() + 1
    }
}
