package com.zarvimo.cricket.scoring

import kotlin.math.exp
import kotlin.math.pow

/**
 * Arithmetic of the Duckworth-Lewis-Stern revised target.
 *
 * IMPORTANT: this does NOT contain the official resource table. The scorer reads the two resource percentages
 * (R1 = resources team 1 had, R2 = resources team 2 has) from the official DLS table / software, and this class only
 * does the final calculation:
 *   - R2 <= R1 : par = S x R2 / R1
 *   - R2 >  R1 : par = S + G50 x (R2 - R1) / 100
 *   - target = floor(par) + 1
 * where S is team 1's score and G50 is the average 50-over score used by the playing conditions (245 for ODIs).
 */
object Dls {
    fun revisedTarget(team1Score: Int, r1Percent: Double, r2Percent: Double, g50: Int): Int? {
        if (team1Score < 0 || r1Percent <= 0.0 || r2Percent <= 0.0 || g50 <= 0) return null
        if (r1Percent > 100.0 || r2Percent > 400.0) return null
        val par = if (r2Percent <= r1Percent) {
            team1Score * (r2Percent / r1Percent)
        } else {
            team1Score + g50 * (r2Percent - r1Percent) / 100.0
        }
        return Math.floor(par + 1e-9).toInt() + 1
    }
}


/**
 * Resource table: percentage of a full 50-over innings still available with [r] overs left and w wickets lost.
 *
 * The OFFICIAL Duckworth-Lewis-Stern tables are licensed and are NOT included in this app. [approximate] is a smooth
 * model made for quick estimates and is always labelled as such. Paste the official table with [parse] (one row per
 * line: overs left, then the resources for 0..9 wickets lost) and [official] becomes true.
 */
class DlsTable private constructor(private val grid: Array<DoubleArray>, val official: Boolean) {

    /** Resources (%) with [oversLeft] overs left (fractions allowed: 12.5 = twelve and a half) and [wickets] lost. */
    fun r(oversLeft: Double, wickets: Int): Double {
        if (wickets >= 10) return 0.0
        val w = wickets.coerceAtLeast(0)
        val u = oversLeft.coerceIn(0.0, 50.0)
        val lo = kotlin.math.floor(u).toInt()
        val hi = kotlin.math.ceil(u).toInt()
        if (lo == hi) return grid[lo][w]
        val f = u - lo
        return grid[lo][w] * (1 - f) + grid[hi][w] * f
    }

    companion object {
        /** Smooth estimate (not official): Z(u, w) = Z0(w) * (1 - exp(-b * u / Z0(w))). */
        fun approximate(): DlsTable {
            val g = Array(51) { DoubleArray(10) }
            fun z(u: Int, w: Int): Double {
                val z0 = 300.0 * (1.0 - w / 10.0).pow(0.85)
                return z0 * (1 - exp(-8.25 * u / z0))
            }
            val full = z(50, 0)
            for (u in 0..50) for (w in 0..9) g[u][w] = 100.0 * z(u, w) / full
            return DlsTable(g, official = false)
        }

        /** Result of [parse]: either a table or a message for the scorer. */
        class Parsed(val table: DlsTable?, val error: String?)

        fun parse(text: String): Parsed {
            val rows = HashMap<Int, DoubleArray>()
            for ((n, raw) in text.lines().withIndex()) {
                val line = raw.trim()
                if (line.isEmpty() || line.startsWith("#")) continue
                val parts = line.split(Regex("[\\s,;\\t]+")).filter { it.isNotEmpty() }
                val nums = parts.mapNotNull { it.replace('%', ' ').trim().toDoubleOrNull() }
                if (nums.size != parts.size) {
                    if (rows.isEmpty()) continue // header line such as "Overs W0 W1 ..."
                    return Parsed(null, "Line ${n + 1}: only numbers are allowed.")
                }
                if (nums.size != 11) return Parsed(null, "Line ${n + 1}: expected 11 numbers (overs left + 10 columns for 0 to 9 wickets lost), found ${nums.size}.")
                val overs = nums[0]
                if (overs != Math.rint(overs) || overs < 0 || overs > 50) return Parsed(null, "Line ${n + 1}: overs left must be a whole number from 0 to 50.")
                val vals = nums.drop(1).toDoubleArray()
                if (vals.any { it < 0.0 || it > 100.5 }) return Parsed(null, "Line ${n + 1}: resources must be between 0 and 100.")
                rows[overs.toInt()] = vals
            }
            val top = rows[50] ?: return Parsed(null, "The row for 50 overs left is required.")
            if (kotlin.math.abs(top[0] - 100.0) > 1.0) return Parsed(null, "50 overs left with 0 wickets lost must be 100%.")
            if (rows.size < 6) return Parsed(null, "Too few rows: paste the whole table (at least 6 different overs values).")
            val g = Array(51) { DoubleArray(10) }
            val keys = rows.keys.sorted()
            for (u in 0..50) {
                val exact = rows[u]
                if (exact != null) { g[u] = exact.copyOf(); continue }
                val lo = keys.lastOrNull { it < u }
                val hi = keys.firstOrNull { it > u }
                for (w in 0..9) {
                    g[u][w] = when {
                        lo == null && hi != null -> rows[hi]!![w] * u / hi // below the smallest row: scale towards zero
                        lo != null && hi != null -> rows[lo]!![w] + (rows[hi]!![w] - rows[lo]!![w]) * (u - lo) / (hi - lo)
                        lo != null -> rows[lo]!![w]
                        else -> 0.0
                    }
                }
            }
            return Parsed(DlsTable(g, official = true), null)
        }
    }
}

/** A stoppage: overs left when play stopped, wickets down, and overs left when it resumed (fewer = overs lost). */
data class DlsStoppage(val oversLeftAtStop: Double, val wicketsDown: Int, val oversLeftAtResume: Double)

/** One team's innings for the calculation: overs it started with (after any pre-match reduction) and its stoppages. */
data class DlsInnings(val startOvers: Double, val stoppages: List<DlsStoppage> = emptyList())

data class DlsOutcome(val r1: Double, val r2: Double, val par: Double, val target: Int)

object DlsCalc {

    /** "12.3" means 12 overs and 3 balls. Returns null when the text is not a valid overs figure. */
    fun parseOvers(text: String, ballsPerOver: Int): Double? {
        val t = text.trim().replace(',', '.')
        if (t.isEmpty()) return null
        val parts = t.split('.')
        if (parts.size > 2) return null
        val whole = parts[0].toIntOrNull() ?: return null
        val balls = if (parts.size == 2 && parts[1].isNotEmpty()) (parts[1].toIntOrNull() ?: return null) else 0
        if (whole < 0 || balls < 0 || balls >= ballsPerOver) return null
        return whole + balls.toDouble() / ballsPerOver
    }

    /** Resources (%) an innings had in total: the full start allocation minus what every stoppage took away. */
    fun resources(table: DlsTable, inn: DlsInnings): Double {
        var r = table.r(inn.startOvers, 0)
        for (s in inn.stoppages) {
            val lost = table.r(s.oversLeftAtStop, s.wicketsDown) - table.r(s.oversLeftAtResume, s.wicketsDown)
            r -= lost.coerceAtLeast(0.0)
        }
        return r.coerceAtLeast(0.0)
    }

    private fun parFor(s1: Int, g50: Int, r1: Double, r2: Double): Double =
        if (r2 <= r1) s1 * r2 / r1 else s1 + g50 * (r2 - r1) / 100.0

    /** Revised target (runs to WIN) for team 2. */
    fun target(table: DlsTable, g50: Int, team1Score: Int, team1: DlsInnings, team2: DlsInnings): DlsOutcome? {
        if (team1Score < 0 || g50 <= 0) return null
        val r1 = resources(table, team1)
        val r2 = resources(table, team2)
        if (r1 <= 0.0 || r2 <= 0.0) return null
        val par = parFor(team1Score, g50, r1, r2)
        return DlsOutcome(r1, r2, par, Math.floor(par + 1e-9).toInt() + 1)
    }

    /**
     * Par score for team 2 at this moment: the score that would leave the match level if play ended now.
     * [oversLeft] and [wicketsLost] are team 2's current position. Past stoppages must be in [team2].
     */
    fun parNow(table: DlsTable, g50: Int, team1Score: Int, team1: DlsInnings, team2: DlsInnings, oversLeft: Double, wicketsLost: Int): Double? {
        if (team1Score < 0 || g50 <= 0) return null
        val r1 = resources(table, team1)
        val r2 = resources(table, team2)
        if (r1 <= 0.0 || r2 <= 0.0) return null
        val used = (r2 - table.r(oversLeft, wicketsLost)).coerceAtLeast(0.0)
        return parFor(team1Score, g50, r1, used)
    }
}
