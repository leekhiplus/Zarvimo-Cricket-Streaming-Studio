# Zarvimo Live Cricket Studio

A native Android app (Kotlin + Jetpack Compose) that lets one person **score a cricket match by hand** and **broadcast the composed
scoreboard video plus live microphone commentary** to YouTube Live or any RTMP/RTMPS ingest server — straight from the phone.
No web browser, no remote renderer: the phone composes, encodes (H.264 + AAC) and transmits.

> **اردو میں مختصر رہنمائی:** پروجیکٹ کو GitHub پر اپلوڈ کریں → *Actions* ٹیب → **Build Android APK** → *Run workflow* → مکمل ہونے پر
> نیچے *Artifacts* سے `Zarvimo-Live-Cricket-Studio-debug-apk` ڈاؤن لوڈ کریں، ZIP کھولیں اور `app-debug.apk` فون میں انسٹال کریں۔
> ایپ میں *Stream* ٹیب میں YouTube کا Stream URL اور Stream key ڈالیں، پھر **GO LIVE** دبائیں۔ کی (key) کسی سے شیئر نہ کریں۔

---------------------------------------------------------------------------------------------------

## 0. Honest verification status (read this first)

| Item | Status |
|---|---|
| All source files written | ✅ done |
| Compiled with Gradle / Kotlin | ❌ **NOT done** — the authoring sandbox had no Gradle, Kotlin compiler, Android SDK or network |
| Unit tests executed | ❌ **NOT executed** (105 tests are written, hand-traced against the engine, but never run) |
| GitHub Actions workflow run | ⚠️ first run failed at the *Set up Android SDK* step (fixed in this version); Gradle has **not** run yet |
| Installed on a physical Android device | ❌ not done |
| Real RTMP/RTMPS stream received by YouTube / a media server | ❌ **NOT tested** |
| Score change visible in the received video | ❌ not tested (by design it is the same frame path, but this is unproven) |
| Stop Live terminates transmission | ❌ not tested on a device |
| Failure behaviour (bad URL / no network) | ❌ not tested on a device (state-machine logic is unit-tested) |

So: **the first `gradle build` may reveal compile errors**, most likely where the app touches the RootEncoder library
(see §13 "First-build checklist"). A successful APK build alone would still not prove that live streaming works —
please run the end-to-end checks in §12 on a real phone before relying on it for a real match.

---------------------------------------------------------------------------------------------------

## 1. What is implemented

* **Manual cricket scoring** (event-sourced; no third-party API): 0–7 runs, boundaries, wides, no-balls (+free hit), byes, leg-byes,
  penalty runs, wickets (8 dismissal types, who is out, fielder, incoming batter), strike rotation, over completion, bowler change rules,
  maidens, fall of wickets, last dismissed batter, target / required runs / balls remaining / run rates, two innings, manual target override,
  **undo / redo**, **edit or delete any earlier ball** (rejected automatically if it would corrupt later balls), ball-by-ball history,
  **manual override** (clearly separated and labelled in the totals).
* **One compositor** (`BroadcastRenderer`): stadium background (built-in procedural stadium or your own image), channel logo, sponsor logo,
  team logos, **19 scoreboard templates** (9 classic designs + 10 broadcast strips: Neon Arena, Capsule Flag, Gold Chevron, Violet Rush, Glass White, Royal Hex, Blue Glow, Black & Gold, Light Capsule, Crimson Gold), recent-balls chips, chase line, last-wicket line, free-hit / end-of-over / result banners, scrolling ticker.
* **Video source of your choice, switchable live:** back camera, front camera, or the background picture. The scoreboard graphics are drawn on
  top of the camera (Camera2 + OpenGL; the preview and the stream show the same picture). If the camera cannot be used the app falls back to the
  background picture and tells you why. A *camera picture rotation* option (Auto / +90 / +180 / +270) fixes a sideways picture on unusual devices.
* **Background music + commentary mix:** add audio files (they loop as a playlist), set music and commentary-mic volume separately.
  **Monitoring:** you hear the music yourself, and (with headphones connected) your own microphone while live. The microphone is never played
  through the speaker (it would howl); a mic level bar shows the real level.
* **On-air graphics (buttons, auto-hide):** full scorecard (batting + bowling + extras + fall of wickets), striker / non-striker / bowler stat cards,
  partnership card, and a run-rate graph (runs per over, wicket markers, current and required rate lines). They follow the live score while on air.
* **Pre-match card:** toss winner, decision (bat / bowl first) and match start time are shown on air before the first ball; the toss also pre-selects the batting team.
* **Automatic animations:** a full-screen FOUR / SIX / WICKET animation when the scorer records one (can be switched off, each one can be previewed).
* **Spoken commentary (text-to-speech):** short English (or Urdu if an Urdu voice is installed) lines for four, six and wicket, mixed into the broadcast while live
  (music dips while it speaks); on the phone speaker when not live.
* **Adaptive bitrate:** lowers the video bitrate when the uplink is congested and raises it again after a calm period (never above the configured value).
* **Local recording:** optional copy of the broadcast saved on the phone (Movies/Zarvimo on Android 10+).
* **DLS helper:** revised-target arithmetic only; you enter the resource percentages from the official DLS table.
* **Super over, full DLS calculator, crowd sounds & effects, DRS and break banners, Toss / Summary / Result / Man of the match full-screen cards.**
* **Playing XI:** enter both teams' players (add, paste a list, reorder), pick batters/bowlers/fielders with one tap, and show the XI on air.
* **Studio screen with tabs:** Source, On-air, Audio, Chat, Status. The preview stays pinned; one tab is shown at a time instead of one long list.
* **Camera in a circle:** optional round camera picture (front or back) over the background picture; size and position adjustable, on/off at any time.
* **Viewers & comments (YouTube):** concurrent viewers, total views, live-chat comments, replies from the app and "Show on air" for any comment.
  Sign-in uses Google's device-code flow with the user's OWN Google Cloud OAuth client (no password is typed in the app). Facebook is not supported.
* **Commentary voice clean-up:** noise cancelling on the microphone (Light / Medium / Strong; spectral noise reduction), studio voice (Natural / Radio:
  EQ + compressor + soft limiter), rumble/wind filter, and a switch for Android's own noise suppressor / echo canceller. Presets: Off, Clean, Studio voice,
  Noisy ground. This is microphone-side noise cancelling (ENC); true ANC (quieting the world in the listener's ears) belongs to the headphones.
* **Join mid-match:** when the stream starts after some overs (or in the 2nd innings), tick "Join mid-match" when starting the innings and type the score
  as it is now (runs/wickets, overs, extras, the batters' and bowlers' figures; dismissed batters and other bowlers are optional). Ball-by-ball scoring
  continues from there; undo/redo, saving and the graphics all work. Overs before the join point are not recorded ball by ball.
* **Pinned preview:** the preview stays fixed at the top (left in landscape); only the options below it scroll.
* **Preview = program output.** The on-screen preview is RootEncoder's GL preview of the *same* frames that feed the H.264 encoder.
  There is no second render path.
* **RTMP / RTMPS streaming** through [RootEncoder](https://github.com/pedroSG94/RootEncoder) (Apache-2.0), MediaCodec H.264 (hardware where
  the device offers it) and AAC-LC.
* **Real state machine** `IDLE → PREPARING → CONNECTING → STREAMING → RECONNECTING → STOPPING → ERROR`, driven only by library callbacks and
  user actions. The word **LIVE** is only shown in the `STREAMING` state.
* Bounded exponential **reconnect** (2 s, 4 s, 8 s … max 30 s, max 6 attempts), optional automatic 25 % bitrate reduction on each reconnect.
* Foreground service (types *microphone* and, when the camera permission is granted, *camera*) with a persistent notification and a **Stop Live** action.
* Mute switch that mutes ONLY the commentary microphone (music, spoken commentary and crowd sounds keep going on air); the microphone is also muted while a call or another app holds audio focus; if the mixer ever stops receiving the microphone a muted microphone is muted natively as a safety net; watchdog that stops the stream if the
  microphone permission is revoked.
* Persistence: saved matches, graphics presets, last-used graphics and stream settings, auto-save of the running match.
  The stream key is **never** in these files.

### Screens
Home · Match Setup · Scoring Console · Program Preview · Graphics Editor (drag the scoreboard on the preview) · Stream Config ·
Live Monitor · Saved Matches & Presets · Settings & Diagnostics (lists the device's H.264 encoders and which profiles they accept).

---------------------------------------------------------------------------------------------------

## 2. Prerequisites

* Android Studio (a recent stable release that supports AGP 8.10) with **JDK 17**, and Android **SDK Platform 36** + build-tools.
* A phone running **Android 7.0 (API 24) or newer**, with a hardware H.264 encoder (almost all do).
* A working upload connection (see §9).

## 3. Build locally

1. Open the folder in Android Studio and let Gradle sync.
   The Gradle *wrapper JAR* could not be generated offline, so run once **`gradle wrapper --gradle-version 8.11.1`**
   (or let Android Studio offer to create it). `gradle/wrapper/gradle-wrapper.properties` is included.
2. Command line (with Gradle 8.11.1 installed):
   ```
   gradle :app:testDebugUnitTest      # unit tests
   gradle :app:assembleDebug          # APK
   ```
3. The APK is `app/build/outputs/apk/debug/app-debug.apk` (application id `com.zarvimo.livecricketstudio.debug`).

## 4. Download the APK from GitHub Actions

1. Create a GitHub repository and push the **contents** of this project (`app/`, `gradle/`, `settings.gradle.kts`, `build.gradle.kts`,
   `.github/workflows/build-android.yml`, …) — not a ZIP file. The workflow file must be at `.github/workflows/` in the repository root.
   If the project ended up inside a sub-folder the workflow now finds it automatically (it searches up to 3 levels); if no Gradle project
   exists it fails immediately with a listing of the repository files.
2. Open the repository → **Actions** → **Build Android APK** → open the latest run (or click **Run workflow**).
3. Wait for the green check. If tests or compilation fail, the run is **red** and no APK artifact is uploaded.
4. Scroll to **Artifacts** at the bottom of the run page and download **`Zarvimo-Live-Cricket-Studio-debug-apk`** (a ZIP containing `app-debug.apk`).
   A second artifact, `unit-test-reports`, holds the HTML test report.
5. Copy `app-debug.apk` to the phone and install it (allow "install unknown apps" for your file manager/browser).

The workflow uses explicit `contents: read` permissions, JDK 17 (Temurin), Gradle 8.11.1, `actions/checkout@v4`, `actions/setup-java@v5`,
`gradle/actions/setup-gradle@v4` and `actions/upload-artifact@v4` (pinned to major versions). It uses the Android SDK that is pre-installed on the
`ubuntu-latest` runner and only accepts its licences (the `android-actions/setup-android` action was removed after it failed on the missing
`tools` package — see the first CI log).
No signing keys or stream credentials are needed. **Release signing is not implemented**; if you add it, store the keystore and passwords in
GitHub *Secrets* and never commit them.

---------------------------------------------------------------------------------------------------

## 5. Set up YouTube Live (or another RTMP/RTMPS destination)

1. YouTube Studio → **Create → Go live → Stream**. Set title/privacy and choose the stream key (or create a new one).
2. Copy **Stream URL** and **Stream key** from the *Stream settings* panel.
   * Stream URL examples (verify them in YouTube Studio): `rtmp://a.rtmp.youtube.com/live2` or `rtmps://a.rtmps.youtube.com:443/live2`.
3. In the app: **Stream** tab → paste the URL and key (the key is masked; tap *Show key* to check it).
4. Pick resolution, fps, bitrate (see §8) → **GO LIVE**. Wait until the badge says **LIVE STREAMING** (the server accepted the connection).
   YouTube may take 10–30 s to show the preview; press *Go live* in YouTube Studio when its preview is healthy.
5. **Stop Live** in the app (or the notification) ends transmission. Then end the event in YouTube Studio.

Any other server that accepts RTMP / RTMPS (Facebook, Twitch, nginx-rtmp, Restream, …) works the same: the URL is `rtmp(s)://host[:port]/app`
and the key is the stream name. The app joins them as `URL/KEY`.

**RTMPS:** supported by the transport library; the app shows whether the chosen URL is encrypted. Not verified against a live server (see §0).

### Keeping the stream key private
Masked by default · never logged (library error text is scrubbed of the key) · not written to JSON files · only stored if you switch on
*Remember key* (AES-256-GCM, key in the Android Keystore) · `allowBackup=false` · do not screenshot or share it · reset the key in YouTube if it leaks.

---------------------------------------------------------------------------------------------------

## 6. Scoreboard & graphics

*Graphics* tab: pick one of three templates (**Classic Lower Third, Modern Bar, Compact Corner**), drag the board on the preview or use the X / Y
sliders, size, margin and safe-area sliders, panel colour / accent / text / border colours, panel opacity, border width, font (Sans, Condensed,
Serif, Mono), toggles for match title, team logos, ticker, sponsor; import background, channel logo and sponsor (copied into app-private storage);
position and size the logo/sponsor. Everything appears in the preview immediately because the preview *is* the compositor output.
Save/load presets from *Saved & Presets*.

All geometry is defined on a 1920×1080 reference canvas and scaled to the output. Smaller outputs (480p/360p) automatically enlarge the board
slightly for legibility, and the board is always clamped inside the safe area (and never overlaps the ticker). You must hold the rights to any
image you import. Urdu/Arabic team names render through Android's system fonts.

## 7. Operating the scorer

1. **Match Setup** → team names/colours/logos, title, venue, overs (T10 / T20 / ODI 50 / custom), players per side → *Create match*.
2. In the same screen: choose the batting team, opening striker, non-striker, bowler → *Start innings*.
3. **Score** tab: tap runs (4/6 are boundaries by default; switch the toggle off if the batters ran them), **W** for a wicket, **Wide / No ball /
   Bye / Leg bye** for extras (the dialog asks for the extra runs; the automatic wide/no-ball penalty run is added for you).
   After a wicket enter the new batter; after an over enter the next bowler (the same bowler cannot bowl consecutive overs).
4. **Undo / Redo**, **Swap strike**, **History** (edit or delete any earlier ball), **More** (penalty runs, manual override, target override, end innings).
5. When the first innings ends, *Start 2nd innings* (target = first innings + 1, or your override).

### Rules as implemented (and unit-tested)
* Wide: 1 penalty run (+ completed runs), not a legal ball, batter does not face, all charged to bowler.
* No-ball: 1 penalty run, runs off the bat credited to the batter and charged to the bowler, byes/leg-byes on a no-ball are extras not charged to the
  bowler, not a legal ball, batter *does* face it, next ball is a free hit (switchable).
* Byes / leg-byes: legal ball, not charged to the bowler. Strike rotates on an odd number of *physically run* runs; a boundary does not rotate.
* Wicket: on a no-ball / free hit only run-out, obstructing the field, hit-ball-twice; on a wide also stumped and hit-wicket. Only run-out /
  obstruction can dismiss the non-striker. Run-out credits runs completed; other dismissals credit none. **Simplification:** after a run-out the
  incoming batter takes the end where the dismissed batter was after the *completed* runs — use *Swap strike* if the batters had crossed differently.
* Maiden: an over with no runs charged to the bowler (byes/leg-byes do not break a maiden; wides/no-balls do). A bowler change mid-over voids the maiden.
* Innings ends on all-out, overs complete, target reached, or manual end. Time-based rules, DLS, retired batters and substitutes are **not** modelled
  (use the manual target / manual override).

---------------------------------------------------------------------------------------------------

## 8. Output profiles, frame rate, audio

| Profile | Size | Video bitrate range (default) |
|---|---|---|
| 360p | 640×360 | 400–800 kbps (600) |
| 480p | **848×480** | 700–1500 kbps (1000) |
| 720p | 1280×720 | 1500–3000 kbps (2200) |
| 1080p (high bandwidth) | 1920×1080 | 3000–6000 kbps (4500) |

* *848×480 instead of 854×480:* many hardware encoders require widths that are multiples of 16; the picture is visually identical.
* Frame rate 15 / 20 / 24 / 30 fps · keyframe every 2 s · audio AAC-LC 44.1 kHz, 64 / 96 / 128 kbps, mono by default (stereo switch).
* Resolution and fps cannot change while live (stop first). Video bitrate **can** be changed live (slider, or *Lower bitrate now*).
* These numbers are starting points, **not guarantees**.

## 9. Bandwidth advice (e.g. mobile data in Pakistan)
Your *upload* speed should be at least ~1.5–2× (video + audio) bitrate and stable. Start with 360p/15–24 fps (≈600 kbps) on weak 3G/4G, test with
a private/unlisted YouTube event first, keep the phone cool and charged, and avoid heavy use of the same tower (stadiums). Lower profiles reduce
bandwidth but never guarantee an uninterrupted stream.

## 10. Permissions & background behaviour
* `INTERNET`, `ACCESS_NETWORK_STATE`.
* `RECORD_AUDIO` — requested with an explanation when you press Go Live. Without it nothing starts.
* `POST_NOTIFICATIONS` (Android 13+) — for the *Stop Live* notification; optional.
* `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_MICROPHONE` — the stream runs in a foreground service (type *microphone*) so it survives
  backgrounding / screen lock. The screen is kept awake while live so you can keep scoring. A partial wake-lock (max 12 h) is held while live.
* No MediaProjection / screen capture is used: frames are rendered directly, so no navigation bar, notification shade or other app can leak into the stream.
* Android may still kill the process (memory pressure, aggressive battery managers on some phones — disable battery optimisation for the app).
  After a kill the app **never resumes transmitting by itself**; open it and press Go Live again. The running match is auto-saved and restored.

---------------------------------------------------------------------------------------------------

## 11. Troubleshooting
* **"Cannot start yet"** — URL must start with `rtmp://` or `rtmps://`, key must be present and contain no spaces.
* **STREAM ERROR on first connect** — wrong URL/key, stream not enabled on the platform, firewall/captive portal, or no internet. The real error text is shown; fix and press **RETRY LIVE**. The app does *not* loop on a first-connection failure.
* **RECONNECTING** — the link dropped; the app retries up to 6 times with growing delays and lowers the bitrate by 25 % each time (switchable). After that it shows the error.
* **Preview works but the platform shows no video** — preview ≠ stream. Check the badge says LIVE STREAMING, the event is active, and the key is current.
* **"Encoder rejected 720p"** — see *Settings & Diagnostics* for the encoders and sizes your phone accepts; choose a lower profile or fps.
* **Audio missing** — check the MIC badge isn't muted, the permission is granted, and no call/other app holds audio focus.
* **Stuttering video** — lower fps/bitrate, close other apps, let the phone cool.

## 12. Real-device test plan (not yet performed)
1. Install the debug APK; open *Settings & Diagnostics* and confirm an H.264 encoder is listed.
2. Create a private YouTube live event; stream 360p for 5 min; confirm video + audio arrive.
3. Change the score; confirm the YouTube player shows the new score within a few seconds, with no restart.
4. Lock the screen / switch apps for 2 min; confirm the stream stays up and the notification shows time.
5. Press *Stop Live*; confirm YouTube reports the stream ended and the notification disappears.
6. Enter a wrong key / switch to airplane mode while live; confirm the error / reconnect messages and bounded retries.

## 13. First-build checklist (where compile errors are most likely)
The only code that touches RootEncoder's API is `stream/BroadcastVideoSource.kt` and `stream/StreamEngine.kt`. If the build fails there, check
against the library version in `app/build.gradle.kts` (`com.github.pedroSG94.RootEncoder:library:2.8.1`, taken from the project README):
* `VideoSource` abstract members (`create`, `start(SurfaceTexture)`, `stop`, `release`, `isRunning`; the app does not override `getOrientationConfig`).
* `GenericStream` constructor, `prepareVideo/prepareAudio` parameter lists, `isStreaming`, `isOnPreview`, `startPreview(SurfaceView)`,
  `getGlInterface().setPreviewResolution`, `getStreamClient().setReTries/reTry`, `setVideoBitrateOnFly`.
* `ConnectChecker` methods and `MicrophoneSource.mute/unMute`.
If Kotlin complains about metadata versions from RootEncoder, raise the Kotlin + compose-compiler plugin versions in the root `build.gradle.kts`.

## 14. Known limitations
* Not compiled / not run / not field-tested (see §0).
* Music is mixed into the stream by the app (decoded with MediaCodec, mixed into RootEncoder's microphone buffers). Microphone monitoring has the
  small delay of the audio chain; Bluetooth headphones add more. Music files are copied into app storage on import.
* Camera mode needs the CAMERA permission; hold the phone in landscape for a full-screen picture (portrait gives a centre-cropped picture).
* Dropped-frame counts and encoder-side fps are shown as *unavailable*; "Compositor fps" and "Measured upload bitrate" are real measurements.
* Preview orientation of the broadcast is always landscape; the phone UI is used in portrait.
* Retired batters, substitutes, DLS, super-over and time-based rules are not modelled.
* Only one stream destination at a time.

## 15. Tests
`app/src/test` contains JUnit 4 tests: `ScoreEngineTest` (64: extras, legal balls, strike, wickets, overs, maidens, free hit, targets, undo/redo/edit/delete,
two innings), `StreamModelTest` (21: URL/key validation, key redaction, profiles, state machine, reconnect backoff, labels), `GraphicsModelTest` (15: safe-area
clamping for every template/scale/position, ticker avoidance, overlay data reflecting real scoring state) and `JsonTest` (5: persistence round-trip, no key in files).
**None of them has been executed yet** — run `gradle :app:testDebugUnitTest` (or push to GitHub and read the Actions result).

## 16. Licenses
This project's own licence is **not chosen yet** — add a `LICENSE` file before publishing. Third-party libraries and their licences are listed in
`THIRD_PARTY_NOTICES.md` (RootEncoder: Apache-2.0).
