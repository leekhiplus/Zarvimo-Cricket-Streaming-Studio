// Top-level build file. Plugin versions are declared once here.
// Kotlin 2.3.21 matches the kotlin-stdlib / kotlinx libraries that RootEncoder 2.8.x pulls in
// (they are compiled with Kotlin 2.3 metadata, which a 2.1.x compiler cannot read).
plugins {
    id("com.android.application") version "8.10.1" apply false
    id("org.jetbrains.kotlin.android") version "2.3.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.3.21" apply false
}
