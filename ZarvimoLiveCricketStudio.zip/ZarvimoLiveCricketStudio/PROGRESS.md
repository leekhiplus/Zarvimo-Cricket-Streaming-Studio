# PROGRESS / HANDOFF

Project: Zarvimo Live Cricket Streaming Studio (native Android, Kotlin, Compose, RootEncoder 2.8.1).
Working dir (sandbox): /home/claude/ZarvimoLiveCricketStudio — deliverable ZIP: /mnt/user-data/outputs/ZarvimoLiveCricketStudio.zip

## Sandbox facts
- JDK 21 only. NO Gradle / Kotlin compiler / Android SDK / network for bash => nothing compiled, no test executed.
- web_search worked (used to verify RootEncoder coordinates/licence: Apache-2.0, RTMP+RTMPS, H264, AAC, JitPack).
- Static checks done instead: bracket/template balance on all 25 .kt files, import-target existence, duplicate test names, resource refs.

## STATUS: ALL planned files written (v0.1.0, UNCOMPILED)
scoring/ (Models, ScoreEngine, MatchSession) · graphics/ (GraphicsModel, BroadcastRenderer) ·
stream/ (StreamModel, BroadcastState, BroadcastVideoSource, StreamEngine, StreamService) ·
data/ (Json, LocalStore, SecretStore, MediaImporter) · ui/ (AppViewModel, Common, ScoringScreen, ScreensMatch,
ScreensBroadcast) · MainActivity, ZarvimoApp · manifest/resources · workflow · README · THIRD_PARTY_NOTICES · 105 unit tests.

## Next steps (when continuing)
1. If the user can supply build output (Actions log / Android Studio errors): fix compile errors. Highest-risk files:
   stream/BroadcastVideoSource.kt and stream/StreamEngine.kt (RootEncoder 2.8.1 API signatures: VideoSource members,
   GenericStream ctor/prepareVideo/prepareAudio/startPreview/getGlInterface/getStreamClient().reTry, ConnectChecker,
   MicrophoneSource.mute/unMute). Then Compose files (ScoringScreen/ScreensBroadcast).
2. Failing unit tests: they were only hand-traced. Fix engine or test, whichever is wrong.
3. Add gradle-wrapper.jar + gradlew (cannot be created offline).
4. Optional: audio level meter, background music, release signing via GitHub Secrets, LICENSE choice by owner.
5. Real-device streaming test per README section 12 (cannot be done in sandbox).

## CI log #1 (user-supplied logs_108001410334.zip)
- Failed at step 4 "Set up Android SDK" (android-actions/setup-android@v3): `Failed to find package 'tools'` (default
  packages "tools platform-tools"). Gradle never ran. FIX: step removed, preinstalled runner SDK used + licence acceptance;
  setup-java bumped to v5. Next CI run will be the first one to reach Gradle => expect real compile errors; send the log.

## CI log #2 (logs_108003712139.zip)
- setup-android removal worked (licence step + Gradle 8.11.1 provisioned). New failure in "Run unit tests":
  "Directory .../Zarvimo-Cricket-Streaming-Studio does not contain a Gradle build" (repo leekhiplus/Zarvimo-Cricket-Streaming-Studio,
  commit cb139be). Cause: project files not at repo root (likely nested ZIP folder, or only workflow/README uploaded).
  FIX: workflow now has a "Locate Gradle project" step (find settings.gradle[.kts] maxdepth 3 -> working-directory; prints repo tree
  and fails clearly if none). Gradle still has NOT compiled anything yet.

## Update: camera source, background music, monitoring, templates, pinned preview
* Video source selector (back camera / front camera / background picture), live switching, automatic fallback with a message.
* Background music playlist (MediaCodec decode, loop) mixed with the commentary microphone; separate stream volumes; monitor switches
  (music, microphone-in-headphones) and a monitor volume; microphone level bar.
* 6 new scoreboard templates (9 total). Title tag moves below a scoreboard parked at the top.
* Preview is pinned (portrait: top, landscape: left); options scroll.
* Status: written without being able to compile or run here; verify with the GitHub Actions build and on a real device
  (camera orientation, music/microphone mix, headphone monitoring).

## Update: on-air graphics, auto animations, voice commentary, recording, adaptive bitrate
* Panels: scorecard, striker/non-striker/bowler cards, partnership, run-rate graph (renderer + PanelBuilder, auto-hide).
* Pre-match card (toss + start time) and toss-based batting team preselection.
* FOUR / SIX / WICKET burst animation; optional TTS commentary mixed into the stream (VoiceBuffer -> MixerEffect, music ducking).
* Adaptive bitrate (uses StreamClient.hasCongestion / dropped frames, 1 s service tick) and local recording (StreamBase.startRecord).
* DLS revised-target calculator (arithmetic only). New unit tests: DlsAndTossTest, CommentaryAndWavTest.
* NOT done (deliberately): streaming to two platforms at once (use a restreaming service), retired batter / super over / substitute in the scoring engine.
* Status: written without being able to compile or run here; verify with the GitHub Actions build and on a real device.

## Update: Studio tabs, camera bubble, YouTube viewers + chat
* StudioScreen (tabs Source / On-air / Audio / Chat / Status) replaces the separate Preview and Monitor screens; Home buttons regrouped.
* Camera bubble (GL compositor: background texture + camera inside a circle + overlay), live on/off, front/back, size, position.
* YouTube: device-code OAuth (user's own Cloud client), liveBroadcasts/videos/liveChat APIs, viewers every 30 s, chat every >=10 s, replies, comment on air.
* Unit tests: YouTubeJsonTest, wrapTwoLines, BubbleConfig clamp. Status: written without compiling; verify with the GitHub Actions build.

## Update: commentary voice clean-up (noise cancelling + studio voice)
* VoiceProcessor (pure Kotlin): rumble high-pass -> spectral noise reducer (512-pt STFT, noise floor tracker frozen during speech, smoothed Wiener gain)
  -> EQ -> compressor -> soft limiter. Runs inside MixerEffect on the microphone buffers (before music/voice mixing); the monitor hears the cleaned voice.
* Algorithm prototyped in numpy before porting: white noise -8 / -14 / -21 dB (light/medium/strong), speech tones kept at 96-98 %.
* Unit tests: VoiceProcessorTest. Status: not compiled or run on a device here; tune strength by ear on a real handsfree microphone.

## Update: join a match in progress
* InningsSetup.seed (InningsSeed): runs, wickets, balls, extras, batters (striker, non-striker, dismissed), bowlers (current + others), per-over runs,
  partnership. Validated by ScoreEngine.seedProblem; applied by InningsBuilder.applySeed; persisted in Json; SeedParser turns the phone form into a seed.
* Tests: SeededInningsTest, SeedJsonTest. Status: not compiled here; verify with the GitHub Actions build.

## Update: pro icons, preview-freeze fix, 10 new templates (UNCOMPILED, same as above)
* Icons: ui/Icons.kt (own line-icon set, no extra library). All emoji/text symbols removed; bottom nav, Studio tabs, Home tiles,
  buttons (BigButton(icon=...)), section headers (SectionCard(icon=...)), WarnLine. New Common.kt: HomeTile, Line/Muted colours.
* Preview freeze: (1) StreamEngine.detachPreview(view) only acts if that view is still the current one (new screen's surface is
  created BEFORE the old one is destroyed, the old "destroyed" used to stop the new preview); (2) reconfigurePreview skips when
  profile/fps unchanged (was restarting on every setting change); (3) BroadcastVideoSource tick always re-posts (an exception used
  to kill the pump for good) + heartbeat; (4) 2 s watchdog in StreamEngine kicks / rebuilds a frozen preview (idle only).
* Templates: 10 new strips (NEON_ARENA ... CRIMSON_GOLD, total 19) via BroadcastRenderer.drawStrip + STRIPS styles;
  OverlayData got targetValue / requiredRuns / ballsLeft for the "REQUIRED: x RUNS IN y BALLS" line.
* Verify first: gradle build (Icons.kt uses compose PathParser; FilterChipDefaults.filterChipBorder signature), then look at the
  10 strips on a device (text positions were laid out by hand, never rendered).
