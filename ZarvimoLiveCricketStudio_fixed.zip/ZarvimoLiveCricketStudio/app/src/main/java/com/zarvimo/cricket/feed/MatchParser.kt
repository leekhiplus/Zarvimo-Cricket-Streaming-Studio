package com.zarvimo.cricket.feed

import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

/** JSON that cricket websites embed in their pages (script tags, window.__X__ = {...}, Next.js flight data). */
internal object JsonBlobs {
    private const val MAX_SCRIPT = 6_000_000
    private val scriptRe = Regex("(?is)<script([^>]*)>(.*?)</script>")
    private val assignRe = Regex("(?:window\\s*\\.\\s*[A-Za-z_\$][\\w\$]*|\\bvar\\s+[A-Za-z_\$][\\w\$]*|\\bconst\\s+[A-Za-z_\$][\\w\$]*|\\blet\\s+[A-Za-z_\$][\\w\$]*)\\s*=\\s*(?=[\\[{])")
    private val flightRe = Regex("self\\.__next_f\\.push\\(\\[\\s*\\d+\\s*,\\s*\"((?:[^\"\\\\]|\\\\.)*)\"\\s*\\]\\)")

    fun extract(html: String): List<Any> {
        val out = ArrayList<Any>()
        val flight = StringBuilder()
        for (m in scriptRe.findAll(html)) {
            val code = m.groupValues[2].trim()
            if (code.isEmpty() || code.length > MAX_SCRIPT) continue
            if (code.startsWith("{") || code.startsWith("[")) {
                val v = Jx.parse(code)
                if (v != null) out.add(v)
                continue
            }
            if (code.contains("__next_f")) {
                for (f in flightRe.findAll(code)) flight.append(unescape(f.groupValues[1]))
                continue
            }
            for (a in assignRe.findAll(code)) {
                val start = a.range.last + 1
                if (start >= code.length) continue
                val block = balanced(code, start) ?: continue
                val v = Jx.parse(block)
                if (v != null) out.add(v)
            }
        }
        if (flight.isNotEmpty()) out.addAll(flightPieces(flight.toString()))
        return out
    }

    private fun unescape(body: String): String = try {
        (JSONTokener("\"" + body + "\"").nextValue() as? String) ?: ""
    } catch (e: Exception) {
        ""
    }

    /** Next.js flight data is a list of lines like  5:{"a":1}  or  8:["\$","div",...]. */
    private fun flightPieces(text: String): List<Any> {
        val out = ArrayList<Any>()
        for (line in text.split('\n')) {
            val idx = line.indexOf(':')
            if (idx < 0 || idx > 8) continue
            val content = line.substring(idx + 1).trim()
            if (content.startsWith("{") || content.startsWith("[")) {
                val v = Jx.parse(content)
                if (v != null) out.add(v)
            }
        }
        return out
    }

    /** The text of the JSON value that starts at [start] (a { or [), up to its matching bracket. */
    private fun balanced(s: String, start: Int): String? {
        var depth = 0
        var inStr = false
        var i = start
        while (i < s.length) {
            val ch = s[i]
            if (inStr) {
                if (ch == '\\') i++ else if (ch == '"') inStr = false
            } else if (ch == '"') {
                inStr = true
            } else if (ch == '{' || ch == '[') {
                depth++
            } else if (ch == '}' || ch == ']') {
                depth--
                if (depth == 0) return s.substring(start, i + 1)
            }
            i++
        }
        return null
    }
}

/** Title / OpenGraph tags: enough for a score line even from a page that has nothing else we can read. */
internal object HeaderMeta {
    private val VS = Regex("(?i)^(.{2,60}?)\\s+(?:vs\\.?|v)\\s+(.{2,60}?)(?:,|\\s+-|\\s+\\||\\s+\\(|\\s+live|\\s+scorecard|\\s+match|\$)")
    private val MENTION = Regex("([A-Za-z][A-Za-z .&'-]{1,30}?)\\s+(\\d{1,4})\\s*[/-]\\s*(\\d{1,2})\\s*\\(\\s*(\\d{1,3}(?:\\.\\d)?)")

    private fun clean(s: String): String =
        s.replace(Regex("\\d{1,4}\\s*[/-]\\s*\\d{1,2}\\s*(\\([^)]*\\))?"), " ")
            .replace(Regex("\\([^)]*\\)"), " ")
            .replace(Regex("(?i)^(live|watch|score|scorecard)\\s*[:|-]?\\s+"), "")
            .replace(Regex("(?i)^(vs\\.?|v)\\s+"), "")
            .replace(Regex("\\s+"), " ").trim()

    fun vsTeams(title: String): Pair<String, String>? {
        val m = VS.find(title.trim()) ?: return null
        val a = clean(m.groupValues[1])
        val b = clean(m.groupValues[2])
        if (a.isBlank() || b.isBlank() || a.length > 40 || b.length > 40) return null
        return Pair(a, b)
    }

    fun fromHtml(html: String): FeedMatch? {
        val texts = listOf(
            HtmlText.metaOf(html, "og:title"), HtmlText.titleOf(html),
            HtmlText.metaOf(html, "og:description"), HtmlText.metaOf(html, "description")
        ).filter { it.isNotBlank() }
        if (texts.isEmpty()) return null
        var teams: Pair<String, String>? = null
        for (t in texts) {
            teams = vsTeams(t)
            if (teams != null) break
        }
        val innings = ArrayList<FeedInnings>()
        for (t in texts) {
            for (m in MENTION.findAll(t)) {
                val team = clean(m.groupValues[1])
                val runs = m.groupValues[2].toIntOrNull() ?: continue
                val wk = m.groupValues[3].toIntOrNull() ?: continue
                if (team.isBlank() || wk > 10 || runs > 999) continue
                if (innings.none { TeamNames.same(it.team, team) }) innings.add(FeedInnings(team = team, runs = runs, wickets = wk, overs = m.groupValues[4]))
            }
            if (innings.isNotEmpty()) break
        }
        if (teams == null && innings.isEmpty()) return null
        return FeedMatch(
            title = if (teams != null) "${teams.first} vs ${teams.second}" else "",
            teamA = teams?.first ?: "", teamB = teams?.second ?: "", innings = innings
        )
    }
}

/** Combines what several pages (or several readers) found about the same match. */
internal object FeedMerge {

    private fun pick(a: String, b: String): String = if (a.isNotBlank()) a else b

    private fun sameInn(x: FeedInnings, y: FeedInnings): Boolean {
        val teamOk = x.team.isBlank() || y.team.isBlank() || TeamNames.same(x.team, y.team)
        val xr = x.runs
        val yr = y.runs
        return teamOk && (xr == null || yr == null || xr == yr)
    }

    private fun fuse(x: FeedInnings, y: FeedInnings): FeedInnings = x.copy(
        team = if (x.team.length >= y.team.length) x.team else y.team,
        runs = x.runs ?: y.runs,
        wickets = x.wickets ?: y.wickets,
        overs = pick(x.overs, y.overs),
        batters = if (x.batters.size >= y.batters.size) x.batters else y.batters,
        bowlers = if (x.bowlers.size >= y.bowlers.size) x.bowlers else y.bowlers,
        extras = pick(x.extras, y.extras),
        fallOfWickets = if (x.fallOfWickets.isNotEmpty()) x.fallOfWickets else y.fallOfWickets,
        yetToBat = if (x.yetToBat.isNotEmpty()) x.yetToBat else y.yetToBat,
        partnerships = if (x.partnerships.isNotEmpty()) x.partnerships else y.partnerships,
        order = if (x.order > 0) x.order else y.order
    )

    private fun mergeInnings(a: List<FeedInnings>, b: List<FeedInnings>): List<FeedInnings> {
        if (a.isEmpty()) return b
        if (b.isEmpty()) return a
        val used = BooleanArray(b.size)
        val out = ArrayList<FeedInnings>()
        for (i in a.indices) {
            val x = a[i]
            var j: Int? = b.indices.firstOrNull { k -> !used[k] && sameInn(x, b[k]) }
            if (j == null && a.size == b.size && i < used.size && !used[i]) j = i
            if (j != null) {
                used[j] = true
                out.add(fuse(x, b[j]))
            } else {
                out.add(x)
            }
        }
        for (k in b.indices) if (!used[k]) out.add(b[k])
        return out
    }

    fun merge(a: FeedMatch?, b: FeedMatch?): FeedMatch? {
        if (a == null) return b
        if (b == null) return a
        return a.copy(
            title = pick(a.title, b.title), series = pick(a.series, b.series), venue = pick(a.venue, b.venue),
            status = pick(a.status, b.status), result = a.result ?: b.result, complete = a.complete || b.complete,
            toss = pick(a.toss, b.toss), teamA = pick(a.teamA, b.teamA), teamB = pick(a.teamB, b.teamB),
            teamAShort = pick(a.teamAShort, b.teamAShort), teamBShort = pick(a.teamBShort, b.teamBShort),
            oversLimit = if (a.oversLimit > 0) a.oversLimit else b.oversLimit,
            innings = mergeInnings(a.innings, b.innings),
            striker = a.striker ?: b.striker, nonStriker = a.nonStriker ?: b.nonStriker, bowler = a.bowler ?: b.bowler,
            recentBalls = if (a.recentBalls.isNotEmpty()) a.recentBalls else b.recentBalls,
            currentRunRate = a.currentRunRate ?: b.currentRunRate, requiredRunRate = a.requiredRunRate ?: b.requiredRunRate,
            target = a.target ?: b.target, requiredRuns = a.requiredRuns ?: b.requiredRuns, ballsLeft = a.ballsLeft ?: b.ballsLeft,
            lastWicket = a.lastWicket ?: b.lastWicket, partnership = a.partnership ?: b.partnership,
            playerOfMatch = pick(a.playerOfMatch, b.playerOfMatch),
            commentary = if (a.commentary.isNotEmpty()) a.commentary else b.commentary
        )
    }
}

/** Fills in everything that can be worked out (run rates, target, who is batting...) once the raw reading is done. */
internal object FeedFinalizer {
    private val NEED = Regex("(?i)(?:^|\\s)(.+?)\\s+(?:need|needs|require|requires)\\s+(\\d+)\\s+runs?(?:\\s+(?:in|from|off)\\s+(\\d+)\\s+balls?)?")
    private val DONE = Regex("(?i)\\bwon by\\b|\\bwin by\\b|\\bmatch tied\\b|\\bmatch drawn\\b|\\bno result\\b|\\babandoned\\b|\\bwon the match\\b|\\bbeat\\b")

    fun finish(input: FeedMatch): FeedMatch {
        val m = input
        var a = m.teamA
        var b = m.teamB
        val distinct = ArrayList<String>()
        for (inn in m.innings) {
            if (inn.team.isNotBlank() && distinct.none { TeamNames.same(it, inn.team) }) distinct.add(inn.team)
        }
        if (a.isBlank()) a = distinct.firstOrNull { !TeamNames.same(it, b) } ?: ""
        if (b.isBlank()) b = distinct.firstOrNull { !TeamNames.same(it, a) } ?: ""

        var innings = m.innings
        val needM = NEED.find(m.status)
        if (needM != null && innings.size >= 2) {
            val who = needM.groupValues[1].trim()
            val idx = innings.indexOfFirst { TeamNames.same(it.team, who) }
            if (idx >= 0 && idx != innings.lastIndex) {
                val moved = innings[idx]
                innings = innings.filterIndexed { k, _ -> k != idx } + moved
            }
        }

        val complete = m.complete || DONE.containsMatchIn(m.status)
        val result = m.result ?: if (complete && m.status.isNotBlank()) m.status else null
        val cur = innings.lastOrNull { it.runs != null || it.batters.isNotEmpty() }
        val curRuns = cur?.runs
        val curBalls = CricketMath.ballsOf(cur?.overs)
        val limit = if (m.oversLimit > 0) m.oversLimit else HeaderScan.oversOfFormat(m.title + " " + m.series)

        var target = m.target
        if (target != null && target <= 0) target = null
        var reqRuns = m.requiredRuns
        var ballsLeft = m.ballsLeft
        if (!complete) {
            if (needM != null) {
                val need = needM.groupValues[2].toIntOrNull()
                val bl = needM.groupValues[3].toIntOrNull()
                if (need != null) {
                    reqRuns = need
                    if (target == null && curRuns != null) target = curRuns + need
                }
                if (bl != null) ballsLeft = bl
            }
            if (target == null && innings.size == 2 && limit > 0) {
                val first = innings[0].runs
                if (first != null) target = first + 1
            }
            if (innings.size < 2 && needM == null) target = null
            val t = target
            if (t != null && curRuns != null && reqRuns == null) reqRuns = maxOf(0, t - curRuns)
            if (ballsLeft == null && limit > 0 && curBalls != null && t != null) ballsLeft = maxOf(0, limit * 6 - curBalls)
        } else {
            reqRuns = null
            ballsLeft = null
        }

        val crr = m.currentRunRate ?: if (curRuns != null && curBalls != null) CricketMath.rate(curRuns, curBalls) else null
        val rr = reqRuns
        val bl = ballsLeft
        val rrr = if (complete) null else m.requiredRunRate ?: if (rr != null && bl != null && bl > 0) CricketMath.rate(rr, bl) else null

        var striker = m.striker
        var non = m.nonStriker
        if (striker == null && cur != null && !complete) {
            val atCrease = cur.batters.filter { it.notOut }
            val s = atCrease.firstOrNull { it.onStrike } ?: atCrease.firstOrNull()
            if (s != null) {
                striker = s.copy(onStrike = true)
                non = atCrease.firstOrNull { it !== s }?.copy(onStrike = false)
            }
        }
        var bowler = m.bowler
        if (bowler == null && cur != null && !complete) bowler = cur.bowlers.firstOrNull { it.current } ?: cur.bowlers.lastOrNull()

        val title = when {
            m.title.isBlank() -> if (a.isNotBlank() && b.isNotBlank()) "$a vs $b" else m.series
            a.isNotBlank() && b.isNotBlank() && !m.title.contains(" vs ", ignoreCase = true) -> "$a vs $b, ${m.title}"
            else -> m.title
        }
        return m.copy(
            title = title, teamA = a, teamB = b, innings = innings, complete = complete, result = result, oversLimit = limit,
            target = target, requiredRuns = reqRuns, ballsLeft = ballsLeft, currentRunRate = crr, requiredRunRate = rrr,
            striker = striker, nonStriker = non, bowler = bowler
        )
    }
}

/**
 * A match page also carries OTHER matches (related / live-now / series lists). Everything that belongs to a different
 * match ID is cut out before reading, so only the requested match can reach the screen.
 */
internal object MatchScope {
    class Result(val matched: Int, val removed: Int)

    private val ID_KEYS = arrayOf("matchId", "matchID", "match_id", "matchid")
    private val WRAP_KEYS = arrayOf("matchInfo", "matchHeader", "match", "matchDetails")
    private val DIGITS = Regex("\\d{3,12}")

    /** The match ID inside a Cricbuzz / ESPNcricinfo match link, or null when the link has none we can trust. */
    fun idOf(url: String): String? {
        Regex("(?i)cricbuzz\\.com/(?:live-cricket-scores|live-cricket-scorecard|cricket-full-commentary|cricket-match-facts|cricket-scores)/(\\d{4,10})").find(url)
            ?.let { return it.groupValues[1] }
        Regex("(?i)espncricinfo\\.com/matches/engine/match/(\\d{4,10})").find(url)?.let { return it.groupValues[1] }
        if (url.contains("espncricinfo.com", ignoreCase = true)) {
            for (seg in url.substringAfter("://").split('/', '?', '#')) {
                val m = Regex("(?i)^.*(?:-vs-|match|final|qualifier|eliminator).*-(\\d{5,10})$").find(seg)
                if (m != null) return m.groupValues[1]
            }
        }
        return null
    }

    private fun idText(v: Any?): String? = when {
        v is Number -> v.toLong().toString()
        v is String && DIGITS.matches(v.trim()) -> v.trim()
        else -> null
    }

    /** The match ID an object belongs to (its own key, or the key of its matchInfo / matchHeader child). */
    private fun keyOf(o: JSONObject): String? {
        for (k in ID_KEYS) idText(o.opt(k))?.let { return it }
        if (o.has("objectId") && (o.has("slug") || o.has("teams") || o.has("team1")) &&
            (o.has("status") || o.has("state") || o.has("stage") || o.has("series"))
        ) idText(o.opt("objectId"))?.let { return it }
        for (w in WRAP_KEYS) {
            val c = o.optJSONObject(w) ?: continue
            for (k in ID_KEYS) idText(c.opt(k))?.let { return it }
        }
        return null
    }

    /** Removes (from the parsed JSON, in place) every object that belongs to another match than [id]. */
    fun prune(roots: MutableList<Any>, id: String): Result {
        val c = IntArray(2)
        val it = roots.iterator()
        while (it.hasNext()) {
            val r = it.next()
            if (r is JSONObject) {
                val k = keyOf(r)
                if (k != null && k != id) { it.remove(); c[1]++; continue }
                if (k != null) c[0]++
            }
            walk(r, id, c, 0)
        }
        return Result(c[0], c[1])
    }

    private fun walk(node: Any?, id: String, c: IntArray, depth: Int) {
        if (depth > 60) return
        if (node is JSONObject) {
            val names = ArrayList<String>()
            val ki = node.keys()
            while (ki.hasNext()) names.add(ki.next())
            for (name in names) {
                val v = node.opt(name)
                if (v is JSONObject) {
                    val k = keyOf(v)
                    if (k != null && k != id) { node.remove(name); c[1]++; continue }
                    if (k != null) c[0]++
                    walk(v, id, c, depth + 1)
                } else if (v is JSONArray) {
                    walk(v, id, c, depth + 1)
                }
            }
        } else if (node is JSONArray) {
            var i = node.length() - 1
            while (i >= 0) {
                val v = node.opt(i)
                if (v is JSONObject) {
                    val k = keyOf(v)
                    if (k != null && k != id) { node.remove(i); c[1]++; i--; continue }
                    if (k != null) c[0]++
                    walk(v, id, c, depth + 1)
                } else if (v is JSONArray) {
                    walk(v, id, c, depth + 1)
                }
                i--
            }
        }
    }

    /** Keeps only innings of the match's own two teams (a sidebar score of some other match is dropped). */
    fun restrict(m: FeedMatch, anchor: Pair<String, String>?): FeedMatch {
        var a = m.teamA
        var b = m.teamB
        if (anchor != null) {
            val ok = a.isNotBlank() && b.isNotBlank() &&
                (TeamNames.same(a, anchor.first) || TeamNames.same(a, anchor.second)) &&
                (TeamNames.same(b, anchor.first) || TeamNames.same(b, anchor.second))
            if (!ok) {
                a = anchor.first; b = anchor.second
            }
        }
        if (a.isBlank() || b.isBlank()) return m.copy(teamA = a, teamB = b)
        val keep = m.innings.filter { it.team.isBlank() || TeamNames.same(it.team, a) || TeamNames.same(it.team, b) }
        val changed = a != m.teamA || b != m.teamB
        return m.copy(
            teamA = a, teamB = b, innings = keep,
            teamAShort = if (changed) "" else m.teamAShort, teamBShort = if (changed) "" else m.teamBShort
        )
    }

    /** False when a match-ID link was redirected to a page that no longer carries that ID (e.g. the home page). */
    fun samePage(requested: String, finalUrl: String): Boolean {
        if (finalUrl.isBlank()) return true
        if (!requested.contains("cricbuzz.com", ignoreCase = true)) return true
        val id = idOf(requested) ?: return true
        return finalUrl.contains(id)
    }
}

object MatchParser {

    /** Takes a pasted link (or a whole shared message that contains one) and returns a clean https URL, or null. */
    fun normalizeUrl(input: String): String? {
        val t = input.trim()
        if (t.isEmpty()) return null
        var u: String? = Regex("(?i)https?://[^\\s\"'<>]+").find(t)?.value
        if (u == null) {
            val bare = Regex("(?i)(?:www\\.)?[a-z0-9-]+(?:\\.[a-z0-9-]+)+(?:/[^\\s\"'<>]*)?").find(t)?.value ?: return null
            u = "https://$bare"
        }
        var url: String = u.trimEnd('.', ',', ';', ')', ']', '}', '!', '"', '\'')
        if (url.startsWith("http://", ignoreCase = true)) url = "https://" + url.substring(7)
        return try {
            val host = java.net.URI(url).host
            if (host.isNullOrBlank()) null else url
        } catch (e: Exception) {
            null
        }
    }

    fun hostName(url: String): String = try {
        (java.net.URI(url).host ?: "").removePrefix("www.")
    } catch (e: Exception) {
        ""
    }

    /** Other pages of the same match that carry more detail (the full scorecard next to the commentary page...). */
    fun companions(url: String): List<String> {
        val out = ArrayList<String>()
        val cb = Regex("(?i)^(https?://(?:www\\.)?cricbuzz\\.com)/(?:live-cricket-scores|live-cricket-scorecard|cricket-full-commentary|cricket-match-facts|cricket-scores)/(\\d+)/?([^/?#]*)").find(url)
        if (cb != null) {
            val base = cb.groupValues[1]
            val id = cb.groupValues[2]
            val slug = cb.groupValues[3]
            val tail = if (slug.isEmpty()) "" else "/$slug"
            out.add("$base/live-cricket-scorecard/$id$tail")
            out.add("$base/live-cricket-scores/$id$tail")
        }
        val ci = Regex("(?i)^(https?://(?:www\\.)?espncricinfo\\.com/.+?)/(?:live-cricket-score|ball-by-ball-commentary|match-impact-player|live-blog|full-scorecard|match-squads|match-report|match-statistics)(?:[/?#].*)?\$").find(url)
        if (ci != null) {
            out.add(ci.groupValues[1] + "/full-scorecard")
            out.add(ci.groupValues[1] + "/live-cricket-score")
        }
        return out.filter { !it.equals(url, ignoreCase = true) }.distinct()
    }

    /** Reads a match out of one page (HTML or JSON). Null when nothing that looks like a cricket match is there. */
    fun parse(url: String, body: String): FeedMatch? {
        val text = body.trim()
        if (text.isEmpty()) return null
        val id = MatchScope.idOf(url)
        val isJson = text.startsWith("{") || text.startsWith("[")
        var best: FeedMatch? = null
        var anchor: Pair<String, String>? = null
        var matched = 0
        if (isJson) {
            val root = Jx.parse(text)
            if (root != null) {
                val roots = arrayListOf<Any>(root)
                if (id != null) {
                    val r = MatchScope.prune(roots, id)
                    matched = r.matched
                    if (r.matched == 0 && r.removed > 0) return null
                }
                if (roots.isNotEmpty()) best = JsonMatchExtractor.extract(roots)
            }
        } else {
            val blobs = JsonBlobs.extract(text).toMutableList()
            val meta = HeaderMeta.fromHtml(text)
            if (meta != null && meta.teamA.isNotBlank() && meta.teamB.isNotBlank()) anchor = Pair(meta.teamA, meta.teamB)
            if (id != null) {
                val r = MatchScope.prune(blobs, id)
                matched = r.matched
                // the page is some other page (wrong ID sent to the home page...): never show its scores
                if (r.matched == 0 && r.removed > 0) return null
                if (r.matched == 0 && anchor == null) return null
            }
            if (blobs.isNotEmpty()) best = JsonMatchExtractor.extract(blobs)
            if (best == null || !best.hasScorecard) {
                val lines = HtmlText.toLines(text)
                best = FeedMerge.merge(best, TextMatchExtractor.extract(lines, HtmlText.titleOf(text)))
            }
            if (best == null || !best.hasScore) best = FeedMerge.merge(best, meta)
        }
        var m = best ?: return null
        if (id != null || anchor != null) m = MatchScope.restrict(m, anchor)
        if (!m.hasScore && m.teamA.isBlank() && m.status.isBlank()) return null
        return FeedFinalizer.finish(m.copy(sourceUrl = url, sourceName = hostName(url)))
    }

    fun samePageOk(requested: String, finalUrl: String): Boolean = MatchScope.samePage(requested, finalUrl)

    /** Several pages of the same match combined into one. */
    fun combine(url: String, parts: List<FeedMatch>): FeedMatch? {
        var acc: FeedMatch? = null
        for (p in parts) acc = FeedMerge.merge(acc, p)
        var m = acc ?: return null
        if (MatchScope.idOf(url) != null) m = MatchScope.restrict(m, null)
        return FeedFinalizer.finish(m.copy(sourceUrl = url, sourceName = hostName(url)))
    }

    /** True when the reading is rich enough to put on air (a score at least). */
    fun useful(m: FeedMatch?): Boolean = m != null && (m.hasScore || m.status.isNotBlank())
}
