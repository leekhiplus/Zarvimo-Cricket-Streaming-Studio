package com.zarvimo.cricket.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.cricket.feed.FeedBatter
import com.zarvimo.cricket.feed.FeedBowler
import com.zarvimo.cricket.feed.FeedInnings
import com.zarvimo.cricket.feed.FeedMatch
import com.zarvimo.cricket.feed.MatchSite
import com.zarvimo.cricket.graphics.PanelKind

/** Paste the link of a cricket website's match page: the score, scorecards and summary are read and put on air. */
@Composable
fun LinkScreen(vm: AppViewModel) {
    val ui by vm.feedUi.collectAsState()
    val clipboard = LocalClipboardManager.current
    val m = ui.match
    var siteName by rememberSaveable { mutableStateOf(MatchSite.CRICBUZZ.name) }
    var idText by rememberSaveable { mutableStateOf("") }
    val site = MatchSite.valueOf(siteName)

    PinnedPreviewScreen(vm, hint = "The preview shows exactly what viewers see. While the link is on, the website drives the score.") {
        SectionCard("Paste a score link", icon = Ic.Trend) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Paste the link of a match page from a cricket score website (Cricbuzz, ESPNcricinfo, Crex, Cricket.com ...). " +
                        "The score, batters, bowler, run rates, scorecards and match summary are read from the page and go on air by themselves.",
                    fontSize = 12.sp, color = Muted
                )
                TextInput("Match page link", ui.url, { vm.setFeedUrlText(it) }, placeholder = "https://...")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BigButton("PASTE", Modifier.weight(1f), icon = Ic.Upload) {
                        val t = clipboard.getText()?.text
                        if (!t.isNullOrBlank()) vm.setFeedUrlText(t)
                    }
                    BigButton(if (ui.running) "RESTART" else "START", Modifier.weight(1f), color = Gold, textColor = Color.Black, icon = Ic.Play) {
                        vm.startFeed(ui.url)
                    }
                }
                Text("Read the page again every", fontSize = 12.sp, color = Muted)
                ChipChoice(listOf(5, 10, 15, 30, 60), ui.intervalSec, { "$it s" }) { vm.setFeedInterval(it) }
                if (vm.feedIsOn) {
                    BigButton("STOP LINK - BACK TO MANUAL SCORING", Modifier.fillMaxWidth(), color = Color(0xFF8E1B1B), icon = Ic.Stop) { vm.stopFeed() }
                }
            }
        }

        SectionCard("Match ID", icon = Ic.Cricket) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("No link? Choose the website and type the match ID instead. The match page address is made for you.", fontSize = 12.sp, color = Muted)
                ChipChoice(MatchSite.values().toList(), site, { it.label }) { siteName = it.name }
                TextInput("Match ID", idText, { idText = it }, numeric = true, placeholder = "e.g. 91811")
                Text("Where to find it: " + site.hint, fontSize = 12.sp, color = Muted)
                val built = site.urlFor(idText)
                if (built != null) Text("Will read: $built", fontSize = 11.sp, color = Mint)
                BigButton("START WITH ID", Modifier.fillMaxWidth(), color = Gold, textColor = Color.Black, icon = Ic.Play) {
                    vm.startFeedById(site, idText)
                }
                Text("If an ID does not open on a website, paste the full match link in the box above instead.", fontSize = 11.sp, color = Muted)
            }
        }

        if (ui.running || ui.status.isNotBlank() || ui.error != null || ui.busy) {
            SectionCard("Status") {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (ui.status.isNotBlank()) Text(ui.status, color = Mint, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    if (ui.busy) Text("Reading the page...", fontSize = 12.sp, color = Muted)
                    val err = ui.error
                    if (err != null) WarnLine(err)
                    if (ui.viaBrowser) Text("This site needs JavaScript, so it is read through a hidden browser (a little slower).", fontSize = 12.sp, color = Muted)
                    if (ui.url.isNotBlank() && vm.feedIsOn) BigButton("READ NOW", Modifier.fillMaxWidth(), icon = Ic.Next) { vm.refreshFeed() }
                }
            }
        }

        if (m != null) {
            SectionCard("Put on air", icon = Ic.Tv) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val items = ArrayList<Pair<String, () -> Unit>>()
                    m.innings.forEachIndexed { i, inn ->
                        if (inn.batters.isNotEmpty() || inn.bowlers.isNotEmpty()) {
                            val label = "Scorecard: " + inn.team.ifBlank { "Innings ${i + 1}" }
                            items.add(label to { vm.showFeedScorecard(i) })
                        }
                    }
                    items.add("Match summary" to { vm.showPanel(PanelKind.MATCH_SUMMARY) })
                    if (m.complete) items.add("Result" to { vm.showPanel(PanelKind.RESULT_CARD) })
                    if (m.toss.isNotBlank()) items.add("Toss" to { vm.showPanel(PanelKind.TOSS_CARD) })
                    if (m.playerOfMatch.isNotBlank()) items.add("Man of the match" to { vm.showPanel(PanelKind.MAN_OF_MATCH) })
                    if (m.striker != null) items.add("Striker" to { vm.showPanel(PanelKind.STRIKER) })
                    if (m.nonStriker != null) items.add("Non-striker" to { vm.showPanel(PanelKind.NON_STRIKER) })
                    if (m.bowler != null) items.add("Bowler" to { vm.showPanel(PanelKind.BOWLER) })
                    if (m.partnership != null) items.add("Partnership" to { vm.showPanel(PanelKind.PARTNERSHIP) })
                    ButtonGrid(items)
                    BigButton("HIDE PANEL", Modifier.fillMaxWidth(), icon = Ic.Close) { vm.hidePanel() }
                }
            }

            SectionCard("What was read from the website", icon = Ic.Info) {
                MatchDetails(m)
            }
        }
    }
}

@Composable
private fun ButtonGrid(items: List<Pair<String, () -> Unit>>) {
    for (chunk in items.chunked(2)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (item in chunk) {
                BigButton(item.first, Modifier.weight(1f)) { item.second() }
            }
            if (chunk.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
private fun MatchDetails(m: FeedMatch) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        if (m.title.isNotBlank()) Text(m.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        val sub = listOf(m.series, m.venue, m.sourceName).filter { it.isNotBlank() }.joinToString("  \u2022  ")
        if (sub.isNotBlank()) Text(sub, fontSize = 12.sp, color = Muted)
        if (m.status.isNotBlank()) Text(m.status, fontSize = 13.sp, color = Gold, fontWeight = FontWeight.Bold)
        if (m.toss.isNotBlank()) Text("Toss: ${m.toss}", fontSize = 12.sp)
        if (m.playerOfMatch.isNotBlank()) Text("Man of the match: ${m.playerOfMatch}", fontSize = 12.sp)
        val live = ArrayList<String>()
        m.currentRunRate?.let { live.add("CRR $it") }
        m.requiredRunRate?.let { live.add("RRR $it") }
        m.target?.let { live.add("Target $it") }
        if (m.recentBalls.isNotEmpty()) live.add("Last balls: " + m.recentBalls.joinToString(" "))
        if (live.isNotEmpty()) Text(live.joinToString("   "), fontSize = 12.sp)
        m.innings.forEachIndexed { i, inn -> InningsDetails(inn, i) }
        if (!m.hasScorecard) {
            Text("This page shows the score but no batting / bowling tables, so the scorecard panels are not available from it.", fontSize = 12.sp, color = Color(0xFFFFB74D))
        }
    }
}

private fun batterLine(b: FeedBatter): String =
    b.name.take(18).padEnd(18) + " " + b.runs.toString().padStart(3) + " (" + b.balls + ")  4s " + b.fours + "  6s " + b.sixes +
        "  " + (if (b.notOut) "not out" else b.dismissal)

private fun bowlerLine(b: FeedBowler): String =
    b.name.take(18).padEnd(18) + " " + b.overs.padStart(4) + "-" + b.maidens + "-" + b.runs + "-" + b.wickets + "  eco " + b.economy

@Composable
private fun InningsDetails(inn: FeedInnings, index: Int) {
    val mono = FontFamily.Monospace
    Text(
        "${index + 1}. " + inn.team.ifBlank { "Innings ${index + 1}" } + "   " + inn.scoreText + "  (" + inn.overs.ifBlank { "-" } + " ov)",
        fontWeight = FontWeight.Bold, color = Gold, fontSize = 14.sp
    )
    for (b in inn.batters.take(12)) Text(batterLine(b), fontFamily = mono, fontSize = 10.sp)
    for (b in inn.bowlers.take(8)) Text(bowlerLine(b), fontFamily = mono, fontSize = 10.sp)
    if (inn.extras.isNotBlank()) Text(inn.extras, fontSize = 11.sp, color = Muted)
    if (inn.fallOfWickets.isNotEmpty()) Text("FOW: " + inn.fallOfWickets.joinToString("  "), fontSize = 11.sp, color = Muted)
}
