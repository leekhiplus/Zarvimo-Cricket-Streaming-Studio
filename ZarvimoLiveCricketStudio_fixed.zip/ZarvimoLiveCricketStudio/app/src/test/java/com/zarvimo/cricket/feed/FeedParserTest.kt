package com.zarvimo.cricket.feed

import com.zarvimo.cricket.graphics.MatchVisuals
import com.zarvimo.cricket.graphics.PanelKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FeedParserTest {

    // ------------------------------------------------------------------ helpers

    @Test fun cricketMath_overs_and_rates() {
        assertEquals(112, CricketMath.ballsOf("18.4"))
        assertEquals(120, CricketMath.ballsOf("20"))
        assertNull(CricketMath.ballsOf("3.7"))
        assertNull(CricketMath.ballsOf("abc"))
        assertEquals("10.74", CricketMath.rate(111, 62))
        assertNull(CricketMath.rate(10, 0))
        assertEquals("18.4", CricketMath.oversText(112))
    }

    @Test fun teamNames_abbreviations() {
        assertTrue(TeamNames.same("PAK", "Pakistan"))
        assertTrue(TeamNames.same("RCB", "Royal Challengers Bangalore"))
        assertTrue(TeamNames.same("pakistan ", "Pakistan"))
        assertFalse(TeamNames.same("India", "Pakistan"))
        assertFalse(TeamNames.same("", "Pakistan"))
    }

    @Test fun normalizeUrl_takesTheLinkOutOfSharedText() {
        assertEquals(
            "https://www.cricbuzz.com/live-cricket-scores/12345/pak-vs-aus-1st-t20i",
            MatchParser.normalizeUrl("Watch this https://www.cricbuzz.com/live-cricket-scores/12345/pak-vs-aus-1st-t20i. Great match!")
        )
        assertEquals(
            "https://www.espncricinfo.com/series/x-1/y-2/live-cricket-score",
            MatchParser.normalizeUrl("www.espncricinfo.com/series/x-1/y-2/live-cricket-score")
        )
        assertEquals("https://example.com/a", MatchParser.normalizeUrl("http://example.com/a"))
        assertNull(MatchParser.normalizeUrl("hello there"))
        assertNull(MatchParser.normalizeUrl("   "))
    }

    @Test fun companions_cricbuzzScorecardPage() {
        val c = MatchParser.companions("https://www.cricbuzz.com/live-cricket-scores/12345/pak-vs-aus")
        assertEquals(listOf("https://www.cricbuzz.com/live-cricket-scorecard/12345/pak-vs-aus"), c)
    }

    @Test fun matchId_buildsTheMatchPageAddress() {
        assertEquals("https://www.cricbuzz.com/live-cricket-scorecard/91811", MatchSite.CRICBUZZ.urlFor("91811"))
        assertEquals("https://www.cricbuzz.com/live-cricket-scorecard/91811", MatchSite.CRICBUZZ.urlFor(" match id: 91811 "))
        assertEquals("https://www.espncricinfo.com/matches/engine/match/1422119.html", MatchSite.CRICINFO.urlFor("1422119"))
        assertNull(MatchSite.CRICBUZZ.urlFor("abc"))
        assertNull(MatchSite.CRICBUZZ.urlFor("12"))
        assertNull(MatchSite.CRICINFO.urlFor(""))
    }

    @Test fun companions_cricbuzzIdOnlyAddress() {
        val c = MatchParser.companions("https://www.cricbuzz.com/live-cricket-scorecard/91811")
        assertEquals(listOf("https://www.cricbuzz.com/live-cricket-scores/91811"), c)
    }

    @Test fun parseBalls_dotBecomesZero_lastSix() {
        assertEquals(listOf("4", "0", "1", "0", "1", "6"), HeaderScan.parseBalls("1 0 W 4 . 1 | 0 1 6"))
    }

    // ------------------------------------------------------------------ JSON (Cricbuzz-like layout)

    private val cricbuzzLike = """
        {"matchHeader":{"matchDescription":"1st T20I","matchFormat":"T20","seriesName":"Australia tour of Pakistan",
          "status":"Pakistan need 111 runs in 62 balls","state":"In Progress",
          "team1":{"name":"Pakistan","shortName":"PAK"},"team2":{"name":"Australia","shortName":"AUS"}},
         "scoreCard":[
          {"inningsId":1,
           "batTeamDetails":{"batTeamName":"Australia","batsmenData":{"bat_1":{"batName":"David Warner","runs":60,"balls":40,"fours":6,"sixes":3,"strikeRate":150.0,"outDesc":"c Babar b Shaheen"}}},
           "bowlTeamDetails":{"bowlTeamName":"Pakistan","bowlersData":{"bowl_1":{"bowlName":"Shaheen Afridi","overs":4,"maidens":0,"runs":30,"wickets":2,"economy":7.5}}},
           "scoreDetails":{"runs":268,"wickets":8,"overs":20.0}},
          {"inningsId":2,
           "batTeamDetails":{"batTeamName":"Pakistan","batsmenData":{
              "bat_1":{"batName":"Babar Azam","runs":72,"balls":48,"fours":6,"sixes":2,"strikeRate":150.0,"outDesc":""},
              "bat_2":{"batName":"Mohammad Rizwan","runs":36,"balls":32,"fours":3,"sixes":1,"strikeRate":112.5,"outDesc":""}}},
           "bowlTeamDetails":{"bowlTeamName":"Australia","bowlersData":{"bowl_1":{"bowlName":"Pat Cummins","overs":3.4,"maidens":0,"runs":28,"wickets":1,"economy":7.64}}},
           "scoreDetails":{"runs":158,"wickets":5,"overs":18.4}}
         ]}
    """.trimIndent()

    @Test fun json_cricbuzzLike_fullMatch() {
        val m = MatchParser.parse("https://www.cricbuzz.com/live-cricket-scorecard/1/x", cricbuzzLike)
        assertNotNull(m)
        m!!
        assertEquals("Pakistan", m.teamA)
        assertEquals("Australia", m.teamB)
        assertEquals(2, m.innings.size)
        assertEquals("Australia", m.innings[0].team)
        assertEquals("268/8", m.innings[0].scoreText)
        assertEquals("158/5", m.innings[1].scoreText)
        assertEquals("18.4", m.innings[1].overs)
        assertEquals(2, m.innings[1].batters.size)
        assertEquals("Pat Cummins", m.innings[1].bowlers[0].name)
        assertEquals(20, m.oversLimit)
        assertEquals(269, m.target)
        assertEquals(111, m.requiredRuns)
        assertEquals(62, m.ballsLeft)
        assertEquals("10.74", m.requiredRunRate)
        assertEquals("Babar Azam", m.striker?.name)
        assertEquals("Mohammad Rizwan", m.nonStriker?.name)
        assertEquals("Pat Cummins", m.bowler?.name)
        assertFalse(m.complete)
        assertEquals("cricbuzz.com", m.sourceName)
    }

    @Test fun mapper_chaseOverlay_and_scorecardPanel() {
        val m = MatchParser.parse("https://www.cricbuzz.com/live-cricket-scorecard/1/x", cricbuzzLike)!!
        val o = FeedMapper.overlay(m, MatchVisuals())
        assertEquals("Pakistan", o.battingTeam)
        assertEquals("Australia", o.bowlingTeam)
        assertEquals("158/5", o.score)
        assertEquals("18.4", o.overs)
        assertEquals("NEED 111 RUNS FROM 62 BALLS", o.chaseText)
        assertEquals(269, o.targetValue)
        assertEquals("1-28 (3.4)", o.bowlerFigures)
        assertEquals("Babar Azam", o.striker?.name)
        assertEquals(72, o.striker?.runs)

        val p = FeedPanels.build(PanelKind.SCORECARD, m, MatchVisuals(), null)
        assertNotNull(p)
        p!!
        assertEquals("PAKISTAN", p.title)
        assertEquals(2, p.bat.size)
        assertEquals(1, p.bowl.size)
        assertTrue(p.subtitle.contains("158/5"))
        val first = FeedPanels.build(PanelKind.SCORECARD, m, MatchVisuals(), 0)
        assertEquals("AUSTRALIA", first!!.title)
        assertEquals("c Babar b Shaheen", first.bat[0].sub)
    }

    // ------------------------------------------------------------------ JSON (ESPNcricinfo-like layout, finished match)

    private val cricinfoLike = """
        {"props":{"pageProps":{"data":{
          "match":{"title":"1st T20I","statusText":"Australia won by 12 runs","state":"POST","format":"T20",
            "ground":{"name":"Gaddafi Stadium","town":"Lahore"},
            "teams":[{"team":{"name":"Pakistan","abbreviation":"PAK"}},{"team":{"name":"Australia","abbreviation":"AUS"}}]},
          "content":{"innings":[
            {"inningNumber":1,"team":{"name":"Australia"},"runs":180,"wickets":6,"overs":20,
             "inningBatsmen":[{"player":{"name":"David Warner"},"runs":60,"balls":40,"fours":6,"sixes":3,"strikerate":150.0,"isNotOut":false,"dismissalText":{"short":"c Babar b Shaheen"}}],
             "inningBowlers":[{"player":{"name":"Shaheen Afridi"},"overs":4,"maidens":0,"conceded":30,"wickets":2,"economy":7.5}],
             "inningFallOfWickets":[{"player":{"name":"David Warner"},"fowOrder":1,"fowRuns":55,"fowOvers":6.2}]},
            {"inningNumber":2,"team":{"name":"Pakistan"},"runs":168,"wickets":9,"overs":20,
             "inningBatsmen":[{"player":{"name":"Babar Azam"},"runs":72,"balls":48,"fours":6,"sixes":2,"isNotOut":false,"dismissalText":{"short":"c Smith b Cummins"}}],
             "inningBowlers":[{"player":{"name":"Pat Cummins"},"overs":4,"maidens":1,"conceded":25,"wickets":3,"economy":6.25}]}
          ]}}}}}
    """.trimIndent()

    @Test fun json_cricinfoLike_finishedMatch() {
        val m = MatchParser.parse("https://www.espncricinfo.com/x/full-scorecard", cricinfoLike)
        assertNotNull(m)
        m!!
        assertTrue(m.complete)
        assertEquals("Australia won by 12 runs", m.result)
        assertEquals("Gaddafi Stadium, Lahore", m.venue)
        assertEquals(20, m.oversLimit)
        assertEquals(2, m.innings.size)
        assertEquals("Australia", m.innings[0].team)
        assertEquals("c Babar b Shaheen", m.innings[0].batters[0].dismissal)
        assertTrue(m.innings[0].fallOfWickets[0].startsWith("1-55"))
        assertEquals("Babar Azam", m.innings[1].batters[0].name)
        assertEquals("150.00", m.innings[1].batters[0].strikeRate)
        assertNull(m.target)

        val o = FeedMapper.overlay(m, MatchVisuals())
        assertEquals("AUSTRALIA WON BY 12 RUNS", o.resultText)
        assertNull(o.chaseText)
        val r = FeedPanels.build(PanelKind.RESULT_CARD, m, MatchVisuals(), null)
        assertNotNull(r)
        assertEquals("AUSTRALIA WON BY 12 RUNS", r!!.subtitle)
    }

    // ------------------------------------------------------------------ HTML without JSON

    @Test fun html_tables_areRead() {
        val html = """
            <html><head><title>Pakistan vs Australia, 1st T20I - Live Cricket Score</title></head><body>
            <div>Pakistan 158/5 (18.4 Ov)</div>
            <table>
            <tr><th>Batter</th><th>Dismissal</th><th>R</th><th>B</th><th>4s</th><th>6s</th><th>SR</th></tr>
            <tr><td>Babar Azam</td><td>not out</td><td>72</td><td>48</td><td>6</td><td>2</td><td>150.00</td></tr>
            <tr><td>Mohammad Rizwan</td><td>not out</td><td>36</td><td>32</td><td>3</td><td>1</td><td>112.50</td></tr>
            </table>
            <div>Extras 10 (b 4, lb 2, w 4)</div>
            <table>
            <tr><th>Bowler</th><th>O</th><th>M</th><th>R</th><th>W</th><th>Econ</th></tr>
            <tr><td>Pat Cummins</td><td>3.4</td><td>0</td><td>28</td><td>1</td><td>7.64</td></tr>
            </table></body></html>
        """.trimIndent()
        val m = MatchParser.parse("https://example.com/match", html)
        assertNotNull(m)
        m!!
        assertEquals("Pakistan", m.teamA)
        assertEquals("Australia", m.teamB)
        assertEquals(1, m.innings.size)
        assertEquals("158/5", m.innings[0].scoreText)
        assertEquals(2, m.innings[0].batters.size)
        assertEquals("1-28 (3.4)", m.innings[0].bowlers[0].figures)
        assertTrue(m.innings[0].extras.startsWith("Extras 10"))
        assertEquals("Babar Azam", m.striker?.name)
        assertEquals(20, m.oversLimit)
    }

    @Test fun html_oneValuePerLine_isRead() {
        val html = "<html><body><div>Pakistan Innings 158-5 (18.4 Ov)</div><div>Batter</div>" +
            "<div>Babar Azam</div><div>not out</div><div>72</div><div>48</div><div>6</div><div>2</div><div>150.00</div>" +
            "<div>Rizwan</div><div>not out</div><div>36</div><div>32</div><div>3</div><div>1</div><div>112.50</div>" +
            "<div>Bowler</div><div>Pat Cummins</div><div>3.4</div><div>0</div><div>28</div><div>1</div><div>7.64</div></body></html>"
        val m = MatchParser.parse("https://example.com/match", html)
        assertNotNull(m)
        m!!
        assertEquals(1, m.innings.size)
        assertEquals("Pakistan", m.innings[0].team)
        assertEquals(2, m.innings[0].batters.size)
        assertEquals("Babar Azam", m.innings[0].batters[0].name)
        assertEquals("not out", m.innings[0].batters[0].dismissal)
        assertEquals(1, m.innings[0].bowlers.size)
    }

    @Test fun html_withNoCricket_isRejected() {
        assertNull(MatchParser.parse("https://example.com", "<html><head><title>Hello</title></head><body><p>Nothing here 12 34</p></body></html>"))
        assertNull(MatchParser.parse("https://example.com", ""))
    }

    @Test fun invalidRows_areNotMistakenForScorecards() {
        // strike rate does not match runs / balls, so this is ordinary text, not a batter
        val html = "<html><body><table><tr><td>Some Person</td><td>5</td><td>40</td><td>1</td><td>0</td><td>999.00</td></tr></table></body></html>"
        assertNull(MatchParser.parse("https://example.com", html))
    }

    // ------------------------------------------------------------------ mapper corners

    @Test fun mapper_preMatch_and_toss() {
        val pre = FeedMatch(teamA = "Pakistan", teamB = "Australia", status = "Toss at 7 pm")
        assertEquals("TOSS AT 7 PM", FeedMapper.overlay(pre, MatchVisuals()).preMatch)

        val m = FeedMatch(teamA = "Pakistan", teamB = "Australia", toss = "Pakistan won the toss and opt to bat")
        val p = FeedPanels.build(PanelKind.TOSS_CARD, m, MatchVisuals(), null)
        assertNotNull(p)
        assertEquals("PAKISTAN", p!!.subtitle)
        assertEquals("AND CHOSE TO BAT FIRST", p.footer)
    }

    @Test fun mapper_firstInnings_hasNoChase() {
        val m = FeedMatch(
            teamA = "Pakistan", teamB = "Australia", oversLimit = 20,
            innings = listOf(FeedInnings(team = "Pakistan", runs = 90, wickets = 2, overs = "10.0"))
        )
        val o = FeedMapper.overlay(m, MatchVisuals())
        assertNull(o.chaseText)
        assertNull(o.targetValue)
        assertEquals("90/2", o.score)
        assertEquals(20, o.oversLimit)
    }

    // ------------------------------------------------------------------ other matches on the same page

    @Test fun matchId_otherMatchesOnThePageAreIgnored() {
        val json = """
            {"matchHeader":{"matchId":91811,"matchDescription":"1st T20I","matchFormat":"T20","status":"Pakistan need 111 runs in 62 balls","state":"In Progress",
              "team1":{"name":"Pakistan","shortName":"PAK"},"team2":{"name":"Australia","shortName":"AUS"}},
             "scoreCard":[{"inningsId":1,"batTeamDetails":{"batTeamName":"Australia","batsmenData":{"bat_1":{"batName":"David Warner","runs":60,"balls":40,"fours":6,"sixes":3,"strikeRate":150.0,"outDesc":"not out"}}},
               "bowlTeamDetails":{"bowlTeamName":"Pakistan","bowlersData":{"bowl_1":{"bowlName":"Shaheen Afridi","overs":4,"maidens":0,"runs":30,"wickets":2,"economy":7.5}}},
               "scoreDetails":{"runs":60,"wickets":0,"overs":"6.0"}}],
             "otherMatches":[{"matchInfo":{"matchId":55555,"team1":{"name":"India"},"team2":{"name":"England"},"status":"India won by 5 wickets"},
               "scoreCard":{"batTeamDetails":{"batTeamName":"India","batsmenData":{"bat_1":{"batName":"Virat Kohli","runs":99,"balls":50,"fours":9,"sixes":4,"strikeRate":198.0,"outDesc":"not out"}}},
                 "bowlTeamDetails":{"bowlTeamName":"England","bowlersData":{"bowl_1":{"bowlName":"Jofra Archer","overs":4,"maidens":0,"runs":40,"wickets":1,"economy":10.0}}},
                 "scoreDetails":{"runs":150,"wickets":3,"overs":"15.0"}}}]}
        """.trimIndent()
        val m = MatchParser.parse("https://www.cricbuzz.com/live-cricket-scorecard/91811/pak-vs-aus", json)!!
        assertEquals("Pakistan", m.teamA)
        assertTrue(m.innings.none { it.team == "India" || it.team == "England" })
        assertTrue(m.innings.none { it.batters.any { b -> b.name.contains("Kohli") } })
    }

    @Test fun matchId_pageWithOnlyOtherMatchesIsRejected() {
        val json = """{"matches":[{"matchInfo":{"matchId":55555,"team1":{"name":"India"},"team2":{"name":"England"},"status":"India won by 5 wickets"}}]}"""
        assertNull(MatchParser.parse("https://www.cricbuzz.com/live-cricket-scorecard/91811", json))
    }

    @Test fun matchId_redirectToHomePageIsDetected() {
        assertFalse(MatchParser.samePageOk("https://www.cricbuzz.com/live-cricket-scorecard/91811", "https://www.cricbuzz.com/"))
        assertTrue(MatchParser.samePageOk("https://www.cricbuzz.com/live-cricket-scorecard/91811", "https://www.cricbuzz.com/live-cricket-scores/91811/pak-vs-aus"))
    }
}
