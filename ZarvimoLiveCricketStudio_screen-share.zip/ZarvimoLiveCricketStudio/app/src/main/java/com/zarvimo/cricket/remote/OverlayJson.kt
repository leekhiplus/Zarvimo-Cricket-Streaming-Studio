package com.zarvimo.cricket.remote

import com.zarvimo.cricket.graphics.MatchVisuals
import com.zarvimo.cricket.scoring.InningsState
import com.zarvimo.cricket.scoring.MatchSetup
import org.json.JSONArray
import org.json.JSONObject

/**
 * The ONLY match data sent to browsers (OBS overlay, remote page). Built from the engine state; contains no stream key,
 * no tokens, no file paths and no settings. Pure Kotlin + org.json.
 */
object OverlayJson {
    private fun hex(c: Int) = String.format("#%06X", c and 0xFFFFFF)

    /** Nothing real to show: the browser overlay draws nothing at all. */
    fun hidden(): JSONObject = JSONObject().put("live", false).put("hidden", true)

    /** The same fields as [build], filled from a website reading (only what the website really gave). */
    fun fromFeed(m: com.zarvimo.cricket.feed.FeedMatch, visuals: MatchVisuals): JSONObject {
        val cur = m.currentInnings ?: return hidden()
        val batIsA = !com.zarvimo.cricket.feed.TeamNames.same(m.battingTeam, m.teamB) || com.zarvimo.cricket.feed.TeamNames.same(m.battingTeam, m.teamA)
        val o = JSONObject().put("title", m.title).put("teamA", m.teamA).put("teamB", m.teamB)
            .put("colorA", hex(visuals.teamAColor)).put("colorB", hex(visuals.teamBColor))
            .put("logoA", false).put("logoB", false).put("result", if (m.complete) (m.result ?: m.status) else JSONObject.NULL)
        o.put("live", cur.runs != null).put("hidden", cur.runs == null && !m.complete)
            .put("battingTeam", m.battingTeam).put("bowlingTeam", m.bowlingTeam)
            .put("battingColor", hex(if (batIsA) visuals.teamAColor else visuals.teamBColor))
            .put("bowlingColor", hex(if (batIsA) visuals.teamBColor else visuals.teamAColor))
            .put("battingLogo", if (batIsA) "a" else "b")
            .put("runs", cur.runs ?: JSONObject.NULL).put("wickets", cur.wickets ?: JSONObject.NULL)
            .put("score", cur.scoreText).put("overs", cur.overs).put("oversLimit", m.oversLimit)
            .put("runRate", m.currentRunRate ?: JSONObject.NULL)
            .put("target", if (m.complete) JSONObject.NULL else (m.target ?: JSONObject.NULL))
            .put("requiredRuns", m.requiredRuns ?: JSONObject.NULL).put("ballsLeft", m.ballsLeft ?: JSONObject.NULL)
            .put("requiredRate", m.requiredRunRate ?: JSONObject.NULL)
            .put("ended", m.complete).put("freeHit", false)
            .put("recent", JSONArray().also { a -> m.recentBalls.forEach { a.put(it) } })
        m.striker?.let { o.put("striker", JSONObject().put("name", it.name).put("runs", it.runs).put("balls", it.balls)) }
        m.nonStriker?.let { o.put("nonStriker", JSONObject().put("name", it.name).put("runs", it.runs).put("balls", it.balls)) }
        m.bowler?.let { o.put("bowler", JSONObject().put("name", it.name).put("figures", it.figures)) }
        return o
    }

    fun build(setup: MatchSetup, visuals: MatchVisuals, st: InningsState?, result: String?, hasLogoA: Boolean, hasLogoB: Boolean): JSONObject {
        val o = JSONObject().put("title", setup.title).put("teamA", setup.teamA).put("teamB", setup.teamB)
            .put("colorA", hex(visuals.teamAColor)).put("colorB", hex(visuals.teamBColor))
            .put("logoA", hasLogoA).put("logoB", hasLogoB).put("result", result ?: JSONObject.NULL)
        if (st == null) return o.put("live", false).put("hidden", result == null && setup.teamA.trim() == "Team A" && setup.teamB.trim() == "Team B")
        val batIsA = st.battingTeam == setup.teamA
        o.put("live", true).put("battingTeam", st.battingTeam).put("bowlingTeam", st.bowlingTeam)
            .put("battingColor", hex(if (batIsA) visuals.teamAColor else visuals.teamBColor))
            .put("bowlingColor", hex(if (batIsA) visuals.teamBColor else visuals.teamAColor))
            .put("battingLogo", if (batIsA) "a" else "b")
            .put("runs", st.runs).put("wickets", st.wickets).put("score", st.scoreText).put("overs", st.oversText).put("oversLimit", st.oversLimit)
            .put("runRate", String.format("%.2f", st.runRate))
            .put("target", st.target ?: JSONObject.NULL).put("requiredRuns", st.requiredRuns ?: JSONObject.NULL)
            .put("ballsLeft", st.ballsRemaining)
            .put("requiredRate", st.requiredRunRate?.let { String.format("%.2f", it) } ?: JSONObject.NULL)
            .put("ended", st.ended).put("freeHit", st.freeHit)
            .put("recent", JSONArray().also { a -> st.recentBalls.forEach { a.put(it.label) } })
        st.striker?.let { o.put("striker", JSONObject().put("name", it.name).put("runs", it.runs).put("balls", it.balls)) }
        st.nonStriker?.let { o.put("nonStriker", JSONObject().put("name", it.name).put("runs", it.runs).put("balls", it.balls)) }
        st.bowler?.let { o.put("bowler", JSONObject().put("name", it.name).put("figures", it.figuresText)) }
        return o
    }
}
