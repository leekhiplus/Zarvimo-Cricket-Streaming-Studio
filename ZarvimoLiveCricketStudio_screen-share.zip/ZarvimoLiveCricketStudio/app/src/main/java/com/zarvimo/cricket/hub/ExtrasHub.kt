package com.zarvimo.cricket.hub

import android.app.Application
import com.zarvimo.cricket.analytics.Zone
import com.zarvimo.cricket.analytics.ZoneEntry
import com.zarvimo.cricket.commentary.CKind
import com.zarvimo.cricket.commentary.CommentaryPlanner
import com.zarvimo.cricket.commentary.Lang
import com.zarvimo.cricket.data.MediaImporter
import com.zarvimo.cricket.graphics.AlertTone
import com.zarvimo.cricket.highlights.HKind
import com.zarvimo.cricket.highlights.HighlightLog
import com.zarvimo.cricket.highlights.Marker
import com.zarvimo.cricket.remote.*
import com.zarvimo.cricket.scoring.MatchSession
import com.zarvimo.cricket.sponsors.Appearance
import com.zarvimo.cricket.sponsors.RotatorState
import com.zarvimo.cricket.sponsors.Sponsor
import com.zarvimo.cricket.sponsors.SponsorRotator
import com.zarvimo.cricket.ui.AppViewModel
import com.zarvimo.cricket.ui.MatchUi
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CompletableFuture
import java.util.concurrent.TimeUnit

data class SavedMarker(val marker: Marker, val recordingFile: String?)
data class PairingRequest(val code: String, val name: String, val address: String, val decision: CompletableFuture<Boolean>)
data class RemoteRequest(val id: Long, val deviceName: String, val action: String)
data class ServerUi(val running: Boolean, val error: String?, val viewers: Int)
data class CommentarySettings(val enabled: Boolean = false, val urdu: Boolean = false, val routineEvery: Int = 2, val spoken: Boolean = true)

/**
 * Glue between the scoring engine / ViewModel and the new modules (highlights, smart commentary, sponsors, wagon-wheel zones,
 * local server for OBS + remote scoring). It never calculates scores: it only reacts to the ViewModel's validated state.
 */
class ExtrasHub(private val app: Application, private val vm: AppViewModel) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val dir = File(app.filesDir, "extras").apply { mkdirs() }
    private var matchId: String? = null

    // ------------------------------------------------------------------ highlights (event MARKING only)
    private val highlightLog = HighlightLog()
    private val markerFiles = HashMap<Long, String?>()
    private val _markers = MutableStateFlow<List<SavedMarker>>(emptyList())
    val markers: StateFlow<List<SavedMarker>> = _markers.asStateFlow()
    @Volatile private var recordingStartMs: Long? = null
    @Volatile private var recordingPath: String? = null
    val preBufferMs = MutableStateFlow(8_000L)
    val postBufferMs = MutableStateFlow(6_000L)

    // ------------------------------------------------------------------ wagon wheel zones (entered by the scorer)
    private val _zones = MutableStateFlow<List<ZoneEntry>>(emptyList())
    val zones: StateFlow<List<ZoneEntry>> = _zones.asStateFlow()

    fun setZone(eventId: Long, zone: Zone, leftHanded: Boolean) {
        _zones.value = _zones.value.filter { it.eventId != eventId } + ZoneEntry(eventId, zone, leftHanded); saveMatchExtras()
    }
    fun clearZone(eventId: Long) { _zones.value = _zones.value.filter { it.eventId != eventId }; saveMatchExtras() }

    // ------------------------------------------------------------------ smart commentary
    val planner = CommentaryPlanner(enabled = false)
    private val _commentary = MutableStateFlow(CommentarySettings())
    val commentary: StateFlow<CommentarySettings> = _commentary.asStateFlow()
    private val _commentaryLog = MutableStateFlow<List<String>>(emptyList())
    val commentaryLog: StateFlow<List<String>> = _commentaryLog.asStateFlow()
    private var speakingUntil = 0L
    private var speakingPriority = 0

    fun updateCommentary(block: (CommentarySettings) -> CommentarySettings) {
        val old = _commentary.value; val n = block(old); _commentary.value = n
        planner.enabled = n.enabled; planner.routineEvery = n.routineEvery.coerceIn(1, 12)
        if (n.urdu != old.urdu) planner.setLanguage(if (n.urdu) Lang.UR else Lang.EN)
    }
    fun setPaused(p: Boolean) { planner.paused = p }
    fun setTemplate(kind: CKind, text: String): String? =
        com.zarvimo.cricket.commentary.DefaultTemplates.validate(text) ?: run { planner.templates[kind] = text; null }
    fun resetTemplates() = planner.setLanguage(planner.lang)

    /** Operator-triggered line about the current real score (works even when automatic commentary is off). */
    fun speakNow() {
        val st = vm.sessionOrNull()?.currentState ?: return
        planner.manual(st)?.let { say(it.text, 3) }
    }

    private fun say(text: String, priority: Int) {
        val now = System.currentTimeMillis()
        if (!CommentaryPlanner.canInterrupt(priority, if (now < speakingUntil) speakingPriority else null)) return
        speakingUntil = now + text.length * 70L + 800; speakingPriority = priority
        _commentaryLog.value = (listOf(text) + _commentaryLog.value).take(20)
        if (_commentary.value.spoken) vm.engineForHub().speakCommentary(text, text, planner.lang == Lang.UR)
    }

    // ------------------------------------------------------------------ sponsors (shown through the existing banner / sponsor slot)
    private val _sponsors = MutableStateFlow<List<Sponsor>>(loadSponsors())
    val sponsors: StateFlow<List<Sponsor>> = _sponsors.asStateFlow()
    private var rotator: SponsorRotator? = null
    private var sponsorJob: Job? = null
    private val _sponsorNow = MutableStateFlow<Sponsor?>(null)
    val sponsorNow: StateFlow<Sponsor?> = _sponsorNow.asStateFlow()
    private val _sponsorState = MutableStateFlow(RotatorState.STOPPED)
    val sponsorState: StateFlow<RotatorState> = _sponsorState.asStateFlow()
    private val _exposure = MutableStateFlow<Map<String, Long>>(emptyMap())
    val exposure: StateFlow<Map<String, Long>> = _exposure.asStateFlow()
    private val _history = MutableStateFlow<List<Appearance>>(loadHistory())
    val history: StateFlow<List<Appearance>> = _history.asStateFlow()

    fun addSponsor(name: String, logoPath: String?, seconds: Int) {
        val n = name.trim().take(40); if (n.isEmpty()) return
        _sponsors.value = _sponsors.value + Sponsor("s" + System.currentTimeMillis(), n, logoPath, seconds.coerceIn(3, 60) * 1000L); saveSponsors()
    }
    fun removeSponsor(id: String) { _sponsors.value = _sponsors.value.filter { it.id != id }; saveSponsors() }
    fun toggleSponsor(id: String) { _sponsors.value = _sponsors.value.map { if (it.id == id) it.copy(enabled = !it.enabled) else it }; saveSponsors() }
    fun moveSponsor(id: String, delta: Int) {
        val l = _sponsors.value.toMutableList(); val i = l.indexOfFirst { it.id == id }; val j = i + delta
        if (i < 0 || j !in l.indices) return
        val x = l.removeAt(i); l.add(j, x); _sponsors.value = l; saveSponsors()
    }
    fun importLogo(uri: android.net.Uri): String? = MediaImporter.importImage(app, uri, "sponsor")

    fun sponsorStart() {
        val r = SponsorRotator(_sponsors.value)
        r.start(System.currentTimeMillis())
        if (r.state != RotatorState.RUNNING) { vm.reportMessage("Add at least one enabled sponsor first"); return }
        rotator = r; runTicker()
    }
    fun sponsorPause() { rotator?.pause(System.currentTimeMillis()); sync() }
    fun sponsorResume() { rotator?.resume(System.currentTimeMillis()); sync() }
    fun sponsorStop() {
        rotator?.stop(System.currentTimeMillis()); sync(); persistHistory(); sponsorJob?.cancel()
        _sponsorNow.value = null
        scope.launch(Dispatchers.IO) { vm.engineForHub().broadcast.assets.sponsor = MediaImporter.load(vm.graphics.value.sponsorUri, 512) }
    }

    private fun runTicker() {
        sponsorJob?.cancel()
        sponsorJob = scope.launch {
            var shown: String? = null
            while (isActive) {
                val r = rotator ?: break
                val cur = r.tick(System.currentTimeMillis())
                if (cur?.id != shown && cur != null) {
                    shown = cur.id
                    // do not cover a DRS / break banner that the operator put on air
                    if (vm.alertOnAir.value == null) withContext(Dispatchers.Main) { vm.showAlertText(cur.name, "SPONSOR", AlertTone.GREY) }
                    // an enabled sponsor slot in the graphics settings also rotates the logo
                    if (cur.logoPath != null && vm.graphics.value.showSponsor) vm.engineForHub().broadcast.assets.sponsor = MediaImporter.load(cur.logoPath, 512)
                }
                _sponsorNow.value = cur; sync()
                delay(500)
            }
        }
    }
    private fun sync() {
        val r = rotator ?: return
        _sponsorState.value = r.state; _exposure.value = r.exposureMs(System.currentTimeMillis()); _history.value = r.history.toList()
    }

    private fun loadSponsors(): List<Sponsor> = try {
        val a = JSONArray(File(dir, "sponsors.json").readText())
        (0 until a.length()).map { val o = a.getJSONObject(it); Sponsor(o.getString("id"), o.getString("name"), o.optString("logo").ifEmpty { null }, o.optLong("ms", 8000), o.optBoolean("on", true)) }
    } catch (_: Exception) { emptyList() }
    private fun saveSponsors() = scope.launch(Dispatchers.IO) {
        val a = JSONArray(); _sponsors.value.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("logo", it.logoPath ?: "").put("ms", it.durationMs).put("on", it.enabled)) }
        File(dir, "sponsors.json").writeText(a.toString())
    }
    private fun loadHistory(): List<Appearance> = try {
        val a = JSONArray(File(dir, "sponsor_history.json").readText())
        (0 until a.length()).map { val o = a.getJSONObject(it); Appearance(o.getString("id"), o.getLong("s"), if (o.has("e")) o.getLong("e") else null) }
    } catch (_: Exception) { emptyList() }
    private fun persistHistory() = scope.launch(Dispatchers.IO) {
        val all = (_history.value).takeLast(2000)
        val a = JSONArray(); all.forEach { a.put(JSONObject().put("id", it.sponsorId).put("s", it.startMs).also { o -> it.endMs?.let { e -> o.put("e", e) } }) }
        File(dir, "sponsor_history.json").writeText(a.toString())
    }

    // ------------------------------------------------------------------ local server: OBS overlay + remote scoring
    private val gate = RemoteGate({ System.currentTimeMillis() })
    private var server: LocalServer? = null
    @Volatile private var lastJson = JSONObject().put("live", false).put("hidden", true).toString()
    @Volatile private var lastManualJson = lastJson
    @Volatile private var feedJson: String? = null

    /** While a website link drives the score, browsers (OBS overlay / remote page) get ITS data, or nothing; null = back to the manual match. */
    fun setFeedOverlay(json: String?) {
        feedJson = json
        val out = json ?: lastManualJson
        lastJson = out
        server?.broadcast(out)
    }
    private val _server = MutableStateFlow(ServerUi(false, null, 0))
    val serverUi: StateFlow<ServerUi> = _server.asStateFlow()
    val pairing = MutableStateFlow<PairingRequest?>(null)
    private val _pairingCode = MutableStateFlow<String?>(null)
    val pairingCode: StateFlow<String?> = _pairingCode.asStateFlow()
    private val _devices = MutableStateFlow<List<PairedDevice>>(emptyList())
    val devices: StateFlow<List<PairedDevice>> = _devices.asStateFlow()
    private val _requests = MutableStateFlow<List<RemoteRequest>>(emptyList())
    val requests: StateFlow<List<RemoteRequest>> = _requests.asStateFlow()
    private val _serverLog = MutableStateFlow<List<String>>(emptyList())
    val serverLog: StateFlow<List<String>> = _serverLog.asStateFlow()
    private var reqId = 0L
    val port = 8765

    private val serverHost = object : ServerHost {
        override fun stateJson() = lastJson
        override fun logoPng(which: String): ByteArray? {
            val m = vm.match.value
            val a = which == "a"
            val bmp = MediaImporter.load(if (a) m.teamALogoPath else m.teamBLogoPath, 384) ?: com.zarvimo.cricket.flags.FlagBitmap.forTeam(if (a) m.setup.teamA else m.setup.teamB) ?: return null
            return java.io.ByteArrayOutputStream().also { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
        }
        override fun requestPairing(code: String, deviceName: String, remoteAddr: String): String? {
            if (!synchronized(gate) { gate.codeValid(code) }) return null
            val fut = CompletableFuture<Boolean>()
            pairing.value = PairingRequest(code, deviceName, remoteAddr, fut)
            val ok = try { fut.get(60, TimeUnit.SECONDS) } catch (_: Exception) { false }
            pairing.value = null
            val token = synchronized(gate) { gate.pair(code, deviceName, ok) }
            if (token != null) { _devices.value = synchronized(gate) { gate.connected() }; _pairingCode.value = null; log("Paired: $deviceName") }
            return token
        }
        override fun handleCommand(c: RemoteCommand): GateResult = synchronized(gate) { gate.check(c) }
        override fun applyOnMain(c: RemoteCommand): String? = runBlocking(Dispatchers.Main) {
            val a = RemoteAction.valueOf(c.action)
            if (a.needsHostApproval) {
                val name = synchronized(gate) { gate.deviceFor(c.token)?.name } ?: "Remote"
                _requests.value = _requests.value + RemoteRequest(++reqId, name, a.name); log("Request from $name: ${a.name}"); null
            } else vm.applyRemote(c)
        }
    }

    fun serverStart() {
        if (server?.isRunning == true) return
        val s = LocalServer(port, serverHost) { log(it) }
        val err = s.start()
        server = if (err == null) s else null
        _server.value = ServerUi(err == null, err, 0)
        if (err == null) { log("Server started on port $port"); scope.launch { while (isActive && server?.isRunning == true) { _server.value = ServerUi(true, null, server?.clients ?: 0); delay(2000) } } }
    }
    fun serverStop() { server?.stop(); server = null; _server.value = ServerUi(false, null, 0); log("Server stopped") }
    fun newPairingCode() { _pairingCode.value = synchronized(gate) { gate.newPairingCode() } }
    fun answerPairing(ok: Boolean) { pairing.value?.decision?.complete(ok) }
    fun disconnect(deviceId: String) { synchronized(gate) { gate.revoke(deviceId); _devices.value = gate.connected() }; log("Disconnected $deviceId") }
    fun resolveRequest(id: Long, approve: Boolean) {
        val r = _requests.value.firstOrNull { it.id == id } ?: return
        _requests.value = _requests.value.filter { it.id != id }
        if (approve && r.action == "UNDO_REQUEST") vm.undo()   // CORRECTION_REQUEST is resolved manually by the host
    }
    private fun log(s: String) { _serverLog.value = (listOf(s) + _serverLog.value).take(30) }

    // ------------------------------------------------------------------ hooks called by the ViewModel
    init {
        scope.launch { vm.engineForHub().recording.collect { on ->
            if (on) { recordingStartMs = System.currentTimeMillis(); recordingPath = vm.engineForHub().currentRecordingPath() } else { recordingStartMs = null }
        } }
    }

    /** A validated ball/event was just added to the session. */
    fun onBall(s: MatchSession, id: Long) {
        val st = s.currentState ?: return
        val rec = st.allBalls.lastOrNull { it.eventId == id }
        if (rec != null) highlightLog.add(rec, System.currentTimeMillis(), recordingStartMs)?.let { m ->
            markerFiles[m.eventId] = if (m.recordingOffsetMs != null) recordingPath else null
            refreshMarkers(); saveMatchExtras()
        }
        val line = planner.next(st) ?: return
        // the existing four/six/wicket voice (AutoShowSettings) already covers these: never speak the same event twice
        if (vm.autoShow.value.voiceEnabled && line.kind in setOf(CKind.WICKET, CKind.SIX, CKind.FOUR)) return
        say(line.text, line.priority)
    }

    /** Every time the ViewModel publishes a new state (also after undo / edit / load). */
    fun onPublished(m: MatchUi, s: MatchSession?) {
        if (matchId != m.matchId) { matchId = m.matchId; loadMatchExtras(m.matchId) }
        val valid = s?.innings?.flatMap { d -> d.events.map { it.id } }?.toSet() ?: emptySet()
        var changed = false
        highlightLog.markers.filter { it.eventId !in valid }.forEach { highlightLog.remove(it.eventId); markerFiles.remove(it.eventId); changed = true }
        if (changed) { refreshMarkers(); saveMatchExtras() }
        val z = _zones.value.filter { it.eventId in valid }; if (z.size != _zones.value.size) { _zones.value = z; saveMatchExtras() }
        val j = OverlayJson.build(m.setup, m.visuals, m.state, m.finalResult, m.teamALogoPath?.let { File(it).exists() } == true || com.zarvimo.cricket.flags.FlagBitmap.forTeam(m.setup.teamA) != null, m.teamBLogoPath?.let { File(it).exists() } == true || com.zarvimo.cricket.flags.FlagBitmap.forTeam(m.setup.teamB) != null).toString()
        lastManualJson = j
        if (feedJson == null) { lastJson = j; server?.broadcast(j) }
    }

    private fun refreshMarkers() { _markers.value = highlightLog.markers.map { SavedMarker(it, markerFiles[it.eventId]) } }

    private fun saveMatchExtras() { val id = matchId ?: return; scope.launch(Dispatchers.IO) { try {
        val ms = JSONArray(); highlightLog.markers.forEach { ms.put(JSONObject().put("id", it.eventId).put("k", it.kind.name).put("l", it.label).put("w", it.wallClockMs).put("o", it.recordingOffsetMs ?: JSONObject.NULL).put("f", markerFiles[it.eventId] ?: JSONObject.NULL)) }
        val zs = JSONArray(); _zones.value.forEach { zs.put(JSONObject().put("id", it.eventId).put("z", it.zone.name).put("lh", it.leftHanded)) }
        val f = File(dir, "match_" + id.filter { c -> c.isLetterOrDigit() || c == '-' } + ".json"); val tmp = File(f.path + ".tmp")
        tmp.writeText(JSONObject().put("markers", ms).put("zones", zs).toString()); if (!tmp.renameTo(f)) { f.writeText(tmp.readText()); tmp.delete() }
    } catch (_: Exception) { } } }

    private fun loadMatchExtras(id: String) {
        _zones.value = emptyList(); markerFiles.clear(); highlightLog.markers.forEach { highlightLog.remove(it.eventId) }
        try {
            val o = JSONObject(File(dir, "match_" + id.filter { c -> c.isLetterOrDigit() || c == '-' } + ".json").readText())
            o.optJSONArray("markers")?.let { a -> for (i in 0 until a.length()) { val m = a.getJSONObject(i)
                highlightLog.restore(Marker(m.getLong("id"), HKind.valueOf(m.getString("k")), m.getString("l"), m.getLong("w"), if (m.isNull("o")) null else m.getLong("o")))
                markerFiles[m.getLong("id")] = if (m.isNull("f")) null else m.getString("f") } }
            o.optJSONArray("zones")?.let { a -> _zones.value = (0 until a.length()).mapNotNull { i -> val z = a.getJSONObject(i); try { ZoneEntry(z.getLong("id"), Zone.valueOf(z.getString("z")), z.optBoolean("lh")) } catch (_: Exception) { null } } }
        } catch (_: Exception) { }
        refreshMarkers()
    }
}
