package com.zarvimo.cricket.stream

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLUtils
import android.opengl.Matrix
import android.os.Handler
import android.os.SystemClock
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Screen mode of the compositor (same idea as [CameraGlCompositor], but the picture is the phone screen):
 *
 *   ScreenCaptureSession (VirtualDisplay) -> SurfaceTexture (OES texture) -> OpenGL draw, fitted into the output
 *   scoreboard overlay (BroadcastRenderer into a transparent Bitmap) -> texture -> blended on top
 *   -> EGL window surface = the Surface RootEncoder gave us (encoder + on-screen preview).
 *
 * Everything runs on the frame-pump thread. A phone screen only produces a new picture when something on it changes, so the
 * last picture is simply drawn again on every tick (the scoreboard keeps animating regardless).
 */
class ScreenGlCompositor(
    private val context: Context,
    private val handler: Handler,
    private val onProblem: (String) -> Unit
) {
    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE

    private var progOes = 0
    private var prog2d = 0
    private var scrTex = 0
    private var ovTex = 0
    private var st: SurfaceTexture? = null
    private var surface: Surface? = null
    private var session: ScreenCaptureSession? = null
    private val frameReady = AtomicBoolean(false)
    private var hasFrame = false

    private val texMatrix = FloatArray(16)
    private val mvp = FloatArray(16)
    private val identity = FloatArray(16)
    private val flipY = FloatArray(16)

    private var overlayBmp: Bitmap? = null
    private var overlayCanvas: Canvas? = null
    private var overlayUploaded = false

    private var outW = 0
    private var outH = 0
    private var lastCheck = 0L

    /** false = the whole phone screen is visible (black bars where the shapes differ); true = fills the frame (edges cropped). */
    @Volatile var fill = false
    @Volatile private var closed = false

    private val quad: FloatBuffer = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(-1f, -1f, 0f, 0f, 1f, -1f, 1f, 0f, -1f, 1f, 0f, 1f, 1f, 1f, 1f, 1f))
        position(0)
    }

    /** Throws if OpenGL cannot be set up. */
    fun start(outputSurface: Surface, width: Int, height: Int, captureSession: ScreenCaptureSession) {
        outW = width
        outH = height
        session = captureSession
        initEgl(outputSurface)
        progOes = buildProgram(VERTEX, FRAGMENT_OES)
        prog2d = buildProgram(VERTEX, FRAGMENT_2D)

        val tex = IntArray(2)
        GLES20.glGenTextures(2, tex, 0)
        scrTex = tex[0]
        ovTex = tex[1]
        configureTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, scrTex)
        configureTexture(GLES20.GL_TEXTURE_2D, ovTex)

        val t = SurfaceTexture(scrTex)
        t.setDefaultBufferSize(captureSession.width, captureSession.height)
        t.setOnFrameAvailableListener({ frameReady.set(true) }, handler)
        st = t
        val s = Surface(t)
        surface = s

        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        overlayBmp = bmp
        overlayCanvas = Canvas(bmp)

        Matrix.setIdentityM(identity, 0)
        Matrix.setIdentityM(flipY, 0)
        flipY[5] = -1f
        flipY[13] = 1f

        captureSession.setTarget(s) // the screen picture starts flowing into our texture
    }

    fun drawFrame(renderOverlay: (Canvas) -> Unit) {
        if (closed) return
        val sess = session
        val tex = st
        val now = SystemClock.uptimeMillis()
        if (sess != null && tex != null && now - lastCheck > 500) {
            lastCheck = now
            if (sess.followOrientation()) tex.setDefaultBufferSize(sess.width, sess.height)
        }
        if (frameReady.getAndSet(false)) {
            try {
                tex?.updateTexImage()
                tex?.getTransformMatrix(texMatrix)
                hasFrame = true
            } catch (e: Exception) {
                // a bad frame is skipped
            }
        }

        GLES20.glViewport(0, 0, outW, outH)
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

        if (hasFrame && sess != null) {
            buildMvp(sess.width, sess.height)
            drawQuad(progOes, GLES11Ext.GL_TEXTURE_EXTERNAL_OES, scrTex, mvp, texMatrix)
        }

        val bmp = overlayBmp
        val cv = overlayCanvas
        if (bmp != null && cv != null) {
            bmp.eraseColor(Color.TRANSPARENT)
            renderOverlay(cv)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ovTex)
            if (!overlayUploaded) {
                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
                overlayUploaded = true
            } else {
                GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, bmp)
            }
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA) // bitmap pixels are premultiplied
            drawQuad(prog2d, GLES20.GL_TEXTURE_2D, ovTex, identity, flipY)
            GLES20.glDisable(GLES20.GL_BLEND)
        }
        EGL14.eglSwapBuffers(eglDisplay, eglSurface)
    }

    /** Scales the screen picture into the output: whole picture visible (fit) or frame filled (crop). */
    private fun buildMvp(srcW: Int, srcH: Int) {
        val src = srcW.toFloat() / srcH.coerceAtLeast(1)
        val out = outW.toFloat() / outH.coerceAtLeast(1)
        var sx = 1f
        var sy = 1f
        val srcWider = src > out
        if (fill) {
            if (srcWider) sx = src / out else sy = out / src
        } else {
            if (srcWider) sy = out / src else sx = src / out
        }
        Matrix.setIdentityM(mvp, 0)
        Matrix.scaleM(mvp, 0, sx, sy, 1f)
    }

    private fun drawQuad(prog: Int, target: Int, tex: Int, mvpM: FloatArray, texM: FloatArray) {
        GLES20.glUseProgram(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(target, tex)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uMvp"), 1, false, mvpM, 0)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uTex"), 1, false, texM, 0)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "sTex"), 0)
        val pos = GLES20.glGetAttribLocation(prog, "aPos")
        val tc = GLES20.glGetAttribLocation(prog, "aTc")
        quad.position(0)
        GLES20.glEnableVertexAttribArray(pos)
        GLES20.glVertexAttribPointer(pos, 2, GLES20.GL_FLOAT, false, 16, quad)
        quad.position(2)
        GLES20.glEnableVertexAttribArray(tc)
        GLES20.glVertexAttribPointer(tc, 2, GLES20.GL_FLOAT, false, 16, quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(pos)
        GLES20.glDisableVertexAttribArray(tc)
    }

    // ------------------------------------------------------------------------------------------ OpenGL set-up

    private fun initEgl(outputSurface: Surface) {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (eglDisplay == EGL14.EGL_NO_DISPLAY) throw IllegalStateException("EGL: no display")
        val version = IntArray(2)
        if (!EGL14.eglInitialize(eglDisplay, version, 0, version, 1)) throw IllegalStateException("EGL: initialize failed")
        val attribs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGLExt.EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        if (!EGL14.eglChooseConfig(eglDisplay, attribs, 0, configs, 0, 1, num, 0) || num[0] <= 0 || configs[0] == null) {
            throw IllegalStateException("EGL: no suitable config")
        }
        val config = configs[0]
        eglContext = EGL14.eglCreateContext(eglDisplay, config, EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        if (eglContext == EGL14.EGL_NO_CONTEXT) throw IllegalStateException("EGL: context failed")
        eglSurface = EGL14.eglCreateWindowSurface(eglDisplay, config, outputSurface, intArrayOf(EGL14.EGL_NONE), 0)
        if (eglSurface == EGL14.EGL_NO_SURFACE) throw IllegalStateException("EGL: window surface failed")
        if (!EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)) throw IllegalStateException("EGL: makeCurrent failed")
    }

    private fun configureTexture(target: Int, tex: Int) {
        GLES20.glBindTexture(target, tex)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    }

    private fun buildProgram(vertex: String, fragment: String): Int {
        val vs = compile(GLES20.GL_VERTEX_SHADER, vertex)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, fragment)
        val prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        val status = IntArray(1)
        GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, status, 0)
        if (status[0] == 0) {
            GLES20.glDeleteProgram(prog)
            throw IllegalStateException("GL: program link failed")
        }
        return prog
    }

    private fun compile(type: Int, source: String): Int {
        val sh = GLES20.glCreateShader(type)
        GLES20.glShaderSource(sh, source)
        GLES20.glCompileShader(sh)
        val status = IntArray(1)
        GLES20.glGetShaderiv(sh, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            GLES20.glDeleteShader(sh)
            throw IllegalStateException("GL: shader compile failed")
        }
        return sh
    }

    // ------------------------------------------------------------------------------------------ teardown

    fun release() {
        closed = true
        // stop the screen picture flowing into a surface that is about to disappear (the capture itself stays alive)
        try {
            session?.setTarget(null)
        } catch (_: Exception) {
        }
        session = null
        try {
            surface?.release()
        } catch (_: Exception) {
        }
        surface = null
        try {
            st?.release()
        } catch (_: Exception) {
        }
        st = null
        if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
            try {
                EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(eglDisplay, eglSurface)
                if (eglContext != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(eglDisplay, eglContext)
                EGL14.eglTerminate(eglDisplay)
            } catch (_: Exception) {
            }
        }
        eglDisplay = EGL14.EGL_NO_DISPLAY
        eglContext = EGL14.EGL_NO_CONTEXT
        eglSurface = EGL14.EGL_NO_SURFACE
        overlayBmp?.recycle()
        overlayBmp = null
        overlayCanvas = null
    }

    private companion object {
        const val VERTEX = """
            uniform mat4 uMvp;
            uniform mat4 uTex;
            attribute vec4 aPos;
            attribute vec4 aTc;
            varying vec2 vTc;
            void main() {
                gl_Position = uMvp * aPos;
                vTc = (uTex * aTc).xy;
            }
        """
        const val FRAGMENT_OES = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 vTc;
            uniform samplerExternalOES sTex;
            void main() {
                gl_FragColor = texture2D(sTex, vTc);
            }
        """
        const val FRAGMENT_2D = """
            precision mediump float;
            varying vec2 vTc;
            uniform sampler2D sTex;
            void main() {
                gl_FragColor = texture2D(sTex, vTc);
            }
        """
    }
}
