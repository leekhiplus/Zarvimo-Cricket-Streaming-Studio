package com.zarvimo.cricket.stream

import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Display
import android.view.Surface
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Size of the picture taken from the phone screen: the longest side is limited to [maxLong] pixels (a phone screen is
 * far larger than the stream), both sides are even numbers, and the shape follows the screen's current orientation.
 */
internal fun captureSize(realW: Int, realH: Int, landscape: Boolean, maxLong: Int = 1280): Pair<Int, Int> {
    val long = max(realW, realH).coerceAtLeast(2)
    val short = min(realW, realH).coerceAtLeast(2)
    val scale = if (long > maxLong) maxLong.toFloat() / long else 1f
    fun even(v: Int): Int = max(2, v - v % 2)
    val l = even((long * scale).roundToInt())
    val s = even((short * scale).roundToInt())
    return if (landscape) Pair(l, s) else Pair(s, l)
}

/**
 * One screen-sharing permission ("MediaProjection") and the VirtualDisplay made from it.
 *
 * Android 14 and newer allow a VirtualDisplay to be created ONLY ONCE per permission, so the display is created here, once,
 * and the compositor merely points it at its own surface with [setTarget] (and away again with null). That way the picture
 * pipeline can be rebuilt (preview restart, resolution change...) without asking the user again.
 *
 * Must be created after the foreground service of type "mediaProjection" is running.
 */
class ScreenCaptureSession(
    private val context: Context,
    private val projection: MediaProjection,
    private val onStopped: () -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var display: VirtualDisplay? = null
    private var dpi = 320

    @Volatile var width = 1280
        private set
    @Volatile var height = 720
        private set
    @Volatile private var stopped = false

    private val callback = object : MediaProjection.Callback() {
        override fun onStop() {
            // the user ended sharing from the system notification / status-bar chip
            if (stopped) return
            stopped = true
            releaseDisplay()
            onStopped()
        }
    }

    private fun realMetrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        try {
            val d = (context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
            @Suppress("DEPRECATION")
            d?.getRealMetrics(dm)
        } catch (_: Exception) {
        }
        if (dm.widthPixels <= 0 || dm.heightPixels <= 0) {
            val r = context.resources.displayMetrics
            dm.widthPixels = r.widthPixels
            dm.heightPixels = r.heightPixels
            dm.densityDpi = r.densityDpi
        }
        return dm
    }

    init {
        val dm = realMetrics()
        dpi = dm.densityDpi.coerceAtLeast(120)
        val size = captureSize(dm.widthPixels, dm.heightPixels, dm.widthPixels >= dm.heightPixels)
        width = size.first
        height = size.second
        // Android 14+: the callback must be registered BEFORE the display is created.
        projection.registerCallback(callback, main)
        display = projection.createVirtualDisplay(
            "CricketScreen", width, height, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, null, null, main
        )
    }

    /** Where the screen picture goes (null = nowhere, e.g. while the compositor is being rebuilt). */
    fun setTarget(surface: Surface?) {
        try {
            display?.setSurface(surface)
        } catch (_: Exception) {
        }
    }

    /** Follows the phone's rotation. Returns true when the capture size changed (the caller must resize its buffer too). */
    fun followOrientation(): Boolean {
        val d = display ?: return false
        val dm = realMetrics()
        val size = captureSize(dm.widthPixels, dm.heightPixels, dm.widthPixels >= dm.heightPixels)
        if (size.first == width && size.second == height) return false
        return try {
            d.resize(size.first, size.second, dpi)
            width = size.first
            height = size.second
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun releaseDisplay() {
        try {
            display?.release()
        } catch (_: Exception) {
        }
        display = null
    }

    /** Ends screen sharing completely. */
    fun stop() {
        stopped = true
        try {
            projection.unregisterCallback(callback)
        } catch (_: Exception) {
        }
        releaseDisplay()
        try {
            projection.stop()
        } catch (_: Exception) {
        }
    }
}
