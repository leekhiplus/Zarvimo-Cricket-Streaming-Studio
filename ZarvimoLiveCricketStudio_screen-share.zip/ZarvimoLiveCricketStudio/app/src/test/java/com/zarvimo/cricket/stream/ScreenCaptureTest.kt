package com.zarvimo.cricket.stream

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ScreenCaptureTest {

    @Test fun captureSize_limitsTheLongSide_keepsTheShape() {
        assertEquals(Pair(1280, 576), captureSize(1080, 2400, true))
        assertEquals(Pair(576, 1280), captureSize(1080, 2400, false))
        assertEquals(Pair(1280, 720), captureSize(1920, 1080, true))
        assertEquals(Pair(800, 480), captureSize(800, 480, true))
    }

    @Test fun captureSize_isAlwaysEven() {
        val (w, h) = captureSize(1081, 2401, true)
        assertTrue(w % 2 == 0 && h % 2 == 0)
        val (w2, h2) = captureSize(721, 1281, false)
        assertTrue(w2 % 2 == 0 && h2 % 2 == 0)
    }

    @Test fun screenMode_isNotACameraMode() {
        assertTrue(VideoSourceMode.SCREEN.isScreen)
        assertFalse(VideoSourceMode.SCREEN.isCamera)
        assertFalse(VideoSourceMode.CAMERA_BACK.isScreen)
        assertFalse(VideoSourceMode.BACKGROUND.isScreen)
    }
}
