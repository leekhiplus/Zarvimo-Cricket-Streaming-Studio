# PROGRESS / HANDOFF

Project: Zarvimo Live Cricket Streaming Studio (native Android, Kotlin, Compose, RootEncoder 2.8.1).
Working dir (sandbox): /home/claude/ZarvimoLiveCricketStudio — deliverable ZIP: /mnt/user-data/outputs/ZarvimoLiveCricketStudio.zip

## Sandbox facts
- JDK 21 only. NO Gradle / Kotlin compiler / Android SDK / network for bash => nothing compiled, no test executed.
- web_search worked (used to verify RootEncoder coordinates/licence: Apache-2.0, RTMP+RTMPS, H264, AAC, JitPack).
- Static checks done instead: bracket/template balance on all 25 .kt files, import-target existence, duplicate test names, resource refs.

## STATUS: ALL planned files written (v0.1.0, UNCOMPILED)
scoring/ (Models, ScoreEngine, MatchSession) · graphics/ (GraphicsModel, BroadcastRenderer) ·
stream/ (StreamModel, BroadcastState, BroadcastVideoSource, StreamEngine, StreamService) ·
data/ (Json, LocalStore, SecretStore, MediaImporter) · ui/ (AppViewModel, Common, ScoringScreen, ScreensMatch,
ScreensBroadcast) · MainActivity, ZarvimoApp · manifest/resources · workflow · README · THIRD_PARTY_NOTICES · 105 unit tests.

## Next steps (when continuing)
1. If the user can supply build output (Actions log / Android Studio errors): fix compile errors. Highest-risk files:
   stream/BroadcastVideoSource.kt and stream/StreamEngine.kt (RootEncoder 2.8.1 API signatures: VideoSource members,
   GenericStream ctor/prepareVideo/prepareAudio/startPreview/getGlInterface/getStreamClient().reTry, ConnectChecker,
   MicrophoneSource.mute/unMute). Then Compose files (ScoringScreen/ScreensBroadcast).
2. Failing unit tests: they were only hand-traced. Fix engine or test, whichever is wrong.
3. Add gradle-wrapper.jar + gradlew (cannot be created offline).
4. Optional: audio level meter, background music, release signing via GitHub Secrets, LICENSE choice by owner.
5. Real-device streaming test per README section 12 (cannot be done in sandbox).

## CI log #1 (user-supplied logs_108001410334.zip)
- Failed at step 4 "Set up Android SDK" (android-actions/setup-android@v3): `Failed to find package 'tools'` (default
  packages "tools platform-tools"). Gradle never ran. FIX: step removed, preinstalled runner SDK used + licence acceptance;
  setup-java bumped to v5. Next CI run will be the first one to reach Gradle => expect real compile errors; send the log.

## CI log #2 (logs_108003712139.zip)
- setup-android removal worked (licence step + Gradle 8.11.1 provisioned). New failure in "Run unit tests":
  "Directory .../Zarvimo-Cricket-Streaming-Studio does not contain a Gradle build" (repo leekhiplus/Zarvimo-Cricket-Streaming-Studio,
  commit cb139be). Cause: project files not at repo root (likely nested ZIP folder, or only workflow/README uploaded).
  FIX: workflow now has a "Locate Gradle project" step (find settings.gradle[.kts] maxdepth 3 -> working-directory; prints repo tree
  and fails clearly if none). Gradle still has NOT compiled anything yet.

## Update: camera source, background music, monitoring, templates, pinned preview
* Video source selector (back camera / front camera / background picture), live switching, automatic fallback with a message.
* Background music playlist (MediaCodec decode, loop) mixed with the commentary microphone; separate stream volumes; monitor switches
  (music, microphone-in-headphones) and a monitor volume; microphone level bar.
* 6 new scoreboard templates (9 total). Title tag moves below a scoreboard parked at the top.
* Preview is pinned (portrait: top, landscape: left); options scroll.
* Status: written without being able to compile or run here; verify with the GitHub Actions build and on a real device
  (camera orientation, music/microphone mix, headphone monitoring).

## Update: on-air graphics, auto animations, voice commentary, recording, adaptive bitrate
* Panels: scorecard, striker/non-striker/bowler cards, partnership, run-rate graph (renderer + PanelBuilder, auto-hide).
* Pre-match card (toss + start time) and toss-based batting team preselection.
* FOUR / SIX / WICKET burst animation; optional TTS commentary mixed into the stream (VoiceBuffer -> MixerEffect, music ducking).
* Adaptive bitrate (uses StreamClient.hasCongestion / dropped frames, 1 s service tick) and local recording (StreamBase.startRecord).
* DLS revised-target calculator (arithmetic only). New unit tests: DlsAndTossTest, CommentaryAndWavTest.
* NOT done (deliberately): streaming to two platforms at once (use a restreaming service), retired batter / super over / substitute in the scoring engine.
* Status: written without being able to compile or run here; verify with the GitHub Actions build and on a real device.

## Update: Studio tabs, camera bubble, YouTube viewers + chat
* StudioScreen (tabs Source / On-air / Audio / Chat / Status) replaces the separate Preview and Monitor screens; Home buttons regrouped.
* Camera bubble (GL compositor: background texture + camera inside a circle + overlay), live on/off, front/back, size, position.
* YouTube: device-code OAuth (user's own Cloud client), liveBroadcasts/videos/liveChat APIs, viewers every 30 s, chat every >=10 s, replies, comment on air.
* Unit tests: YouTubeJsonTest, wrapTwoLines, BubbleConfig clamp. Status: written without compiling; verify with the GitHub Actions build.

## Update: commentary voice clean-up (noise cancelling + studio voice)
* VoiceProcessor (pure Kotlin): rumble high-pass -> spectral noise reducer (512-pt STFT, noise floor tracker frozen during speech, smoothed Wiener gain)
  -> EQ -> compressor -> soft limiter. Runs inside MixerEffect on the microphone buffers (before music/voice mixing); the monitor hears the cleaned voice.
* Algorithm prototyped in numpy before porting: white noise -8 / -14 / -21 dB (light/medium/strong), speech tones kept at 96-98 %.
* Unit tests: VoiceProcessorTest. Status: not compiled or run on a device here; tune strength by ear on a real handsfree microphone.

## Update: join a match in progress
* InningsSetup.seed (InningsSeed): runs, wickets, balls, extras, batters (striker, non-striker, dismissed), bowlers (current + others), per-over runs,
  partnership. Validated by ScoreEngine.seedProblem; applied by InningsBuilder.applySeed; persisted in Json; SeedParser turns the phone form into a seed.
* Tests: SeededInningsTest, SeedJsonTest. Status: not compiled here; verify with the GitHub Actions build.

## Update: pro icons, preview-freeze fix, 10 new templates (UNCOMPILED, same as above)
* Icons: ui/Icons.kt (own line-icon set, no extra library). All emoji/text symbols removed; bottom nav, Studio tabs, Home tiles,
  buttons (BigButton(icon=...)), section headers (SectionCard(icon=...)), WarnLine. New Common.kt: HomeTile, Line/Muted colours.
* Preview freeze: (1) StreamEngine.detachPreview(view) only acts if that view is still the current one (new screen's surface is
  created BEFORE the old one is destroyed, the old "destroyed" used to stop the new preview); (2) reconfigurePreview skips when
  profile/fps unchanged (was restarting on every setting change); (3) BroadcastVideoSource tick always re-posts (an exception used
  to kill the pump for good) + heartbeat; (4) 2 s watchdog in StreamEngine kicks / rebuilds a frozen preview (idle only).
* Templates: 10 new strips (NEON_ARENA ... CRIMSON_GOLD, total 19) via BroadcastRenderer.drawStrip + STRIPS styles;
  OverlayData got targetValue / requiredRuns / ballsLeft for the "REQUIRED: x RUNS IN y BALLS" line.
* Verify first: gradle build (Icons.kt uses compose PathParser; FilterChipDefaults.filterChipBorder signature), then look at the
  10 strips on a device (text positions were laid out by hand, never rendered).

## Update: Playing XI (squads)
* MatchSetup.squadA/squadB (batting order, max 15) + squadOf(team); JSON keys squadA/squadB (old saves load with empty lists).
* Setup screen: "Playing XI" card (SquadEditor: add one, paste list, reorder, remove). Editable any time (also after the match started).
* Used by: innings start (tap names for striker/non-striker/bowler), new-batter and bowler prompts, wicket dialog (fielder / incoming).
* On air: PanelKind.PLAYING_XI (two numbered columns in team colours; works before the first ball). Tests: SquadTest.

## Update: super over, DLS, crowd sounds, DRS/break banners, full-screen cards (UNCOMPILED)
* Super over: innings are pairs (0-1 match, 2-3 first super over, 4-5 second...). MatchSession.configFor() = 1 over / 2 wickets for
  index >= 2; isTied / canStartSuperOver / nextSuperOverBattingTeam / finalResult(); up to 5 super overs. UI: start button on the
  scoring screen, innings-start card, overlay title/banners. Tests: SuperOverTest.
* DLS: DlsTable (paste official table; built-in smooth ESTIMATE is labelled), DlsCalc (resources with stoppages, target, par now),
  per-innings reduced overs (InningsData.oversOverride, saved in JSON), DlsDialog (More tools > DLS calculator), applyDls().
  The OFFICIAL tables are not in the app; without a pasted table every result is an estimate. Tests: DlsEngineTest.
* Crowd sounds: stream/CrowdSynth.kt (synthesised cheer / roar / applause / oh no / whistle / horn / drum roll / atmosphere loop),
  SfxPlayer mixed in MixerEffect; pads + atmosphere + auto reactions (CrowdSoundsCard). Not live = local test play only.
* Banners: graphics/Alerts.kt + OverlayData.alert + drawAlert; AnnouncementsCard (DRS review per team, out / not out / umpire's call,
  reviews left, drinks / timeout / rain / bad light / lunch / tea / innings break / play resumes, own text).
* Full-screen cards: PanelKind TOSS_CARD, MATCH_SUMMARY, RESULT_CARD, MAN_OF_MATCH (+ man of the match fields in MatchSetup and a
  Setup card with suggestions). Tests: CardsAndAlertsTest.

## Update: audio on air + music separated from commentary (UNCOMPILED)
* Bug: muting the mic (or an audio-focus loss) muted the microphone NATIVELY whenever no music was playing; the mixer (which carries
  music, spoken commentary and crowd sounds) is a hook on the microphone buffers, so everything went silent. Now muting only silences
  the mic inside the mixer (StreamEngine.applyMute); native mute is a safety net only when the mixer is dead for > 3 s.
* Spoken commentary goes into the stream whenever live (was: only while the hook had processed a buffer in the last 1.5 s).
* audioHealthLocked() each second while live: re-attaches the mixer if it stopped, AudioUiState.chainHooked drives a warning.
* WavDecoder accepts WAVE_FORMAT_EXTENSIBLE and 32-bit float; a decode failure now shows a notice.
* New settings: musicOnAir (send music to viewers), duckMusic + duckLevel (music lowers while the mic / spoken commentary speaks).
* UI: Audio tab = "What viewers hear" (status), "Commentary microphone", voice clean-up, "Background music", crowd sounds.

## Update: clearer scoreboard text + real sound effects (UNCOMPILED)
* Strips: new layout (bowler name on line 1, figures + last balls on line 2, wider batter names, bigger sizes), bottom line in the main
  text colour at 25 px; text() halo adapts to dark/light text, shrinks to 80% at most; dim white text colours brightened everywhere.
* Sounds: stream/SfxDecoder.kt decodes any audio file to 44.1 kHz stereo; SfxLibrary uses the operator's real recording for a pad
  when one is chosen (AudioMixSettings.sfxFiles) and falls back to the generated sound; up to 12 extra pads (extraSfx).
  The generated sounds stay as a fallback. No real recordings are bundled (none could be downloaded or licensed here).


## Update: crowd sounds REMOVED, cards beside the score strip, auto over cards, score-screen preview, crash log (UNCOMPILED)
* Removed completely (CrowdSynth, SfxPlayer/Library/Decoder, pads, atmosphere, real-recording import, settings, tests): the operator did
  not want them. Earlier "crowd" lines above are history only.
* Cards: BroadcastRenderer draws the card FIRST (fitted into the free area above/below the score strip, panelArea()), then the score
  strip on top, so the score stays visible. Entry: slide + pop + staggered rows (reveal/withReveal); exit animation via
  PanelInfo.exitAtMs (AppViewModel.hidePanel waits 400 ms). Full-screen cards keep a full-frame backdrop with sliding colour bands.
* Automatic graphic after each completed over (AutoShowSettings.overCards / overCardEvery, OverCardTracker, random kind, never the same
  twice, waits for a four/six/wicket animation, skipped when something else is on air).
* Score screen has a hideable live preview (ProgramPreview) under the status strip.
* Buttons grow instead of clipping text (heightIn + adaptive font in BigButton).
* Crash diagnostics: data/CrashLog (uncaught exceptions + handled engine-worker errors + Android exit reason on API 30+) shown in a dialog
  on the next start with a Copy button. Engine worker tasks run through exec{} so one failure no longer closes the app.
* Startup race fixed: properties declared after the init blocks (over-card state) were read by the IO coroutine that restores the match.

## Fix: score screen layout
* BatterRow: the figures ("118 (26) 4s 12 6s 10") were squeezed to one character per line; the name now takes the free space (ellipsis) and the figures stay on one line.
* Score screen: status strip + Hide/Show + live preview are PINNED at the top; only the part below scrolls (missing closing brace fixed).

## Master-prompt upgrade (5 phases) — STATUS: only Phase 1A core started (UNCOMPILED)
* Added report/MatchReport.kt (ReportBuilder: scorecard model from MatchSession.stateOf, CSV, JSON, printable HTML) + MatchReportTest.
* NOT done: PDF (needs android.graphics.pdf wiring), share/export UI, backup/restore, and Phases 2-5. No compiler/SDK/network in the sandbox.
* Partnership pairs are not recorded by the engine; the report shows runs between wickets only.
* Added data/Backup.kt (export/validate/plan/freshId; no secrets; corrupt entries skipped; duplicate plan for user confirmation), report/PdfExporter.kt (platform PdfDocument, Latin text only), data/BackupTest.kt.
* STILL TO WIRE: UI buttons (export/share via FileProvider, restore dialog using Backup.plan + confirmation, DuplicatePolicy apply in LocalStore), interrupted-save recovery check for .tmp files. Phases 2-5 not started.
* Added analytics/Analytics.kt (runs/over, cumulative, required rate per over, dot/boundary %, ball filters, innings comparison, runs between wickets; null = unavailable) + AnalyticsTest. MatchReport now uses Analytics.isBoundary. No UI yet (Phase 2A charts/dashboard, wagon wheel, graphics package, Phases 3-5 pending).
* Phase 3-5 LOGIC modules added (pure Kotlin, unit tests written, UNCOMPILED, NOT wired to UI/engine):
  commentary/SmartCommentary.kt (EN+UR editable templates, dedupe, pause/disable, frequency, priority), health/StreamHealth.kt (null = unavailable, suggestions only),
  highlights/Highlights.kt (markers + clip ranges; NO clip extraction, NO live replay), sponsors/SponsorRotator.kt (rotation, pause/stop, history, exposure),
  remote/RemoteGate.kt (pairing code with host approval, token, permissions, dedupe, sequence gaps; NO network transport).
* STILL MISSING: all UI screens/navigation; real metrics collection from StreamEngine/BatteryManager/StatFs; MediaMuxer clip export; WebSocket/HTTP server
  (needs a library such as Ktor/NanoHTTPD = new dependency) for remote scoring + OBS browser overlay; wagon wheel; graphics package using BroadcastRenderer;
  FileProvider sharing; restore dialog; Urdu font for PDF. Nothing has been compiled or run.

## Full wiring pass (UNCOMPILED) — see NEW_FEATURES.md
Added: hub/ExtrasHub.kt, remote/{LocalServer,WebPages,OverlayJson}.kt, analytics/WagonWheel.kt, report/ClipExporter.kt,
ui/ScreensExtras1.kt (More, Reports+Backup, Analytics+Wagon wheel, Graphics package), ui/ScreensExtras2.kt (Health, Highlights, Sponsors, Remote, OBS, Commentary),
AppViewModel hooks (addEventChecked, applyRemote, renderCard, backup/restore, hub.onBall/onPublished), StreamEngine.currentRecordingPath/listRecordings,
LocalStore.recoverInterruptedSaves, FileProvider, nav routes + Home tile.
NOT implemented: live replay, burned-in title cards, QR code, direct OBS WebSocket control, sponsor boundary/innings-break graphics, Urdu PDF font, innings transitions via remote.

## Static cross-check (no compiler available)
Every engine/UI/stream/graphics name used by the new code was grep-checked against the real definitions: BallEvent, WicketInfo, ExtraType, InningsState,
BallRecord, SavedMatch, LocalStore, StreamStatus, AutoShowSettings, PanelKind, BurstKind, AlertInfo, BurstInfo, MediaImporter, UI helpers and icons: all matched.
Still unverified: Kotlin type inference/smart casts, Compose imports, nullable handling, and every runtime behaviour. Expect a handful of compile errors on the first Gradle build.

## Camera fix + country flags (UNCOMPILED)
* CameraGlCompositor.computeRotation: sensorOrientation removed (SurfaceTexture transform already applies it). Evidence: user screenshots - Auto was 90 deg off on the front camera,
  while front +90 / back +270 (= minus the sensor angle) looked correct. Saved v1 offsets are reset once (Json "camRotV").
* flags/CountryFlags.kt (all ISO countries via platform names, English + Urdu, cricket codes, aliases, suffix rules) + flags/FlagBitmap.kt (flag emoji -> cropped bitmap).
  Team logo = uploaded logo, else flag when the team name is a country. Works in every template (existing logo slot), Graphics package PNGs and the OBS overlay (/logo/a, /logo/b).
* Limits: needs the phone's colour-emoji font (no flag drawn rather than two letters); Urdu names need the phone's ICU data; West Indies / Northern Ireland have no flag emoji.
