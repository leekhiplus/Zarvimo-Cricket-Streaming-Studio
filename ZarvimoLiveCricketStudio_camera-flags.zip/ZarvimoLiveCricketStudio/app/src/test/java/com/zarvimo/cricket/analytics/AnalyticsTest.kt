package com.zarvimo.cricket.analytics

import com.zarvimo.cricket.scoring.*
import org.junit.Assert.*
import org.junit.Test

class AnalyticsTest {
    private fun state(events: List<(Long) -> ScoreEvent>, overs: Int = 5): InningsState {
        val s = MatchSession(MatchSetup(teamA = "L", teamB = "T", oversLimit = overs))
        s.startInnings(InningsSetup("L", "T", "A1", "A2", "T1"))
        events.forEach { s.add(it) }
        return s.stateOf(0)!!
    }

    @Test fun overs_sumToTeamRuns_andDotsBoundariesCounted() {
        val ev = mutableListOf<(Long) -> ScoreEvent>()
        ev += { BallEvent(it, runsBat = 4, boundary = true) }
        repeat(2) { ev += { id -> BallEvent(id) } }
        ev += { BallEvent(it, runsBat = 6, boundary = true) }
        val st = state(ev)
        val o = Analytics.overs(st)
        assertEquals(st.runs, o.sumOf { it.runs })
        val s = Analytics.summarize(st.allBalls)
        assertEquals(4, s.legalBalls); assertEquals(2, s.dots); assertEquals(2, s.boundaries)
        assertEquals(50.0, s.dotPercent!!, 0.001)
    }

    @Test fun emptyInnings_hasNullPercentages() {
        val s = Analytics.summarize(emptyList())
        assertNull(s.dotPercent); assertNull(s.boundaryPercent)
    }

    @Test fun noBallBoundary_counts_runOutFourDoesNot() {
        val mk = { l: String -> BallRecord(1, 0, l, 4, false, false, "b", "s") }
        assertTrue(Analytics.isBoundary(mk("Nb+4"))); assertTrue(Analytics.isBoundary(mk("6")))
        assertFalse(Analytics.isBoundary(mk("4W"))); assertFalse(Analytics.isBoundary(mk("Wd+4")))
    }

    @Test fun filter_byBowler() {
        val st = state(listOf({ BallEvent(it, runsBat = 1) }, { BallEvent(it, runsBat = 2) }))
        assertEquals(3, Analytics.summarize(st.allBalls, BallFilter(bowler = "T1")).runs)
        assertEquals(0, Analytics.summarize(st.allBalls, BallFilter(bowler = "nobody")).runs)
    }
}
